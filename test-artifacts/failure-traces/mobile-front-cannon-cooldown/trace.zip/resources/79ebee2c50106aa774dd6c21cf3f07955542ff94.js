import { G as Texture, H as warn, J as TextureSource, K as TextureMatrix, N as DOMAdapter, R as BigPool, U as Color, V as GlobalResourceRegistry, W as Bounds, _t as ExtensionType, ct as uid$1, d as BindGroup, dt as Matrix, f as UniformGroup, ft as Point, g as GpuProgram, gt as eventemitter3_default, it as v8_21_0, lt as Rectangle, nt as deprecation, rt as v8_0_0, t as CanvasPool, u as RendererType, vt as extensions, w as GlProgram } from "/node_modules/.vite/deps/CanvasPool-BcIVNj8Y.js?v=7ab6e4ce";
import { D as multiplyColors, L as FilterEffect, O as getGlobalBounds, _ as TexturePool, c as Sprite, g as RenderGroup, i as Ticker, r as State, s as CanvasSource, t as Filter, u as Container, w as getLocalBounds } from "/node_modules/.vite/deps/Filter-BpcfXGWT.js?v=7ab6e4ce";
import { F as STENCIL_MODES, n as DefaultBatcher } from "/node_modules/.vite/deps/GCManagedHash-BlELPMdI.js?v=7ab6e4ce";
//#region node_modules/pixi.js/lib/environment/autoDetectEnvironment.mjs
var environments = [];
extensions.handleByNamedList(ExtensionType.Environment, environments);
async function loadEnvironmentExtensions(skip) {
	if (skip) return;
	for (let i = 0; i < environments.length; i++) {
		const env = environments[i];
		if (env.value.test()) {
			await env.value.load();
			return;
		}
	}
}
async function autoDetectEnvironment(add) {
	return loadEnvironmentExtensions(!add);
}
//#endregion
//#region node_modules/pixi.js/lib/utils/browser/unsafeEvalSupported.mjs
var unsafeEval;
function unsafeEvalSupported() {
	if (typeof unsafeEval === "boolean") return unsafeEval;
	try {
		unsafeEval = new Function("param1", "param2", "param3", "return param1[param2] === param3;")({ a: "b" }, "a", "b") === true;
	} catch (_e) {
		unsafeEval = false;
	}
	return unsafeEval;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gl/const.mjs
var CLEAR = /* @__PURE__ */ ((CLEAR2) => {
	CLEAR2[CLEAR2["NONE"] = 0] = "NONE";
	CLEAR2[CLEAR2["COLOR"] = 16384] = "COLOR";
	CLEAR2[CLEAR2["STENCIL"] = 1024] = "STENCIL";
	CLEAR2[CLEAR2["DEPTH"] = 256] = "DEPTH";
	CLEAR2[CLEAR2["COLOR_DEPTH"] = 16640] = "COLOR_DEPTH";
	CLEAR2[CLEAR2["COLOR_STENCIL"] = 17408] = "COLOR_STENCIL";
	CLEAR2[CLEAR2["DEPTH_STENCIL"] = 1280] = "DEPTH_STENCIL";
	CLEAR2[CLEAR2["ALL"] = 17664] = "ALL";
	return CLEAR2;
})(CLEAR || {});
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/system/SystemRunner.mjs
var SystemRunner = class {
	/**
	* @param name - The function name that will be executed on the listeners added to this Runner.
	*/
	constructor(name) {
		this.items = [];
		this._name = name;
	}
	/**
	* Dispatch/Broadcast Runner to all listeners added to the queue.
	* @param {...any} params - (optional) parameters to pass to each listener
	*/
	emit(a0, a1, a2, a3, a4, a5, a6, a7) {
		const { name, items } = this;
		for (let i = 0, len = items.length; i < len; i++) items[i][name](a0, a1, a2, a3, a4, a5, a6, a7);
		return this;
	}
	/**
	* Add a listener to the Runner
	*
	* Runners do not need to have scope or functions passed to them.
	* All that is required is to pass the listening object and ensure that it has contains a function that has the same name
	* as the name provided to the Runner when it was created.
	*
	* Eg A listener passed to this Runner will require a 'complete' function.
	*
	* ```ts
	* import { Runner } from 'pixi.js';
	*
	* const complete = new Runner('complete');
	* ```
	*
	* The scope used will be the object itself.
	* @param {any} item - The object that will be listening.
	*/
	add(item) {
		if (item[this._name]) {
			this.remove(item);
			this.items.push(item);
		}
		return this;
	}
	/**
	* Remove a single listener from the dispatch queue.
	* @param {any} item - The listener that you would like to remove.
	*/
	remove(item) {
		const index = this.items.indexOf(item);
		if (index !== -1) this.items.splice(index, 1);
		return this;
	}
	/**
	* Check to see if the listener is already in the Runner
	* @param {any} item - The listener that you would like to check.
	*/
	contains(item) {
		return this.items.indexOf(item) !== -1;
	}
	/** Remove all listeners from the Runner */
	removeAll() {
		this.items.length = 0;
		return this;
	}
	/** Remove all references, don't use after this. */
	destroy() {
		this.removeAll();
		this.items = null;
		this._name = null;
	}
	/**
	* `true` if there are no this Runner contains no listeners
	* @readonly
	*/
	get empty() {
		return this.items.length === 0;
	}
	/**
	* The name of the runner.
	* @readonly
	*/
	get name() {
		return this._name;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/system/AbstractRenderer.mjs
var defaultRunners = [
	"init",
	"destroy",
	"contextChange",
	"resolutionChange",
	"resetState",
	"renderEnd",
	"renderStart",
	"render",
	"update",
	"postrender",
	"prerender"
];
var _AbstractRenderer = class _AbstractRenderer extends eventemitter3_default {
	/**
	* Set up a system with a collection of SystemClasses and runners.
	* Systems are attached dynamically to this class when added.
	* @param config - the config for the system manager
	*/
	constructor(config) {
		super();
		/** The current tick of the renderer. */
		this.tick = 0;
		/** @internal */
		this.uid = uid$1("renderer");
		/** @internal */
		this.runners = /* @__PURE__ */ Object.create(null);
		/** @internal */
		this.renderPipes = /* @__PURE__ */ Object.create(null);
		this._initOptions = {};
		this._systemsHash = /* @__PURE__ */ Object.create(null);
		this.type = config.type;
		this.name = config.name;
		this.config = config;
		const combinedRunners = [...defaultRunners, ...this.config.runners ?? []];
		this._addRunners(...combinedRunners);
		this._unsafeEvalCheck();
	}
	/**
	* Initialize the renderer.
	* @param options - The options to use to create the renderer.
	*/
	async init(options = {}) {
		const skip = options.skipExtensionImports === true ? true : options.manageImports === false;
		await loadEnvironmentExtensions(skip);
		if (!skip && this.config.loaders) await Promise.all(this.config.loaders.map((loader) => loader.value.load()));
		this._addSystems(this.config.systems);
		this._addPipes(this.config.renderPipes, this.config.renderPipeAdaptors);
		for (const systemName in this._systemsHash) options = {
			...this._systemsHash[systemName].constructor.defaultOptions,
			...options
		};
		options = {
			..._AbstractRenderer.defaultOptions,
			...options
		};
		this._roundPixels = options.roundPixels ? 1 : 0;
		for (let i = 0; i < this.runners.init.items.length; i++) await this.runners.init.items[i].init(options);
		this._initOptions = options;
	}
	render(args, deprecated) {
		this.tick++;
		let options = args;
		if (options instanceof Container) {
			options = { container: options };
			if (deprecated) {
				deprecation(v8_0_0, "passing a second argument is deprecated, please use render options instead");
				options.target = deprecated.renderTexture;
			}
		}
		options.target || (options.target = this.view.renderTarget);
		if (options.target === this.view.renderTarget) {
			this._lastObjectRendered = options.container;
			options.clearColor ?? (options.clearColor = this.background.colorRgba);
			options.clear ?? (options.clear = this.background.clearBeforeRender);
		}
		if (options.clearColor) {
			const isRGBAArray = Array.isArray(options.clearColor) && options.clearColor.length === 4;
			options.clearColor = isRGBAArray ? options.clearColor : Color.shared.setValue(options.clearColor).toArray();
		}
		if (!options.transform) {
			options.container.updateLocalTransform();
			options.transform = options.container.localTransform;
		}
		if (!options.container.visible) return;
		options.container.enableRenderGroup();
		this.runners.prerender.emit(options);
		this.runners.renderStart.emit(options);
		this.runners.render.emit(options);
		this.runners.renderEnd.emit(options);
		this.runners.postrender.emit(options);
	}
	/**
	* Resizes the WebGL view to the specified width and height.
	* @param desiredScreenWidth - The desired width of the screen.
	* @param desiredScreenHeight - The desired height of the screen.
	* @param resolution - The resolution / device pixel ratio of the renderer.
	*/
	resize(desiredScreenWidth, desiredScreenHeight, resolution) {
		const previousResolution = this.view.resolution;
		this.view.resize(desiredScreenWidth, desiredScreenHeight, resolution);
		this.emit("resize", this.view.screen.width, this.view.screen.height, this.view.resolution);
		if (resolution !== void 0 && resolution !== previousResolution) this.runners.resolutionChange.emit(resolution);
	}
	/**
	* Clears the render target.
	* @param options - The options to use when clearing the render target.
	* @param options.target - The render target to clear.
	* @param options.clearColor - The color to clear with.
	* @param options.clear - The clear mode to use.
	* @advanced
	*/
	clear(options = {}) {
		const renderer = this;
		options.target || (options.target = renderer.renderTarget.renderTarget);
		options.clearColor || (options.clearColor = this.background.colorRgba);
		options.clear ?? (options.clear = CLEAR.ALL);
		const { clear, clearColor, target, mipLevel, layer } = options;
		Color.shared.setValue(clearColor ?? this.background.colorRgba);
		renderer.renderTarget.clear(target, clear, Color.shared.toArray(), mipLevel ?? 0, layer ?? 0);
	}
	/** The resolution / device pixel ratio of the renderer. */
	get resolution() {
		return this.view.resolution;
	}
	set resolution(value) {
		this.view.resolution = value;
		this.runners.resolutionChange.emit(value);
	}
	/**
	* Same as view.width, actual number of pixels in the canvas by horizontal.
	* @type {number}
	* @readonly
	* @default 800
	*/
	get width() {
		return this.view.texture.frame.width;
	}
	/**
	* Same as view.height, actual number of pixels in the canvas by vertical.
	* @default 600
	*/
	get height() {
		return this.view.texture.frame.height;
	}
	/**
	* The canvas element that everything is drawn to.
	* @type {environment.ICanvas}
	*/
	get canvas() {
		return this.view.canvas;
	}
	/**
	* the last object rendered by the renderer. Useful for other plugins like interaction managers
	* @readonly
	*/
	get lastObjectRendered() {
		return this._lastObjectRendered;
	}
	/**
	* Flag if we are rendering to the screen vs renderTexture
	* @readonly
	* @default true
	*/
	get renderingToScreen() {
		return this.renderTarget.renderingToScreen;
	}
	/**
	* Measurements of the screen. (0, 0, screenWidth, screenHeight).
	*
	* Its safe to use as filterArea or hitArea for the whole stage.
	*/
	get screen() {
		return this.view.screen;
	}
	/**
	* Create a bunch of runners based of a collection of ids
	* @param runnerIds - the runner ids to add
	*/
	_addRunners(...runnerIds) {
		runnerIds.forEach((runnerId) => {
			this.runners[runnerId] = new SystemRunner(runnerId);
		});
	}
	_addSystems(systems) {
		let i;
		for (i in systems) {
			const val = systems[i];
			this._addSystem(val.value, val.name);
		}
	}
	/**
	* Add a new system to the renderer.
	* @param ClassRef - Class reference
	* @param name - Property name for system, if not specified
	*        will use a static `name` property on the class itself. This
	*        name will be assigned as s property on the Renderer so make
	*        sure it doesn't collide with properties on Renderer.
	* @returns Return instance of renderer
	*/
	_addSystem(ClassRef, name) {
		const system = new ClassRef(this);
		if (this[name]) throw new Error(`Whoops! The name "${name}" is already in use`);
		this[name] = system;
		this._systemsHash[name] = system;
		for (const i in this.runners) this.runners[i].add(system);
		return this;
	}
	_addPipes(pipes, pipeAdaptors) {
		const adaptors = pipeAdaptors.reduce((acc, adaptor) => {
			acc[adaptor.name] = adaptor.value;
			return acc;
		}, {});
		pipes.forEach((pipe) => {
			const PipeClass = pipe.value;
			const name = pipe.name;
			const Adaptor = adaptors[name];
			this.renderPipes[name] = new PipeClass(this, Adaptor ? new Adaptor() : null);
			this.runners.destroy.add(this.renderPipes[name]);
		});
	}
	destroy(options = false) {
		this.runners.destroy.items.reverse();
		this.runners.destroy.emit(options);
		if (options === true || typeof options === "object" && options.releaseGlobalResources) GlobalResourceRegistry.release();
		Object.values(this.runners).forEach((runner) => {
			runner.destroy();
		});
		this._systemsHash = null;
		this.renderPipes = null;
		this.removeAllListeners();
	}
	/**
	* Generate a texture from a container.
	* @param options - options or container target to use when generating the texture
	* @returns a texture
	*/
	generateTexture(options) {
		return this.textureGenerator.generateTexture(options);
	}
	/**
	* Whether the renderer will round coordinates to whole pixels when rendering.
	* Can be overridden on a per scene item basis.
	*/
	get roundPixels() {
		return !!this._roundPixels;
	}
	/**
	* Overridable function by `pixi.js/unsafe-eval` to silence
	* throwing an error if platform doesn't support unsafe-evals.
	* @private
	* @ignore
	*/
	_unsafeEvalCheck() {
		if (!unsafeEvalSupported()) throw new Error("Current environment does not allow unsafe-eval, please use pixi.js/unsafe-eval module to enable support.");
	}
	/**
	* Resets the rendering state of the renderer.
	* This is useful when you want to use the WebGL context directly and need to ensure PixiJS's internal state
	* stays synchronized. When modifying the WebGL context state externally, calling this method before the next Pixi
	* render will reset all internal caches and ensure it executes correctly.
	*
	* This is particularly useful when combining PixiJS with other rendering engines like Three.js:
	* ```js
	* // Reset Three.js state
	* threeRenderer.resetState();
	*
	* // Render a Three.js scene
	* threeRenderer.render(threeScene, threeCamera);
	*
	* // Reset PixiJS state since Three.js modified the WebGL context
	* pixiRenderer.resetState();
	*
	* // Now render Pixi content
	* pixiRenderer.render(pixiScene);
	* ```
	* @advanced
	*/
	resetState() {
		this.runners.resetState.emit();
	}
};
/** The default options for the renderer. */
_AbstractRenderer.defaultOptions = {
	/**
	* Default resolution / device pixel ratio of the renderer.
	* @default 1
	*/
	resolution: 1,
	/**
	* Should the `failIfMajorPerformanceCaveat` flag be enabled as a context option used in the `isWebGLSupported`
	* function. If set to true, a WebGL renderer can fail to be created if the browser thinks there could be
	* performance issues when using WebGL.
	*
	* In PixiJS v6 this has changed from true to false by default, to allow WebGL to work in as many
	* scenarios as possible. However, some users may have a poor experience, for example, if a user has a gpu or
	* driver version blacklisted by the
	* browser.
	*
	* If your application requires high performance rendering, you may wish to set this to false.
	* We recommend one of two options if you decide to set this flag to false:
	*
	* 1: Use the Canvas renderer as a fallback in case high performance WebGL is
	*    not supported.
	*
	* 2: Call `isWebGLSupported` (which if found in the utils package) in your code before attempting to create a
	*    PixiJS renderer, and show an error message to the user if the function returns false, explaining that their
	*    device & browser combination does not support high performance WebGL.
	*    This is a much better strategy than trying to create a PixiJS renderer and finding it then fails.
	* @default false
	*/
	failIfMajorPerformanceCaveat: false,
	/**
	* Should round pixels be forced when rendering?
	* @default false
	*/
	roundPixels: false
};
var AbstractRenderer = _AbstractRenderer;
//#endregion
//#region node_modules/pixi.js/lib/utils/const.mjs
var DATA_URI = /^\s*data:(?:([\w-]+)\/([\w+.-]+))?(?:;charset=([\w-]+))?(?:;(base64))?,(.*)/i;
var VERSION = "8.22.0";
//#endregion
//#region node_modules/pixi.js/lib/utils/global/globalHooks.mjs
var ApplicationInitHook = class {
	static init() {
		globalThis.__PIXI_APP_INIT__?.(this, VERSION);
	}
	static destroy() {}
};
/** @ignore */
ApplicationInitHook.extension = ExtensionType.Application;
var RendererInitHook = class {
	constructor(renderer) {
		this._renderer = renderer;
	}
	init() {
		globalThis.__PIXI_RENDERER_INIT__?.(this._renderer, VERSION);
	}
	destroy() {
		this._renderer = null;
	}
};
/** @ignore */
RendererInitHook.extension = {
	type: [ExtensionType.WebGLSystem, ExtensionType.WebGPUSystem],
	name: "initHook",
	priority: -10
};
//#endregion
//#region node_modules/pixi.js/lib/filters/mask/mask.frag.mjs
var fragment = "in vec2 vMaskCoord;\nin vec2 vTextureCoord;\n\nuniform sampler2D uTexture;\nuniform sampler2D uMaskTexture;\n\nuniform float uAlpha;\nuniform vec4 uMaskClamp;\nuniform float uInverse;\nuniform float uChannel;\n\nout vec4 finalColor;\n\nvoid main(void)\n{\n    float clip = step(3.5,\n        step(uMaskClamp.x, vMaskCoord.x) +\n        step(uMaskClamp.y, vMaskCoord.y) +\n        step(vMaskCoord.x, uMaskClamp.z) +\n        step(vMaskCoord.y, uMaskClamp.w));\n\n    // TODO look into why this is needed\n    float npmAlpha = uAlpha;\n    vec4 original = texture(uTexture, vTextureCoord);\n    vec4 masky = texture(uMaskTexture, vMaskCoord);\n\n    float a;\n    if (uChannel == 1.0) {\n        a = masky.a * npmAlpha * clip;\n    } else {\n        float alphaMul = 1.0 - npmAlpha * (1.0 - masky.a);\n        a = alphaMul * masky.r * npmAlpha * clip;\n    }\n\n    if (uInverse == 1.0) {\n        a = 1.0 - a;\n    }\n\n    finalColor = original * a;\n}\n";
//#endregion
//#region node_modules/pixi.js/lib/filters/mask/mask.vert.mjs
var vertex = "in vec2 aPosition;\n\nout vec2 vTextureCoord;\nout vec2 vMaskCoord;\n\n\nuniform vec4 uInputSize;\nuniform vec4 uOutputFrame;\nuniform vec4 uOutputTexture;\nuniform mat3 uFilterMatrix;\n\nvec4 filterVertexPosition(  vec2 aPosition )\n{\n    vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;\n       \n    position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord(  vec2 aPosition )\n{\n    return aPosition * (uOutputFrame.zw * uInputSize.zw);\n}\n\nvec2 getFilterCoord( vec2 aPosition )\n{\n    return  ( uFilterMatrix * vec3( filterTextureCoord(aPosition), 1.0)  ).xy;\n}   \n\nvoid main(void)\n{\n    gl_Position = filterVertexPosition(aPosition);\n    vTextureCoord = filterTextureCoord(aPosition);\n    vMaskCoord = getFilterCoord(aPosition);\n}\n";
//#endregion
//#region node_modules/pixi.js/lib/filters/mask/mask.wgsl.mjs
var source = "struct GlobalFilterUniforms {\n  uInputSize:vec4<f32>,\n  uInputPixel:vec4<f32>,\n  uInputClamp:vec4<f32>,\n  uOutputFrame:vec4<f32>,\n  uGlobalFrame:vec4<f32>,\n  uOutputTexture:vec4<f32>,\n};\n\nstruct MaskUniforms {\n  uFilterMatrix:mat3x3<f32>,\n  uMaskClamp:vec4<f32>,\n  uAlpha:f32,\n  uInverse:f32,\n  uChannel:f32,\n};\n\n@group(0) @binding(0) var<uniform> gfu: GlobalFilterUniforms;\n@group(0) @binding(1) var uTexture: texture_2d<f32>;\n@group(0) @binding(2) var uSampler : sampler;\n\n@group(1) @binding(0) var<uniform> filterUniforms : MaskUniforms;\n@group(1) @binding(1) var uMaskTexture: texture_2d<f32>;\n\nstruct VSOutput {\n    @builtin(position) position: vec4<f32>,\n    @location(0) uv : vec2<f32>,\n    @location(1) filterUv : vec2<f32>,\n};\n\nfn filterVertexPosition(aPosition:vec2<f32>) -> vec4<f32>\n{\n    var position = aPosition * gfu.uOutputFrame.zw + gfu.uOutputFrame.xy;\n\n    position.x = position.x * (2.0 / gfu.uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*gfu.uOutputTexture.z / gfu.uOutputTexture.y) - gfu.uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nfn filterTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n    return aPosition * (gfu.uOutputFrame.zw * gfu.uInputSize.zw);\n}\n\nfn globalTextureCoord( aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return  (aPosition.xy / gfu.uGlobalFrame.zw) + (gfu.uGlobalFrame.xy / gfu.uGlobalFrame.zw);\n}\n\nfn getFilterCoord(aPosition:vec2<f32> ) -> vec2<f32>\n{\n  return ( filterUniforms.uFilterMatrix * vec3( filterTextureCoord(aPosition), 1.0)  ).xy;\n}\n\nfn getSize() -> vec2<f32>\n{\n  return gfu.uGlobalFrame.zw;\n}\n\n@vertex\nfn mainVertex(\n  @location(0) aPosition : vec2<f32>,\n) -> VSOutput {\n  return VSOutput(\n   filterVertexPosition(aPosition),\n   filterTextureCoord(aPosition),\n   getFilterCoord(aPosition)\n  );\n}\n\n@fragment\nfn mainFragment(\n  @location(0) uv: vec2<f32>,\n  @location(1) filterUv: vec2<f32>,\n  @builtin(position) position: vec4<f32>\n) -> @location(0) vec4<f32> {\n\n    var maskClamp = filterUniforms.uMaskClamp;\n    var uAlpha = filterUniforms.uAlpha;\n\n    var clip = step(3.5,\n      step(maskClamp.x, filterUv.x) +\n      step(maskClamp.y, filterUv.y) +\n      step(filterUv.x, maskClamp.z) +\n      step(filterUv.y, maskClamp.w));\n\n    var mask = textureSample(uMaskTexture, uSampler, filterUv);\n    var source = textureSample(uTexture, uSampler, uv);\n\n    var a: f32;\n    if (filterUniforms.uChannel == 1.0) {\n        a = mask.a * uAlpha * clip;\n    } else {\n        var alphaMul = 1.0 - uAlpha * (1.0 - mask.a);\n        a = alphaMul * mask.r * uAlpha * clip;\n    }\n\n    if (filterUniforms.uInverse == 1.0) {\n        a = 1.0 - a;\n    }\n\n    return source * a;\n}\n";
//#endregion
//#region node_modules/pixi.js/lib/filters/mask/MaskFilter.mjs
var MaskFilter = class extends Filter {
	constructor(options) {
		const { sprite, ...rest } = options;
		const textureMatrix = new TextureMatrix(sprite.texture);
		const filterUniforms = new UniformGroup({
			uFilterMatrix: {
				value: new Matrix(),
				type: "mat3x3<f32>"
			},
			uMaskClamp: {
				value: textureMatrix.uClampFrame,
				type: "vec4<f32>"
			},
			uAlpha: {
				value: 1,
				type: "f32"
			},
			uInverse: {
				value: options.inverse ? 1 : 0,
				type: "f32"
			},
			uChannel: {
				value: options.channel === "alpha" ? 1 : 0,
				type: "f32"
			}
		});
		const gpuProgram = GpuProgram.from({
			vertex: {
				source,
				entryPoint: "mainVertex"
			},
			fragment: {
				source,
				entryPoint: "mainFragment"
			}
		});
		const glProgram = GlProgram.from({
			vertex,
			fragment,
			name: "mask-filter"
		});
		super({
			...rest,
			gpuProgram,
			glProgram,
			clipToViewport: false,
			resources: {
				filterUniforms,
				uMaskTexture: sprite.texture.source
			}
		});
		this.sprite = sprite;
		this._textureMatrix = textureMatrix;
	}
	/**
	* Rebinds the filter to a new mask sprite, moving the texture-matrix `update`
	* listener and the bind group's `change` subscription over to the new sprite's
	* texture. `apply` refreshes the same bindings on every use — this method exists
	* to release the previous sprite's texture immediately, without waiting for
	* (or requiring) another `apply`.
	* @param sprite - the sprite to mask with from now on.
	*/
	setSprite(sprite) {
		this.sprite = sprite;
		const texture = this._getSafeTexture();
		this._textureMatrix.texture = texture;
		this.resources.uMaskTexture = texture.source;
	}
	set inverse(value) {
		this.resources.filterUniforms.uniforms.uInverse = value ? 1 : 0;
	}
	get inverse() {
		return this.resources.filterUniforms.uniforms.uInverse === 1;
	}
	set channel(value) {
		this.resources.filterUniforms.uniforms.uChannel = value === "alpha" ? 1 : 0;
	}
	get channel() {
		return this.resources.filterUniforms.uniforms.uChannel === 1 ? "alpha" : "red";
	}
	apply(filterManager, input, output, clearMode) {
		const texture = this._getSafeTexture();
		this._textureMatrix.texture = texture;
		filterManager.calculateSpriteMatrix(this.resources.filterUniforms.uniforms.uFilterMatrix, this.sprite).prepend(this._textureMatrix.mapCoord);
		this.resources.uMaskTexture = texture.source;
		filterManager.applyFilter(this, input, output, clearMode);
	}
	/**
	* The sprite's texture, or `Texture.EMPTY` when that texture has been destroyed —
	* a destroyed texture has no source left to sample, so the mask degrades to empty
	* rather than crashing the render.
	*/
	_getSafeTexture() {
		const texture = this.sprite.texture;
		if (texture.destroyed || !texture.source || texture.source.destroyed) {
			warn("[MaskFilter] The mask texture was destroyed while the mask is still in use. Remove the mask before destroying its texture.");
			return Texture.EMPTY;
		}
		return texture;
	}
	destroy(destroyPrograms = false) {
		this._textureMatrix.destroy();
		super.destroy(destroyPrograms);
	}
};
//#endregion
//#region node_modules/pixi.js/lib/scene/graphics/gpu/colorToUniform.mjs
function colorToUniform(rgb, alpha, out, offset) {
	out[offset++] = (rgb >> 16 & 255) / 255;
	out[offset++] = (rgb >> 8 & 255) / 255;
	out[offset++] = (rgb & 255) / 255;
	out[offset++] = alpha;
}
function color32BitToUniform(abgr, out, offset) {
	const alpha = (abgr >> 24 & 255) / 255;
	out[offset++] = (abgr & 255) / 255 * alpha;
	out[offset++] = (abgr >> 8 & 255) / 255 * alpha;
	out[offset++] = (abgr >> 16 & 255) / 255 * alpha;
	out[offset++] = alpha;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite/BatchableSprite.mjs
var BatchableSprite = class {
	constructor() {
		this.batcherName = "default";
		this.topology = "triangle-list";
		this.attributeSize = 4;
		this.indexSize = 6;
		this.packAsQuad = true;
		this.roundPixels = 0;
		this._attributeStart = 0;
		this._batcher = null;
		this._batch = null;
	}
	get blendMode() {
		return this.renderable.groupBlendMode;
	}
	get color() {
		return this.renderable.groupColorAlpha;
	}
	reset() {
		this.renderable = null;
		this.texture = null;
		this._batcher = null;
		this._batch = null;
		this.bounds = null;
	}
	destroy() {
		this.reset();
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/batcher/shared/BatcherPipe.mjs
var _BatcherPipe = class _BatcherPipe {
	constructor(renderer, adaptor) {
		this.state = State.for2d();
		this._batchersByInstructionSet = /* @__PURE__ */ Object.create(null);
		/** A record of all active batchers, keyed by their names */
		this._activeBatches = /* @__PURE__ */ Object.create(null);
		this.renderer = renderer;
		this._adaptor = adaptor;
		this._adaptor.init?.(this);
	}
	static getBatcher(name, maxTextures) {
		return new this._availableBatchers[name]({ maxTextures });
	}
	buildStart(instructionSet) {
		let batchers = this._batchersByInstructionSet[instructionSet.uid];
		if (!batchers) {
			batchers = this._batchersByInstructionSet[instructionSet.uid] = /* @__PURE__ */ Object.create(null);
			batchers.default || (batchers.default = new DefaultBatcher({ maxTextures: this.renderer.limits.maxBatchableTextures }));
		}
		this._activeBatches = batchers;
		this._activeBatch = this._activeBatches.default;
		for (const i in this._activeBatches) this._activeBatches[i].begin();
	}
	addToBatch(batchableObject, instructionSet) {
		if (this._activeBatch.name !== batchableObject.batcherName) {
			this._activeBatch.break(instructionSet);
			let batch = this._activeBatches[batchableObject.batcherName];
			if (!batch) {
				batch = this._activeBatches[batchableObject.batcherName] = _BatcherPipe.getBatcher(batchableObject.batcherName, this.renderer.limits.maxBatchableTextures);
				batch.begin();
			}
			this._activeBatch = batch;
		}
		this._activeBatch.add(batchableObject);
	}
	break(instructionSet) {
		this._activeBatch.break(instructionSet);
	}
	buildEnd(instructionSet) {
		this._activeBatch.break(instructionSet);
		const batches = this._activeBatches;
		for (const i in batches) {
			const batch = batches[i];
			const geometry = batch.geometry;
			geometry.indexBuffer.setDataWithSize(batch.indexBuffer, batch.indexSize, true);
			geometry.buffers[0].setDataWithSize(batch.attributeBuffer.float32View, batch.attributeSize, false);
		}
	}
	upload(instructionSet) {
		const batchers = this._batchersByInstructionSet[instructionSet.uid];
		for (const i in batchers) {
			const batcher = batchers[i];
			const geometry = batcher.geometry;
			if (batcher.dirty) {
				batcher.dirty = false;
				geometry.buffers[0].update(batcher.attributeSize * 4);
			}
		}
	}
	execute(batch) {
		if (batch.action === "startBatch") {
			const batcher = batch.batcher;
			const geometry = batcher.geometry;
			const shader = batcher.shader;
			this._adaptor.start(this, geometry, shader);
		}
		this._adaptor.execute(this, batch);
	}
	/**
	* Releases all batchers cached for the given InstructionSet. Called from
	* `InstructionSet.destroy()` so that batchers (and their GPU geometry / attribute
	* buffers / referenced textures) do not leak when the owning RenderGroup is destroyed.
	* @param instructionSet - the instruction set being destroyed
	*/
	destroyInstructionSet(instructionSet) {
		const batchers = this._batchersByInstructionSet[instructionSet.uid];
		if (!batchers) return;
		for (const i in batchers) batchers[i].destroy();
		delete this._batchersByInstructionSet[instructionSet.uid];
		if (this._activeBatches === batchers) {
			this._activeBatches = /* @__PURE__ */ Object.create(null);
			this._activeBatch = null;
		}
	}
	destroy() {
		this.state = null;
		this.renderer = null;
		this._adaptor = null;
		for (const i in this._activeBatches) this._activeBatches[i].destroy();
		this._activeBatches = null;
	}
};
/** @ignore */
_BatcherPipe.extension = {
	type: [
		ExtensionType.WebGLPipes,
		ExtensionType.WebGPUPipes,
		ExtensionType.CanvasPipes
	],
	name: "batch"
};
_BatcherPipe._availableBatchers = /* @__PURE__ */ Object.create(null);
var BatcherPipe = _BatcherPipe;
extensions.handleByMap(ExtensionType.Batcher, BatcherPipe._availableBatchers);
extensions.add(DefaultBatcher);
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/alpha/AlphaMaskPipe.mjs
var tempBounds$1 = new Bounds();
var AlphaMaskEffect = class extends FilterEffect {
	constructor() {
		super();
		/** the sprite the pooled filter is parked on between uses */
		this._placeholderSprite = new Sprite(Texture.EMPTY);
		this.filters = [new MaskFilter({
			sprite: this._placeholderSprite,
			inverse: false,
			resolution: "inherit",
			antialias: "inherit"
		})];
	}
	get sprite() {
		return this.filters[0].sprite;
	}
	set sprite(value) {
		this.filters[0].setSprite(value);
	}
	get inverse() {
		return this.filters[0].inverse;
	}
	set inverse(value) {
		this.filters[0].inverse = value;
	}
	get channel() {
		return this.filters[0].channel;
	}
	set channel(value) {
		this.filters[0].channel = value;
	}
	/**
	* Called by {@link BigPool} when the pipe returns the effect: parks the filter
	* on the empty placeholder so a pooled effect keeps no bindings to the last
	* mask it applied. Without this, the pooled filter pins the mask sprite and
	* its texture for as long as the effect sits in the pool, and destroying that
	* texture's source hits a bind group subscription the user cannot release.
	*/
	reset() {
		this._placeholderSprite.texture = Texture.EMPTY;
		this.sprite = this._placeholderSprite;
	}
};
var AlphaMaskPipe = class {
	constructor(renderer) {
		this._activeMaskStage = [];
		this._usedEffects = [];
		this._renderer = renderer;
		renderer.runners.postrender.add(this);
	}
	push(mask, maskedContainer, instructionSet) {
		const renderer = this._renderer;
		renderer.renderPipes.batch.break(instructionSet);
		instructionSet.add({
			renderPipeId: "alphaMask",
			action: "pushMaskBegin",
			mask,
			inverse: maskedContainer._maskOptions.inverse,
			canBundle: false,
			maskedContainer
		});
		mask.inverse = maskedContainer._maskOptions.inverse;
		mask.channel = maskedContainer._maskOptions.channel ?? "red";
		if (mask.renderMaskToTexture) {
			const maskContainer = mask.mask;
			maskContainer.includeInBuild = true;
			maskContainer.collectRenderables(instructionSet, renderer, null);
			maskContainer.includeInBuild = false;
		}
		renderer.renderPipes.batch.break(instructionSet);
		instructionSet.add({
			renderPipeId: "alphaMask",
			action: "pushMaskEnd",
			mask,
			maskedContainer,
			inverse: maskedContainer._maskOptions.inverse,
			canBundle: false
		});
	}
	pop(mask, _maskedContainer, instructionSet) {
		this._renderer.renderPipes.batch.break(instructionSet);
		instructionSet.add({
			renderPipeId: "alphaMask",
			action: "popMaskEnd",
			mask,
			inverse: _maskedContainer._maskOptions.inverse,
			canBundle: false
		});
	}
	execute(instruction) {
		const renderer = this._renderer;
		const renderMask = instruction.mask.renderMaskToTexture;
		if (instruction.action === "pushMaskBegin") {
			const filterEffect = BigPool.get(AlphaMaskEffect);
			filterEffect.inverse = instruction.inverse;
			filterEffect.channel = instruction.mask.channel;
			if (renderMask) {
				instruction.mask.mask.measurable = true;
				const bounds = getGlobalBounds(instruction.mask.mask, true, tempBounds$1);
				instruction.mask.mask.measurable = false;
				bounds.ceil();
				const colorTextureSource = renderer.renderTarget.renderTarget.colorTexture.source;
				const filterTexture = TexturePool.getOptimalTexture({
					width: bounds.width,
					height: bounds.height,
					resolution: colorTextureSource._resolution,
					antialias: colorTextureSource.antialias
				});
				renderer.renderTarget.push({
					target: filterTexture,
					clear: true
				});
				renderer.globalUniforms.push({
					offset: bounds,
					worldColor: 4294967295
				});
				const sprite = filterEffect.sprite;
				sprite.texture = filterTexture;
				sprite.worldTransform.tx = bounds.minX;
				sprite.worldTransform.ty = bounds.minY;
				this._activeMaskStage.push({
					filterEffect,
					maskedContainer: instruction.maskedContainer,
					filterTexture
				});
			} else {
				filterEffect.sprite = instruction.mask.mask;
				this._activeMaskStage.push({
					filterEffect,
					maskedContainer: instruction.maskedContainer
				});
			}
		} else if (instruction.action === "pushMaskEnd") {
			const maskData = this._activeMaskStage[this._activeMaskStage.length - 1];
			if (renderMask) {
				if (renderer.type === RendererType.WEBGL) renderer.renderTarget.finishRenderPass();
				renderer.renderTarget.pop();
				renderer.globalUniforms.pop();
			}
			renderer.filter.push({
				renderPipeId: "filter",
				action: "pushFilter",
				container: maskData.maskedContainer,
				filterEffect: maskData.filterEffect,
				canBundle: false
			});
		} else if (instruction.action === "popMaskEnd") {
			renderer.filter.pop();
			const maskData = this._activeMaskStage.pop();
			if (renderMask) TexturePool.returnTexture(maskData.filterTexture);
			this._usedEffects.push(maskData.filterEffect);
		}
	}
	postrender() {
		const effects = this._usedEffects;
		for (let i = 0; i < effects.length; i++) BigPool.return(effects[i]);
		effects.length = 0;
	}
	destroy() {
		this.postrender();
		this._renderer.runners.postrender.remove(this);
		this._renderer = null;
		this._activeMaskStage = null;
		this._usedEffects = null;
	}
};
/** @ignore */
AlphaMaskPipe.extension = {
	type: [
		ExtensionType.WebGLPipes,
		ExtensionType.WebGPUPipes,
		ExtensionType.CanvasPipes
	],
	name: "alphaMask"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/color/ColorMaskPipe.mjs
var ColorMaskPipe = class {
	constructor(renderer) {
		this._colorStack = [];
		this._colorStackIndex = 0;
		this._currentColor = 0;
		this._renderer = renderer;
	}
	buildStart() {
		this._colorStack[0] = 15;
		this._colorStackIndex = 1;
		this._currentColor = 15;
	}
	push(mask, _container, instructionSet) {
		this._renderer.renderPipes.batch.break(instructionSet);
		const colorStack = this._colorStack;
		colorStack[this._colorStackIndex] = colorStack[this._colorStackIndex - 1] & mask.mask;
		const currentColor = this._colorStack[this._colorStackIndex];
		if (currentColor !== this._currentColor) {
			this._currentColor = currentColor;
			instructionSet.add({
				renderPipeId: "colorMask",
				colorMask: currentColor,
				canBundle: false
			});
		}
		this._colorStackIndex++;
	}
	pop(_mask, _container, instructionSet) {
		this._renderer.renderPipes.batch.break(instructionSet);
		const colorStack = this._colorStack;
		this._colorStackIndex--;
		const currentColor = colorStack[this._colorStackIndex - 1];
		if (currentColor !== this._currentColor) {
			this._currentColor = currentColor;
			instructionSet.add({
				renderPipeId: "colorMask",
				colorMask: currentColor,
				canBundle: false
			});
		}
	}
	execute(instruction) {
		this._renderer.colorMask.setMask(instruction.colorMask);
	}
	destroy() {
		this._renderer = null;
		this._colorStack = null;
	}
};
/** @ignore */
ColorMaskPipe.extension = {
	type: [ExtensionType.WebGLPipes, ExtensionType.WebGPUPipes],
	name: "colorMask"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/stencil/StencilMaskPipe.mjs
var StencilMaskPipe = class {
	constructor(renderer) {
		this._maskHash = /* @__PURE__ */ new WeakMap();
		this._renderer = renderer;
	}
	push(mask, _container, instructionSet) {
		const effect = mask;
		const renderer = this._renderer;
		renderer.renderPipes.batch.break(instructionSet);
		renderer.renderPipes.blendMode.setBlendMode(effect.mask, "none", instructionSet);
		instructionSet.add({
			renderPipeId: "stencilMask",
			action: "pushMaskBegin",
			mask,
			inverse: _container._maskOptions.inverse,
			canBundle: false
		});
		const maskContainer = effect.mask;
		maskContainer.includeInBuild = true;
		if (!this._maskHash.has(effect)) this._maskHash.set(effect, {
			instructionsStart: 0,
			instructionsLength: 0
		});
		const maskData = this._maskHash.get(effect);
		maskData.instructionsStart = instructionSet.instructionSize;
		maskContainer.collectRenderables(instructionSet, renderer, null);
		maskContainer.includeInBuild = false;
		renderer.renderPipes.batch.break(instructionSet);
		instructionSet.add({
			renderPipeId: "stencilMask",
			action: "pushMaskEnd",
			mask,
			inverse: _container._maskOptions.inverse,
			canBundle: false
		});
		maskData.instructionsLength = instructionSet.instructionSize - maskData.instructionsStart - 1;
	}
	pop(mask, _container, instructionSet) {
		const effect = mask;
		const renderer = this._renderer;
		renderer.renderPipes.batch.break(instructionSet);
		renderer.renderPipes.blendMode.setBlendMode(effect.mask, "none", instructionSet);
		instructionSet.add({
			renderPipeId: "stencilMask",
			action: "popMaskBegin",
			inverse: _container._maskOptions.inverse,
			canBundle: false
		});
		const maskData = this._maskHash.get(mask);
		for (let i = 0; i < maskData.instructionsLength; i++) instructionSet.instructions[instructionSet.instructionSize++] = instructionSet.instructions[maskData.instructionsStart++];
		instructionSet.add({
			renderPipeId: "stencilMask",
			action: "popMaskEnd",
			canBundle: false
		});
	}
	execute(instruction) {
		const gpuRenderer = this._renderer;
		const gpuRenderTarget = gpuRenderer.renderTarget.getGpuRenderTarget(gpuRenderer.renderTarget.renderTarget);
		let maskStackIndex = gpuRenderTarget.maskStackIndex;
		if (instruction.action === "pushMaskBegin") {
			gpuRenderer.renderTarget.ensureDepthStencil();
			gpuRenderer.stencil.setStencilMode(STENCIL_MODES.RENDERING_MASK_ADD, maskStackIndex);
			maskStackIndex++;
			gpuRenderer.colorMask.setMask(0);
		} else if (instruction.action === "pushMaskEnd") {
			if (instruction.inverse) gpuRenderer.stencil.setStencilMode(STENCIL_MODES.INVERSE_MASK_ACTIVE, maskStackIndex);
			else gpuRenderer.stencil.setStencilMode(STENCIL_MODES.MASK_ACTIVE, maskStackIndex);
			gpuRenderer.colorMask.setMask(15);
		} else if (instruction.action === "popMaskBegin") {
			gpuRenderer.colorMask.setMask(0);
			if (maskStackIndex !== 0) gpuRenderer.stencil.setStencilMode(STENCIL_MODES.RENDERING_MASK_REMOVE, maskStackIndex);
			else {
				gpuRenderer.renderTarget.clear(null, CLEAR.STENCIL);
				gpuRenderer.stencil.setStencilMode(STENCIL_MODES.DISABLED, maskStackIndex);
			}
			maskStackIndex--;
		} else if (instruction.action === "popMaskEnd") {
			if (instruction.inverse) gpuRenderer.stencil.setStencilMode(STENCIL_MODES.INVERSE_MASK_ACTIVE, maskStackIndex);
			else gpuRenderer.stencil.setStencilMode(STENCIL_MODES.MASK_ACTIVE, maskStackIndex);
			gpuRenderer.colorMask.setMask(15);
		}
		gpuRenderTarget.maskStackIndex = maskStackIndex;
	}
	destroy() {
		this._renderer = null;
		this._maskHash = null;
	}
};
StencilMaskPipe.extension = {
	type: [ExtensionType.WebGLPipes, ExtensionType.WebGPUPipes],
	name: "stencilMask"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/CustomRenderPipe.mjs
var CustomRenderPipe = class {
	constructor(renderer) {
		this._renderer = renderer;
	}
	updateRenderable() {}
	destroyRenderable() {}
	validateRenderable() {
		return false;
	}
	addRenderable(container, instructionSet) {
		this._renderer.renderPipes.batch.break(instructionSet);
		instructionSet.add(container);
	}
	execute(container) {
		if (!container.isRenderable) return;
		container.render(this._renderer);
	}
	destroy() {
		this._renderer = null;
	}
};
CustomRenderPipe.extension = {
	type: [
		ExtensionType.WebGLPipes,
		ExtensionType.WebGPUPipes,
		ExtensionType.CanvasPipes
	],
	name: "customRender"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/executeInstructions.mjs
function executeInstructions(renderGroup, renderer) {
	const instructionSet = renderGroup.instructionSet;
	const instructions = instructionSet.instructions;
	for (let i = 0; i < instructionSet.instructionSize; i++) {
		const instruction = instructions[i];
		renderer[instruction.renderPipeId].execute(instruction);
	}
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/RenderGroupPipe.mjs
var RenderGroupPipe = class {
	constructor(renderer) {
		this._renderer = renderer;
	}
	addRenderGroup(renderGroup, instructionSet) {
		if (renderGroup.isCachedAsTexture) this._addRenderableCacheAsTexture(renderGroup, instructionSet);
		else this._addRenderableDirect(renderGroup, instructionSet);
	}
	execute(renderGroup) {
		if (!renderGroup.isRenderable) return;
		if (renderGroup.isCachedAsTexture) this._executeCacheAsTexture(renderGroup);
		else this._executeDirect(renderGroup);
	}
	destroy() {
		this._renderer = null;
	}
	_addRenderableDirect(renderGroup, instructionSet) {
		this._renderer.renderPipes.batch.break(instructionSet);
		if (renderGroup._batchableRenderGroup) {
			BigPool.return(renderGroup._batchableRenderGroup);
			renderGroup._batchableRenderGroup = null;
		}
		instructionSet.add(renderGroup);
	}
	_addRenderableCacheAsTexture(renderGroup, instructionSet) {
		const batchableRenderGroup = renderGroup._batchableRenderGroup ?? (renderGroup._batchableRenderGroup = BigPool.get(BatchableSprite));
		batchableRenderGroup.renderable = renderGroup.root;
		batchableRenderGroup.transform = renderGroup.root.relativeGroupTransform;
		batchableRenderGroup.texture = renderGroup.texture;
		batchableRenderGroup.bounds = renderGroup._textureBounds;
		instructionSet.add(renderGroup);
		this._renderer.renderPipes.blendMode.pushBlendMode(renderGroup, renderGroup.root.groupBlendMode, instructionSet);
		this._renderer.renderPipes.batch.addToBatch(batchableRenderGroup, instructionSet);
		this._renderer.renderPipes.blendMode.popBlendMode(instructionSet);
	}
	_executeCacheAsTexture(renderGroup) {
		if (renderGroup.textureNeedsUpdate) {
			renderGroup.textureNeedsUpdate = false;
			const worldTransformMatrix = new Matrix().translate(-renderGroup._textureBounds.x, -renderGroup._textureBounds.y);
			this._renderer.renderTarget.push({
				target: renderGroup.texture,
				clear: true,
				frame: renderGroup.texture.frame
			});
			this._renderer.globalUniforms.push({
				worldTransformMatrix,
				worldColor: 4294967295,
				offset: {
					x: 0,
					y: 0
				}
			});
			executeInstructions(renderGroup, this._renderer.renderPipes);
			this._renderer.renderTarget.finishRenderPass();
			this._renderer.renderTarget.pop();
			this._renderer.globalUniforms.pop();
		}
		renderGroup._batchableRenderGroup._batcher.updateElement(renderGroup._batchableRenderGroup);
		renderGroup._batchableRenderGroup._batcher.geometry.buffers[0].update();
	}
	_executeDirect(renderGroup) {
		this._renderer.globalUniforms.push({
			worldTransformMatrix: renderGroup.inverseParentTextureTransform,
			worldColor: renderGroup.worldColorAlpha
		});
		executeInstructions(renderGroup, this._renderer.renderPipes);
		this._renderer.globalUniforms.pop();
	}
};
RenderGroupPipe.extension = {
	type: [
		ExtensionType.WebGLPipes,
		ExtensionType.WebGPUPipes,
		ExtensionType.CanvasPipes
	],
	name: "renderGroup"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/sprite/SpritePipe.mjs
var SpritePipe = class {
	constructor(renderer) {
		this._renderer = renderer;
	}
	addRenderable(sprite, instructionSet) {
		const gpuSprite = this._getGpuSprite(sprite);
		if (sprite.didViewUpdate) this._updateBatchableSprite(sprite, gpuSprite);
		this._renderer.renderPipes.batch.addToBatch(gpuSprite, instructionSet);
	}
	updateRenderable(sprite) {
		const gpuSprite = this._getGpuSprite(sprite);
		if (sprite.didViewUpdate) this._updateBatchableSprite(sprite, gpuSprite);
		gpuSprite._batcher.updateElement(gpuSprite);
	}
	validateRenderable(sprite) {
		const gpuSprite = this._getGpuSprite(sprite);
		return !gpuSprite._batcher.checkAndUpdateTexture(gpuSprite, sprite._texture);
	}
	_updateBatchableSprite(sprite, batchableSprite) {
		batchableSprite.bounds = sprite.visualBounds;
		batchableSprite.texture = sprite._texture;
	}
	_getGpuSprite(sprite) {
		return sprite._gpuData[this._renderer.uid] || this._initGPUSprite(sprite);
	}
	_initGPUSprite(sprite) {
		const batchableSprite = new BatchableSprite();
		batchableSprite.renderable = sprite;
		batchableSprite.transform = sprite.groupTransform;
		batchableSprite.texture = sprite._texture;
		batchableSprite.bounds = sprite.visualBounds;
		batchableSprite.roundPixels = this._renderer._roundPixels | sprite._roundPixels;
		sprite._gpuData[this._renderer.uid] = batchableSprite;
		return batchableSprite;
	}
	destroy() {
		this._renderer = null;
	}
};
/** @ignore */
SpritePipe.extension = {
	type: [
		ExtensionType.WebGLPipes,
		ExtensionType.WebGPUPipes,
		ExtensionType.CanvasPipes
	],
	name: "sprite"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/blendModes/BlendModePipe.mjs
var BLEND_MODE_FILTERS = {};
extensions.handle(ExtensionType.BlendMode, (value) => {
	if (!value.name) throw new Error("BlendMode extension must have a name property");
	BLEND_MODE_FILTERS[value.name] = value.ref;
}, (value) => {
	delete BLEND_MODE_FILTERS[value.name];
});
var BlendModePipe = class {
	constructor(renderer) {
		this._blendModeStack = [];
		this._isAdvanced = false;
		this._filterHash = /* @__PURE__ */ Object.create(null);
		this._renderer = renderer;
		this._renderer.runners.prerender.add(this);
	}
	prerender() {
		this._activeBlendMode = "normal";
		this._isAdvanced = false;
	}
	/**
	* Push a blend mode onto the internal stack and apply it to the instruction set if needed.
	* @param renderable - The renderable or {@link RenderGroup} associated with the change.
	* @param blendMode - The blend mode to activate.
	* @param instructionSet - The instruction set being built.
	*/
	pushBlendMode(renderable, blendMode, instructionSet) {
		this._blendModeStack.push(blendMode);
		this.setBlendMode(renderable, blendMode, instructionSet);
	}
	/**
	* Pop the last blend mode from the stack and apply the new top-of-stack mode.
	* @param instructionSet - The instruction set being built.
	*/
	popBlendMode(instructionSet) {
		this._blendModeStack.pop();
		const blendMode = this._blendModeStack[this._activeBlendMode.length - 1] ?? "normal";
		this.setBlendMode(null, blendMode, instructionSet);
	}
	/**
	* Ensure a blend mode switch is added to the instruction set when the mode changes.
	* If an advanced blend mode is active, subsequent renderables will be collected so they can be
	* rendered within a single filter pass.
	* @param renderable - The renderable or {@link RenderGroup} to associate with the change, or null when unwinding.
	* @param blendMode - The target blend mode.
	* @param instructionSet - The instruction set being built.
	*/
	setBlendMode(renderable, blendMode, instructionSet) {
		const isRenderGroup = renderable instanceof RenderGroup;
		if (this._activeBlendMode === blendMode) {
			if (this._isAdvanced && renderable && !isRenderGroup) this._renderableList?.push(renderable);
			return;
		}
		if (this._isAdvanced) this._endAdvancedBlendMode(instructionSet);
		this._activeBlendMode = blendMode;
		if (!renderable) return;
		this._isAdvanced = !!BLEND_MODE_FILTERS[blendMode];
		if (this._isAdvanced) this._beginAdvancedBlendMode(renderable, instructionSet);
	}
	_beginAdvancedBlendMode(renderable, instructionSet) {
		this._renderer.renderPipes.batch.break(instructionSet);
		const blendMode = this._activeBlendMode;
		if (!BLEND_MODE_FILTERS[blendMode]) {
			warn(`Unable to assign BlendMode: '${blendMode}'. You may want to include: import 'pixi.js/advanced-blend-modes'`);
			return;
		}
		const filterEffect = this._ensureFilterEffect(blendMode);
		const isRenderGroup = renderable instanceof RenderGroup;
		const instruction = {
			renderPipeId: "filter",
			action: "pushFilter",
			filterEffect,
			renderables: isRenderGroup ? null : [renderable],
			container: isRenderGroup ? renderable.root : null,
			canBundle: false
		};
		this._renderableList = instruction.renderables;
		instructionSet.add(instruction);
	}
	_ensureFilterEffect(blendMode) {
		let filterEffect = this._filterHash[blendMode];
		if (!filterEffect) {
			filterEffect = this._filterHash[blendMode] = new FilterEffect();
			filterEffect.filters = [new BLEND_MODE_FILTERS[blendMode]()];
		}
		return filterEffect;
	}
	_endAdvancedBlendMode(instructionSet) {
		this._isAdvanced = false;
		this._renderableList = null;
		this._renderer.renderPipes.batch.break(instructionSet);
		instructionSet.add({
			renderPipeId: "filter",
			action: "popFilter",
			canBundle: false
		});
	}
	/**
	* called when the instruction build process is starting this will reset internally to the default blend mode
	* @internal
	*/
	buildStart() {
		this._isAdvanced = false;
	}
	/**
	* called when the instruction build process is finished, ensuring that if there is an advanced blend mode
	* active, we add the final render instructions added to the instruction set
	* @param instructionSet - The instruction set we are adding to
	* @internal
	*/
	buildEnd(instructionSet) {
		if (!this._isAdvanced) return;
		this._endAdvancedBlendMode(instructionSet);
	}
	/** @internal */
	destroy() {
		this._renderer = null;
		this._renderableList = null;
		for (const i in this._filterHash) this._filterHash[i].destroy();
		this._filterHash = null;
	}
};
/** @ignore */
BlendModePipe.extension = {
	type: [
		ExtensionType.WebGLPipes,
		ExtensionType.WebGPUPipes,
		ExtensionType.CanvasPipes
	],
	name: "blendMode"
};
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/clearList.mjs
function clearList(list, index) {
	index || (index = 0);
	for (let j = index; j < list.length; j++) if (list[j]) list[j] = null;
	else break;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/updateRenderGroupTransforms.mjs
var tempContainer = new Container();
var UPDATE_BLEND_COLOR_VISIBLE = 7;
function updateRenderGroupTransforms(renderGroup, updateChildRenderGroups = false) {
	updateRenderGroupTransform(renderGroup);
	const childrenToUpdate = renderGroup.childrenToUpdate;
	const updateTick = renderGroup.updateTick++;
	for (const j in childrenToUpdate) {
		const renderGroupDepth = Number(j);
		const childrenAtDepth = childrenToUpdate[j];
		const list = childrenAtDepth.list;
		const index = childrenAtDepth.index;
		for (let i = 0; i < index; i++) {
			const child = list[i];
			if (child.parentRenderGroup === renderGroup && child.relativeRenderGroupDepth === renderGroupDepth) updateTransformAndChildren(child, updateTick, 0);
		}
		clearList(list, index);
		childrenAtDepth.index = 0;
	}
	if (updateChildRenderGroups) for (let i = 0; i < renderGroup.renderGroupChildren.length; i++) updateRenderGroupTransforms(renderGroup.renderGroupChildren[i], updateChildRenderGroups);
}
function updateRenderGroupTransform(renderGroup) {
	const root = renderGroup.root;
	let worldAlpha;
	if (renderGroup.renderGroupParent) {
		const renderGroupParent = renderGroup.renderGroupParent;
		renderGroup.worldTransform.appendFrom(root.relativeGroupTransform, renderGroupParent.worldTransform);
		renderGroup.worldColor = multiplyColors(root.groupColor, renderGroupParent.worldColor);
		worldAlpha = root.groupAlpha * renderGroupParent.worldAlpha;
	} else {
		renderGroup.worldTransform.copyFrom(root.localTransform);
		renderGroup.worldColor = root.localColor;
		worldAlpha = root.localAlpha;
	}
	worldAlpha = worldAlpha < 0 ? 0 : worldAlpha > 1 ? 1 : worldAlpha;
	renderGroup.worldAlpha = worldAlpha;
	renderGroup.worldColorAlpha = renderGroup.worldColor + ((worldAlpha * 255 | 0) << 24);
}
function updateTransformAndChildren(container, updateTick, updateFlags) {
	if (updateTick === container.updateTick) return;
	container.updateTick = updateTick;
	container.didChange = false;
	const localTransform = container.localTransform;
	container.updateLocalTransform();
	const parent = container.parent;
	if (parent && !parent.renderGroup) {
		updateFlags |= container._updateFlags;
		container.relativeGroupTransform.appendFrom(localTransform, parent.relativeGroupTransform);
		if (updateFlags & UPDATE_BLEND_COLOR_VISIBLE) updateColorBlendVisibility(container, parent, updateFlags);
	} else {
		updateFlags = container._updateFlags;
		container.relativeGroupTransform.copyFrom(localTransform);
		if (updateFlags & UPDATE_BLEND_COLOR_VISIBLE) updateColorBlendVisibility(container, tempContainer, updateFlags);
	}
	if (!container.renderGroup) {
		const children = container.children;
		const length = children.length;
		for (let i = 0; i < length; i++) updateTransformAndChildren(children[i], updateTick, updateFlags);
		const renderGroup = container.parentRenderGroup;
		const renderable = container;
		if (renderable.renderPipeId && !renderGroup.structureDidChange) renderGroup.updateRenderable(renderable);
	}
}
function updateColorBlendVisibility(container, parent, updateFlags) {
	if (updateFlags & 1) {
		container.groupColor = multiplyColors(container.localColor, parent.groupColor);
		let groupAlpha = container.localAlpha * parent.groupAlpha;
		groupAlpha = groupAlpha < 0 ? 0 : groupAlpha > 1 ? 1 : groupAlpha;
		container.groupAlpha = groupAlpha;
		container.groupColorAlpha = container.groupColor + ((groupAlpha * 255 | 0) << 24);
	}
	if (updateFlags & 2) container.groupBlendMode = container.localBlendMode === "inherit" ? parent.groupBlendMode : container.localBlendMode;
	if (updateFlags & 4) container.globalDisplayStatus = container.localDisplayStatus & parent.globalDisplayStatus;
	container._updateFlags = 0;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/utils/validateRenderables.mjs
function validateRenderables(renderGroup, renderPipes) {
	const { list } = renderGroup.childrenRenderablesToUpdate;
	let rebuildRequired = false;
	for (let i = 0; i < renderGroup.childrenRenderablesToUpdate.index; i++) {
		const container = list[i];
		rebuildRequired = renderPipes[container.renderPipeId].validateRenderable(container);
		if (rebuildRequired) break;
	}
	renderGroup.structureDidChange = rebuildRequired;
	return rebuildRequired;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/container/RenderGroupSystem.mjs
var tempMatrix = new Matrix();
var RenderGroupSystem = class {
	constructor(renderer) {
		this._renderer = renderer;
	}
	render({ container, transform }) {
		const parent = container.parent;
		const renderGroupParent = container.renderGroup.renderGroupParent;
		container.parent = null;
		container.renderGroup.renderGroupParent = null;
		const renderer = this._renderer;
		const originalLocalTransform = tempMatrix;
		if (transform) {
			originalLocalTransform.copyFrom(container.renderGroup.localTransform);
			container.renderGroup.localTransform.copyFrom(transform);
		}
		const renderPipes = renderer.renderPipes;
		this._updateCachedRenderGroups(container.renderGroup, null);
		this._updateRenderGroups(container.renderGroup);
		renderer.globalUniforms.start({
			worldTransformMatrix: transform ? container.renderGroup.localTransform : container.renderGroup.worldTransform,
			worldColor: container.renderGroup.worldColorAlpha
		});
		executeInstructions(container.renderGroup, renderPipes);
		if (renderPipes.uniformBatch) renderPipes.uniformBatch.renderEnd();
		if (transform) container.renderGroup.localTransform.copyFrom(originalLocalTransform);
		container.parent = parent;
		container.renderGroup.renderGroupParent = renderGroupParent;
	}
	destroy() {
		this._renderer = null;
	}
	_updateCachedRenderGroups(renderGroup, closestCacheAsTexture) {
		renderGroup._parentCacheAsTextureRenderGroup = closestCacheAsTexture;
		if (renderGroup.isCachedAsTexture) {
			if (!renderGroup.textureNeedsUpdate) return;
			closestCacheAsTexture = renderGroup;
		}
		for (let i = renderGroup.renderGroupChildren.length - 1; i >= 0; i--) this._updateCachedRenderGroups(renderGroup.renderGroupChildren[i], closestCacheAsTexture);
		renderGroup.invalidateMatrices();
		if (renderGroup.isCachedAsTexture) {
			if (renderGroup.textureNeedsUpdate) {
				const bounds = renderGroup.root.getLocalBounds();
				const renderer = this._renderer;
				const resolution = renderGroup.textureOptions.resolution || renderer.view.resolution;
				const antialias = renderGroup.textureOptions.antialias ?? renderer.view.antialias;
				const scaleMode = renderGroup.textureOptions.scaleMode ?? "linear";
				const lastTexture = renderGroup.texture;
				bounds.ceil();
				if (renderGroup.texture) TexturePool.returnTexture(renderGroup.texture);
				renderGroup.texture = TexturePool.getOptimalTexture({
					width: bounds.width,
					height: bounds.height,
					resolution,
					antialias,
					scaleMode
				});
				renderGroup._textureBounds || (renderGroup._textureBounds = new Bounds());
				renderGroup._textureBounds.copyFrom(bounds);
				if (lastTexture !== renderGroup.texture) {
					if (renderGroup.renderGroupParent) renderGroup.renderGroupParent.structureDidChange = true;
				}
			}
		} else if (renderGroup.texture) {
			TexturePool.returnTexture(renderGroup.texture);
			renderGroup.texture = null;
		}
	}
	_updateRenderGroups(renderGroup) {
		const renderer = this._renderer;
		const renderPipes = renderer.renderPipes;
		renderGroup.runOnRender(renderer);
		renderGroup.instructionSet.renderPipes = renderPipes;
		if (!renderGroup.structureDidChange) validateRenderables(renderGroup, renderPipes);
		else clearList(renderGroup.childrenRenderablesToUpdate.list, 0);
		updateRenderGroupTransforms(renderGroup);
		if (renderGroup.structureDidChange) {
			renderGroup.structureDidChange = false;
			this._buildInstructions(renderGroup, renderer);
		} else this._updateRenderables(renderGroup);
		renderGroup.childrenRenderablesToUpdate.index = 0;
		renderer.renderPipes.batch.upload(renderGroup.instructionSet);
		if (renderGroup.isCachedAsTexture && !renderGroup.textureNeedsUpdate) return;
		for (let i = 0; i < renderGroup.renderGroupChildren.length; i++) this._updateRenderGroups(renderGroup.renderGroupChildren[i]);
	}
	_updateRenderables(renderGroup) {
		const { list, index } = renderGroup.childrenRenderablesToUpdate;
		for (let i = 0; i < index; i++) {
			const container = list[i];
			if (container.didViewUpdate) renderGroup.updateRenderable(container);
		}
		clearList(list, index);
	}
	_buildInstructions(renderGroup, rendererOrPipes) {
		const root = renderGroup.root;
		const instructionSet = renderGroup.instructionSet;
		instructionSet.reset();
		const renderer = rendererOrPipes.renderPipes ? rendererOrPipes : rendererOrPipes.batch.renderer;
		const renderPipes = renderer.renderPipes;
		renderPipes.batch.buildStart(instructionSet);
		renderPipes.blendMode.buildStart();
		renderPipes.colorMask.buildStart();
		if (root.sortableChildren) root.sortChildren();
		root.collectRenderablesWithEffects(instructionSet, renderer, null);
		renderPipes.batch.buildEnd(instructionSet);
		renderPipes.blendMode.buildEnd(instructionSet);
	}
};
/** @ignore */
RenderGroupSystem.extension = {
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.WebGPUSystem,
		ExtensionType.CanvasSystem
	],
	name: "renderGroup"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/background/BackgroundSystem.mjs
var _BackgroundSystem = class _BackgroundSystem {
	constructor() {
		this.clearBeforeRender = true;
		this._backgroundColor = new Color(0);
		this.color = this._backgroundColor;
		this.alpha = 1;
	}
	/**
	* initiates the background system
	* @param options - the options for the background colors
	*/
	init(options) {
		options = {
			..._BackgroundSystem.defaultOptions,
			...options
		};
		this.clearBeforeRender = options.clearBeforeRender;
		this.color = options.background || options.backgroundColor || this._backgroundColor;
		this.alpha = options.backgroundAlpha;
		this._backgroundColor.setAlpha(options.backgroundAlpha);
	}
	/** The background color to fill if not transparent */
	get color() {
		return this._backgroundColor;
	}
	set color(value) {
		if (Color.shared.setValue(value).alpha < 1 && this._backgroundColor.alpha === 1) warn("Cannot set a transparent background on an opaque canvas. To enable transparency, set backgroundAlpha < 1 when initializing your Application.");
		this._backgroundColor.setValue(value);
	}
	/** The background color alpha. Setting this to 0 will make the canvas transparent. */
	get alpha() {
		return this._backgroundColor.alpha;
	}
	set alpha(value) {
		this._backgroundColor.setAlpha(value);
	}
	/** The background color as an [R, G, B, A] array. */
	get colorRgba() {
		return this._backgroundColor.toArray();
	}
	/**
	* destroys the background system
	* @internal
	*/
	destroy() {}
};
/** @ignore */
_BackgroundSystem.extension = {
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.WebGPUSystem,
		ExtensionType.CanvasSystem
	],
	name: "background",
	priority: 0
};
/** default options used by the system */
_BackgroundSystem.defaultOptions = {
	/**
	* {@link WebGLOptions.backgroundAlpha}
	* @default 1
	*/
	backgroundAlpha: 1,
	/**
	* {@link WebGLOptions.backgroundColor}
	* @default 0x000000
	*/
	backgroundColor: 0,
	/**
	* {@link WebGLOptions.clearBeforeRender}
	* @default true
	*/
	clearBeforeRender: true
};
var BackgroundSystem = _BackgroundSystem;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/extract/ExtractSystem.mjs
var imageTypes = {
	png: "image/png",
	jpg: "image/jpeg",
	webp: "image/webp"
};
var _ExtractSystem = class _ExtractSystem {
	/** @param renderer - The renderer this System works for. */
	constructor(renderer) {
		this._renderer = renderer;
	}
	_normalizeOptions(options, defaults = {}) {
		if (options instanceof Container || options instanceof Texture) return {
			target: options,
			...defaults
		};
		return {
			...defaults,
			...options
		};
	}
	/**
	* Creates an IImage from a display object or texture.
	* @param options - Options for creating the image, or the target to extract
	* @returns Promise that resolves with the generated IImage
	* @example
	* ```ts
	* // Basic usage with a sprite
	* const sprite = new Sprite(texture);
	* const image = await renderer.extract.image(sprite);
	* document.body.appendChild(image);
	*
	* // Advanced usage with options
	* const image = await renderer.extract.image({
	*     target: container,
	*     format: 'webp',
	*     quality: 0.8,
	*     frame: new Rectangle(0, 0, 100, 100),
	*     resolution: 2,
	*     clearColor: '#ff0000',
	*     antialias: true
	* });
	*
	* // Extract directly from a texture
	* const texture = Texture.from('myTexture.png');
	* const image = await renderer.extract.image(texture);
	* ```
	* @see {@link ExtractImageOptions} For detailed options
	* @see {@link ExtractSystem.base64} For base64 string output
	* @see {@link ExtractSystem.canvas} For canvas output
	* @see {@link ImageLike} For the image interface
	* @category rendering
	*/
	async image(options) {
		const image = DOMAdapter.get().createImage();
		image.src = await this.base64(options);
		return image;
	}
	/**
	* Converts the target into a base64 encoded string.
	*
	* This method works by first creating
	* a canvas using `Extract.canvas` and then converting it to a base64 string.
	* @param options - The options for creating the base64 string, or the target to extract
	* @returns Promise that resolves with the base64 encoded string
	* @example
	* ```ts
	* // Basic usage with a sprite
	* const sprite = new Sprite(texture);
	* const base64 = await renderer.extract.base64(sprite);
	* console.log(base64); // data:image/png;base64,...
	*
	* // Advanced usage with options
	* const base64 = await renderer.extract.base64({
	*     target: container,
	*     format: 'webp',
	*     quality: 0.8,
	*     frame: new Rectangle(0, 0, 100, 100),
	*     resolution: 2
	* });
	* ```
	* @throws Will throw an error if the platform doesn't support any of:
	* - ICanvas.toDataURL
	* - ICanvas.toBlob
	* - ICanvas.convertToBlob
	* @see {@link ExtractImageOptions} For detailed options
	* @see {@link ExtractSystem.canvas} For canvas output
	* @see {@link ExtractSystem.image} For HTMLImage output
	* @category rendering
	*/
	async base64(options) {
		options = this._normalizeOptions(options, _ExtractSystem.defaultImageOptions);
		const { format, quality } = options;
		const canvas = this.canvas(options);
		if (canvas.toBlob !== void 0) return new Promise((resolve, reject) => {
			canvas.toBlob((blob) => {
				if (!blob) {
					reject(/* @__PURE__ */ new Error("ICanvas.toBlob failed!"));
					return;
				}
				const reader = new FileReader();
				reader.onload = () => resolve(reader.result);
				reader.onerror = reject;
				reader.readAsDataURL(blob);
			}, imageTypes[format], quality);
		});
		if (canvas.toDataURL !== void 0) return canvas.toDataURL(imageTypes[format], quality);
		if (canvas.convertToBlob !== void 0) {
			const blob = await canvas.convertToBlob({
				type: imageTypes[format],
				quality
			});
			return new Promise((resolve, reject) => {
				const reader = new FileReader();
				reader.onload = () => resolve(reader.result);
				reader.onerror = reject;
				reader.readAsDataURL(blob);
			});
		}
		throw new Error("Extract.base64() requires ICanvas.toDataURL, ICanvas.toBlob, or ICanvas.convertToBlob to be implemented");
	}
	/**
	* Creates a Canvas element, renders the target to it and returns it.
	* This method is useful for creating static images or when you need direct canvas access.
	* @param options - The options for creating the canvas, or the target to extract
	* @returns A Canvas element with the texture rendered on
	* @example
	* ```ts
	* // Basic canvas extraction from a sprite
	* const sprite = new Sprite(texture);
	* const canvas = renderer.extract.canvas(sprite);
	* document.body.appendChild(canvas);
	*
	* // Extract with custom region
	* const canvas = renderer.extract.canvas({
	*     target: container,
	*     frame: new Rectangle(0, 0, 100, 100)
	* });
	*
	* // Extract with high resolution
	* const canvas = renderer.extract.canvas({
	*     target: sprite,
	*     resolution: 2,
	*     clearColor: '#ff0000'
	* });
	*
	* // Extract directly from a texture
	* const texture = Texture.from('myTexture.png');
	* const canvas = renderer.extract.canvas(texture);
	*
	* // Extract with anti-aliasing
	* const canvas = renderer.extract.canvas({
	*     target: graphics,
	*     antialias: true
	* });
	* ```
	* @see {@link ExtractOptions} For detailed options
	* @see {@link ExtractSystem.image} For HTMLImage output
	* @see {@link ExtractSystem.pixels} For raw pixel data
	* @category rendering
	*/
	canvas(options) {
		options = this._normalizeOptions(options);
		const target = options.target;
		const renderer = this._renderer;
		if (target instanceof Texture) return renderer.texture.generateCanvas(target);
		const texture = renderer.textureGenerator.generateTexture(options);
		const canvas = renderer.texture.generateCanvas(texture);
		texture.destroy(true);
		return canvas;
	}
	/**
	* Returns a one-dimensional array containing the pixel data of the entire texture in RGBA order,
	* with integer values between 0 and 255 (inclusive).
	* > [!NOE] The returned array is a flat Uint8Array where every 4 values represent RGBA
	* @param options - The options for extracting the image, or the target to extract
	* @returns One-dimensional Uint8Array containing the pixel data in RGBA format
	* @example
	* ```ts
	* // Basic pixel extraction
	* const sprite = new Sprite(texture);
	* const pixels = renderer.extract.pixels(sprite);
	* console.log(pixels[0], pixels[1], pixels[2], pixels[3]); // R,G,B,A values
	*
	* // Extract with custom region
	* const pixels = renderer.extract.pixels({
	*     target: sprite,
	*     frame: new Rectangle(0, 0, 100, 100)
	* });
	*
	* // Extract with high resolution
	* const pixels = renderer.extract.pixels({
	*     target: sprite,
	*     resolution: 2
	* });
	* ```
	* @see {@link ExtractOptions} For detailed options
	* @see {@link ExtractSystem.canvas} For canvas output
	* @see {@link ExtractSystem.image} For image output
	* @category rendering
	*/
	pixels(options) {
		options = this._normalizeOptions(options);
		const target = options.target;
		const renderer = this._renderer;
		const texture = target instanceof Texture ? target : renderer.textureGenerator.generateTexture(options);
		const pixelInfo = renderer.texture.getPixels(texture);
		if (target instanceof Container) texture.destroy(true);
		return pixelInfo;
	}
	/**
	* Creates a texture from a display object or existing texture.
	*
	* This is useful for creating
	* reusable textures from rendered content or making copies of existing textures.
	* > [!NOTE] The returned texture should be destroyed when no longer needed
	* @param options - The options for creating the texture, or the target to extract
	* @returns A new texture containing the extracted content
	* @example
	* ```ts
	* // Basic texture extraction from a sprite
	* const sprite = new Sprite(texture);
	* const extractedTexture = renderer.extract.texture(sprite);
	*
	* // Extract with custom region
	* const regionTexture = renderer.extract.texture({
	*     target: container,
	*     frame: new Rectangle(0, 0, 100, 100)
	* });
	*
	* // Extract with high resolution
	* const hiResTexture = renderer.extract.texture({
	*     target: sprite,
	*     resolution: 2,
	*     clearColor: '#ff0000'
	* });
	*
	* // Create a new sprite from extracted texture
	* const newSprite = new Sprite(
	*     renderer.extract.texture({
	*         target: graphics,
	*         antialias: true
	*     })
	* );
	*
	* // Clean up when done
	* extractedTexture.destroy(true);
	* ```
	* @see {@link ExtractOptions} For detailed options
	* @see {@link Texture} For texture management
	* @see {@link GenerateTextureSystem} For texture generation
	* @category rendering
	*/
	texture(options) {
		options = this._normalizeOptions(options);
		if (options.target instanceof Texture) return options.target;
		return this._renderer.textureGenerator.generateTexture(options);
	}
	/**
	* Extracts and downloads content from the renderer as an image file.
	* This is a convenient way to save screenshots or export rendered content.
	* > [!NOTE] The download will use PNG format regardless of the filename extension
	* @param options - The options for downloading and extracting the image, or the target to extract
	* @example
	* ```ts
	* // Basic download with default filename
	* const sprite = new Sprite(texture);
	* renderer.extract.download(sprite); // Downloads as 'image.png'
	*
	* // Download with custom filename
	* renderer.extract.download({
	*     target: sprite,
	*     filename: 'screenshot.png'
	* });
	*
	* // Download with custom region
	* renderer.extract.download({
	*     target: container,
	*     filename: 'region.png',
	*     frame: new Rectangle(0, 0, 100, 100)
	* });
	*
	* // Download with high resolution and background
	* renderer.extract.download({
	*     target: stage,
	*     filename: 'hd-screenshot.png',
	*     resolution: 2,
	*     clearColor: '#ff0000'
	* });
	*
	* // Download with anti-aliasing
	* renderer.extract.download({
	*     target: graphics,
	*     filename: 'smooth.png',
	*     antialias: true
	* });
	* ```
	* @see {@link ExtractDownloadOptions} For detailed options
	* @see {@link ExtractSystem.image} For creating images without download
	* @see {@link ExtractSystem.canvas} For canvas output
	* @category rendering
	*/
	download(options) {
		options = this._normalizeOptions(options);
		const canvas = this.canvas(options);
		const link = document.createElement("a");
		link.download = options.filename ?? "image.png";
		link.href = canvas.toDataURL("image/png");
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	}
	/**
	* Logs the target to the console as an image. This is a useful way to debug what's happening in the renderer.
	* The image will be displayed in the browser's console using CSS background images.
	* @param options - The options for logging the image, or the target to log
	* @param options.width - The width of the logged image preview in the console (in pixels)
	* @example
	* ```ts
	* // Basic usage
	* const sprite = new Sprite(texture);
	* renderer.extract.log(sprite);
	* ```
	* @see {@link ExtractSystem.canvas} For getting raw canvas output
	* @see {@link ExtractSystem.pixels} For raw pixel data
	* @category rendering
	* @advanced
	*/
	log(options) {
		const width = options.width ?? 200;
		options = this._normalizeOptions(options);
		const canvas = this.canvas(options);
		const base64 = canvas.toDataURL();
		console.log(`[Pixi Texture] ${canvas.width}px ${canvas.height}px`);
		const style = [
			"font-size: 1px;",
			`padding: ${width}px 300px;`,
			`background: url(${base64}) no-repeat;`,
			"background-size: contain;"
		].join(" ");
		console.log("%c ", style);
	}
	destroy() {
		this._renderer = null;
	}
};
/** @ignore */
_ExtractSystem.extension = {
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.WebGPUSystem,
		ExtensionType.CanvasSystem
	],
	name: "extract"
};
/**
* Default options for image extraction.
* @example
* ```ts
* // Customize default options
* ExtractSystem.defaultImageOptions.format = 'webp';
* ExtractSystem.defaultImageOptions.quality = 0.8;
*
* // Use defaults
* const image = await renderer.extract.image(sprite);
* ```
*/
_ExtractSystem.defaultImageOptions = {
	format: "png",
	quality: 1
};
var ExtractSystem = _ExtractSystem;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/RenderTexture.mjs
var RenderTexture = class RenderTexture extends Texture {
	/**
	* Creates a RenderTexture. Pass `dynamic: true` in options to allow resizing after creation.
	* @param options - Options for the RenderTexture, including width, height, textureOptions, and dynamic.
	* @returns A new RenderTexture instance.
	* @example
	* const textureOptions = { defaultAnchor: { x: 0.5, y: 0.5 } };
	* const rt = RenderTexture.create({ width: 100, height: 100, dynamic: true, textureOptions });
	* rt.resize(500, 500);
	*/
	static create(options) {
		const { dynamic, textureOptions, ...rest } = options;
		return new RenderTexture({
			...textureOptions,
			source: new TextureSource(rest),
			dynamic: dynamic ?? false
		});
	}
	/**
	* Resizes the render texture.
	* @param width - The new width of the render texture.
	* @param height - The new height of the render texture.
	* @param resolution - The new resolution of the render texture.
	* @returns This texture.
	*/
	resize(width, height, resolution) {
		this.source.resize(width, height, resolution);
		return this;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/extract/GenerateTextureSystem.mjs
var tempRect = new Rectangle();
var tempBounds = new Bounds();
var noColor = [
	0,
	0,
	0,
	0
];
var GenerateTextureSystem = class {
	constructor(renderer) {
		this._renderer = renderer;
	}
	/**
	* Creates a texture from a display object that can be used for creating sprites and other textures.
	* This is particularly useful for optimizing performance when a complex container needs to be reused.
	* @param options - Generate texture options or a container to convert to texture
	* @returns A new RenderTexture containing the rendered display object
	* @example
	* ```ts
	* // Basic usage with a container
	* const container = new Container();
	* container.addChild(
	*     new Graphics()
	*         .circle(0, 0, 50)
	*         .fill('red')
	* );
	*
	* const texture = renderer.textureGenerator.generateTexture(container);
	*
	* // Advanced usage with options
	* const texture = renderer.textureGenerator.generateTexture({
	*     target: container,
	*     frame: new Rectangle(0, 0, 100, 100), // Specific region
	*     resolution: 2,                        // High DPI
	*     clearColor: '#ff0000',               // Red background
	*     antialias: true                      // Smooth edges
	* });
	*
	* // Create a sprite from the generated texture
	* const sprite = new Sprite(texture);
	*
	* // Clean up when done
	* texture.destroy(true);
	* ```
	* @see {@link GenerateTextureOptions} For detailed texture generation options
	* @see {@link RenderTexture} For the type of texture created
	* @category rendering
	*/
	generateTexture(options) {
		if (options instanceof Container) options = {
			target: options,
			frame: void 0,
			textureSourceOptions: {},
			resolution: void 0
		};
		const resolution = options.resolution || this._renderer.resolution;
		const antialias = options.antialias || this._renderer.view.antialias;
		const container = options.target;
		let clearColor = options.clearColor;
		if (clearColor) clearColor = Array.isArray(clearColor) && clearColor.length === 4 ? clearColor : Color.shared.setValue(clearColor).toArray();
		else clearColor = noColor;
		const region = options.frame?.copyTo(tempRect) || getLocalBounds(container, tempBounds).rectangle;
		const textureOptions = options.defaultAnchor && { defaultAnchor: options.defaultAnchor };
		region.width = Math.max(region.width, 1 / resolution) | 0;
		region.height = Math.max(region.height, 1 / resolution) | 0;
		const target = RenderTexture.create({
			...options.textureSourceOptions,
			width: region.width,
			height: region.height,
			resolution,
			antialias,
			textureOptions
		});
		const transform = Matrix.shared.translate(-region.x, -region.y);
		this._renderer.render({
			container,
			transform,
			target,
			clearColor
		});
		target.source.updateMipmaps();
		return target;
	}
	destroy() {
		this._renderer = null;
	}
};
/** @ignore */
GenerateTextureSystem.extension = {
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.WebGPUSystem,
		ExtensionType.CanvasSystem
	],
	name: "textureGenerator"
};
//#endregion
//#region node_modules/pixi.js/lib/utils/data/clean.mjs
function cleanHash(hash) {
	let clean = false;
	for (const i in hash) if (hash[i] == void 0) {
		clean = true;
		break;
	}
	if (!clean) return hash;
	const cleanHash2 = /* @__PURE__ */ Object.create(null);
	for (const i in hash) {
		const value = hash[i];
		if (value) cleanHash2[i] = value;
	}
	return cleanHash2;
}
function cleanArray(arr) {
	let offset = 0;
	for (let i = 0; i < arr.length; i++) if (arr[i] == void 0) offset++;
	else arr[i - offset] = arr[i];
	arr.length -= offset;
	return arr;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/GCSystem.mjs
var _GCSystem = class _GCSystem {
	/**
	* Creates a new GCSystem instance.
	* @param renderer - The renderer this garbage collection system works for
	*/
	constructor(renderer) {
		/** Array of resources being tracked for garbage collection */
		this._managedResources = [];
		this._managedResourceHashes = [];
		this._managedCollections = [];
		this._ready = false;
		this._running = false;
		this._renderer = renderer;
	}
	/**
	* Initializes the garbage collection system with the provided options.
	* @param options - Configuration options
	*/
	init(options) {
		options = {
			..._GCSystem.defaultOptions,
			...options
		};
		this.maxUnusedTime = options.gcMaxUnusedTime;
		this._frequency = options.gcFrequency;
		this.enabled = options.gcActive;
		this.now = performance.now();
	}
	/**
	* Gets whether the garbage collection system is currently enabled.
	* @returns True if GC is enabled, false otherwise
	*/
	get enabled() {
		return !!this._handler;
	}
	/**
	* Enables or disables the garbage collection system.
	* When enabled, schedules periodic cleanup of resources.
	* When disabled, cancels all scheduled cleanups.
	*/
	set enabled(value) {
		if (this.enabled === value) return;
		if (value) {
			this._handler = this._renderer.scheduler.repeat(() => {
				this._ready = true;
			}, this._frequency, false);
			this._collectionsHandler = this._renderer.scheduler.repeat(() => {
				for (const hash of this._managedCollections) {
					const { context, collection, type } = hash;
					if (type === "hash") context[collection] = cleanHash(context[collection]);
					else context[collection] = cleanArray(context[collection]);
				}
			}, this._frequency);
		} else {
			this._renderer.scheduler.cancel(this._handler);
			this._renderer.scheduler.cancel(this._collectionsHandler);
			this._handler = 0;
			this._collectionsHandler = 0;
		}
	}
	/**
	* Called before rendering. Updates the current timestamp.
	* @param options - The render options
	* @param options.container - The container to render
	*/
	prerender({ container }) {
		this.now = performance.now();
		container.renderGroup.gcTick = this._renderer.tick++;
		this._updateInstructionGCTick(container.renderGroup, container.renderGroup.gcTick);
	}
	/** Performs garbage collection after rendering. */
	postrender() {
		if (!this._ready || !this.enabled) return;
		this.run();
		this._ready = false;
	}
	/**
	* Updates the GC tick counter for a render group and its children.
	* @param renderGroup - The render group to update
	* @param gcTick - The new tick value
	*/
	_updateInstructionGCTick(renderGroup, gcTick) {
		renderGroup.instructionSet.gcTick = gcTick;
		renderGroup.gcTick = gcTick;
		for (const child of renderGroup.renderGroupChildren) this._updateInstructionGCTick(child, gcTick);
	}
	/**
	* Registers a collection for garbage collection tracking.
	* @param context - The object containing the collection
	* @param collection - The property name on context that holds the collection
	* @param type - The type of collection to track ('hash' or 'array')
	*/
	addCollection(context, collection, type) {
		this._managedCollections.push({
			context,
			collection,
			type
		});
	}
	/**
	* Registers a resource for garbage collection tracking.
	* @param resource - The resource to track
	* @param type - The type of resource to track
	*/
	addResource(resource, type) {
		if (resource._gcLastUsed !== -1) {
			resource._gcLastUsed = this.now;
			resource._onTouch?.(this.now);
			return;
		}
		resource._gcData = {
			index: this._managedResources.length,
			type
		};
		resource._gcLastUsed = this.now;
		resource._onTouch?.(this.now);
		resource.once("unload", this.removeResource, this);
		this._managedResources.push(resource);
	}
	/**
	* Removes a resource from garbage collection tracking.
	* Call this when manually destroying a resource.
	* @param resource - The resource to stop tracking
	*/
	removeResource(resource) {
		const gcData = resource._gcData;
		if (!gcData) return;
		const index = gcData.index;
		const last = this._managedResources.length - 1;
		if (this._running) this._managedResources[index] = null;
		else {
			if (index !== last) {
				const lastResource = this._managedResources[last];
				this._managedResources[index] = lastResource;
				lastResource._gcData.index = index;
			}
			this._managedResources.length--;
		}
		resource._gcData = null;
		resource._gcLastUsed = -1;
	}
	/**
	* Registers a hash-based resource collection for garbage collection tracking.
	* Resources in the hash will be automatically tracked and cleaned up when unused.
	* @param context - The object containing the hash property
	* @param hash - The property name on context that holds the resource hash
	* @param type - The type of resources in the hash ('resource' or 'renderable')
	* @param priority - Processing priority (lower values are processed first)
	*/
	addResourceHash(context, hash, type, priority = 0) {
		this._managedResourceHashes.push({
			context,
			hash,
			type,
			priority
		});
		this._managedResourceHashes.sort((a, b) => a.priority - b.priority);
	}
	/**
	* Performs garbage collection by cleaning up unused resources.
	* Removes resources that haven't been used for longer than maxUnusedTime.
	*/
	run() {
		if (this._running) return;
		const now = performance.now();
		const managedResourceHashes = this._managedResourceHashes;
		const managedResources = this._managedResources;
		this._running = true;
		try {
			for (const hashEntry of managedResourceHashes) this.runOnHash(hashEntry, now);
			const length = managedResources.length;
			for (let i = 0; i < length; i++) {
				const resource = managedResources[i];
				if (resource) this.runOnResource(resource, now);
			}
		} finally {
			let writeIndex = 0;
			for (let i = 0; i < managedResources.length; i++) {
				const resource = managedResources[i];
				if (!resource) continue;
				if (writeIndex !== i) {
					managedResources[writeIndex] = resource;
					resource._gcData.index = writeIndex;
				}
				writeIndex++;
			}
			managedResources.length = writeIndex;
			this._running = false;
		}
	}
	updateRenderableGCTick(renderable, now) {
		const renderGroup = renderable.renderGroup ?? renderable.parentRenderGroup;
		const currentTick = renderGroup?.instructionSet?.gcTick ?? -1;
		if ((renderGroup?.gcTick ?? 0) === currentTick) {
			renderable._gcLastUsed = now;
			renderable._onTouch?.(now);
		}
	}
	runOnResource(resource, now) {
		if (resource._gcData.type === "renderable") this.updateRenderableGCTick(resource, now);
		if (now - resource._gcLastUsed < this.maxUnusedTime || !resource.autoGarbageCollect) return;
		resource.off("unload", this.removeResource, this);
		resource.unload();
		this.removeResource(resource);
	}
	/**
	* Creates a clone of the hash, copying all non-null entries up to (but not including) the stop key.
	* @param hashValue - The original hash to clone from
	* @param stopKey - The key to stop at (exclusive)
	* @returns A new hash object with copied entries
	*/
	_createHashClone(hashValue, stopKey) {
		const hashClone = /* @__PURE__ */ Object.create(null);
		for (const k in hashValue) {
			if (k === stopKey) break;
			if (hashValue[k] !== null) hashClone[k] = hashValue[k];
		}
		return hashClone;
	}
	runOnHash(hashEntry, now) {
		const { context, hash, type } = hashEntry;
		const hashValue = context[hash];
		let hashClone = null;
		let nullCount = 0;
		for (const key in hashValue) {
			const resource = hashValue[key];
			if (resource === null) {
				nullCount++;
				if (nullCount === 1e4 && !hashClone) hashClone = this._createHashClone(hashValue, key);
				continue;
			}
			if (resource._gcLastUsed === -1) {
				resource._gcLastUsed = now;
				resource._onTouch?.(now);
				if (hashClone) hashClone[key] = resource;
				continue;
			}
			if (type === "renderable") this.updateRenderableGCTick(resource, now);
			if (!(now - resource._gcLastUsed < this.maxUnusedTime) && resource.autoGarbageCollect) {
				if (type === "renderable") {
					const res = resource;
					const renderGroup = res.renderGroup ?? res.parentRenderGroup;
					if (renderGroup) renderGroup.structureDidChange = true;
				}
				resource.unload();
				resource._gcData = null;
				resource._gcLastUsed = -1;
				if (!hashClone) {
					if (nullCount + 1 !== 1e4) {
						hashValue[key] = null;
						nullCount++;
					} else hashClone = this._createHashClone(hashValue, key);
				}
			} else if (hashClone) hashClone[key] = resource;
		}
		if (hashClone) context[hash] = hashClone;
	}
	/** Cleans up the garbage collection system. Disables GC and removes all tracked resources. */
	destroy() {
		this.enabled = false;
		this._managedResources.forEach((resource) => {
			resource?.off("unload", this.removeResource, this);
		});
		this._managedResources.length = 0;
		this._managedResourceHashes.length = 0;
		this._managedCollections.length = 0;
		this._renderer = null;
	}
};
/** @ignore */
_GCSystem.extension = {
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.WebGPUSystem,
		ExtensionType.CanvasSystem
	],
	name: "gc",
	priority: 0
};
/** Default options for the GCSystem */
_GCSystem.defaultOptions = {
	/** Enable/disable the garbage collector */
	gcActive: true,
	/** Time in ms before an unused resource is collected (default 1 minute) */
	gcMaxUnusedTime: 6e4,
	/** How often to run garbage collection in ms (default 30 seconds) */
	gcFrequency: 3e4
};
var GCSystem = _GCSystem;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/renderTarget/GlobalUniformSystem.mjs
var GlobalUniformSystem = class {
	constructor(renderer) {
		this._stackIndex = 0;
		this._globalUniformDataStack = [];
		this._uniformsPool = [];
		this._activeUniforms = [];
		this._bindGroupPool = [];
		this._activeBindGroups = [];
		this._renderer = renderer;
	}
	reset() {
		this._stackIndex = 0;
		for (let i = 0; i < this._activeUniforms.length; i++) this._uniformsPool.push(this._activeUniforms[i]);
		for (let i = 0; i < this._activeBindGroups.length; i++) this._bindGroupPool.push(this._activeBindGroups[i]);
		this._activeUniforms.length = 0;
		this._activeBindGroups.length = 0;
	}
	start(options) {
		this.reset();
		this.push(options);
	}
	bind({ size, projectionMatrix, worldTransformMatrix, worldColor, offset }) {
		const renderTarget = this._renderer.renderTarget.renderTarget;
		const currentGlobalUniformData = this._stackIndex ? this._globalUniformDataStack[this._stackIndex - 1] : {
			projectionData: renderTarget,
			worldTransformMatrix: new Matrix(),
			worldColor: 4294967295,
			offset: new Point()
		};
		const globalUniformData = {
			projectionMatrix: projectionMatrix || this._renderer.renderTarget.projectionMatrix,
			resolution: size || renderTarget.size,
			worldTransformMatrix: worldTransformMatrix || currentGlobalUniformData.worldTransformMatrix,
			worldColor: worldColor || currentGlobalUniformData.worldColor,
			offset: offset || currentGlobalUniformData.offset,
			bindGroup: null
		};
		const uniformGroup = this._uniformsPool.pop() || this._createUniforms();
		this._activeUniforms.push(uniformGroup);
		const uniforms = uniformGroup.uniforms;
		uniforms.uProjectionMatrix = globalUniformData.projectionMatrix;
		uniforms.uResolution = globalUniformData.resolution;
		uniforms.uWorldTransformMatrix.copyFrom(globalUniformData.worldTransformMatrix);
		uniforms.uWorldTransformMatrix.tx -= globalUniformData.offset.x;
		uniforms.uWorldTransformMatrix.ty -= globalUniformData.offset.y;
		color32BitToUniform(globalUniformData.worldColor, uniforms.uWorldColorAlpha, 0);
		uniformGroup.update();
		let bindGroup;
		if (this._renderer.renderPipes.uniformBatch) bindGroup = this._renderer.renderPipes.uniformBatch.getUniformBindGroup(uniformGroup, false);
		else {
			bindGroup = this._bindGroupPool.pop() || new BindGroup();
			this._activeBindGroups.push(bindGroup);
			bindGroup.setResource(uniformGroup, 0);
		}
		globalUniformData.bindGroup = bindGroup;
		this._currentGlobalUniformData = globalUniformData;
	}
	push(options) {
		this.bind(options);
		this._globalUniformDataStack[this._stackIndex++] = this._currentGlobalUniformData;
	}
	pop() {
		this._currentGlobalUniformData = this._globalUniformDataStack[--this._stackIndex - 1];
		if (this._renderer.type === RendererType.WEBGL) this._currentGlobalUniformData.bindGroup.resources[0].update();
	}
	get bindGroup() {
		return this._currentGlobalUniformData.bindGroup;
	}
	get globalUniformData() {
		return this._currentGlobalUniformData;
	}
	get uniformGroup() {
		return this._currentGlobalUniformData.bindGroup.resources[0];
	}
	_createUniforms() {
		return new UniformGroup({
			uProjectionMatrix: {
				value: new Matrix(),
				type: "mat3x3<f32>"
			},
			uWorldTransformMatrix: {
				value: new Matrix(),
				type: "mat3x3<f32>"
			},
			uWorldColorAlpha: {
				value: /* @__PURE__ */ new Float32Array(4),
				type: "vec4<f32>"
			},
			uResolution: {
				value: [0, 0],
				type: "vec2<f32>"
			}
		}, { isStatic: true });
	}
	destroy() {
		this._renderer = null;
		this._globalUniformDataStack.length = 0;
		this._uniformsPool.length = 0;
		this._activeUniforms.length = 0;
		this._bindGroupPool.length = 0;
		this._activeBindGroups.length = 0;
		this._currentGlobalUniformData = null;
	}
};
/** @ignore */
GlobalUniformSystem.extension = {
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.WebGPUSystem,
		ExtensionType.CanvasSystem
	],
	name: "globalUniforms"
};
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/SchedulerSystem.mjs
var uid = 1;
var SchedulerSystem = class {
	constructor() {
		this._tasks = [];
		/** a small off set to apply to the repeat schedules. This is just to make sure they run at slightly different times */
		this._offset = 0;
	}
	/** Initializes the scheduler system and starts the ticker. */
	init() {
		Ticker.system.add(this._update, this);
	}
	/**
	* Schedules a repeating task.
	* @param func - The function to execute.
	* @param duration - The interval duration in milliseconds.
	* @param useOffset - this will spread out tasks so that they do not all run at the same time
	* @returns The unique identifier for the scheduled task.
	*/
	repeat(func, duration, useOffset = true) {
		const id = uid++;
		let offset = 0;
		if (useOffset) {
			this._offset += 1e3;
			offset = this._offset;
		}
		this._tasks.push({
			func,
			duration,
			start: performance.now(),
			offset,
			last: performance.now(),
			repeat: true,
			id
		});
		return id;
	}
	/**
	* Cancels a scheduled task.
	* @param id - The unique identifier of the task to cancel.
	*/
	cancel(id) {
		for (let i = 0; i < this._tasks.length; i++) if (this._tasks[i].id === id) {
			this._tasks.splice(i, 1);
			return;
		}
	}
	/**
	* Updates and executes the scheduled tasks.
	* @private
	*/
	_update() {
		const now = performance.now();
		for (let i = 0; i < this._tasks.length; i++) {
			const task = this._tasks[i];
			if (now - task.offset - task.last >= task.duration) {
				const elapsed = now - task.start;
				task.func(elapsed);
				task.last = now;
			}
		}
	}
	/**
	* Destroys the scheduler system and removes all tasks.
	* @internal
	*/
	destroy() {
		Ticker.system.remove(this._update, this);
		this._tasks.length = 0;
	}
};
/** @ignore */
SchedulerSystem.extension = {
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.WebGPUSystem,
		ExtensionType.CanvasSystem
	],
	name: "scheduler",
	priority: 0
};
//#endregion
//#region node_modules/pixi.js/lib/utils/sayHello.mjs
var saidHello = false;
function sayHello(type) {
	if (saidHello) return;
	if (DOMAdapter.get().getNavigator().userAgent.toLowerCase().indexOf("chrome") > -1) {
		const args = [
			`%c  %c  %c  %c  %c PixiJS %c v${VERSION} (${type}) http://www.pixijs.com/

`,
			"background: #E72264; padding:5px 0;",
			"background: #6CA2EA; padding:5px 0;",
			"background: #B5D33D; padding:5px 0;",
			"background: #FED23F; padding:5px 0;",
			"color: #FFFFFF; background: #E72264; padding:5px 0;",
			"color: #E72264; background: #FFFFFF; padding:5px 0;"
		];
		globalThis.console.log(...args);
	} else if (globalThis.console) globalThis.console.log(`PixiJS ${VERSION} - ${type} - http://www.pixijs.com/`);
	saidHello = true;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/startup/HelloSystem.mjs
var HelloSystem = class {
	constructor(renderer) {
		this._renderer = renderer;
	}
	/**
	* It all starts here! This initiates every system, passing in the options for any system by name.
	* @param options - the config for the renderer and all its systems
	*/
	init(options) {
		if (options.hello) {
			let name = this._renderer.name;
			if (this._renderer.type === RendererType.WEBGL) name += ` ${this._renderer.context.webGLVersion}`;
			sayHello(name);
		}
	}
};
/** @ignore */
HelloSystem.extension = {
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.WebGPUSystem,
		ExtensionType.CanvasSystem
	],
	name: "hello",
	priority: -2
};
/** The default options for the system. */
HelloSystem.defaultOptions = { 
/** {@link WebGLOptions.hello} */
hello: false };
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/RenderableGCSystem.mjs
var _RenderableGCSystem = class _RenderableGCSystem {
	/**
	* Creates a new RenderableGCSystem instance.
	* @param renderer - The renderer this garbage collection system works for
	*/
	constructor(renderer) {
		this._renderer = renderer;
	}
	/**
	* Initializes the garbage collection system with the provided options.
	* @param options - Configuration options for the renderer
	*/
	init(options) {
		options = {
			..._RenderableGCSystem.defaultOptions,
			...options
		};
		this.maxUnusedTime = options.renderableGCMaxUnusedTime;
	}
	/**
	* Gets whether the garbage collection system is currently enabled.
	* @returns True if GC is enabled, false otherwise
	*/
	get enabled() {
		deprecation("8.15.0", "RenderableGCSystem.enabled is deprecated, please use the GCSystem.enabled instead.");
		return this._renderer.gc.enabled;
	}
	/**
	* Enables or disables the garbage collection system.
	* When enabled, schedules periodic cleanup of resources.
	* When disabled, cancels all scheduled cleanups.
	*/
	set enabled(value) {
		deprecation("8.15.0", "RenderableGCSystem.enabled is deprecated, please use the GCSystem.enabled instead.");
		this._renderer.gc.enabled = value;
	}
	/**
	* Adds a hash table to be managed by the garbage collector.
	* @param context - The object containing the hash table
	* @param hash - The property name of the hash table
	*/
	addManagedHash(context, hash) {
		deprecation("8.15.0", "RenderableGCSystem.addManagedHash is deprecated, please use the GCSystem.addCollection instead.");
		this._renderer.gc.addCollection(context, hash, "hash");
	}
	/**
	* Adds an array to be managed by the garbage collector.
	* @param context - The object containing the array
	* @param hash - The property name of the array
	*/
	addManagedArray(context, hash) {
		deprecation("8.15.0", "RenderableGCSystem.addManagedArray is deprecated, please use the GCSystem.addCollection instead.");
		this._renderer.gc.addCollection(context, hash, "array");
	}
	/**
	* Starts tracking a renderable for garbage collection.
	* @param _renderable - The renderable to track
	* @deprecated since 8.15.0
	*/
	addRenderable(_renderable) {
		deprecation("8.15.0", "RenderableGCSystem.addRenderable is deprecated, please use the GCSystem instead.");
		this._renderer.gc.addResource(_renderable, "renderable");
	}
	/**
	* Performs garbage collection by cleaning up unused renderables.
	* Removes renderables that haven't been used for longer than maxUnusedTime.
	*/
	run() {
		deprecation("8.15.0", "RenderableGCSystem.run is deprecated, please use the GCSystem instead.");
		this._renderer.gc.run();
	}
	/** Cleans up the garbage collection system. Disables GC and removes all tracked resources. */
	destroy() {
		this._renderer = null;
	}
};
/**
* Extension metadata for registering this system with the renderer.
* @ignore
*/
_RenderableGCSystem.extension = {
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.WebGPUSystem,
		ExtensionType.CanvasSystem
	],
	name: "renderableGC",
	priority: 0
};
/**
* Default configuration options for the garbage collection system.
* These can be overridden when initializing the renderer.
* @deprecated since 8.15.0
*/
_RenderableGCSystem.defaultOptions = {
	/** Enable/disable the garbage collector */
	renderableGCActive: true,
	/** Time in ms before an unused resource is collected (default 1 minute) */
	renderableGCMaxUnusedTime: 6e4,
	/** How often to run garbage collection in ms (default 30 seconds) */
	renderableGCFrequency: 3e4
};
var RenderableGCSystem = _RenderableGCSystem;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/TextureGCSystem.mjs
var _TextureGCSystem = class _TextureGCSystem {
	/**
	* Frame count since started.
	* @readonly
	* @deprecated since 8.15.0
	*/
	get count() {
		return this._renderer.tick;
	}
	/**
	* Frame count since last garbage collection.
	* @readonly
	* @deprecated since 8.15.0
	*/
	get checkCount() {
		return this._checkCount;
	}
	set checkCount(value) {
		deprecation("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
		this._checkCount = value;
	}
	/**
	* Maximum idle frames before a texture is destroyed by garbage collection.
	* @see TextureGCSystem.defaultMaxIdle
	* @deprecated since 8.15.0
	*/
	get maxIdle() {
		return this._renderer.gc.maxUnusedTime / 1e3 * 60;
	}
	set maxIdle(value) {
		deprecation("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
		this._renderer.gc.maxUnusedTime = value / 60 * 1e3;
	}
	/**
	* Frames between two garbage collections.
	* @see TextureGCSystem.defaultCheckCountMax
	* @deprecated since 8.15.0
	*/
	get checkCountMax() {
		return Math.floor(this._renderer.gc["_frequency"] / 1e3);
	}
	set checkCountMax(_value) {
		deprecation("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
	}
	/**
	* Current garbage collection mode.
	* @see TextureGCSystem.defaultMode
	* @deprecated since 8.15.0
	*/
	get active() {
		return this._renderer.gc.enabled;
	}
	set active(value) {
		deprecation("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
		this._renderer.gc.enabled = value;
	}
	/** @param renderer - The renderer this System works for. */
	constructor(renderer) {
		this._renderer = renderer;
		this._checkCount = 0;
	}
	init(options) {
		if (options.textureGCActive !== _TextureGCSystem.defaultOptions.textureGCActive) this.active = options.textureGCActive;
		if (options.textureGCMaxIdle !== _TextureGCSystem.defaultOptions.textureGCMaxIdle) this.maxIdle = options.textureGCMaxIdle;
		if (options.textureGCCheckCountMax !== _TextureGCSystem.defaultOptions.textureGCCheckCountMax) this.checkCountMax = options.textureGCCheckCountMax;
	}
	/**
	* Checks to see when the last time a texture was used.
	* If the texture has not been used for a specified amount of time, it will be removed from the GPU.
	* @deprecated since 8.15.0
	*/
	run() {
		deprecation("8.15.0", "TextureGCSystem.run is deprecated, please use the GCSystem instead.");
		this._renderer.gc.run();
	}
	destroy() {
		this._renderer = null;
	}
};
/** @ignore */
_TextureGCSystem.extension = {
	type: [ExtensionType.WebGLSystem, ExtensionType.WebGPUSystem],
	name: "textureGC"
};
/**
* Default options for the TextureGCSystem
* @deprecated since 8.15.0
*/
_TextureGCSystem.defaultOptions = {
	/**
	* If set to true, this will enable the garbage collector on the GPU.
	* @default true
	*/
	textureGCActive: true,
	/**
	* @deprecated since 8.3.0
	* @see {@link TextureGCSystemOptions.textureGCMaxIdle}
	*/
	textureGCAMaxIdle: null,
	/**
	* The maximum idle frames before a texture is destroyed by garbage collection.
	* @default 60 * 60
	*/
	textureGCMaxIdle: 3600,
	/**
	* Frames between two garbage collections.
	* @default 600
	*/
	textureGCCheckCountMax: 600
};
var TextureGCSystem = _TextureGCSystem;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/renderTarget/RenderTarget.mjs
var _RenderTarget = class _RenderTarget extends eventemitter3_default {
	/**
	* @param options - Options for creating a render target, or a WebGPU-flavored descriptor.
	*/
	constructor(options = {}) {
		super();
		/** unique id for this render target */
		this.uid = uid$1("renderTarget");
		/**
		* An array of attachments that define exactly how the GPU should render to the color textures.
		* This includes the texture itself, as well as load/store operations and clear values.
		*/
		this.colorAttachments = [];
		this.dirtyId = 0;
		this.isRoot = false;
		this._size = /* @__PURE__ */ new Float32Array(2);
		/** if true, then when the render target is destroyed, it will destroy all the textures that were created for it. */
		this._managedColorTextures = false;
		/** depth capability requested for this target — via options, attachment format, or the mask system @internal */
		this._depth = false;
		/** stencil capability requested for this target — via options, attachment format, or the mask system @internal */
		this._stencil = false;
		this._colorTextures = null;
		const descriptor = "colorAttachments" in options ? options : this._normalizeOptions(options);
		this.isRoot = descriptor.isRoot ?? false;
		this.label = descriptor.label;
		this.colorAttachments = descriptor.colorAttachments;
		this.depthStencilAttachment = descriptor.depthStencilAttachment;
		if (this.depthStencilAttachment) {
			const format = this.depthStencilAttachment.texture.format;
			this._depth || (this._depth = format.includes("depth"));
			this._stencil || (this._stencil = format.includes("stencil"));
		}
		if (this.colorAttachments.length === 0 && !this.depthStencilAttachment) throw new Error("[RenderTarget] no color textures or depth textures were provided. Provide a depthStencilTexture or set depth/stencil to true when using colorTextures: 0.");
		if (this.colorAttachments.length > 0) {
			const colorSource = this.colorTexture;
			this.resize(colorSource.width, colorSource.height, colorSource._resolution);
		}
		if (this.sizeSource) this.sizeSource.on("resize", this.onSourceResize, this);
	}
	_normalizeOptions(options) {
		const opts = {
			..._RenderTarget.defaultOptions,
			...options
		};
		const colorAttachments = [];
		let depthStencilAttachment;
		if (typeof opts.colorTextures === "number") {
			if (opts.colorTextures > 0) {
				this._managedColorTextures = true;
				for (let i = 0; i < opts.colorTextures; i++) colorAttachments.push({
					texture: new TextureSource({
						width: opts.width,
						height: opts.height,
						resolution: opts.resolution,
						antialias: opts.antialias
					}),
					loadOp: "clear",
					storeOp: "store"
				});
			}
		} else opts.colorTextures.forEach((texture) => {
			colorAttachments.push({
				texture: texture.source,
				loadOp: "clear",
				storeOp: "store"
			});
		});
		const wantsDepthStencilTexture = opts.depthStencilTexture === true;
		this._depth = !!(opts.depth || wantsDepthStencilTexture);
		this._stencil = !!(opts.stencil || wantsDepthStencilTexture);
		if (opts.depthStencilTexture instanceof Texture || opts.depthStencilTexture instanceof TextureSource) {
			if (opts.isRoot) throw new Error("[RenderTarget] cannot attach a depth-stencil texture to the screen — the canvas owns its own depth/stencil buffers. Render to a texture target instead.");
			depthStencilAttachment = { texture: opts.depthStencilTexture.source };
		} else if (wantsDepthStencilTexture && !opts.isRoot || (opts.stencil || opts.depth) && colorAttachments.length === 0) depthStencilAttachment = this._createDepthStencilTexture(opts.width, opts.height, opts.resolution);
		return {
			colorAttachments,
			depthStencilAttachment,
			isRoot: opts.isRoot,
			label: opts.label
		};
	}
	get size() {
		const _size = this._size;
		_size[0] = this.pixelWidth;
		_size[1] = this.pixelHeight;
		return _size;
	}
	get width() {
		return this.sizeSource.width;
	}
	get height() {
		return this.sizeSource.height;
	}
	get pixelWidth() {
		return this.sizeSource.pixelWidth;
	}
	get pixelHeight() {
		return this.sizeSource.pixelHeight;
	}
	get resolution() {
		return this.sizeSource._resolution;
	}
	/**
	* An array of textures that can be written to by the GPU - mostly this has one texture in Pixi, but you could
	* write to multiple if required! (eg deferred lighting).
	* This is a backwards-compatible getter that extracts the textures from `colorAttachments`.
	*/
	get colorTextures() {
		this._colorTextures || (this._colorTextures = this.colorAttachments.map((a) => a.texture));
		return this._colorTextures;
	}
	/** The stencil and depth buffer will write to this texture in WebGPU. */
	get depthStencilTexture() {
		return this.depthStencilAttachment?.texture ?? null;
	}
	/** Whether this target provides a depth buffer — requested via options or implied by its attachment's format. */
	get depth() {
		return this._depth;
	}
	/** Whether this target provides a stencil buffer — requested via options or implied by its attachment's format. */
	get stencil() {
		return this._stencil;
	}
	get colorTexture() {
		return this.colorAttachments[0]?.texture;
	}
	/**
	* The texture that drives size, resolution, and resize events.
	* For standard targets this is `colorAttachments[0].texture`;
	* for depth-only targets it is `depthStencilAttachment.texture`.
	*/
	get sizeSource() {
		return this.colorAttachments[0]?.texture ?? this.depthStencilAttachment?.texture;
	}
	onSourceResize(source) {
		this.resize(source.width, source.height, source._resolution, true);
	}
	/**
	* This will ensure a depthStencil texture is created for this render target.
	* Most likely called by the mask system to make sure we have stencil buffer added.
	* @internal
	*/
	ensureDepthStencilTexture() {
		this._createDepthStencilTexture(this.sizeSource.width, this.sizeSource.height, this.sizeSource._resolution);
		this._depth = true;
		this._stencil = true;
	}
	resize(width, height, resolution = this.resolution, skipColorTexture = false) {
		this.dirtyId++;
		this.colorAttachments.forEach((colorAttachment, i) => {
			if (skipColorTexture && i === 0) return;
			colorAttachment.texture.resize(width, height, resolution);
		});
		if (this.depthStencilAttachment) {
			if (skipColorTexture && this.colorAttachments.length === 0) return;
			this.depthStencilAttachment.texture.resize(width, height, resolution);
		}
	}
	destroy() {
		if (!this.colorAttachments && !this.depthStencilAttachment) return;
		this.emit("destroy", this);
		this.sizeSource.off("resize", this.onSourceResize, this);
		if (this._managedColorTextures) this.colorAttachments.forEach((attachment) => {
			attachment.texture.destroy();
		});
		if (this.depthStencilAttachment) {
			this.depthStencilAttachment.texture.destroy();
			delete this.depthStencilAttachment;
		}
		this.colorAttachments = null;
		this._colorTextures = null;
		this.removeAllListeners();
	}
	/**
	* The single recipe for internally-created depth-stencil textures.
	* @param width
	* @param height
	* @param resolution
	*/
	_createDepthStencilTexture(width, height, resolution) {
		this.depthStencilAttachment ?? (this.depthStencilAttachment = { texture: new TextureSource({
			width,
			height,
			resolution,
			format: "depth24plus-stencil8",
			autoGenerateMipmaps: false,
			antialias: false,
			mipLevelCount: 1
		}) });
		return this.depthStencilAttachment;
	}
};
/**
* emits when the render target is destroyed, before its attachments are released.
* letting the renderer know that it needs to free the framebuffers and MSAA buffers it built for it
* @event destroy
*/
/** The default options for a render target */
_RenderTarget.defaultOptions = {
	/** the width of the RenderTarget */
	width: 0,
	/** the height of the RenderTarget */
	height: 0,
	/** the resolution of the RenderTarget */
	resolution: 1,
	/** an array of textures, or a number indicating how many color textures there should be */
	colorTextures: 1,
	/** should this render target have a stencil buffer? */
	stencil: false,
	/** should this render target have a depth buffer? */
	depth: false,
	/** should this render target be antialiased? */
	antialias: false,
	/** is this a root element, true if this is gl context owners render target */
	isRoot: false
};
var RenderTarget = _RenderTarget;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/utils/getCanvasTexture.mjs
var canvasCache = /* @__PURE__ */ new Map();
GlobalResourceRegistry.register(canvasCache);
function getCanvasTexture(canvas, options) {
	if (!canvasCache.has(canvas)) {
		const texture = new Texture({ source: new CanvasSource({
			resource: canvas,
			...options
		}) });
		const onDestroy = () => {
			if (canvasCache.get(canvas) === texture) canvasCache.delete(canvas);
		};
		texture.once("destroy", onDestroy);
		texture.source.once("destroy", onDestroy);
		canvasCache.set(canvas, texture);
	}
	return canvasCache.get(canvas);
}
function hasCachedCanvasTexture(canvas) {
	return canvasCache.has(canvas);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/view/ViewSystem.mjs
var _ViewSystem = class _ViewSystem {
	/**
	* Whether CSS dimensions of canvas view should be resized to screen dimensions automatically.
	* This is only supported for HTMLCanvasElement and will be ignored if the canvas is an OffscreenCanvas.
	* @type {boolean}
	*/
	get autoDensity() {
		return this.texture.source.autoDensity;
	}
	set autoDensity(value) {
		this.texture.source.autoDensity = value;
	}
	/** The resolution / device pixel ratio of the renderer. */
	get resolution() {
		return this.texture.source._resolution;
	}
	set resolution(value) {
		this.texture.source.resize(this.texture.source.width, this.texture.source.height, value);
	}
	constructor(renderer) {
		this._renderer = renderer;
	}
	/**
	* initiates the view system
	* @param options - the options for the view
	*/
	init(options) {
		options = {
			..._ViewSystem.defaultOptions,
			...options
		};
		if (options.view) {
			deprecation(v8_0_0, "ViewSystem.view has been renamed to ViewSystem.canvas");
			options.canvas = options.view;
		}
		this.screen = new Rectangle(0, 0, options.width, options.height);
		this.canvas = options.canvas || DOMAdapter.get().createCanvas();
		this.antialias = !!options.antialias;
		const { depth, ...canvasOptions } = options;
		this.texture = getCanvasTexture(this.canvas, canvasOptions);
		this.renderTarget = new RenderTarget({
			colorTextures: [this.texture],
			depth: !!depth,
			isRoot: true
		});
		this.texture.source.transparent = options.backgroundAlpha < 1;
		this.texture.source.on("resize", this._updateScreenSize, this);
		this.resolution = options.resolution;
		this._updateScreenSize();
	}
	/**
	* Resizes the screen and canvas to the specified dimensions.
	* @param desiredScreenWidth - The new width of the screen.
	* @param desiredScreenHeight - The new height of the screen.
	* @param resolution
	*/
	resize(desiredScreenWidth, desiredScreenHeight, resolution) {
		this.texture.source.resize(desiredScreenWidth, desiredScreenHeight, resolution);
		this.screen.width = this.texture.frame.width;
		this.screen.height = this.texture.frame.height;
	}
	/**
	* Destroys this System and optionally removes the canvas from the dom.
	* @param {options | false} options - The options for destroying the view, or "false".
	* @example
	* viewSystem.destroy();
	* viewSystem.destroy(true);
	* viewSystem.destroy({ removeView: true });
	*/
	destroy(options = false) {
		if ((typeof options === "boolean" ? options : !!options?.removeView) && this.canvas.parentNode) this.canvas.parentNode.removeChild(this.canvas);
		this.texture.source.off("resize", this._updateScreenSize, this);
		TexturePool.removeScreen(this._renderer.uid);
		CanvasPool.removeScreen(this._renderer.uid);
		this.texture.destroy();
	}
	/**
	* Tells the texture and canvas pools how big this renderer's screen is, in physical pixels, so they
	* can hand out screen sized resources instead of rounding every request up to a power of two.
	*/
	_updateScreenSize() {
		const { pixelWidth, pixelHeight } = this.texture.source;
		const uid = this._renderer.uid;
		TexturePool.setScreenSize(uid, pixelWidth, pixelHeight);
		CanvasPool.setScreenSize(uid, pixelWidth, pixelHeight);
	}
};
/** @ignore */
_ViewSystem.extension = {
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.WebGPUSystem,
		ExtensionType.CanvasSystem
	],
	name: "view",
	priority: 0
};
/** The default options for the view system. */
_ViewSystem.defaultOptions = {
	/**
	* {@link WebGLOptions.width}
	* @default 800
	*/
	width: 800,
	/**
	* {@link WebGLOptions.height}
	* @default 600
	*/
	height: 600,
	/**
	* {@link WebGLOptions.autoDensity}
	* @default false
	*/
	autoDensity: false,
	/**
	* {@link WebGLOptions.antialias}
	* @default false
	*/
	antialias: false
};
var ViewSystem = _ViewSystem;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/system/SharedSystems.mjs
var SharedSystems = [
	BackgroundSystem,
	GlobalUniformSystem,
	HelloSystem,
	ViewSystem,
	RenderGroupSystem,
	GCSystem,
	TextureGCSystem,
	GenerateTextureSystem,
	ExtractSystem,
	RendererInitHook,
	RenderableGCSystem,
	SchedulerSystem
];
var SharedRenderPipes = [
	BlendModePipe,
	BatcherPipe,
	SpritePipe,
	RenderGroupPipe,
	AlphaMaskPipe,
	StencilMaskPipe,
	ColorMaskPipe,
	CustomRenderPipe
];
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/gpu/renderTarget/calculateProjection.mjs
function calculateProjection(pm, x, y, width, height, flipY) {
	const sign = flipY ? 1 : -1;
	pm.identity();
	pm.a = 1 / width * 2;
	pm.d = sign * (1 / height * 2);
	pm.tx = -1 - x * pm.a;
	pm.ty = -sign - y * pm.d;
	return pm;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/renderTarget/isRenderingToScreen.mjs
function isRenderingToScreen(renderTarget) {
	if (renderTarget.colorAttachments.length === 0) return false;
	const resource = renderTarget.colorTexture.resource;
	return globalThis.HTMLCanvasElement && resource instanceof HTMLCanvasElement && document.body.contains(resource);
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/renderTarget/RenderTargetSystem.mjs
var RenderTargetSystem = class {
	constructor(renderer) {
		/** This is the root viewport for the render pass */
		this.rootViewPort = new Rectangle();
		/** the current viewport that the gpu is using */
		this.viewport = new Rectangle();
		/**
		* a runner that lets systems know if the active render target has changed.
		* Eg the Stencil System needs to know so it can manage the stencil buffer
		*/
		this.onRenderTargetChange = new SystemRunner("onRenderTargetChange");
		/** the projection matrix that is used by the shaders based on the active render target and the viewport */
		this.projectionMatrix = new Matrix();
		/** the default clear color for render targets */
		this.defaultClearColor = [
			0,
			0,
			0,
			0
		];
		/**
		* a hash that stores the render target for a given render surface. When you pass in a texture source,
		* a render target is created for it. This map stores and makes it easy to retrieve the render target
		*/
		this._renderSurfaceToRenderTargetHash = /* @__PURE__ */ new Map();
		/** A hash that stores a gpu render target for a given render target. */
		this._gpuRenderTargetHash = /* @__PURE__ */ Object.create(null);
		/** the pushed bindings; each entry is a replayable BindOptions that pop() re-binds */
		this._renderTargetStack = [];
		/**
		* the state of the current binding, written on every bind — backs the `renderSurface`,
		* `mipLevel` and `layer` getters and `getBindState`. Its `frame` aliases `_bindFrame`
		* and must never be handed out by reference.
		*/
		this._bindState = {
			target: null,
			frame: void 0,
			mipLevel: 0,
			layer: 0,
			flipY: false
		};
		/** system-owned rect backing `_bindState.frame`; as-passed frames are copied into it */
		this._bindFrame = new Rectangle();
		this._renderer = renderer;
		renderer.gc.addCollection(this, "_gpuRenderTargetHash", "hash");
	}
	/** the current active render surface that the render target is created from */
	get renderSurface() {
		return this._bindState.target;
	}
	/** the current mip level being rendered to (for texture subresources) */
	get mipLevel() {
		return this._bindState.mipLevel;
	}
	/** the current array layer being rendered to (for array-backed targets) */
	get layer() {
		return this._bindState.layer;
	}
	/** called when dev wants to finish a render pass */
	finishRenderPass() {
		this.adaptor.finishRenderPass(this.renderTarget);
	}
	/**
	* called when the renderer starts to render a scene: resets the bind stack and binds the
	* root render surface
	* @param options - the {@link BindOptions} for the root binding
	*/
	renderStart(options) {
		this._renderTargetStack.length = 0;
		this.push(options);
		this.rootViewPort.copyFrom(this.viewport);
		this.rootRenderTarget = this.renderTarget;
		this.renderingToScreen = isRenderingToScreen(this.rootRenderTarget);
		this.adaptor.prerender?.(this.rootRenderTarget);
	}
	postrender() {
		this.adaptor.postrender?.(this.rootRenderTarget);
	}
	bind(surfaceOrOptions, clear = true, clearColor, frame, mipLevel = 0, layer = 0, flipY) {
		let options;
		if ("target" in surfaceOrOptions) options = surfaceOrOptions;
		else {
			deprecation("8.20.0", "RenderTargetSystem.bind: positional arguments are deprecated, please use an options object instead: bind({ target, clear, clearColor, frame, mipLevel, layer, flipY })");
			options = {
				target: surfaceOrOptions,
				clear,
				clearColor,
				frame,
				mipLevel,
				layer,
				flipY
			};
		}
		const renderSurface = options.target;
		clear = options.clear ?? true;
		clearColor = options.clearColor;
		mipLevel = (options.mipLevel ?? 0) | 0;
		layer = (options.layer ?? 0) | 0;
		flipY = options.flipY;
		frame = options.frame;
		const renderTarget = this.getRenderTarget(renderSurface);
		const didChange = this.renderTarget !== renderTarget || !!renderTarget.flipY !== !!flipY;
		this.renderTarget = renderTarget;
		const gpuRenderTarget = this.getGpuRenderTarget(renderTarget);
		if (renderTarget.pixelWidth !== gpuRenderTarget.width || renderTarget.pixelHeight !== gpuRenderTarget.height) {
			this.adaptor.resizeGpuRenderTarget(renderTarget);
			gpuRenderTarget.width = renderTarget.pixelWidth;
			gpuRenderTarget.height = renderTarget.pixelHeight;
		}
		const source = renderTarget.colorAttachments[0]?.texture || renderTarget.depthStencilAttachment?.texture;
		const viewport = this.viewport;
		const layerCount = source.dimension === "3d" ? Math.max(source.depth >> mipLevel, 1) : source.depthOrArrayLayers;
		if (layer < 0 || layer >= layerCount) throw new Error(`[RenderTargetSystem] layer ${layer} is out of bounds (layer count=${layerCount}).`);
		const bindState = this._bindState;
		bindState.target = renderSurface;
		bindState.frame = frame ? this._bindFrame.copyFrom(frame) : void 0;
		bindState.mipLevel = mipLevel;
		bindState.layer = layer;
		bindState.flipY = flipY;
		const pixelWidth = Math.max(source.pixelWidth >> mipLevel, 1);
		const pixelHeight = Math.max(source.pixelHeight >> mipLevel, 1);
		if (!frame && renderSurface instanceof Texture) frame = renderSurface.frame;
		if (frame) {
			const resolution = source._resolution;
			const scale = 1 << Math.max(mipLevel, 0);
			const baseX = frame.x * resolution + .5 | 0;
			const baseY = frame.y * resolution + .5 | 0;
			const baseW = frame.width * resolution + .5 | 0;
			const baseH = frame.height * resolution + .5 | 0;
			let x = Math.floor(baseX / scale);
			let y = Math.floor(baseY / scale);
			let w = Math.ceil(baseW / scale);
			let h = Math.ceil(baseH / scale);
			if (x < 0) {
				w += x;
				x = 0;
			}
			if (y < 0) {
				h += y;
				y = 0;
			}
			x = Math.min(x, pixelWidth - 1);
			y = Math.min(y, pixelHeight - 1);
			w = Math.min(w, pixelWidth - x);
			h = Math.min(h, pixelHeight - y);
			w = Math.max(w, 1);
			h = Math.max(h, 1);
			viewport.x = x;
			viewport.y = y;
			viewport.width = w;
			viewport.height = h;
		} else {
			viewport.x = 0;
			viewport.y = 0;
			viewport.width = pixelWidth;
			viewport.height = pixelHeight;
		}
		renderTarget.flipY = flipY;
		calculateProjection(this.projectionMatrix, 0, 0, viewport.width / source.resolution, viewport.height / source.resolution, !renderTarget.isRoot !== !!renderTarget.flipY);
		this.adaptor.startRenderPass(renderTarget, clear, clearColor, viewport, mipLevel, layer);
		if (didChange) this.onRenderTargetChange.emit(renderTarget);
		return renderTarget;
	}
	/**
	* Captures the current binding as a {@link BindOptions} that can be passed back to
	* {@link RenderTargetSystem.bind} to restore it. The capture replays non-destructively:
	* its `clear` is `CLEAR.NONE`, so restoring never wipes the target.
	*
	* ```js
	* const saved = renderer.renderTarget.getBindState();
	*
	* renderer.renderTarget.bind({ target: scratchTexture, clear: true });
	* // ... draw ...
	* renderer.renderTarget.bind(saved);
	*
	* // or compose: the saved binding, but into mip 1
	* renderer.renderTarget.bind({ ...saved, mipLevel: 1 });
	* ```
	*
	* The capture is a snapshot owned by the caller — later binds cannot change it — and holds
	* `target` and `frame` as they were passed, so a Texture bound without an explicit frame
	* replays through its frame fallback. It stays valid for as long as its target does.
	* Pass `out` to reuse one object across captures; every field of it is overwritten.
	* @param out - an optional object to write the bind state into; allocated when omitted
	* @returns the captured bind state (`out` when provided)
	*/
	getBindState(out) {
		if (!this.renderTarget) throw new Error("[RenderTargetSystem] getBindState is only valid while a render surface is bound");
		const bindState = this._bindState;
		out ?? (out = {});
		out.target = bindState.target;
		out.clear = CLEAR.NONE;
		out.clearColor = void 0;
		if (!bindState.frame) out.frame = void 0;
		else if (out.frame) out.frame.copyFrom(bindState.frame);
		else out.frame = bindState.frame.clone();
		out.mipLevel = bindState.mipLevel;
		out.layer = bindState.layer;
		out.flipY = !!bindState.flipY;
		return out;
	}
	/**
	* Whether pixi inverts the front face for a bind — `true` when a front-facing triangle ends up
	* wound the opposite way on the surface, so the winding/cull has been inverted to compensate.
	*
	* With no arguments, answers for the current bind. With a target, answers for that target as if
	* it were bound with the given `flipY` (defaulting to `false`, exactly as {@link bind} would), so
	* a consumer can choose a projection or a `flipY` before binding.
	*
	* This is the requested `flipY` combined with the backend's inherent orientation, not the raw request:
	*
	* ```text
	* inverted = flipY XOR (isWebGL && !isRoot)
	* ```
	*
	* WebGL's non-root FBOs carry an inherent Y-flip vs the root (the classic render-texture flip), so the
	* same requested `flipY` lands with the opposite winding depending on `isRoot`. WebGPU has no such
	* inherent flip, so there it is simply `flipY`. This is the one spelling of the rule: the winding each
	* backend bakes at bind ({@link GlStateSystem} / {@link PipelineSystem}) comes from here too, so
	* consumers (e.g. 3D pipelines) read the resolved orientation instead of re-deriving it.
	* @param renderTarget - the target to ask about; omit for the current bind
	* @param flipY - the `flipY` the target would be bound with; ignored when `renderTarget` is omitted
	* @returns whether the front face is inverted
	*/
	isFrontFaceInverted(renderTarget, flipY) {
		if (!renderTarget) {
			renderTarget = this.renderTarget;
			if (!renderTarget) return false;
			flipY = renderTarget.flipY;
		}
		return !!flipY !== (this._renderer.type === RendererType.WEBGL && !renderTarget.isRoot);
	}
	/**
	* The effective front-face orientation of the current bind.
	* @deprecated since 8.21.0, use {@link isFrontFaceInverted} instead
	* @returns whether the current bind's front face is inverted
	*/
	get frontFaceInverted() {
		deprecation(v8_21_0, "RenderTargetSystem.frontFaceInverted is deprecated, use isFrontFaceInverted() instead");
		return this.isFrontFaceInverted();
	}
	clear(target, clear = CLEAR.ALL, clearColor, mipLevel = this.mipLevel, layer = this.layer) {
		if (!clear) return;
		if (target) target = this.getRenderTarget(target);
		this.adaptor.clear(target || this.renderTarget, clear, clearColor, this.viewport, mipLevel, layer);
	}
	contextChange() {
		this._gpuRenderTargetHash = /* @__PURE__ */ Object.create(null);
	}
	push(surfaceOrOptions, clear = CLEAR.ALL, clearColor, frame, mipLevel = 0, layer = 0, flipY) {
		let options;
		if ("target" in surfaceOrOptions) options = surfaceOrOptions;
		else {
			deprecation("8.20.0", "RenderTargetSystem.push: positional arguments are deprecated, please use an options object instead: push({ target, clear, clearColor, frame, mipLevel, layer, flipY })");
			options = {
				target: surfaceOrOptions,
				clear,
				clearColor,
				frame,
				mipLevel,
				layer,
				flipY
			};
		}
		const renderTarget = this.bind(options);
		this._renderTargetStack.push({
			target: options.target,
			clear: false,
			clearColor: void 0,
			frame: options.frame ? options.frame.clone() : void 0,
			mipLevel: options.mipLevel,
			layer: options.layer,
			flipY: options.flipY
		});
		return renderTarget;
	}
	/**
	* Pops the current render target and restores the previous binding.
	* @returns the render target that was restored
	*/
	pop() {
		this._renderTargetStack.pop();
		const previous = this._renderTargetStack[this._renderTargetStack.length - 1];
		if (!previous) throw new Error("[RenderTargetSystem] pop: no previous binding to restore (unbalanced pop)");
		return this.bind(previous);
	}
	/**
	* Gets the render target from the provide render surface. Eg if its a texture,
	* it will return the render target for the texture.
	* If its a render target, it will return the same render target.
	* @param renderSurface - the render surface to get the render target for
	* @returns the render target for the render surface
	*/
	getRenderTarget(renderSurface) {
		if (renderSurface.isTexture) renderSurface = renderSurface.source;
		return this._renderSurfaceToRenderTargetHash.get(renderSurface) ?? this._initRenderTarget(renderSurface);
	}
	/**
	* Copies a render surface to another texture.
	*
	* NOTE:
	* for sourceRenderSurfaceTexture, The render target must be something that is written too by the renderer
	*
	* The following is not valid:
	* @example
	* const canvas = document.createElement('canvas')
	* canvas.width = 200;
	* canvas.height = 200;
	*
	* const ctx = canvas2.getContext('2d')!
	* ctx.fillStyle = 'red'
	* ctx.fillRect(0, 0, 200, 200);
	*
	* const texture = RenderTexture.create({
	*   width: 200,
	*   height: 200,
	* })
	* const renderTarget = renderer.renderTarget.getRenderTarget(canvas2);
	*
	* renderer.renderTarget.copyToTexture(renderTarget,texture, {x:0,y:0},{width:200,height:200},{x:0,y:0});
	*
	* The best way to copy a canvas is to create a texture from it. Then render with that.
	*
	* Parsing in a RenderTarget canvas context (with a 2d context)
	* @param sourceRenderSurface - the render surface (render target, texture, or canvas) to copy from
	* @param {Texture} destinationTexture - the texture to copy to
	* @param {object} originSrc - the origin of the copy
	* @param {number} originSrc.x - the x origin of the copy
	* @param {number} originSrc.y - the y origin of the copy
	* @param {object} size - the size of the copy
	* @param {number} size.width - the width of the copy
	* @param {number} size.height - the height of the copy
	* @param {object} originDest - the destination origin (top left to paste from!)
	* @param {number} originDest.x - the x origin of the paste
	* @param {number} originDest.y - the y origin of the paste
	*/
	copyToTexture(sourceRenderSurface, destinationTexture, originSrc, size, originDest) {
		const sourceRenderTarget = this.getRenderTarget(sourceRenderSurface);
		if (originSrc.x < 0) {
			size.width += originSrc.x;
			originDest.x -= originSrc.x;
			originSrc.x = 0;
		}
		if (originSrc.y < 0) {
			size.height += originSrc.y;
			originDest.y -= originSrc.y;
			originSrc.y = 0;
		}
		const { pixelWidth, pixelHeight } = sourceRenderTarget;
		size.width = Math.min(size.width, pixelWidth - originSrc.x);
		size.height = Math.min(size.height, pixelHeight - originSrc.y);
		return this.adaptor.copyToTexture(sourceRenderTarget, destinationTexture, originSrc, size, originDest);
	}
	/**
	* Copies the depth attachment from one render target to another.
	* Both source and destination must have a depthStencilAttachment.
	*
	* **Important Note:** When using the copied depth buffer in a subsequent render pass,
	* you must ensure you do not clear the depth buffer again. If you need to clear the color
	* buffer of the destination render target, use `clear: CLEAR.COLOR` to preserve the copied depth data.
	* @example
	* ```js
	* renderer.renderTarget.copyDepthTexture(
	*   sourceRT, destRT, { x: 0, y: 0 }, { width: 200, height: 200 }, { x: 0, y: 0 }
	* );
	*
	* // In the subsequent render pass, clear ONLY the color buffer!
	* renderer.render({
	*   target: destRT,
	*   container: myMesh,
	*   clear: CLEAR.COLOR, // Preserves the copied depth
	*   clearColor: [0, 0, 0, 1]
	* });
	* ```
	* @param source - the render surface (render target, depth texture, or canvas) to copy depth from
	* @param destination - the depth/stencil texture to copy depth to
	* @param {object} originSrc - the origin of the copy
	* @param {number} originSrc.x - the x origin of the copy
	* @param {number} originSrc.y - the y origin of the copy
	* @param {object} size - the size of the copy
	* @param {number} size.width - the width of the copy
	* @param {number} size.height - the height of the copy
	* @param {object} originDest - the destination origin (top left to paste from!)
	* @param {number} originDest.x - the x origin of the paste
	* @param {number} originDest.y - the y origin of the paste
	*/
	copyDepthTexture(source, destination, originSrc, size, originDest = {
		x: 0,
		y: 0
	}) {
		const sourceRenderTarget = this.getRenderTarget(source);
		if (!sourceRenderTarget.depthStencilAttachment) {
			warn("[RenderTargetSystem] copyDepthTexture: the source render target has no depth attachment to copy from");
			return;
		}
		const destSource = destination.source;
		if (!destSource.format.includes("depth") && !destSource.format.includes("stencil")) {
			warn(`[RenderTargetSystem] copyDepthTexture: the destination texture must have a depth/stencil format (got '${destSource.format}')`);
			return;
		}
		let srcX = originSrc.x;
		let srcY = originSrc.y;
		let destX = originDest.x;
		let destY = originDest.y;
		let width = size.width;
		let height = size.height;
		if (srcX < 0) {
			width += srcX;
			destX -= srcX;
			srcX = 0;
		}
		if (srcY < 0) {
			height += srcY;
			destY -= srcY;
			srcY = 0;
		}
		width = Math.min(width, sourceRenderTarget.pixelWidth - srcX);
		height = Math.min(height, sourceRenderTarget.pixelHeight - srcY);
		width = Math.min(width, destSource.pixelWidth - destX);
		height = Math.min(height, destSource.pixelHeight - destY);
		if (width <= 0 || height <= 0) return;
		this.adaptor.copyDepthTexture(sourceRenderTarget, destination, {
			x: srcX,
			y: srcY
		}, {
			width,
			height
		}, {
			x: destX,
			y: destY
		});
	}
	/**
	* ensures that we have a depth stencil buffer available to render to
	* This is used by the mask system to make sure we have a stencil buffer.
	*/
	ensureDepthStencil() {
		if (!this.renderTarget.stencil) {
			if (this.renderTarget.depthStencilTexture) {
				warn(`[RenderTargetSystem] a stencil mask is being used, but the render target's depthStencilTexture format '${this.renderTarget.depthStencilTexture.format}' has no stencil aspect, so masking cannot work here. Use a 'depth24plus-stencil8' texture instead.`);
				return;
			}
			this.renderTarget._depth = true;
			this.renderTarget._stencil = true;
			this.adaptor.startRenderPass(this.renderTarget, false, null, this.viewport, 0, this.layer);
		}
	}
	/** nukes the render target system */
	destroy() {
		this._renderer = null;
		this._renderSurfaceToRenderTargetHash.forEach((renderTarget, key) => {
			if (renderTarget !== key) this._releaseRenderTarget(key, renderTarget);
			else renderTarget.off("destroy", this._onRenderTargetDestroy, this);
		});
		this._renderSurfaceToRenderTargetHash.clear();
		for (const gpuRenderTarget of Object.values(this._gpuRenderTargetHash)) if (gpuRenderTarget) this.adaptor.destroyGpuRenderTarget(gpuRenderTarget);
		this._gpuRenderTargetHash = /* @__PURE__ */ Object.create(null);
	}
	_initRenderTarget(renderSurface) {
		let renderTarget = null;
		if (CanvasSource.test(renderSurface)) renderSurface = getCanvasTexture(renderSurface).source;
		if (renderSurface instanceof RenderTarget) {
			renderTarget = renderSurface;
			renderSurface.once("destroy", this._onRenderTargetDestroy, this);
		} else if (renderSurface instanceof TextureSource) {
			const format = renderSurface.format;
			renderTarget = format.includes("depth") || format.includes("stencil") ? new RenderTarget({
				colorTextures: 0,
				depthStencilTexture: renderSurface
			}) : new RenderTarget({ colorTextures: [renderSurface] });
			if (renderSurface.source instanceof CanvasSource) renderTarget.isRoot = true;
			renderSurface.once("destroy", this._onRenderSurfaceDestroy, this);
		}
		this._renderSurfaceToRenderTargetHash.set(renderSurface, renderTarget);
		return renderTarget;
	}
	_onRenderSurfaceDestroy(renderSurface) {
		const renderTarget = this._renderSurfaceToRenderTargetHash.get(renderSurface);
		if (renderTarget) this._releaseRenderTarget(renderSurface, renderTarget);
	}
	/**
	* A caller-owned render target is tearing itself down. It releases its own attachments,
	* so only the system's references to it and the backend objects built for it go here.
	* @param renderTarget - the render target being destroyed
	*/
	_onRenderTargetDestroy(renderTarget) {
		this._renderSurfaceToRenderTargetHash.delete(renderTarget);
		this._releaseGpuRenderTarget(renderTarget);
	}
	/**
	* Tears down a render target that wraps a texture source, removing every reference the
	* system holds to it so neither the system's own teardown nor the source's `destroy`
	* event can destroy it a second time.
	* @param renderSurface - the texture source the render target wraps
	* @param renderTarget - the render target to release
	*/
	_releaseRenderTarget(renderSurface, renderTarget) {
		renderTarget.destroy();
		this._renderSurfaceToRenderTargetHash.delete(renderSurface);
		renderSurface.off("destroy", this._onRenderSurfaceDestroy, this);
		this._releaseGpuRenderTarget(renderTarget);
	}
	/**
	* Frees the backend objects (framebuffers, renderbuffers, MSAA textures) cached for a render target.
	* @param renderTarget - the render target whose backend counterpart is no longer needed
	*/
	_releaseGpuRenderTarget(renderTarget) {
		const gpuRenderTarget = this._gpuRenderTargetHash[renderTarget.uid];
		if (gpuRenderTarget) {
			this._gpuRenderTargetHash[renderTarget.uid] = null;
			this.adaptor.destroyGpuRenderTarget(gpuRenderTarget);
		}
	}
	getGpuRenderTarget(renderTarget) {
		return this._gpuRenderTargetHash[renderTarget.uid] || (this._gpuRenderTargetHash[renderTarget.uid] = this.adaptor.initGpuRenderTarget(renderTarget));
	}
	resetState() {
		this.renderTarget = null;
		this._bindState.target = null;
	}
};
//#endregion
export { autoDetectEnvironment as $, SpritePipe as A, colorToUniform as B, RenderGroupSystem as C, updateTransformAndChildren as D, updateRenderGroupTransforms as E, ColorMaskPipe as F, ApplicationInitHook as G, source as H, AlphaMaskPipe as I, VERSION as J, RendererInitHook as K, BatcherPipe as L, executeInstructions as M, CustomRenderPipe as N, clearList as O, StencilMaskPipe as P, unsafeEvalSupported as Q, BatchableSprite as R, BackgroundSystem as S, updateRenderGroupTransform as T, vertex as U, MaskFilter as V, fragment as W, SystemRunner as X, AbstractRenderer as Y, CLEAR as Z, cleanArray as _, SharedSystems as a, RenderTexture as b, hasCachedCanvasTexture as c, RenderableGCSystem as d, loadEnvironmentExtensions as et, HelloSystem as f, GCSystem as g, GlobalUniformSystem as h, SharedRenderPipes as i, RenderGroupPipe as j, BlendModePipe as k, RenderTarget as l, SchedulerSystem as m, isRenderingToScreen as n, ViewSystem as o, sayHello as p, DATA_URI as q, calculateProjection as r, getCanvasTexture as s, RenderTargetSystem as t, TextureGCSystem as u, cleanHash as v, validateRenderables as w, ExtractSystem as x, GenerateTextureSystem as y, color32BitToUniform as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUmVuZGVyVGFyZ2V0U3lzdGVtLUJ0cGxUUHlxLmpzIiwibmFtZXMiOlsiRXZlbnRFbWl0dGVyIiwidWlkIiwidGVtcEJvdW5kcyIsInJlbmRlcmFibGUiLCJFdmVudEVtaXR0ZXIiLCJ1aWQiXSwic291cmNlcyI6WyIuLi8uLi9waXhpLmpzL2xpYi9lbnZpcm9ubWVudC9hdXRvRGV0ZWN0RW52aXJvbm1lbnQubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvdXRpbHMvYnJvd3Nlci91bnNhZmVFdmFsU3VwcG9ydGVkLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvZ2wvY29uc3QubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvc3lzdGVtL1N5c3RlbVJ1bm5lci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9zeXN0ZW0vQWJzdHJhY3RSZW5kZXJlci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi91dGlscy9jb25zdC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi91dGlscy9nbG9iYWwvZ2xvYmFsSG9va3MubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvZmlsdGVycy9tYXNrL21hc2suZnJhZy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9maWx0ZXJzL21hc2svbWFzay52ZXJ0Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2ZpbHRlcnMvbWFzay9tYXNrLndnc2wubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvZmlsdGVycy9tYXNrL01hc2tGaWx0ZXIubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvZ3JhcGhpY3MvZ3B1L2NvbG9yVG9Vbmlmb3JtLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL3Nwcml0ZS9CYXRjaGFibGVTcHJpdGUubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL2JhdGNoZXIvc2hhcmVkL0JhdGNoZXJQaXBlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9tYXNrL2FscGhhL0FscGhhTWFza1BpcGUubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL21hc2svY29sb3IvQ29sb3JNYXNrUGlwZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvbWFzay9zdGVuY2lsL1N0ZW5jaWxNYXNrUGlwZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvQ3VzdG9tUmVuZGVyUGlwZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvdXRpbHMvZXhlY3V0ZUluc3RydWN0aW9ucy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvUmVuZGVyR3JvdXBQaXBlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL3Nwcml0ZS9TcHJpdGVQaXBlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL2JsZW5kTW9kZXMvQmxlbmRNb2RlUGlwZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zY2VuZS9jb250YWluZXIvdXRpbHMvY2xlYXJMaXN0Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL2NvbnRhaW5lci91dGlscy91cGRhdGVSZW5kZXJHcm91cFRyYW5zZm9ybXMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvY29udGFpbmVyL3V0aWxzL3ZhbGlkYXRlUmVuZGVyYWJsZXMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvY29udGFpbmVyL1JlbmRlckdyb3VwU3lzdGVtLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL2JhY2tncm91bmQvQmFja2dyb3VuZFN5c3RlbS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9leHRyYWN0L0V4dHJhY3RTeXN0ZW0ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9SZW5kZXJUZXh0dXJlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL2V4dHJhY3QvR2VuZXJhdGVUZXh0dXJlU3lzdGVtLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3V0aWxzL2RhdGEvY2xlYW4ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvR0NTeXN0ZW0ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvcmVuZGVyVGFyZ2V0L0dsb2JhbFVuaWZvcm1TeXN0ZW0ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvU2NoZWR1bGVyU3lzdGVtLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3V0aWxzL3NheUhlbGxvLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3N0YXJ0dXAvSGVsbG9TeXN0ZW0ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9SZW5kZXJhYmxlR0NTeXN0ZW0ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9UZXh0dXJlR0NTeXN0ZW0ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvcmVuZGVyVGFyZ2V0L1JlbmRlclRhcmdldC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL3V0aWxzL2dldENhbnZhc1RleHR1cmUubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdmlldy9WaWV3U3lzdGVtLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3N5c3RlbS9TaGFyZWRTeXN0ZW1zLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvZ3B1L3JlbmRlclRhcmdldC9jYWxjdWxhdGVQcm9qZWN0aW9uLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3JlbmRlclRhcmdldC9pc1JlbmRlcmluZ1RvU2NyZWVuLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3JlbmRlclRhcmdldC9SZW5kZXJUYXJnZXRTeXN0ZW0ubWpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGV4dGVuc2lvbnMsIEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBlbnZpcm9ubWVudHMgPSBbXTtcbmV4dGVuc2lvbnMuaGFuZGxlQnlOYW1lZExpc3QoRXh0ZW5zaW9uVHlwZS5FbnZpcm9ubWVudCwgZW52aXJvbm1lbnRzKTtcbmFzeW5jIGZ1bmN0aW9uIGxvYWRFbnZpcm9ubWVudEV4dGVuc2lvbnMoc2tpcCkge1xuICBpZiAoc2tpcCkgcmV0dXJuO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGVudmlyb25tZW50cy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGVudiA9IGVudmlyb25tZW50c1tpXTtcbiAgICBpZiAoZW52LnZhbHVlLnRlc3QoKSkge1xuICAgICAgYXdhaXQgZW52LnZhbHVlLmxvYWQoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gIH1cbn1cbmFzeW5jIGZ1bmN0aW9uIGF1dG9EZXRlY3RFbnZpcm9ubWVudChhZGQpIHtcbiAgcmV0dXJuIGxvYWRFbnZpcm9ubWVudEV4dGVuc2lvbnMoIWFkZCk7XG59XG5cbmV4cG9ydCB7IGF1dG9EZXRlY3RFbnZpcm9ubWVudCwgbG9hZEVudmlyb25tZW50RXh0ZW5zaW9ucyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXV0b0RldGVjdEVudmlyb25tZW50Lm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xubGV0IHVuc2FmZUV2YWw7XG5mdW5jdGlvbiB1bnNhZmVFdmFsU3VwcG9ydGVkKCkge1xuICBpZiAodHlwZW9mIHVuc2FmZUV2YWwgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgcmV0dXJuIHVuc2FmZUV2YWw7XG4gIH1cbiAgdHJ5IHtcbiAgICBjb25zdCBmdW5jID0gbmV3IEZ1bmN0aW9uKFwicGFyYW0xXCIsIFwicGFyYW0yXCIsIFwicGFyYW0zXCIsIFwicmV0dXJuIHBhcmFtMVtwYXJhbTJdID09PSBwYXJhbTM7XCIpO1xuICAgIHVuc2FmZUV2YWwgPSBmdW5jKHsgYTogXCJiXCIgfSwgXCJhXCIsIFwiYlwiKSA9PT0gdHJ1ZTtcbiAgfSBjYXRjaCAoX2UpIHtcbiAgICB1bnNhZmVFdmFsID0gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHVuc2FmZUV2YWw7XG59XG5cbmV4cG9ydCB7IHVuc2FmZUV2YWxTdXBwb3J0ZWQgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVuc2FmZUV2YWxTdXBwb3J0ZWQubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgQ0xFQVIgPSAvKiBAX19QVVJFX18gKi8gKChDTEVBUjIpID0+IHtcbiAgQ0xFQVIyW0NMRUFSMltcIk5PTkVcIl0gPSAwXSA9IFwiTk9ORVwiO1xuICBDTEVBUjJbQ0xFQVIyW1wiQ09MT1JcIl0gPSAxNjM4NF0gPSBcIkNPTE9SXCI7XG4gIENMRUFSMltDTEVBUjJbXCJTVEVOQ0lMXCJdID0gMTAyNF0gPSBcIlNURU5DSUxcIjtcbiAgQ0xFQVIyW0NMRUFSMltcIkRFUFRIXCJdID0gMjU2XSA9IFwiREVQVEhcIjtcbiAgQ0xFQVIyW0NMRUFSMltcIkNPTE9SX0RFUFRIXCJdID0gMTY2NDBdID0gXCJDT0xPUl9ERVBUSFwiO1xuICBDTEVBUjJbQ0xFQVIyW1wiQ09MT1JfU1RFTkNJTFwiXSA9IDE3NDA4XSA9IFwiQ09MT1JfU1RFTkNJTFwiO1xuICBDTEVBUjJbQ0xFQVIyW1wiREVQVEhfU1RFTkNJTFwiXSA9IDEyODBdID0gXCJERVBUSF9TVEVOQ0lMXCI7XG4gIENMRUFSMltDTEVBUjJbXCJBTExcIl0gPSAxNzY2NF0gPSBcIkFMTFwiO1xuICByZXR1cm4gQ0xFQVIyO1xufSkoQ0xFQVIgfHwge30pO1xuXG5leHBvcnQgeyBDTEVBUiB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29uc3QubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBTeXN0ZW1SdW5uZXIge1xuICAvKipcbiAgICogQHBhcmFtIG5hbWUgLSBUaGUgZnVuY3Rpb24gbmFtZSB0aGF0IHdpbGwgYmUgZXhlY3V0ZWQgb24gdGhlIGxpc3RlbmVycyBhZGRlZCB0byB0aGlzIFJ1bm5lci5cbiAgICovXG4gIGNvbnN0cnVjdG9yKG5hbWUpIHtcbiAgICB0aGlzLml0ZW1zID0gW107XG4gICAgdGhpcy5fbmFtZSA9IG5hbWU7XG4gIH1cbiAgLyoganNkb2MvY2hlY2stcGFyYW0tbmFtZXMgKi9cbiAgLyoqXG4gICAqIERpc3BhdGNoL0Jyb2FkY2FzdCBSdW5uZXIgdG8gYWxsIGxpc3RlbmVycyBhZGRlZCB0byB0aGUgcXVldWUuXG4gICAqIEBwYXJhbSB7Li4uYW55fSBwYXJhbXMgLSAob3B0aW9uYWwpIHBhcmFtZXRlcnMgdG8gcGFzcyB0byBlYWNoIGxpc3RlbmVyXG4gICAqL1xuICAvKiBqc2RvYy9jaGVjay1wYXJhbS1uYW1lcyAqL1xuICBlbWl0KGEwLCBhMSwgYTIsIGEzLCBhNCwgYTUsIGE2LCBhNykge1xuICAgIGNvbnN0IHsgbmFtZSwgaXRlbXMgfSA9IHRoaXM7XG4gICAgZm9yIChsZXQgaSA9IDAsIGxlbiA9IGl0ZW1zLmxlbmd0aDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICBpdGVtc1tpXVtuYW1lXShhMCwgYTEsIGEyLCBhMywgYTQsIGE1LCBhNiwgYTcpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKipcbiAgICogQWRkIGEgbGlzdGVuZXIgdG8gdGhlIFJ1bm5lclxuICAgKlxuICAgKiBSdW5uZXJzIGRvIG5vdCBuZWVkIHRvIGhhdmUgc2NvcGUgb3IgZnVuY3Rpb25zIHBhc3NlZCB0byB0aGVtLlxuICAgKiBBbGwgdGhhdCBpcyByZXF1aXJlZCBpcyB0byBwYXNzIHRoZSBsaXN0ZW5pbmcgb2JqZWN0IGFuZCBlbnN1cmUgdGhhdCBpdCBoYXMgY29udGFpbnMgYSBmdW5jdGlvbiB0aGF0IGhhcyB0aGUgc2FtZSBuYW1lXG4gICAqIGFzIHRoZSBuYW1lIHByb3ZpZGVkIHRvIHRoZSBSdW5uZXIgd2hlbiBpdCB3YXMgY3JlYXRlZC5cbiAgICpcbiAgICogRWcgQSBsaXN0ZW5lciBwYXNzZWQgdG8gdGhpcyBSdW5uZXIgd2lsbCByZXF1aXJlIGEgJ2NvbXBsZXRlJyBmdW5jdGlvbi5cbiAgICpcbiAgICogYGBgdHNcbiAgICogaW1wb3J0IHsgUnVubmVyIH0gZnJvbSAncGl4aS5qcyc7XG4gICAqXG4gICAqIGNvbnN0IGNvbXBsZXRlID0gbmV3IFJ1bm5lcignY29tcGxldGUnKTtcbiAgICogYGBgXG4gICAqXG4gICAqIFRoZSBzY29wZSB1c2VkIHdpbGwgYmUgdGhlIG9iamVjdCBpdHNlbGYuXG4gICAqIEBwYXJhbSB7YW55fSBpdGVtIC0gVGhlIG9iamVjdCB0aGF0IHdpbGwgYmUgbGlzdGVuaW5nLlxuICAgKi9cbiAgYWRkKGl0ZW0pIHtcbiAgICBpZiAoaXRlbVt0aGlzLl9uYW1lXSkge1xuICAgICAgdGhpcy5yZW1vdmUoaXRlbSk7XG4gICAgICB0aGlzLml0ZW1zLnB1c2goaXRlbSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBSZW1vdmUgYSBzaW5nbGUgbGlzdGVuZXIgZnJvbSB0aGUgZGlzcGF0Y2ggcXVldWUuXG4gICAqIEBwYXJhbSB7YW55fSBpdGVtIC0gVGhlIGxpc3RlbmVyIHRoYXQgeW91IHdvdWxkIGxpa2UgdG8gcmVtb3ZlLlxuICAgKi9cbiAgcmVtb3ZlKGl0ZW0pIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMuaXRlbXMuaW5kZXhPZihpdGVtKTtcbiAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICB0aGlzLml0ZW1zLnNwbGljZShpbmRleCwgMSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIC8qKlxuICAgKiBDaGVjayB0byBzZWUgaWYgdGhlIGxpc3RlbmVyIGlzIGFscmVhZHkgaW4gdGhlIFJ1bm5lclxuICAgKiBAcGFyYW0ge2FueX0gaXRlbSAtIFRoZSBsaXN0ZW5lciB0aGF0IHlvdSB3b3VsZCBsaWtlIHRvIGNoZWNrLlxuICAgKi9cbiAgY29udGFpbnMoaXRlbSkge1xuICAgIHJldHVybiB0aGlzLml0ZW1zLmluZGV4T2YoaXRlbSkgIT09IC0xO1xuICB9XG4gIC8qKiBSZW1vdmUgYWxsIGxpc3RlbmVycyBmcm9tIHRoZSBSdW5uZXIgKi9cbiAgcmVtb3ZlQWxsKCkge1xuICAgIHRoaXMuaXRlbXMubGVuZ3RoID0gMDtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICAvKiogUmVtb3ZlIGFsbCByZWZlcmVuY2VzLCBkb24ndCB1c2UgYWZ0ZXIgdGhpcy4gKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLnJlbW92ZUFsbCgpO1xuICAgIHRoaXMuaXRlbXMgPSBudWxsO1xuICAgIHRoaXMuX25hbWUgPSBudWxsO1xuICB9XG4gIC8qKlxuICAgKiBgdHJ1ZWAgaWYgdGhlcmUgYXJlIG5vIHRoaXMgUnVubmVyIGNvbnRhaW5zIG5vIGxpc3RlbmVyc1xuICAgKiBAcmVhZG9ubHlcbiAgICovXG4gIGdldCBlbXB0eSgpIHtcbiAgICByZXR1cm4gdGhpcy5pdGVtcy5sZW5ndGggPT09IDA7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBydW5uZXIuXG4gICAqIEByZWFkb25seVxuICAgKi9cbiAgZ2V0IG5hbWUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX25hbWU7XG4gIH1cbn1cblxuZXhwb3J0IHsgU3lzdGVtUnVubmVyIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1TeXN0ZW1SdW5uZXIubWpzLm1hcFxuIiwiaW1wb3J0IHsgQ29sb3IgfSBmcm9tICcuLi8uLi8uLi8uLi9jb2xvci9Db2xvci5tanMnO1xuaW1wb3J0IHsgbG9hZEVudmlyb25tZW50RXh0ZW5zaW9ucyB9IGZyb20gJy4uLy4uLy4uLy4uL2Vudmlyb25tZW50L2F1dG9EZXRlY3RFbnZpcm9ubWVudC5tanMnO1xuaW1wb3J0IHsgQ29udGFpbmVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2NlbmUvY29udGFpbmVyL0NvbnRhaW5lci5tanMnO1xuaW1wb3J0IHsgdW5zYWZlRXZhbFN1cHBvcnRlZCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2Jyb3dzZXIvdW5zYWZlRXZhbFN1cHBvcnRlZC5tanMnO1xuaW1wb3J0IHsgdWlkIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvZGF0YS91aWQubWpzJztcbmltcG9ydCB7IGRlcHJlY2F0aW9uLCB2OF8wXzAgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9sb2dnaW5nL2RlcHJlY2F0aW9uLm1qcyc7XG5pbXBvcnQgeyBHbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5IH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvcG9vbC9HbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5Lm1qcyc7XG5pbXBvcnQgJy4uLy4uLy4uLy4uL3V0aWxzL3V0aWxzLm1qcyc7XG5pbXBvcnQgeyBDTEVBUiB9IGZyb20gJy4uLy4uL2dsL2NvbnN0Lm1qcyc7XG5pbXBvcnQgeyBTeXN0ZW1SdW5uZXIgfSBmcm9tICcuL1N5c3RlbVJ1bm5lci5tanMnO1xuaW1wb3J0IEV2ZW50RW1pdHRlciBmcm9tICdldmVudGVtaXR0ZXIzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBkZWZhdWx0UnVubmVycyA9IFtcbiAgXCJpbml0XCIsXG4gIFwiZGVzdHJveVwiLFxuICBcImNvbnRleHRDaGFuZ2VcIixcbiAgXCJyZXNvbHV0aW9uQ2hhbmdlXCIsXG4gIFwicmVzZXRTdGF0ZVwiLFxuICBcInJlbmRlckVuZFwiLFxuICBcInJlbmRlclN0YXJ0XCIsXG4gIFwicmVuZGVyXCIsXG4gIFwidXBkYXRlXCIsXG4gIFwicG9zdHJlbmRlclwiLFxuICBcInByZXJlbmRlclwiXG5dO1xuY29uc3QgX0Fic3RyYWN0UmVuZGVyZXIgPSBjbGFzcyBfQWJzdHJhY3RSZW5kZXJlciBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIC8qKlxuICAgKiBTZXQgdXAgYSBzeXN0ZW0gd2l0aCBhIGNvbGxlY3Rpb24gb2YgU3lzdGVtQ2xhc3NlcyBhbmQgcnVubmVycy5cbiAgICogU3lzdGVtcyBhcmUgYXR0YWNoZWQgZHluYW1pY2FsbHkgdG8gdGhpcyBjbGFzcyB3aGVuIGFkZGVkLlxuICAgKiBAcGFyYW0gY29uZmlnIC0gdGhlIGNvbmZpZyBmb3IgdGhlIHN5c3RlbSBtYW5hZ2VyXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihjb25maWcpIHtcbiAgICBzdXBlcigpO1xuICAgIC8qKiBUaGUgY3VycmVudCB0aWNrIG9mIHRoZSByZW5kZXJlci4gKi9cbiAgICB0aGlzLnRpY2sgPSAwO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLnVpZCA9IHVpZChcInJlbmRlcmVyXCIpO1xuICAgIC8qKiBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLnJ1bm5lcnMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAvKiogQGludGVybmFsICovXG4gICAgdGhpcy5yZW5kZXJQaXBlcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIHRoaXMuX2luaXRPcHRpb25zID0ge307XG4gICAgdGhpcy5fc3lzdGVtc0hhc2ggPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB0aGlzLnR5cGUgPSBjb25maWcudHlwZTtcbiAgICB0aGlzLm5hbWUgPSBjb25maWcubmFtZTtcbiAgICB0aGlzLmNvbmZpZyA9IGNvbmZpZztcbiAgICBjb25zdCBjb21iaW5lZFJ1bm5lcnMgPSBbLi4uZGVmYXVsdFJ1bm5lcnMsIC4uLnRoaXMuY29uZmlnLnJ1bm5lcnMgPz8gW11dO1xuICAgIHRoaXMuX2FkZFJ1bm5lcnMoLi4uY29tYmluZWRSdW5uZXJzKTtcbiAgICB0aGlzLl91bnNhZmVFdmFsQ2hlY2soKTtcbiAgfVxuICAvKipcbiAgICogSW5pdGlhbGl6ZSB0aGUgcmVuZGVyZXIuXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgdG8gdXNlIHRvIGNyZWF0ZSB0aGUgcmVuZGVyZXIuXG4gICAqL1xuICBhc3luYyBpbml0KG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IHNraXAgPSBvcHRpb25zLnNraXBFeHRlbnNpb25JbXBvcnRzID09PSB0cnVlID8gdHJ1ZSA6IG9wdGlvbnMubWFuYWdlSW1wb3J0cyA9PT0gZmFsc2U7XG4gICAgYXdhaXQgbG9hZEVudmlyb25tZW50RXh0ZW5zaW9ucyhza2lwKTtcbiAgICBpZiAoIXNraXAgJiYgdGhpcy5jb25maWcubG9hZGVycykge1xuICAgICAgYXdhaXQgUHJvbWlzZS5hbGwodGhpcy5jb25maWcubG9hZGVycy5tYXAoKGxvYWRlcikgPT4gbG9hZGVyLnZhbHVlLmxvYWQoKSkpO1xuICAgIH1cbiAgICB0aGlzLl9hZGRTeXN0ZW1zKHRoaXMuY29uZmlnLnN5c3RlbXMpO1xuICAgIHRoaXMuX2FkZFBpcGVzKHRoaXMuY29uZmlnLnJlbmRlclBpcGVzLCB0aGlzLmNvbmZpZy5yZW5kZXJQaXBlQWRhcHRvcnMpO1xuICAgIGZvciAoY29uc3Qgc3lzdGVtTmFtZSBpbiB0aGlzLl9zeXN0ZW1zSGFzaCkge1xuICAgICAgY29uc3Qgc3lzdGVtID0gdGhpcy5fc3lzdGVtc0hhc2hbc3lzdGVtTmFtZV07XG4gICAgICBjb25zdCBkZWZhdWx0U3lzdGVtT3B0aW9ucyA9IHN5c3RlbS5jb25zdHJ1Y3Rvci5kZWZhdWx0T3B0aW9ucztcbiAgICAgIG9wdGlvbnMgPSB7IC4uLmRlZmF1bHRTeXN0ZW1PcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgfVxuICAgIG9wdGlvbnMgPSB7IC4uLl9BYnN0cmFjdFJlbmRlcmVyLmRlZmF1bHRPcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgdGhpcy5fcm91bmRQaXhlbHMgPSBvcHRpb25zLnJvdW5kUGl4ZWxzID8gMSA6IDA7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLnJ1bm5lcnMuaW5pdC5pdGVtcy5sZW5ndGg7IGkrKykge1xuICAgICAgYXdhaXQgdGhpcy5ydW5uZXJzLmluaXQuaXRlbXNbaV0uaW5pdChvcHRpb25zKTtcbiAgICB9XG4gICAgdGhpcy5faW5pdE9wdGlvbnMgPSBvcHRpb25zO1xuICB9XG4gIHJlbmRlcihhcmdzLCBkZXByZWNhdGVkKSB7XG4gICAgdGhpcy50aWNrKys7XG4gICAgbGV0IG9wdGlvbnMgPSBhcmdzO1xuICAgIGlmIChvcHRpb25zIGluc3RhbmNlb2YgQ29udGFpbmVyKSB7XG4gICAgICBvcHRpb25zID0geyBjb250YWluZXI6IG9wdGlvbnMgfTtcbiAgICAgIGlmIChkZXByZWNhdGVkKSB7XG4gICAgICAgIGRlcHJlY2F0aW9uKHY4XzBfMCwgXCJwYXNzaW5nIGEgc2Vjb25kIGFyZ3VtZW50IGlzIGRlcHJlY2F0ZWQsIHBsZWFzZSB1c2UgcmVuZGVyIG9wdGlvbnMgaW5zdGVhZFwiKTtcbiAgICAgICAgb3B0aW9ucy50YXJnZXQgPSBkZXByZWNhdGVkLnJlbmRlclRleHR1cmU7XG4gICAgICB9XG4gICAgfVxuICAgIG9wdGlvbnMudGFyZ2V0IHx8IChvcHRpb25zLnRhcmdldCA9IHRoaXMudmlldy5yZW5kZXJUYXJnZXQpO1xuICAgIGlmIChvcHRpb25zLnRhcmdldCA9PT0gdGhpcy52aWV3LnJlbmRlclRhcmdldCkge1xuICAgICAgdGhpcy5fbGFzdE9iamVjdFJlbmRlcmVkID0gb3B0aW9ucy5jb250YWluZXI7XG4gICAgICBvcHRpb25zLmNsZWFyQ29sb3IgPz8gKG9wdGlvbnMuY2xlYXJDb2xvciA9IHRoaXMuYmFja2dyb3VuZC5jb2xvclJnYmEpO1xuICAgICAgb3B0aW9ucy5jbGVhciA/PyAob3B0aW9ucy5jbGVhciA9IHRoaXMuYmFja2dyb3VuZC5jbGVhckJlZm9yZVJlbmRlcik7XG4gICAgfVxuICAgIGlmIChvcHRpb25zLmNsZWFyQ29sb3IpIHtcbiAgICAgIGNvbnN0IGlzUkdCQUFycmF5ID0gQXJyYXkuaXNBcnJheShvcHRpb25zLmNsZWFyQ29sb3IpICYmIG9wdGlvbnMuY2xlYXJDb2xvci5sZW5ndGggPT09IDQ7XG4gICAgICBvcHRpb25zLmNsZWFyQ29sb3IgPSBpc1JHQkFBcnJheSA/IG9wdGlvbnMuY2xlYXJDb2xvciA6IENvbG9yLnNoYXJlZC5zZXRWYWx1ZShvcHRpb25zLmNsZWFyQ29sb3IpLnRvQXJyYXkoKTtcbiAgICB9XG4gICAgaWYgKCFvcHRpb25zLnRyYW5zZm9ybSkge1xuICAgICAgb3B0aW9ucy5jb250YWluZXIudXBkYXRlTG9jYWxUcmFuc2Zvcm0oKTtcbiAgICAgIG9wdGlvbnMudHJhbnNmb3JtID0gb3B0aW9ucy5jb250YWluZXIubG9jYWxUcmFuc2Zvcm07XG4gICAgfVxuICAgIGlmICghb3B0aW9ucy5jb250YWluZXIudmlzaWJsZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBvcHRpb25zLmNvbnRhaW5lci5lbmFibGVSZW5kZXJHcm91cCgpO1xuICAgIHRoaXMucnVubmVycy5wcmVyZW5kZXIuZW1pdChvcHRpb25zKTtcbiAgICB0aGlzLnJ1bm5lcnMucmVuZGVyU3RhcnQuZW1pdChvcHRpb25zKTtcbiAgICB0aGlzLnJ1bm5lcnMucmVuZGVyLmVtaXQob3B0aW9ucyk7XG4gICAgdGhpcy5ydW5uZXJzLnJlbmRlckVuZC5lbWl0KG9wdGlvbnMpO1xuICAgIHRoaXMucnVubmVycy5wb3N0cmVuZGVyLmVtaXQob3B0aW9ucyk7XG4gIH1cbiAgLyoqXG4gICAqIFJlc2l6ZXMgdGhlIFdlYkdMIHZpZXcgdG8gdGhlIHNwZWNpZmllZCB3aWR0aCBhbmQgaGVpZ2h0LlxuICAgKiBAcGFyYW0gZGVzaXJlZFNjcmVlbldpZHRoIC0gVGhlIGRlc2lyZWQgd2lkdGggb2YgdGhlIHNjcmVlbi5cbiAgICogQHBhcmFtIGRlc2lyZWRTY3JlZW5IZWlnaHQgLSBUaGUgZGVzaXJlZCBoZWlnaHQgb2YgdGhlIHNjcmVlbi5cbiAgICogQHBhcmFtIHJlc29sdXRpb24gLSBUaGUgcmVzb2x1dGlvbiAvIGRldmljZSBwaXhlbCByYXRpbyBvZiB0aGUgcmVuZGVyZXIuXG4gICAqL1xuICByZXNpemUoZGVzaXJlZFNjcmVlbldpZHRoLCBkZXNpcmVkU2NyZWVuSGVpZ2h0LCByZXNvbHV0aW9uKSB7XG4gICAgY29uc3QgcHJldmlvdXNSZXNvbHV0aW9uID0gdGhpcy52aWV3LnJlc29sdXRpb247XG4gICAgdGhpcy52aWV3LnJlc2l6ZShkZXNpcmVkU2NyZWVuV2lkdGgsIGRlc2lyZWRTY3JlZW5IZWlnaHQsIHJlc29sdXRpb24pO1xuICAgIHRoaXMuZW1pdChcInJlc2l6ZVwiLCB0aGlzLnZpZXcuc2NyZWVuLndpZHRoLCB0aGlzLnZpZXcuc2NyZWVuLmhlaWdodCwgdGhpcy52aWV3LnJlc29sdXRpb24pO1xuICAgIGlmIChyZXNvbHV0aW9uICE9PSB2b2lkIDAgJiYgcmVzb2x1dGlvbiAhPT0gcHJldmlvdXNSZXNvbHV0aW9uKSB7XG4gICAgICB0aGlzLnJ1bm5lcnMucmVzb2x1dGlvbkNoYW5nZS5lbWl0KHJlc29sdXRpb24pO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogQ2xlYXJzIHRoZSByZW5kZXIgdGFyZ2V0LlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvcHRpb25zIHRvIHVzZSB3aGVuIGNsZWFyaW5nIHRoZSByZW5kZXIgdGFyZ2V0LlxuICAgKiBAcGFyYW0gb3B0aW9ucy50YXJnZXQgLSBUaGUgcmVuZGVyIHRhcmdldCB0byBjbGVhci5cbiAgICogQHBhcmFtIG9wdGlvbnMuY2xlYXJDb2xvciAtIFRoZSBjb2xvciB0byBjbGVhciB3aXRoLlxuICAgKiBAcGFyYW0gb3B0aW9ucy5jbGVhciAtIFRoZSBjbGVhciBtb2RlIHRvIHVzZS5cbiAgICogQGFkdmFuY2VkXG4gICAqL1xuICBjbGVhcihvcHRpb25zID0ge30pIHtcbiAgICBjb25zdCByZW5kZXJlciA9IHRoaXM7XG4gICAgb3B0aW9ucy50YXJnZXQgfHwgKG9wdGlvbnMudGFyZ2V0ID0gcmVuZGVyZXIucmVuZGVyVGFyZ2V0LnJlbmRlclRhcmdldCk7XG4gICAgb3B0aW9ucy5jbGVhckNvbG9yIHx8IChvcHRpb25zLmNsZWFyQ29sb3IgPSB0aGlzLmJhY2tncm91bmQuY29sb3JSZ2JhKTtcbiAgICBvcHRpb25zLmNsZWFyID8/IChvcHRpb25zLmNsZWFyID0gQ0xFQVIuQUxMKTtcbiAgICBjb25zdCB7IGNsZWFyLCBjbGVhckNvbG9yLCB0YXJnZXQsIG1pcExldmVsLCBsYXllciB9ID0gb3B0aW9ucztcbiAgICBDb2xvci5zaGFyZWQuc2V0VmFsdWUoY2xlYXJDb2xvciA/PyB0aGlzLmJhY2tncm91bmQuY29sb3JSZ2JhKTtcbiAgICByZW5kZXJlci5yZW5kZXJUYXJnZXQuY2xlYXIodGFyZ2V0LCBjbGVhciwgQ29sb3Iuc2hhcmVkLnRvQXJyYXkoKSwgbWlwTGV2ZWwgPz8gMCwgbGF5ZXIgPz8gMCk7XG4gIH1cbiAgLyoqIFRoZSByZXNvbHV0aW9uIC8gZGV2aWNlIHBpeGVsIHJhdGlvIG9mIHRoZSByZW5kZXJlci4gKi9cbiAgZ2V0IHJlc29sdXRpb24oKSB7XG4gICAgcmV0dXJuIHRoaXMudmlldy5yZXNvbHV0aW9uO1xuICB9XG4gIHNldCByZXNvbHV0aW9uKHZhbHVlKSB7XG4gICAgdGhpcy52aWV3LnJlc29sdXRpb24gPSB2YWx1ZTtcbiAgICB0aGlzLnJ1bm5lcnMucmVzb2x1dGlvbkNoYW5nZS5lbWl0KHZhbHVlKTtcbiAgfVxuICAvKipcbiAgICogU2FtZSBhcyB2aWV3LndpZHRoLCBhY3R1YWwgbnVtYmVyIG9mIHBpeGVscyBpbiB0aGUgY2FudmFzIGJ5IGhvcml6b250YWwuXG4gICAqIEB0eXBlIHtudW1iZXJ9XG4gICAqIEByZWFkb25seVxuICAgKiBAZGVmYXVsdCA4MDBcbiAgICovXG4gIGdldCB3aWR0aCgpIHtcbiAgICByZXR1cm4gdGhpcy52aWV3LnRleHR1cmUuZnJhbWUud2lkdGg7XG4gIH1cbiAgLyoqXG4gICAqIFNhbWUgYXMgdmlldy5oZWlnaHQsIGFjdHVhbCBudW1iZXIgb2YgcGl4ZWxzIGluIHRoZSBjYW52YXMgYnkgdmVydGljYWwuXG4gICAqIEBkZWZhdWx0IDYwMFxuICAgKi9cbiAgZ2V0IGhlaWdodCgpIHtcbiAgICByZXR1cm4gdGhpcy52aWV3LnRleHR1cmUuZnJhbWUuaGVpZ2h0O1xuICB9XG4gIC8vIE5PVEU6IHRoaXMgd2FzIGB2aWV3YCBpbiB2N1xuICAvKipcbiAgICogVGhlIGNhbnZhcyBlbGVtZW50IHRoYXQgZXZlcnl0aGluZyBpcyBkcmF3biB0by5cbiAgICogQHR5cGUge2Vudmlyb25tZW50LklDYW52YXN9XG4gICAqL1xuICBnZXQgY2FudmFzKCkge1xuICAgIHJldHVybiB0aGlzLnZpZXcuY2FudmFzO1xuICB9XG4gIC8qKlxuICAgKiB0aGUgbGFzdCBvYmplY3QgcmVuZGVyZWQgYnkgdGhlIHJlbmRlcmVyLiBVc2VmdWwgZm9yIG90aGVyIHBsdWdpbnMgbGlrZSBpbnRlcmFjdGlvbiBtYW5hZ2Vyc1xuICAgKiBAcmVhZG9ubHlcbiAgICovXG4gIGdldCBsYXN0T2JqZWN0UmVuZGVyZWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xhc3RPYmplY3RSZW5kZXJlZDtcbiAgfVxuICAvKipcbiAgICogRmxhZyBpZiB3ZSBhcmUgcmVuZGVyaW5nIHRvIHRoZSBzY3JlZW4gdnMgcmVuZGVyVGV4dHVyZVxuICAgKiBAcmVhZG9ubHlcbiAgICogQGRlZmF1bHQgdHJ1ZVxuICAgKi9cbiAgZ2V0IHJlbmRlcmluZ1RvU2NyZWVuKCkge1xuICAgIGNvbnN0IHJlbmRlcmVyID0gdGhpcztcbiAgICByZXR1cm4gcmVuZGVyZXIucmVuZGVyVGFyZ2V0LnJlbmRlcmluZ1RvU2NyZWVuO1xuICB9XG4gIC8qKlxuICAgKiBNZWFzdXJlbWVudHMgb2YgdGhlIHNjcmVlbi4gKDAsIDAsIHNjcmVlbldpZHRoLCBzY3JlZW5IZWlnaHQpLlxuICAgKlxuICAgKiBJdHMgc2FmZSB0byB1c2UgYXMgZmlsdGVyQXJlYSBvciBoaXRBcmVhIGZvciB0aGUgd2hvbGUgc3RhZ2UuXG4gICAqL1xuICBnZXQgc2NyZWVuKCkge1xuICAgIHJldHVybiB0aGlzLnZpZXcuc2NyZWVuO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBidW5jaCBvZiBydW5uZXJzIGJhc2VkIG9mIGEgY29sbGVjdGlvbiBvZiBpZHNcbiAgICogQHBhcmFtIHJ1bm5lcklkcyAtIHRoZSBydW5uZXIgaWRzIHRvIGFkZFxuICAgKi9cbiAgX2FkZFJ1bm5lcnMoLi4ucnVubmVySWRzKSB7XG4gICAgcnVubmVySWRzLmZvckVhY2goKHJ1bm5lcklkKSA9PiB7XG4gICAgICB0aGlzLnJ1bm5lcnNbcnVubmVySWRdID0gbmV3IFN5c3RlbVJ1bm5lcihydW5uZXJJZCk7XG4gICAgfSk7XG4gIH1cbiAgX2FkZFN5c3RlbXMoc3lzdGVtcykge1xuICAgIGxldCBpO1xuICAgIGZvciAoaSBpbiBzeXN0ZW1zKSB7XG4gICAgICBjb25zdCB2YWwgPSBzeXN0ZW1zW2ldO1xuICAgICAgdGhpcy5fYWRkU3lzdGVtKHZhbC52YWx1ZSwgdmFsLm5hbWUpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogQWRkIGEgbmV3IHN5c3RlbSB0byB0aGUgcmVuZGVyZXIuXG4gICAqIEBwYXJhbSBDbGFzc1JlZiAtIENsYXNzIHJlZmVyZW5jZVxuICAgKiBAcGFyYW0gbmFtZSAtIFByb3BlcnR5IG5hbWUgZm9yIHN5c3RlbSwgaWYgbm90IHNwZWNpZmllZFxuICAgKiAgICAgICAgd2lsbCB1c2UgYSBzdGF0aWMgYG5hbWVgIHByb3BlcnR5IG9uIHRoZSBjbGFzcyBpdHNlbGYuIFRoaXNcbiAgICogICAgICAgIG5hbWUgd2lsbCBiZSBhc3NpZ25lZCBhcyBzIHByb3BlcnR5IG9uIHRoZSBSZW5kZXJlciBzbyBtYWtlXG4gICAqICAgICAgICBzdXJlIGl0IGRvZXNuJ3QgY29sbGlkZSB3aXRoIHByb3BlcnRpZXMgb24gUmVuZGVyZXIuXG4gICAqIEByZXR1cm5zIFJldHVybiBpbnN0YW5jZSBvZiByZW5kZXJlclxuICAgKi9cbiAgX2FkZFN5c3RlbShDbGFzc1JlZiwgbmFtZSkge1xuICAgIGNvbnN0IHN5c3RlbSA9IG5ldyBDbGFzc1JlZih0aGlzKTtcbiAgICBpZiAodGhpc1tuYW1lXSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBXaG9vcHMhIFRoZSBuYW1lIFwiJHtuYW1lfVwiIGlzIGFscmVhZHkgaW4gdXNlYCk7XG4gICAgfVxuICAgIHRoaXNbbmFtZV0gPSBzeXN0ZW07XG4gICAgdGhpcy5fc3lzdGVtc0hhc2hbbmFtZV0gPSBzeXN0ZW07XG4gICAgZm9yIChjb25zdCBpIGluIHRoaXMucnVubmVycykge1xuICAgICAgdGhpcy5ydW5uZXJzW2ldLmFkZChzeXN0ZW0pO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcztcbiAgfVxuICBfYWRkUGlwZXMocGlwZXMsIHBpcGVBZGFwdG9ycykge1xuICAgIGNvbnN0IGFkYXB0b3JzID0gcGlwZUFkYXB0b3JzLnJlZHVjZSgoYWNjLCBhZGFwdG9yKSA9PiB7XG4gICAgICBhY2NbYWRhcHRvci5uYW1lXSA9IGFkYXB0b3IudmFsdWU7XG4gICAgICByZXR1cm4gYWNjO1xuICAgIH0sIHt9KTtcbiAgICBwaXBlcy5mb3JFYWNoKChwaXBlKSA9PiB7XG4gICAgICBjb25zdCBQaXBlQ2xhc3MgPSBwaXBlLnZhbHVlO1xuICAgICAgY29uc3QgbmFtZSA9IHBpcGUubmFtZTtcbiAgICAgIGNvbnN0IEFkYXB0b3IgPSBhZGFwdG9yc1tuYW1lXTtcbiAgICAgIHRoaXMucmVuZGVyUGlwZXNbbmFtZV0gPSBuZXcgUGlwZUNsYXNzKFxuICAgICAgICB0aGlzLFxuICAgICAgICBBZGFwdG9yID8gbmV3IEFkYXB0b3IoKSA6IG51bGxcbiAgICAgICk7XG4gICAgICB0aGlzLnJ1bm5lcnMuZGVzdHJveS5hZGQodGhpcy5yZW5kZXJQaXBlc1tuYW1lXSk7XG4gICAgfSk7XG4gIH1cbiAgZGVzdHJveShvcHRpb25zID0gZmFsc2UpIHtcbiAgICB0aGlzLnJ1bm5lcnMuZGVzdHJveS5pdGVtcy5yZXZlcnNlKCk7XG4gICAgdGhpcy5ydW5uZXJzLmRlc3Ryb3kuZW1pdChvcHRpb25zKTtcbiAgICBpZiAob3B0aW9ucyA9PT0gdHJ1ZSB8fCB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJvYmplY3RcIiAmJiBvcHRpb25zLnJlbGVhc2VHbG9iYWxSZXNvdXJjZXMpIHtcbiAgICAgIEdsb2JhbFJlc291cmNlUmVnaXN0cnkucmVsZWFzZSgpO1xuICAgIH1cbiAgICBPYmplY3QudmFsdWVzKHRoaXMucnVubmVycykuZm9yRWFjaCgocnVubmVyKSA9PiB7XG4gICAgICBydW5uZXIuZGVzdHJveSgpO1xuICAgIH0pO1xuICAgIHRoaXMuX3N5c3RlbXNIYXNoID0gbnVsbDtcbiAgICB0aGlzLnJlbmRlclBpcGVzID0gbnVsbDtcbiAgICB0aGlzLnJlbW92ZUFsbExpc3RlbmVycygpO1xuICB9XG4gIC8qKlxuICAgKiBHZW5lcmF0ZSBhIHRleHR1cmUgZnJvbSBhIGNvbnRhaW5lci5cbiAgICogQHBhcmFtIG9wdGlvbnMgLSBvcHRpb25zIG9yIGNvbnRhaW5lciB0YXJnZXQgdG8gdXNlIHdoZW4gZ2VuZXJhdGluZyB0aGUgdGV4dHVyZVxuICAgKiBAcmV0dXJucyBhIHRleHR1cmVcbiAgICovXG4gIGdlbmVyYXRlVGV4dHVyZShvcHRpb25zKSB7XG4gICAgcmV0dXJuIHRoaXMudGV4dHVyZUdlbmVyYXRvci5nZW5lcmF0ZVRleHR1cmUob3B0aW9ucyk7XG4gIH1cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIHJlbmRlcmVyIHdpbGwgcm91bmQgY29vcmRpbmF0ZXMgdG8gd2hvbGUgcGl4ZWxzIHdoZW4gcmVuZGVyaW5nLlxuICAgKiBDYW4gYmUgb3ZlcnJpZGRlbiBvbiBhIHBlciBzY2VuZSBpdGVtIGJhc2lzLlxuICAgKi9cbiAgZ2V0IHJvdW5kUGl4ZWxzKCkge1xuICAgIHJldHVybiAhIXRoaXMuX3JvdW5kUGl4ZWxzO1xuICB9XG4gIC8qKlxuICAgKiBPdmVycmlkYWJsZSBmdW5jdGlvbiBieSBgcGl4aS5qcy91bnNhZmUtZXZhbGAgdG8gc2lsZW5jZVxuICAgKiB0aHJvd2luZyBhbiBlcnJvciBpZiBwbGF0Zm9ybSBkb2Vzbid0IHN1cHBvcnQgdW5zYWZlLWV2YWxzLlxuICAgKiBAcHJpdmF0ZVxuICAgKiBAaWdub3JlXG4gICAqL1xuICBfdW5zYWZlRXZhbENoZWNrKCkge1xuICAgIGlmICghdW5zYWZlRXZhbFN1cHBvcnRlZCgpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDdXJyZW50IGVudmlyb25tZW50IGRvZXMgbm90IGFsbG93IHVuc2FmZS1ldmFsLCBwbGVhc2UgdXNlIHBpeGkuanMvdW5zYWZlLWV2YWwgbW9kdWxlIHRvIGVuYWJsZSBzdXBwb3J0LlwiKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIFJlc2V0cyB0aGUgcmVuZGVyaW5nIHN0YXRlIG9mIHRoZSByZW5kZXJlci5cbiAgICogVGhpcyBpcyB1c2VmdWwgd2hlbiB5b3Ugd2FudCB0byB1c2UgdGhlIFdlYkdMIGNvbnRleHQgZGlyZWN0bHkgYW5kIG5lZWQgdG8gZW5zdXJlIFBpeGlKUydzIGludGVybmFsIHN0YXRlXG4gICAqIHN0YXlzIHN5bmNocm9uaXplZC4gV2hlbiBtb2RpZnlpbmcgdGhlIFdlYkdMIGNvbnRleHQgc3RhdGUgZXh0ZXJuYWxseSwgY2FsbGluZyB0aGlzIG1ldGhvZCBiZWZvcmUgdGhlIG5leHQgUGl4aVxuICAgKiByZW5kZXIgd2lsbCByZXNldCBhbGwgaW50ZXJuYWwgY2FjaGVzIGFuZCBlbnN1cmUgaXQgZXhlY3V0ZXMgY29ycmVjdGx5LlxuICAgKlxuICAgKiBUaGlzIGlzIHBhcnRpY3VsYXJseSB1c2VmdWwgd2hlbiBjb21iaW5pbmcgUGl4aUpTIHdpdGggb3RoZXIgcmVuZGVyaW5nIGVuZ2luZXMgbGlrZSBUaHJlZS5qczpcbiAgICogYGBganNcbiAgICogLy8gUmVzZXQgVGhyZWUuanMgc3RhdGVcbiAgICogdGhyZWVSZW5kZXJlci5yZXNldFN0YXRlKCk7XG4gICAqXG4gICAqIC8vIFJlbmRlciBhIFRocmVlLmpzIHNjZW5lXG4gICAqIHRocmVlUmVuZGVyZXIucmVuZGVyKHRocmVlU2NlbmUsIHRocmVlQ2FtZXJhKTtcbiAgICpcbiAgICogLy8gUmVzZXQgUGl4aUpTIHN0YXRlIHNpbmNlIFRocmVlLmpzIG1vZGlmaWVkIHRoZSBXZWJHTCBjb250ZXh0XG4gICAqIHBpeGlSZW5kZXJlci5yZXNldFN0YXRlKCk7XG4gICAqXG4gICAqIC8vIE5vdyByZW5kZXIgUGl4aSBjb250ZW50XG4gICAqIHBpeGlSZW5kZXJlci5yZW5kZXIocGl4aVNjZW5lKTtcbiAgICogYGBgXG4gICAqIEBhZHZhbmNlZFxuICAgKi9cbiAgcmVzZXRTdGF0ZSgpIHtcbiAgICB0aGlzLnJ1bm5lcnMucmVzZXRTdGF0ZS5lbWl0KCk7XG4gIH1cbn07XG4vKiogVGhlIGRlZmF1bHQgb3B0aW9ucyBmb3IgdGhlIHJlbmRlcmVyLiAqL1xuX0Fic3RyYWN0UmVuZGVyZXIuZGVmYXVsdE9wdGlvbnMgPSB7XG4gIC8qKlxuICAgKiBEZWZhdWx0IHJlc29sdXRpb24gLyBkZXZpY2UgcGl4ZWwgcmF0aW8gb2YgdGhlIHJlbmRlcmVyLlxuICAgKiBAZGVmYXVsdCAxXG4gICAqL1xuICByZXNvbHV0aW9uOiAxLFxuICAvKipcbiAgICogU2hvdWxkIHRoZSBgZmFpbElmTWFqb3JQZXJmb3JtYW5jZUNhdmVhdGAgZmxhZyBiZSBlbmFibGVkIGFzIGEgY29udGV4dCBvcHRpb24gdXNlZCBpbiB0aGUgYGlzV2ViR0xTdXBwb3J0ZWRgXG4gICAqIGZ1bmN0aW9uLiBJZiBzZXQgdG8gdHJ1ZSwgYSBXZWJHTCByZW5kZXJlciBjYW4gZmFpbCB0byBiZSBjcmVhdGVkIGlmIHRoZSBicm93c2VyIHRoaW5rcyB0aGVyZSBjb3VsZCBiZVxuICAgKiBwZXJmb3JtYW5jZSBpc3N1ZXMgd2hlbiB1c2luZyBXZWJHTC5cbiAgICpcbiAgICogSW4gUGl4aUpTIHY2IHRoaXMgaGFzIGNoYW5nZWQgZnJvbSB0cnVlIHRvIGZhbHNlIGJ5IGRlZmF1bHQsIHRvIGFsbG93IFdlYkdMIHRvIHdvcmsgaW4gYXMgbWFueVxuICAgKiBzY2VuYXJpb3MgYXMgcG9zc2libGUuIEhvd2V2ZXIsIHNvbWUgdXNlcnMgbWF5IGhhdmUgYSBwb29yIGV4cGVyaWVuY2UsIGZvciBleGFtcGxlLCBpZiBhIHVzZXIgaGFzIGEgZ3B1IG9yXG4gICAqIGRyaXZlciB2ZXJzaW9uIGJsYWNrbGlzdGVkIGJ5IHRoZVxuICAgKiBicm93c2VyLlxuICAgKlxuICAgKiBJZiB5b3VyIGFwcGxpY2F0aW9uIHJlcXVpcmVzIGhpZ2ggcGVyZm9ybWFuY2UgcmVuZGVyaW5nLCB5b3UgbWF5IHdpc2ggdG8gc2V0IHRoaXMgdG8gZmFsc2UuXG4gICAqIFdlIHJlY29tbWVuZCBvbmUgb2YgdHdvIG9wdGlvbnMgaWYgeW91IGRlY2lkZSB0byBzZXQgdGhpcyBmbGFnIHRvIGZhbHNlOlxuICAgKlxuICAgKiAxOiBVc2UgdGhlIENhbnZhcyByZW5kZXJlciBhcyBhIGZhbGxiYWNrIGluIGNhc2UgaGlnaCBwZXJmb3JtYW5jZSBXZWJHTCBpc1xuICAgKiAgICBub3Qgc3VwcG9ydGVkLlxuICAgKlxuICAgKiAyOiBDYWxsIGBpc1dlYkdMU3VwcG9ydGVkYCAod2hpY2ggaWYgZm91bmQgaW4gdGhlIHV0aWxzIHBhY2thZ2UpIGluIHlvdXIgY29kZSBiZWZvcmUgYXR0ZW1wdGluZyB0byBjcmVhdGUgYVxuICAgKiAgICBQaXhpSlMgcmVuZGVyZXIsIGFuZCBzaG93IGFuIGVycm9yIG1lc3NhZ2UgdG8gdGhlIHVzZXIgaWYgdGhlIGZ1bmN0aW9uIHJldHVybnMgZmFsc2UsIGV4cGxhaW5pbmcgdGhhdCB0aGVpclxuICAgKiAgICBkZXZpY2UgJiBicm93c2VyIGNvbWJpbmF0aW9uIGRvZXMgbm90IHN1cHBvcnQgaGlnaCBwZXJmb3JtYW5jZSBXZWJHTC5cbiAgICogICAgVGhpcyBpcyBhIG11Y2ggYmV0dGVyIHN0cmF0ZWd5IHRoYW4gdHJ5aW5nIHRvIGNyZWF0ZSBhIFBpeGlKUyByZW5kZXJlciBhbmQgZmluZGluZyBpdCB0aGVuIGZhaWxzLlxuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgZmFpbElmTWFqb3JQZXJmb3JtYW5jZUNhdmVhdDogZmFsc2UsXG4gIC8qKlxuICAgKiBTaG91bGQgcm91bmQgcGl4ZWxzIGJlIGZvcmNlZCB3aGVuIHJlbmRlcmluZz9cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIHJvdW5kUGl4ZWxzOiBmYWxzZVxufTtcbmxldCBBYnN0cmFjdFJlbmRlcmVyID0gX0Fic3RyYWN0UmVuZGVyZXI7XG5cbmV4cG9ydCB7IEFic3RyYWN0UmVuZGVyZXIgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUFic3RyYWN0UmVuZGVyZXIubWpzLm1hcFxuIiwiZXhwb3J0IHsgZGVmYXVsdCBhcyBFdmVudEVtaXR0ZXIgfSBmcm9tICdldmVudGVtaXR0ZXIzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBEQVRBX1VSSSA9IC9eXFxzKmRhdGE6KD86KFtcXHctXSspXFwvKFtcXHcrLi1dKykpPyg/OjtjaGFyc2V0PShbXFx3LV0rKSk/KD86OyhiYXNlNjQpKT8sKC4qKS9pO1xuY29uc3QgVkVSU0lPTiA9IFwiOC4yMi4wXCI7XG5cbmV4cG9ydCB7IERBVEFfVVJJLCBWRVJTSU9OIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb25zdC5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBWRVJTSU9OIH0gZnJvbSAnLi4vY29uc3QubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBBcHBsaWNhdGlvbkluaXRIb29rIHtcbiAgc3RhdGljIGluaXQoKSB7XG4gICAgZ2xvYmFsVGhpcy5fX1BJWElfQVBQX0lOSVRfXz8uKHRoaXMsIFZFUlNJT04pO1xuICB9XG4gIHN0YXRpYyBkZXN0cm95KCkge1xuICB9XG59XG4vKiogQGlnbm9yZSAqL1xuQXBwbGljYXRpb25Jbml0SG9vay5leHRlbnNpb24gPSBFeHRlbnNpb25UeXBlLkFwcGxpY2F0aW9uO1xuY2xhc3MgUmVuZGVyZXJJbml0SG9vayB7XG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSByZW5kZXJlcjtcbiAgfVxuICBpbml0KCkge1xuICAgIGdsb2JhbFRoaXMuX19QSVhJX1JFTkRFUkVSX0lOSVRfXz8uKHRoaXMuX3JlbmRlcmVyLCBWRVJTSU9OKTtcbiAgfVxuICBkZXN0cm95KCkge1xuICAgIHRoaXMuX3JlbmRlcmVyID0gbnVsbDtcbiAgfVxufVxuLyoqIEBpZ25vcmUgKi9cblJlbmRlcmVySW5pdEhvb2suZXh0ZW5zaW9uID0ge1xuICB0eXBlOiBbXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHTFN5c3RlbSxcbiAgICBFeHRlbnNpb25UeXBlLldlYkdQVVN5c3RlbVxuICBdLFxuICBuYW1lOiBcImluaXRIb29rXCIsXG4gIHByaW9yaXR5OiAtMTBcbn07XG5cbmV4cG9ydCB7IEFwcGxpY2F0aW9uSW5pdEhvb2ssIFJlbmRlcmVySW5pdEhvb2sgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWdsb2JhbEhvb2tzLm1qcy5tYXBcbiIsInZhciBmcmFnbWVudCA9IFwiaW4gdmVjMiB2TWFza0Nvb3JkO1xcbmluIHZlYzIgdlRleHR1cmVDb29yZDtcXG5cXG51bmlmb3JtIHNhbXBsZXIyRCB1VGV4dHVyZTtcXG51bmlmb3JtIHNhbXBsZXIyRCB1TWFza1RleHR1cmU7XFxuXFxudW5pZm9ybSBmbG9hdCB1QWxwaGE7XFxudW5pZm9ybSB2ZWM0IHVNYXNrQ2xhbXA7XFxudW5pZm9ybSBmbG9hdCB1SW52ZXJzZTtcXG51bmlmb3JtIGZsb2F0IHVDaGFubmVsO1xcblxcbm91dCB2ZWM0IGZpbmFsQ29sb3I7XFxuXFxudm9pZCBtYWluKHZvaWQpXFxue1xcbiAgICBmbG9hdCBjbGlwID0gc3RlcCgzLjUsXFxuICAgICAgICBzdGVwKHVNYXNrQ2xhbXAueCwgdk1hc2tDb29yZC54KSArXFxuICAgICAgICBzdGVwKHVNYXNrQ2xhbXAueSwgdk1hc2tDb29yZC55KSArXFxuICAgICAgICBzdGVwKHZNYXNrQ29vcmQueCwgdU1hc2tDbGFtcC56KSArXFxuICAgICAgICBzdGVwKHZNYXNrQ29vcmQueSwgdU1hc2tDbGFtcC53KSk7XFxuXFxuICAgIC8vIFRPRE8gbG9vayBpbnRvIHdoeSB0aGlzIGlzIG5lZWRlZFxcbiAgICBmbG9hdCBucG1BbHBoYSA9IHVBbHBoYTtcXG4gICAgdmVjNCBvcmlnaW5hbCA9IHRleHR1cmUodVRleHR1cmUsIHZUZXh0dXJlQ29vcmQpO1xcbiAgICB2ZWM0IG1hc2t5ID0gdGV4dHVyZSh1TWFza1RleHR1cmUsIHZNYXNrQ29vcmQpO1xcblxcbiAgICBmbG9hdCBhO1xcbiAgICBpZiAodUNoYW5uZWwgPT0gMS4wKSB7XFxuICAgICAgICBhID0gbWFza3kuYSAqIG5wbUFscGhhICogY2xpcDtcXG4gICAgfSBlbHNlIHtcXG4gICAgICAgIGZsb2F0IGFscGhhTXVsID0gMS4wIC0gbnBtQWxwaGEgKiAoMS4wIC0gbWFza3kuYSk7XFxuICAgICAgICBhID0gYWxwaGFNdWwgKiBtYXNreS5yICogbnBtQWxwaGEgKiBjbGlwO1xcbiAgICB9XFxuXFxuICAgIGlmICh1SW52ZXJzZSA9PSAxLjApIHtcXG4gICAgICAgIGEgPSAxLjAgLSBhO1xcbiAgICB9XFxuXFxuICAgIGZpbmFsQ29sb3IgPSBvcmlnaW5hbCAqIGE7XFxufVxcblwiO1xuXG5leHBvcnQgeyBmcmFnbWVudCBhcyBkZWZhdWx0IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tYXNrLmZyYWcubWpzLm1hcFxuIiwidmFyIHZlcnRleCA9IFwiaW4gdmVjMiBhUG9zaXRpb247XFxuXFxub3V0IHZlYzIgdlRleHR1cmVDb29yZDtcXG5vdXQgdmVjMiB2TWFza0Nvb3JkO1xcblxcblxcbnVuaWZvcm0gdmVjNCB1SW5wdXRTaXplO1xcbnVuaWZvcm0gdmVjNCB1T3V0cHV0RnJhbWU7XFxudW5pZm9ybSB2ZWM0IHVPdXRwdXRUZXh0dXJlO1xcbnVuaWZvcm0gbWF0MyB1RmlsdGVyTWF0cml4O1xcblxcbnZlYzQgZmlsdGVyVmVydGV4UG9zaXRpb24oICB2ZWMyIGFQb3NpdGlvbiApXFxue1xcbiAgICB2ZWMyIHBvc2l0aW9uID0gYVBvc2l0aW9uICogdU91dHB1dEZyYW1lLnp3ICsgdU91dHB1dEZyYW1lLnh5O1xcbiAgICAgICBcXG4gICAgcG9zaXRpb24ueCA9IHBvc2l0aW9uLnggKiAoMi4wIC8gdU91dHB1dFRleHR1cmUueCkgLSAxLjA7XFxuICAgIHBvc2l0aW9uLnkgPSBwb3NpdGlvbi55ICogKDIuMCp1T3V0cHV0VGV4dHVyZS56IC8gdU91dHB1dFRleHR1cmUueSkgLSB1T3V0cHV0VGV4dHVyZS56O1xcblxcbiAgICByZXR1cm4gdmVjNChwb3NpdGlvbiwgMC4wLCAxLjApO1xcbn1cXG5cXG52ZWMyIGZpbHRlclRleHR1cmVDb29yZCggIHZlYzIgYVBvc2l0aW9uIClcXG57XFxuICAgIHJldHVybiBhUG9zaXRpb24gKiAodU91dHB1dEZyYW1lLnp3ICogdUlucHV0U2l6ZS56dyk7XFxufVxcblxcbnZlYzIgZ2V0RmlsdGVyQ29vcmQoIHZlYzIgYVBvc2l0aW9uIClcXG57XFxuICAgIHJldHVybiAgKCB1RmlsdGVyTWF0cml4ICogdmVjMyggZmlsdGVyVGV4dHVyZUNvb3JkKGFQb3NpdGlvbiksIDEuMCkgICkueHk7XFxufSAgIFxcblxcbnZvaWQgbWFpbih2b2lkKVxcbntcXG4gICAgZ2xfUG9zaXRpb24gPSBmaWx0ZXJWZXJ0ZXhQb3NpdGlvbihhUG9zaXRpb24pO1xcbiAgICB2VGV4dHVyZUNvb3JkID0gZmlsdGVyVGV4dHVyZUNvb3JkKGFQb3NpdGlvbik7XFxuICAgIHZNYXNrQ29vcmQgPSBnZXRGaWx0ZXJDb29yZChhUG9zaXRpb24pO1xcbn1cXG5cIjtcblxuZXhwb3J0IHsgdmVydGV4IGFzIGRlZmF1bHQgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW1hc2sudmVydC5tanMubWFwXG4iLCJ2YXIgc291cmNlID0gXCJzdHJ1Y3QgR2xvYmFsRmlsdGVyVW5pZm9ybXMge1xcbiAgdUlucHV0U2l6ZTp2ZWM0PGYzMj4sXFxuICB1SW5wdXRQaXhlbDp2ZWM0PGYzMj4sXFxuICB1SW5wdXRDbGFtcDp2ZWM0PGYzMj4sXFxuICB1T3V0cHV0RnJhbWU6dmVjNDxmMzI+LFxcbiAgdUdsb2JhbEZyYW1lOnZlYzQ8ZjMyPixcXG4gIHVPdXRwdXRUZXh0dXJlOnZlYzQ8ZjMyPixcXG59O1xcblxcbnN0cnVjdCBNYXNrVW5pZm9ybXMge1xcbiAgdUZpbHRlck1hdHJpeDptYXQzeDM8ZjMyPixcXG4gIHVNYXNrQ2xhbXA6dmVjNDxmMzI+LFxcbiAgdUFscGhhOmYzMixcXG4gIHVJbnZlcnNlOmYzMixcXG4gIHVDaGFubmVsOmYzMixcXG59O1xcblxcbkBncm91cCgwKSBAYmluZGluZygwKSB2YXI8dW5pZm9ybT4gZ2Z1OiBHbG9iYWxGaWx0ZXJVbmlmb3JtcztcXG5AZ3JvdXAoMCkgQGJpbmRpbmcoMSkgdmFyIHVUZXh0dXJlOiB0ZXh0dXJlXzJkPGYzMj47XFxuQGdyb3VwKDApIEBiaW5kaW5nKDIpIHZhciB1U2FtcGxlciA6IHNhbXBsZXI7XFxuXFxuQGdyb3VwKDEpIEBiaW5kaW5nKDApIHZhcjx1bmlmb3JtPiBmaWx0ZXJVbmlmb3JtcyA6IE1hc2tVbmlmb3JtcztcXG5AZ3JvdXAoMSkgQGJpbmRpbmcoMSkgdmFyIHVNYXNrVGV4dHVyZTogdGV4dHVyZV8yZDxmMzI+O1xcblxcbnN0cnVjdCBWU091dHB1dCB7XFxuICAgIEBidWlsdGluKHBvc2l0aW9uKSBwb3NpdGlvbjogdmVjNDxmMzI+LFxcbiAgICBAbG9jYXRpb24oMCkgdXYgOiB2ZWMyPGYzMj4sXFxuICAgIEBsb2NhdGlvbigxKSBmaWx0ZXJVdiA6IHZlYzI8ZjMyPixcXG59O1xcblxcbmZuIGZpbHRlclZlcnRleFBvc2l0aW9uKGFQb3NpdGlvbjp2ZWMyPGYzMj4pIC0+IHZlYzQ8ZjMyPlxcbntcXG4gICAgdmFyIHBvc2l0aW9uID0gYVBvc2l0aW9uICogZ2Z1LnVPdXRwdXRGcmFtZS56dyArIGdmdS51T3V0cHV0RnJhbWUueHk7XFxuXFxuICAgIHBvc2l0aW9uLnggPSBwb3NpdGlvbi54ICogKDIuMCAvIGdmdS51T3V0cHV0VGV4dHVyZS54KSAtIDEuMDtcXG4gICAgcG9zaXRpb24ueSA9IHBvc2l0aW9uLnkgKiAoMi4wKmdmdS51T3V0cHV0VGV4dHVyZS56IC8gZ2Z1LnVPdXRwdXRUZXh0dXJlLnkpIC0gZ2Z1LnVPdXRwdXRUZXh0dXJlLno7XFxuXFxuICAgIHJldHVybiB2ZWM0KHBvc2l0aW9uLCAwLjAsIDEuMCk7XFxufVxcblxcbmZuIGZpbHRlclRleHR1cmVDb29yZCggYVBvc2l0aW9uOnZlYzI8ZjMyPiApIC0+IHZlYzI8ZjMyPlxcbntcXG4gICAgcmV0dXJuIGFQb3NpdGlvbiAqIChnZnUudU91dHB1dEZyYW1lLnp3ICogZ2Z1LnVJbnB1dFNpemUuencpO1xcbn1cXG5cXG5mbiBnbG9iYWxUZXh0dXJlQ29vcmQoIGFQb3NpdGlvbjp2ZWMyPGYzMj4gKSAtPiB2ZWMyPGYzMj5cXG57XFxuICByZXR1cm4gIChhUG9zaXRpb24ueHkgLyBnZnUudUdsb2JhbEZyYW1lLnp3KSArIChnZnUudUdsb2JhbEZyYW1lLnh5IC8gZ2Z1LnVHbG9iYWxGcmFtZS56dyk7XFxufVxcblxcbmZuIGdldEZpbHRlckNvb3JkKGFQb3NpdGlvbjp2ZWMyPGYzMj4gKSAtPiB2ZWMyPGYzMj5cXG57XFxuICByZXR1cm4gKCBmaWx0ZXJVbmlmb3Jtcy51RmlsdGVyTWF0cml4ICogdmVjMyggZmlsdGVyVGV4dHVyZUNvb3JkKGFQb3NpdGlvbiksIDEuMCkgICkueHk7XFxufVxcblxcbmZuIGdldFNpemUoKSAtPiB2ZWMyPGYzMj5cXG57XFxuICByZXR1cm4gZ2Z1LnVHbG9iYWxGcmFtZS56dztcXG59XFxuXFxuQHZlcnRleFxcbmZuIG1haW5WZXJ0ZXgoXFxuICBAbG9jYXRpb24oMCkgYVBvc2l0aW9uIDogdmVjMjxmMzI+LFxcbikgLT4gVlNPdXRwdXQge1xcbiAgcmV0dXJuIFZTT3V0cHV0KFxcbiAgIGZpbHRlclZlcnRleFBvc2l0aW9uKGFQb3NpdGlvbiksXFxuICAgZmlsdGVyVGV4dHVyZUNvb3JkKGFQb3NpdGlvbiksXFxuICAgZ2V0RmlsdGVyQ29vcmQoYVBvc2l0aW9uKVxcbiAgKTtcXG59XFxuXFxuQGZyYWdtZW50XFxuZm4gbWFpbkZyYWdtZW50KFxcbiAgQGxvY2F0aW9uKDApIHV2OiB2ZWMyPGYzMj4sXFxuICBAbG9jYXRpb24oMSkgZmlsdGVyVXY6IHZlYzI8ZjMyPixcXG4gIEBidWlsdGluKHBvc2l0aW9uKSBwb3NpdGlvbjogdmVjNDxmMzI+XFxuKSAtPiBAbG9jYXRpb24oMCkgdmVjNDxmMzI+IHtcXG5cXG4gICAgdmFyIG1hc2tDbGFtcCA9IGZpbHRlclVuaWZvcm1zLnVNYXNrQ2xhbXA7XFxuICAgIHZhciB1QWxwaGEgPSBmaWx0ZXJVbmlmb3Jtcy51QWxwaGE7XFxuXFxuICAgIHZhciBjbGlwID0gc3RlcCgzLjUsXFxuICAgICAgc3RlcChtYXNrQ2xhbXAueCwgZmlsdGVyVXYueCkgK1xcbiAgICAgIHN0ZXAobWFza0NsYW1wLnksIGZpbHRlclV2LnkpICtcXG4gICAgICBzdGVwKGZpbHRlclV2LngsIG1hc2tDbGFtcC56KSArXFxuICAgICAgc3RlcChmaWx0ZXJVdi55LCBtYXNrQ2xhbXAudykpO1xcblxcbiAgICB2YXIgbWFzayA9IHRleHR1cmVTYW1wbGUodU1hc2tUZXh0dXJlLCB1U2FtcGxlciwgZmlsdGVyVXYpO1xcbiAgICB2YXIgc291cmNlID0gdGV4dHVyZVNhbXBsZSh1VGV4dHVyZSwgdVNhbXBsZXIsIHV2KTtcXG5cXG4gICAgdmFyIGE6IGYzMjtcXG4gICAgaWYgKGZpbHRlclVuaWZvcm1zLnVDaGFubmVsID09IDEuMCkge1xcbiAgICAgICAgYSA9IG1hc2suYSAqIHVBbHBoYSAqIGNsaXA7XFxuICAgIH0gZWxzZSB7XFxuICAgICAgICB2YXIgYWxwaGFNdWwgPSAxLjAgLSB1QWxwaGEgKiAoMS4wIC0gbWFzay5hKTtcXG4gICAgICAgIGEgPSBhbHBoYU11bCAqIG1hc2suciAqIHVBbHBoYSAqIGNsaXA7XFxuICAgIH1cXG5cXG4gICAgaWYgKGZpbHRlclVuaWZvcm1zLnVJbnZlcnNlID09IDEuMCkge1xcbiAgICAgICAgYSA9IDEuMCAtIGE7XFxuICAgIH1cXG5cXG4gICAgcmV0dXJuIHNvdXJjZSAqIGE7XFxufVxcblwiO1xuXG5leHBvcnQgeyBzb3VyY2UgYXMgZGVmYXVsdCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bWFzay53Z3NsLm1qcy5tYXBcbiIsImltcG9ydCB7IE1hdHJpeCB9IGZyb20gJy4uLy4uL21hdGhzL21hdHJpeC9NYXRyaXgubWpzJztcbmltcG9ydCB7IEdsUHJvZ3JhbSB9IGZyb20gJy4uLy4uL3JlbmRlcmluZy9yZW5kZXJlcnMvZ2wvc2hhZGVyL0dsUHJvZ3JhbS5tanMnO1xuaW1wb3J0IHsgR3B1UHJvZ3JhbSB9IGZyb20gJy4uLy4uL3JlbmRlcmluZy9yZW5kZXJlcnMvZ3B1L3NoYWRlci9HcHVQcm9ncmFtLm1qcyc7XG5pbXBvcnQgeyBVbmlmb3JtR3JvdXAgfSBmcm9tICcuLi8uLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9zaGFkZXIvVW5pZm9ybUdyb3VwLm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlIH0gZnJvbSAnLi4vLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9UZXh0dXJlLm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlTWF0cml4IH0gZnJvbSAnLi4vLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9UZXh0dXJlTWF0cml4Lm1qcyc7XG5pbXBvcnQgeyB3YXJuIH0gZnJvbSAnLi4vLi4vdXRpbHMvbG9nZ2luZy93YXJuLm1qcyc7XG5pbXBvcnQgeyBGaWx0ZXIgfSBmcm9tICcuLi9GaWx0ZXIubWpzJztcbmltcG9ydCBmcmFnbWVudCBmcm9tICcuL21hc2suZnJhZy5tanMnO1xuaW1wb3J0IHZlcnRleCBmcm9tICcuL21hc2sudmVydC5tanMnO1xuaW1wb3J0IHNvdXJjZSBmcm9tICcuL21hc2sud2dzbC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIE1hc2tGaWx0ZXIgZXh0ZW5kcyBGaWx0ZXIge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgY29uc3QgeyBzcHJpdGUsIC4uLnJlc3QgfSA9IG9wdGlvbnM7XG4gICAgY29uc3QgdGV4dHVyZU1hdHJpeCA9IG5ldyBUZXh0dXJlTWF0cml4KHNwcml0ZS50ZXh0dXJlKTtcbiAgICBjb25zdCBmaWx0ZXJVbmlmb3JtcyA9IG5ldyBVbmlmb3JtR3JvdXAoe1xuICAgICAgdUZpbHRlck1hdHJpeDogeyB2YWx1ZTogbmV3IE1hdHJpeCgpLCB0eXBlOiBcIm1hdDN4MzxmMzI+XCIgfSxcbiAgICAgIHVNYXNrQ2xhbXA6IHsgdmFsdWU6IHRleHR1cmVNYXRyaXgudUNsYW1wRnJhbWUsIHR5cGU6IFwidmVjNDxmMzI+XCIgfSxcbiAgICAgIHVBbHBoYTogeyB2YWx1ZTogMSwgdHlwZTogXCJmMzJcIiB9LFxuICAgICAgdUludmVyc2U6IHsgdmFsdWU6IG9wdGlvbnMuaW52ZXJzZSA/IDEgOiAwLCB0eXBlOiBcImYzMlwiIH0sXG4gICAgICB1Q2hhbm5lbDogeyB2YWx1ZTogb3B0aW9ucy5jaGFubmVsID09PSBcImFscGhhXCIgPyAxIDogMCwgdHlwZTogXCJmMzJcIiB9XG4gICAgfSk7XG4gICAgY29uc3QgZ3B1UHJvZ3JhbSA9IEdwdVByb2dyYW0uZnJvbSh7XG4gICAgICB2ZXJ0ZXg6IHtcbiAgICAgICAgc291cmNlLFxuICAgICAgICBlbnRyeVBvaW50OiBcIm1haW5WZXJ0ZXhcIlxuICAgICAgfSxcbiAgICAgIGZyYWdtZW50OiB7XG4gICAgICAgIHNvdXJjZSxcbiAgICAgICAgZW50cnlQb2ludDogXCJtYWluRnJhZ21lbnRcIlxuICAgICAgfVxuICAgIH0pO1xuICAgIGNvbnN0IGdsUHJvZ3JhbSA9IEdsUHJvZ3JhbS5mcm9tKHtcbiAgICAgIHZlcnRleCxcbiAgICAgIGZyYWdtZW50LFxuICAgICAgbmFtZTogXCJtYXNrLWZpbHRlclwiXG4gICAgfSk7XG4gICAgc3VwZXIoe1xuICAgICAgLi4ucmVzdCxcbiAgICAgIGdwdVByb2dyYW0sXG4gICAgICBnbFByb2dyYW0sXG4gICAgICBjbGlwVG9WaWV3cG9ydDogZmFsc2UsXG4gICAgICByZXNvdXJjZXM6IHtcbiAgICAgICAgZmlsdGVyVW5pZm9ybXMsXG4gICAgICAgIHVNYXNrVGV4dHVyZTogc3ByaXRlLnRleHR1cmUuc291cmNlXG4gICAgICB9XG4gICAgfSk7XG4gICAgdGhpcy5zcHJpdGUgPSBzcHJpdGU7XG4gICAgdGhpcy5fdGV4dHVyZU1hdHJpeCA9IHRleHR1cmVNYXRyaXg7XG4gIH1cbiAgLyoqXG4gICAqIFJlYmluZHMgdGhlIGZpbHRlciB0byBhIG5ldyBtYXNrIHNwcml0ZSwgbW92aW5nIHRoZSB0ZXh0dXJlLW1hdHJpeCBgdXBkYXRlYFxuICAgKiBsaXN0ZW5lciBhbmQgdGhlIGJpbmQgZ3JvdXAncyBgY2hhbmdlYCBzdWJzY3JpcHRpb24gb3ZlciB0byB0aGUgbmV3IHNwcml0ZSdzXG4gICAqIHRleHR1cmUuIGBhcHBseWAgcmVmcmVzaGVzIHRoZSBzYW1lIGJpbmRpbmdzIG9uIGV2ZXJ5IHVzZSDigJQgdGhpcyBtZXRob2QgZXhpc3RzXG4gICAqIHRvIHJlbGVhc2UgdGhlIHByZXZpb3VzIHNwcml0ZSdzIHRleHR1cmUgaW1tZWRpYXRlbHksIHdpdGhvdXQgd2FpdGluZyBmb3JcbiAgICogKG9yIHJlcXVpcmluZykgYW5vdGhlciBgYXBwbHlgLlxuICAgKiBAcGFyYW0gc3ByaXRlIC0gdGhlIHNwcml0ZSB0byBtYXNrIHdpdGggZnJvbSBub3cgb24uXG4gICAqL1xuICBzZXRTcHJpdGUoc3ByaXRlKSB7XG4gICAgdGhpcy5zcHJpdGUgPSBzcHJpdGU7XG4gICAgY29uc3QgdGV4dHVyZSA9IHRoaXMuX2dldFNhZmVUZXh0dXJlKCk7XG4gICAgdGhpcy5fdGV4dHVyZU1hdHJpeC50ZXh0dXJlID0gdGV4dHVyZTtcbiAgICB0aGlzLnJlc291cmNlcy51TWFza1RleHR1cmUgPSB0ZXh0dXJlLnNvdXJjZTtcbiAgfVxuICBzZXQgaW52ZXJzZSh2YWx1ZSkge1xuICAgIHRoaXMucmVzb3VyY2VzLmZpbHRlclVuaWZvcm1zLnVuaWZvcm1zLnVJbnZlcnNlID0gdmFsdWUgPyAxIDogMDtcbiAgfVxuICBnZXQgaW52ZXJzZSgpIHtcbiAgICByZXR1cm4gdGhpcy5yZXNvdXJjZXMuZmlsdGVyVW5pZm9ybXMudW5pZm9ybXMudUludmVyc2UgPT09IDE7XG4gIH1cbiAgc2V0IGNoYW5uZWwodmFsdWUpIHtcbiAgICB0aGlzLnJlc291cmNlcy5maWx0ZXJVbmlmb3Jtcy51bmlmb3Jtcy51Q2hhbm5lbCA9IHZhbHVlID09PSBcImFscGhhXCIgPyAxIDogMDtcbiAgfVxuICBnZXQgY2hhbm5lbCgpIHtcbiAgICByZXR1cm4gdGhpcy5yZXNvdXJjZXMuZmlsdGVyVW5pZm9ybXMudW5pZm9ybXMudUNoYW5uZWwgPT09IDEgPyBcImFscGhhXCIgOiBcInJlZFwiO1xuICB9XG4gIGFwcGx5KGZpbHRlck1hbmFnZXIsIGlucHV0LCBvdXRwdXQsIGNsZWFyTW9kZSkge1xuICAgIGNvbnN0IHRleHR1cmUgPSB0aGlzLl9nZXRTYWZlVGV4dHVyZSgpO1xuICAgIHRoaXMuX3RleHR1cmVNYXRyaXgudGV4dHVyZSA9IHRleHR1cmU7XG4gICAgZmlsdGVyTWFuYWdlci5jYWxjdWxhdGVTcHJpdGVNYXRyaXgoXG4gICAgICB0aGlzLnJlc291cmNlcy5maWx0ZXJVbmlmb3Jtcy51bmlmb3Jtcy51RmlsdGVyTWF0cml4LFxuICAgICAgdGhpcy5zcHJpdGVcbiAgICApLnByZXBlbmQodGhpcy5fdGV4dHVyZU1hdHJpeC5tYXBDb29yZCk7XG4gICAgdGhpcy5yZXNvdXJjZXMudU1hc2tUZXh0dXJlID0gdGV4dHVyZS5zb3VyY2U7XG4gICAgZmlsdGVyTWFuYWdlci5hcHBseUZpbHRlcih0aGlzLCBpbnB1dCwgb3V0cHV0LCBjbGVhck1vZGUpO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgc3ByaXRlJ3MgdGV4dHVyZSwgb3IgYFRleHR1cmUuRU1QVFlgIHdoZW4gdGhhdCB0ZXh0dXJlIGhhcyBiZWVuIGRlc3Ryb3llZCDigJRcbiAgICogYSBkZXN0cm95ZWQgdGV4dHVyZSBoYXMgbm8gc291cmNlIGxlZnQgdG8gc2FtcGxlLCBzbyB0aGUgbWFzayBkZWdyYWRlcyB0byBlbXB0eVxuICAgKiByYXRoZXIgdGhhbiBjcmFzaGluZyB0aGUgcmVuZGVyLlxuICAgKi9cbiAgX2dldFNhZmVUZXh0dXJlKCkge1xuICAgIGNvbnN0IHRleHR1cmUgPSB0aGlzLnNwcml0ZS50ZXh0dXJlO1xuICAgIGlmICh0ZXh0dXJlLmRlc3Ryb3llZCB8fCAhdGV4dHVyZS5zb3VyY2UgfHwgdGV4dHVyZS5zb3VyY2UuZGVzdHJveWVkKSB7XG4gICAgICB3YXJuKFwiW01hc2tGaWx0ZXJdIFRoZSBtYXNrIHRleHR1cmUgd2FzIGRlc3Ryb3llZCB3aGlsZSB0aGUgbWFzayBpcyBzdGlsbCBpbiB1c2UuIFJlbW92ZSB0aGUgbWFzayBiZWZvcmUgZGVzdHJveWluZyBpdHMgdGV4dHVyZS5cIik7XG4gICAgICByZXR1cm4gVGV4dHVyZS5FTVBUWTtcbiAgICB9XG4gICAgcmV0dXJuIHRleHR1cmU7XG4gIH1cbiAgZGVzdHJveShkZXN0cm95UHJvZ3JhbXMgPSBmYWxzZSkge1xuICAgIHRoaXMuX3RleHR1cmVNYXRyaXguZGVzdHJveSgpO1xuICAgIHN1cGVyLmRlc3Ryb3koZGVzdHJveVByb2dyYW1zKTtcbiAgfVxufVxuXG5leHBvcnQgeyBNYXNrRmlsdGVyIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1NYXNrRmlsdGVyLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gY29sb3JUb1VuaWZvcm0ocmdiLCBhbHBoYSwgb3V0LCBvZmZzZXQpIHtcbiAgb3V0W29mZnNldCsrXSA9IChyZ2IgPj4gMTYgJiAyNTUpIC8gMjU1O1xuICBvdXRbb2Zmc2V0KytdID0gKHJnYiA+PiA4ICYgMjU1KSAvIDI1NTtcbiAgb3V0W29mZnNldCsrXSA9IChyZ2IgJiAyNTUpIC8gMjU1O1xuICBvdXRbb2Zmc2V0KytdID0gYWxwaGE7XG59XG5mdW5jdGlvbiBjb2xvcjMyQml0VG9Vbmlmb3JtKGFiZ3IsIG91dCwgb2Zmc2V0KSB7XG4gIGNvbnN0IGFscGhhID0gKGFiZ3IgPj4gMjQgJiAyNTUpIC8gMjU1O1xuICBvdXRbb2Zmc2V0KytdID0gKGFiZ3IgJiAyNTUpIC8gMjU1ICogYWxwaGE7XG4gIG91dFtvZmZzZXQrK10gPSAoYWJnciA+PiA4ICYgMjU1KSAvIDI1NSAqIGFscGhhO1xuICBvdXRbb2Zmc2V0KytdID0gKGFiZ3IgPj4gMTYgJiAyNTUpIC8gMjU1ICogYWxwaGE7XG4gIG91dFtvZmZzZXQrK10gPSBhbHBoYTtcbn1cblxuZXhwb3J0IHsgY29sb3IzMkJpdFRvVW5pZm9ybSwgY29sb3JUb1VuaWZvcm0gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbG9yVG9Vbmlmb3JtLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY2xhc3MgQmF0Y2hhYmxlU3ByaXRlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5iYXRjaGVyTmFtZSA9IFwiZGVmYXVsdFwiO1xuICAgIHRoaXMudG9wb2xvZ3kgPSBcInRyaWFuZ2xlLWxpc3RcIjtcbiAgICAvLyBiYXRjaCBzcGVjaWZpYy4uXG4gICAgdGhpcy5hdHRyaWJ1dGVTaXplID0gNDtcbiAgICB0aGlzLmluZGV4U2l6ZSA9IDY7XG4gICAgdGhpcy5wYWNrQXNRdWFkID0gdHJ1ZTtcbiAgICB0aGlzLnJvdW5kUGl4ZWxzID0gMDtcbiAgICB0aGlzLl9hdHRyaWJ1dGVTdGFydCA9IDA7XG4gICAgLy8gbG9jYXRpb24gaW4gdGhlIGJ1ZmZlclxuICAgIHRoaXMuX2JhdGNoZXIgPSBudWxsO1xuICAgIHRoaXMuX2JhdGNoID0gbnVsbDtcbiAgfVxuICBnZXQgYmxlbmRNb2RlKCkge1xuICAgIHJldHVybiB0aGlzLnJlbmRlcmFibGUuZ3JvdXBCbGVuZE1vZGU7XG4gIH1cbiAgZ2V0IGNvbG9yKCkge1xuICAgIHJldHVybiB0aGlzLnJlbmRlcmFibGUuZ3JvdXBDb2xvckFscGhhO1xuICB9XG4gIHJlc2V0KCkge1xuICAgIHRoaXMucmVuZGVyYWJsZSA9IG51bGw7XG4gICAgdGhpcy50ZXh0dXJlID0gbnVsbDtcbiAgICB0aGlzLl9iYXRjaGVyID0gbnVsbDtcbiAgICB0aGlzLl9iYXRjaCA9IG51bGw7XG4gICAgdGhpcy5ib3VuZHMgPSBudWxsO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5yZXNldCgpO1xuICB9XG59XG5cbmV4cG9ydCB7IEJhdGNoYWJsZVNwcml0ZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QmF0Y2hhYmxlU3ByaXRlLm1qcy5tYXBcbiIsImltcG9ydCB7IEV4dGVuc2lvblR5cGUsIGV4dGVuc2lvbnMgfSBmcm9tICcuLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IFN0YXRlIH0gZnJvbSAnLi4vLi4vcmVuZGVyZXJzL3NoYXJlZC9zdGF0ZS9TdGF0ZS5tanMnO1xuaW1wb3J0IHsgRGVmYXVsdEJhdGNoZXIgfSBmcm9tICcuL0RlZmF1bHRCYXRjaGVyLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgX0JhdGNoZXJQaXBlID0gY2xhc3MgX0JhdGNoZXJQaXBlIHtcbiAgY29uc3RydWN0b3IocmVuZGVyZXIsIGFkYXB0b3IpIHtcbiAgICB0aGlzLnN0YXRlID0gU3RhdGUuZm9yMmQoKTtcbiAgICB0aGlzLl9iYXRjaGVyc0J5SW5zdHJ1Y3Rpb25TZXQgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAvKiogQSByZWNvcmQgb2YgYWxsIGFjdGl2ZSBiYXRjaGVycywga2V5ZWQgYnkgdGhlaXIgbmFtZXMgKi9cbiAgICB0aGlzLl9hY3RpdmVCYXRjaGVzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgdGhpcy5yZW5kZXJlciA9IHJlbmRlcmVyO1xuICAgIHRoaXMuX2FkYXB0b3IgPSBhZGFwdG9yO1xuICAgIHRoaXMuX2FkYXB0b3IuaW5pdD8uKHRoaXMpO1xuICB9XG4gIHN0YXRpYyBnZXRCYXRjaGVyKG5hbWUsIG1heFRleHR1cmVzKSB7XG4gICAgcmV0dXJuIG5ldyB0aGlzLl9hdmFpbGFibGVCYXRjaGVyc1tuYW1lXSh7IG1heFRleHR1cmVzIH0pO1xuICB9XG4gIGJ1aWxkU3RhcnQoaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICBsZXQgYmF0Y2hlcnMgPSB0aGlzLl9iYXRjaGVyc0J5SW5zdHJ1Y3Rpb25TZXRbaW5zdHJ1Y3Rpb25TZXQudWlkXTtcbiAgICBpZiAoIWJhdGNoZXJzKSB7XG4gICAgICBiYXRjaGVycyA9IHRoaXMuX2JhdGNoZXJzQnlJbnN0cnVjdGlvblNldFtpbnN0cnVjdGlvblNldC51aWRdID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICBiYXRjaGVycy5kZWZhdWx0IHx8IChiYXRjaGVycy5kZWZhdWx0ID0gbmV3IERlZmF1bHRCYXRjaGVyKHtcbiAgICAgICAgbWF4VGV4dHVyZXM6IHRoaXMucmVuZGVyZXIubGltaXRzLm1heEJhdGNoYWJsZVRleHR1cmVzXG4gICAgICB9KSk7XG4gICAgfVxuICAgIHRoaXMuX2FjdGl2ZUJhdGNoZXMgPSBiYXRjaGVycztcbiAgICB0aGlzLl9hY3RpdmVCYXRjaCA9IHRoaXMuX2FjdGl2ZUJhdGNoZXMuZGVmYXVsdDtcbiAgICBmb3IgKGNvbnN0IGkgaW4gdGhpcy5fYWN0aXZlQmF0Y2hlcykge1xuICAgICAgdGhpcy5fYWN0aXZlQmF0Y2hlc1tpXS5iZWdpbigpO1xuICAgIH1cbiAgfVxuICBhZGRUb0JhdGNoKGJhdGNoYWJsZU9iamVjdCwgaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICBpZiAodGhpcy5fYWN0aXZlQmF0Y2gubmFtZSAhPT0gYmF0Y2hhYmxlT2JqZWN0LmJhdGNoZXJOYW1lKSB7XG4gICAgICB0aGlzLl9hY3RpdmVCYXRjaC5icmVhayhpbnN0cnVjdGlvblNldCk7XG4gICAgICBsZXQgYmF0Y2ggPSB0aGlzLl9hY3RpdmVCYXRjaGVzW2JhdGNoYWJsZU9iamVjdC5iYXRjaGVyTmFtZV07XG4gICAgICBpZiAoIWJhdGNoKSB7XG4gICAgICAgIGJhdGNoID0gdGhpcy5fYWN0aXZlQmF0Y2hlc1tiYXRjaGFibGVPYmplY3QuYmF0Y2hlck5hbWVdID0gX0JhdGNoZXJQaXBlLmdldEJhdGNoZXIoYmF0Y2hhYmxlT2JqZWN0LmJhdGNoZXJOYW1lLCB0aGlzLnJlbmRlcmVyLmxpbWl0cy5tYXhCYXRjaGFibGVUZXh0dXJlcyk7XG4gICAgICAgIGJhdGNoLmJlZ2luKCk7XG4gICAgICB9XG4gICAgICB0aGlzLl9hY3RpdmVCYXRjaCA9IGJhdGNoO1xuICAgIH1cbiAgICB0aGlzLl9hY3RpdmVCYXRjaC5hZGQoYmF0Y2hhYmxlT2JqZWN0KTtcbiAgfVxuICBicmVhayhpbnN0cnVjdGlvblNldCkge1xuICAgIHRoaXMuX2FjdGl2ZUJhdGNoLmJyZWFrKGluc3RydWN0aW9uU2V0KTtcbiAgfVxuICBidWlsZEVuZChpbnN0cnVjdGlvblNldCkge1xuICAgIHRoaXMuX2FjdGl2ZUJhdGNoLmJyZWFrKGluc3RydWN0aW9uU2V0KTtcbiAgICBjb25zdCBiYXRjaGVzID0gdGhpcy5fYWN0aXZlQmF0Y2hlcztcbiAgICBmb3IgKGNvbnN0IGkgaW4gYmF0Y2hlcykge1xuICAgICAgY29uc3QgYmF0Y2ggPSBiYXRjaGVzW2ldO1xuICAgICAgY29uc3QgZ2VvbWV0cnkgPSBiYXRjaC5nZW9tZXRyeTtcbiAgICAgIGdlb21ldHJ5LmluZGV4QnVmZmVyLnNldERhdGFXaXRoU2l6ZShiYXRjaC5pbmRleEJ1ZmZlciwgYmF0Y2guaW5kZXhTaXplLCB0cnVlKTtcbiAgICAgIGdlb21ldHJ5LmJ1ZmZlcnNbMF0uc2V0RGF0YVdpdGhTaXplKGJhdGNoLmF0dHJpYnV0ZUJ1ZmZlci5mbG9hdDMyVmlldywgYmF0Y2guYXR0cmlidXRlU2l6ZSwgZmFsc2UpO1xuICAgIH1cbiAgfVxuICB1cGxvYWQoaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICBjb25zdCBiYXRjaGVycyA9IHRoaXMuX2JhdGNoZXJzQnlJbnN0cnVjdGlvblNldFtpbnN0cnVjdGlvblNldC51aWRdO1xuICAgIGZvciAoY29uc3QgaSBpbiBiYXRjaGVycykge1xuICAgICAgY29uc3QgYmF0Y2hlciA9IGJhdGNoZXJzW2ldO1xuICAgICAgY29uc3QgZ2VvbWV0cnkgPSBiYXRjaGVyLmdlb21ldHJ5O1xuICAgICAgaWYgKGJhdGNoZXIuZGlydHkpIHtcbiAgICAgICAgYmF0Y2hlci5kaXJ0eSA9IGZhbHNlO1xuICAgICAgICBnZW9tZXRyeS5idWZmZXJzWzBdLnVwZGF0ZShiYXRjaGVyLmF0dHJpYnV0ZVNpemUgKiA0KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgZXhlY3V0ZShiYXRjaCkge1xuICAgIGlmIChiYXRjaC5hY3Rpb24gPT09IFwic3RhcnRCYXRjaFwiKSB7XG4gICAgICBjb25zdCBiYXRjaGVyID0gYmF0Y2guYmF0Y2hlcjtcbiAgICAgIGNvbnN0IGdlb21ldHJ5ID0gYmF0Y2hlci5nZW9tZXRyeTtcbiAgICAgIGNvbnN0IHNoYWRlciA9IGJhdGNoZXIuc2hhZGVyO1xuICAgICAgdGhpcy5fYWRhcHRvci5zdGFydCh0aGlzLCBnZW9tZXRyeSwgc2hhZGVyKTtcbiAgICB9XG4gICAgdGhpcy5fYWRhcHRvci5leGVjdXRlKHRoaXMsIGJhdGNoKTtcbiAgfVxuICAvKipcbiAgICogUmVsZWFzZXMgYWxsIGJhdGNoZXJzIGNhY2hlZCBmb3IgdGhlIGdpdmVuIEluc3RydWN0aW9uU2V0LiBDYWxsZWQgZnJvbVxuICAgKiBgSW5zdHJ1Y3Rpb25TZXQuZGVzdHJveSgpYCBzbyB0aGF0IGJhdGNoZXJzIChhbmQgdGhlaXIgR1BVIGdlb21ldHJ5IC8gYXR0cmlidXRlXG4gICAqIGJ1ZmZlcnMgLyByZWZlcmVuY2VkIHRleHR1cmVzKSBkbyBub3QgbGVhayB3aGVuIHRoZSBvd25pbmcgUmVuZGVyR3JvdXAgaXMgZGVzdHJveWVkLlxuICAgKiBAcGFyYW0gaW5zdHJ1Y3Rpb25TZXQgLSB0aGUgaW5zdHJ1Y3Rpb24gc2V0IGJlaW5nIGRlc3Ryb3llZFxuICAgKi9cbiAgZGVzdHJveUluc3RydWN0aW9uU2V0KGluc3RydWN0aW9uU2V0KSB7XG4gICAgY29uc3QgYmF0Y2hlcnMgPSB0aGlzLl9iYXRjaGVyc0J5SW5zdHJ1Y3Rpb25TZXRbaW5zdHJ1Y3Rpb25TZXQudWlkXTtcbiAgICBpZiAoIWJhdGNoZXJzKSByZXR1cm47XG4gICAgZm9yIChjb25zdCBpIGluIGJhdGNoZXJzKSB7XG4gICAgICBiYXRjaGVyc1tpXS5kZXN0cm95KCk7XG4gICAgfVxuICAgIGRlbGV0ZSB0aGlzLl9iYXRjaGVyc0J5SW5zdHJ1Y3Rpb25TZXRbaW5zdHJ1Y3Rpb25TZXQudWlkXTtcbiAgICBpZiAodGhpcy5fYWN0aXZlQmF0Y2hlcyA9PT0gYmF0Y2hlcnMpIHtcbiAgICAgIHRoaXMuX2FjdGl2ZUJhdGNoZXMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgIHRoaXMuX2FjdGl2ZUJhdGNoID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLnN0YXRlID0gbnVsbDtcbiAgICB0aGlzLnJlbmRlcmVyID0gbnVsbDtcbiAgICB0aGlzLl9hZGFwdG9yID0gbnVsbDtcbiAgICBmb3IgKGNvbnN0IGkgaW4gdGhpcy5fYWN0aXZlQmF0Y2hlcykge1xuICAgICAgdGhpcy5fYWN0aXZlQmF0Y2hlc1tpXS5kZXN0cm95KCk7XG4gICAgfVxuICAgIHRoaXMuX2FjdGl2ZUJhdGNoZXMgPSBudWxsO1xuICB9XG59O1xuLyoqIEBpZ25vcmUgKi9cbl9CYXRjaGVyUGlwZS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMUGlwZXMsXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHUFVQaXBlcyxcbiAgICBFeHRlbnNpb25UeXBlLkNhbnZhc1BpcGVzXG4gIF0sXG4gIG5hbWU6IFwiYmF0Y2hcIlxufTtcbl9CYXRjaGVyUGlwZS5fYXZhaWxhYmxlQmF0Y2hlcnMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbmxldCBCYXRjaGVyUGlwZSA9IF9CYXRjaGVyUGlwZTtcbmV4dGVuc2lvbnMuaGFuZGxlQnlNYXAoRXh0ZW5zaW9uVHlwZS5CYXRjaGVyLCBCYXRjaGVyUGlwZS5fYXZhaWxhYmxlQmF0Y2hlcnMpO1xuZXh0ZW5zaW9ucy5hZGQoRGVmYXVsdEJhdGNoZXIpO1xuXG5leHBvcnQgeyBCYXRjaGVyUGlwZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QmF0Y2hlclBpcGUubWpzLm1hcFxuIiwiaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgRmlsdGVyRWZmZWN0IH0gZnJvbSAnLi4vLi4vLi4vZmlsdGVycy9GaWx0ZXJFZmZlY3QubWpzJztcbmltcG9ydCB7IE1hc2tGaWx0ZXIgfSBmcm9tICcuLi8uLi8uLi9maWx0ZXJzL21hc2svTWFza0ZpbHRlci5tanMnO1xuaW1wb3J0IHsgQm91bmRzIH0gZnJvbSAnLi4vLi4vLi4vc2NlbmUvY29udGFpbmVyL2JvdW5kcy9Cb3VuZHMubWpzJztcbmltcG9ydCB7IGdldEdsb2JhbEJvdW5kcyB9IGZyb20gJy4uLy4uLy4uL3NjZW5lL2NvbnRhaW5lci9ib3VuZHMvZ2V0R2xvYmFsQm91bmRzLm1qcyc7XG5pbXBvcnQgeyBTcHJpdGUgfSBmcm9tICcuLi8uLi8uLi9zY2VuZS9zcHJpdGUvU3ByaXRlLm1qcyc7XG5pbXBvcnQgeyBCaWdQb29sIH0gZnJvbSAnLi4vLi4vLi4vdXRpbHMvcG9vbC9Qb29sR3JvdXAubWpzJztcbmltcG9ydCB7IFRleHR1cmUgfSBmcm9tICcuLi8uLi9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvVGV4dHVyZS5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVBvb2wgfSBmcm9tICcuLi8uLi9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvVGV4dHVyZVBvb2wubWpzJztcbmltcG9ydCB7IFJlbmRlcmVyVHlwZSB9IGZyb20gJy4uLy4uL3JlbmRlcmVycy90eXBlcy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IHRlbXBCb3VuZHMgPSBuZXcgQm91bmRzKCk7XG5jbGFzcyBBbHBoYU1hc2tFZmZlY3QgZXh0ZW5kcyBGaWx0ZXJFZmZlY3Qge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpO1xuICAgIC8qKiB0aGUgc3ByaXRlIHRoZSBwb29sZWQgZmlsdGVyIGlzIHBhcmtlZCBvbiBiZXR3ZWVuIHVzZXMgKi9cbiAgICB0aGlzLl9wbGFjZWhvbGRlclNwcml0ZSA9IG5ldyBTcHJpdGUoVGV4dHVyZS5FTVBUWSk7XG4gICAgdGhpcy5maWx0ZXJzID0gW25ldyBNYXNrRmlsdGVyKHtcbiAgICAgIHNwcml0ZTogdGhpcy5fcGxhY2Vob2xkZXJTcHJpdGUsXG4gICAgICBpbnZlcnNlOiBmYWxzZSxcbiAgICAgIHJlc29sdXRpb246IFwiaW5oZXJpdFwiLFxuICAgICAgYW50aWFsaWFzOiBcImluaGVyaXRcIlxuICAgIH0pXTtcbiAgfVxuICBnZXQgc3ByaXRlKCkge1xuICAgIHJldHVybiB0aGlzLmZpbHRlcnNbMF0uc3ByaXRlO1xuICB9XG4gIHNldCBzcHJpdGUodmFsdWUpIHtcbiAgICB0aGlzLmZpbHRlcnNbMF0uc2V0U3ByaXRlKHZhbHVlKTtcbiAgfVxuICBnZXQgaW52ZXJzZSgpIHtcbiAgICByZXR1cm4gdGhpcy5maWx0ZXJzWzBdLmludmVyc2U7XG4gIH1cbiAgc2V0IGludmVyc2UodmFsdWUpIHtcbiAgICB0aGlzLmZpbHRlcnNbMF0uaW52ZXJzZSA9IHZhbHVlO1xuICB9XG4gIGdldCBjaGFubmVsKCkge1xuICAgIHJldHVybiB0aGlzLmZpbHRlcnNbMF0uY2hhbm5lbDtcbiAgfVxuICBzZXQgY2hhbm5lbCh2YWx1ZSkge1xuICAgIHRoaXMuZmlsdGVyc1swXS5jaGFubmVsID0gdmFsdWU7XG4gIH1cbiAgLyoqXG4gICAqIENhbGxlZCBieSB7QGxpbmsgQmlnUG9vbH0gd2hlbiB0aGUgcGlwZSByZXR1cm5zIHRoZSBlZmZlY3Q6IHBhcmtzIHRoZSBmaWx0ZXJcbiAgICogb24gdGhlIGVtcHR5IHBsYWNlaG9sZGVyIHNvIGEgcG9vbGVkIGVmZmVjdCBrZWVwcyBubyBiaW5kaW5ncyB0byB0aGUgbGFzdFxuICAgKiBtYXNrIGl0IGFwcGxpZWQuIFdpdGhvdXQgdGhpcywgdGhlIHBvb2xlZCBmaWx0ZXIgcGlucyB0aGUgbWFzayBzcHJpdGUgYW5kXG4gICAqIGl0cyB0ZXh0dXJlIGZvciBhcyBsb25nIGFzIHRoZSBlZmZlY3Qgc2l0cyBpbiB0aGUgcG9vbCwgYW5kIGRlc3Ryb3lpbmcgdGhhdFxuICAgKiB0ZXh0dXJlJ3Mgc291cmNlIGhpdHMgYSBiaW5kIGdyb3VwIHN1YnNjcmlwdGlvbiB0aGUgdXNlciBjYW5ub3QgcmVsZWFzZS5cbiAgICovXG4gIHJlc2V0KCkge1xuICAgIHRoaXMuX3BsYWNlaG9sZGVyU3ByaXRlLnRleHR1cmUgPSBUZXh0dXJlLkVNUFRZO1xuICAgIHRoaXMuc3ByaXRlID0gdGhpcy5fcGxhY2Vob2xkZXJTcHJpdGU7XG4gIH1cbn1cbmNsYXNzIEFscGhhTWFza1BpcGUge1xuICBjb25zdHJ1Y3RvcihyZW5kZXJlcikge1xuICAgIHRoaXMuX2FjdGl2ZU1hc2tTdGFnZSA9IFtdO1xuICAgIHRoaXMuX3VzZWRFZmZlY3RzID0gW107XG4gICAgdGhpcy5fcmVuZGVyZXIgPSByZW5kZXJlcjtcbiAgICByZW5kZXJlci5ydW5uZXJzLnBvc3RyZW5kZXIuYWRkKHRoaXMpO1xuICB9XG4gIHB1c2gobWFzaywgbWFza2VkQ29udGFpbmVyLCBpbnN0cnVjdGlvblNldCkge1xuICAgIGNvbnN0IHJlbmRlcmVyID0gdGhpcy5fcmVuZGVyZXI7XG4gICAgcmVuZGVyZXIucmVuZGVyUGlwZXMuYmF0Y2guYnJlYWsoaW5zdHJ1Y3Rpb25TZXQpO1xuICAgIGluc3RydWN0aW9uU2V0LmFkZCh7XG4gICAgICByZW5kZXJQaXBlSWQ6IFwiYWxwaGFNYXNrXCIsXG4gICAgICBhY3Rpb246IFwicHVzaE1hc2tCZWdpblwiLFxuICAgICAgbWFzayxcbiAgICAgIGludmVyc2U6IG1hc2tlZENvbnRhaW5lci5fbWFza09wdGlvbnMuaW52ZXJzZSxcbiAgICAgIGNhbkJ1bmRsZTogZmFsc2UsXG4gICAgICBtYXNrZWRDb250YWluZXJcbiAgICB9KTtcbiAgICBtYXNrLmludmVyc2UgPSBtYXNrZWRDb250YWluZXIuX21hc2tPcHRpb25zLmludmVyc2U7XG4gICAgbWFzay5jaGFubmVsID0gbWFza2VkQ29udGFpbmVyLl9tYXNrT3B0aW9ucy5jaGFubmVsID8/IFwicmVkXCI7XG4gICAgaWYgKG1hc2sucmVuZGVyTWFza1RvVGV4dHVyZSkge1xuICAgICAgY29uc3QgbWFza0NvbnRhaW5lciA9IG1hc2subWFzaztcbiAgICAgIG1hc2tDb250YWluZXIuaW5jbHVkZUluQnVpbGQgPSB0cnVlO1xuICAgICAgbWFza0NvbnRhaW5lci5jb2xsZWN0UmVuZGVyYWJsZXMoXG4gICAgICAgIGluc3RydWN0aW9uU2V0LFxuICAgICAgICByZW5kZXJlcixcbiAgICAgICAgbnVsbFxuICAgICAgKTtcbiAgICAgIG1hc2tDb250YWluZXIuaW5jbHVkZUluQnVpbGQgPSBmYWxzZTtcbiAgICB9XG4gICAgcmVuZGVyZXIucmVuZGVyUGlwZXMuYmF0Y2guYnJlYWsoaW5zdHJ1Y3Rpb25TZXQpO1xuICAgIGluc3RydWN0aW9uU2V0LmFkZCh7XG4gICAgICByZW5kZXJQaXBlSWQ6IFwiYWxwaGFNYXNrXCIsXG4gICAgICBhY3Rpb246IFwicHVzaE1hc2tFbmRcIixcbiAgICAgIG1hc2ssXG4gICAgICBtYXNrZWRDb250YWluZXIsXG4gICAgICBpbnZlcnNlOiBtYXNrZWRDb250YWluZXIuX21hc2tPcHRpb25zLmludmVyc2UsXG4gICAgICBjYW5CdW5kbGU6IGZhbHNlXG4gICAgfSk7XG4gIH1cbiAgcG9wKG1hc2ssIF9tYXNrZWRDb250YWluZXIsIGluc3RydWN0aW9uU2V0KSB7XG4gICAgY29uc3QgcmVuZGVyZXIgPSB0aGlzLl9yZW5kZXJlcjtcbiAgICByZW5kZXJlci5yZW5kZXJQaXBlcy5iYXRjaC5icmVhayhpbnN0cnVjdGlvblNldCk7XG4gICAgaW5zdHJ1Y3Rpb25TZXQuYWRkKHtcbiAgICAgIHJlbmRlclBpcGVJZDogXCJhbHBoYU1hc2tcIixcbiAgICAgIGFjdGlvbjogXCJwb3BNYXNrRW5kXCIsXG4gICAgICBtYXNrLFxuICAgICAgaW52ZXJzZTogX21hc2tlZENvbnRhaW5lci5fbWFza09wdGlvbnMuaW52ZXJzZSxcbiAgICAgIGNhbkJ1bmRsZTogZmFsc2VcbiAgICB9KTtcbiAgfVxuICBleGVjdXRlKGluc3RydWN0aW9uKSB7XG4gICAgY29uc3QgcmVuZGVyZXIgPSB0aGlzLl9yZW5kZXJlcjtcbiAgICBjb25zdCByZW5kZXJNYXNrID0gaW5zdHJ1Y3Rpb24ubWFzay5yZW5kZXJNYXNrVG9UZXh0dXJlO1xuICAgIGlmIChpbnN0cnVjdGlvbi5hY3Rpb24gPT09IFwicHVzaE1hc2tCZWdpblwiKSB7XG4gICAgICBjb25zdCBmaWx0ZXJFZmZlY3QgPSBCaWdQb29sLmdldChBbHBoYU1hc2tFZmZlY3QpO1xuICAgICAgZmlsdGVyRWZmZWN0LmludmVyc2UgPSBpbnN0cnVjdGlvbi5pbnZlcnNlO1xuICAgICAgZmlsdGVyRWZmZWN0LmNoYW5uZWwgPSBpbnN0cnVjdGlvbi5tYXNrLmNoYW5uZWw7XG4gICAgICBpZiAocmVuZGVyTWFzaykge1xuICAgICAgICBpbnN0cnVjdGlvbi5tYXNrLm1hc2subWVhc3VyYWJsZSA9IHRydWU7XG4gICAgICAgIGNvbnN0IGJvdW5kcyA9IGdldEdsb2JhbEJvdW5kcyhpbnN0cnVjdGlvbi5tYXNrLm1hc2ssIHRydWUsIHRlbXBCb3VuZHMpO1xuICAgICAgICBpbnN0cnVjdGlvbi5tYXNrLm1hc2subWVhc3VyYWJsZSA9IGZhbHNlO1xuICAgICAgICBib3VuZHMuY2VpbCgpO1xuICAgICAgICBjb25zdCBjb2xvclRleHR1cmVTb3VyY2UgPSByZW5kZXJlci5yZW5kZXJUYXJnZXQucmVuZGVyVGFyZ2V0LmNvbG9yVGV4dHVyZS5zb3VyY2U7XG4gICAgICAgIGNvbnN0IGZpbHRlclRleHR1cmUgPSBUZXh0dXJlUG9vbC5nZXRPcHRpbWFsVGV4dHVyZSh7XG4gICAgICAgICAgd2lkdGg6IGJvdW5kcy53aWR0aCxcbiAgICAgICAgICBoZWlnaHQ6IGJvdW5kcy5oZWlnaHQsXG4gICAgICAgICAgcmVzb2x1dGlvbjogY29sb3JUZXh0dXJlU291cmNlLl9yZXNvbHV0aW9uLFxuICAgICAgICAgIGFudGlhbGlhczogY29sb3JUZXh0dXJlU291cmNlLmFudGlhbGlhc1xuICAgICAgICB9KTtcbiAgICAgICAgcmVuZGVyZXIucmVuZGVyVGFyZ2V0LnB1c2goeyB0YXJnZXQ6IGZpbHRlclRleHR1cmUsIGNsZWFyOiB0cnVlIH0pO1xuICAgICAgICByZW5kZXJlci5nbG9iYWxVbmlmb3Jtcy5wdXNoKHtcbiAgICAgICAgICBvZmZzZXQ6IGJvdW5kcyxcbiAgICAgICAgICB3b3JsZENvbG9yOiA0Mjk0OTY3Mjk1XG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBzcHJpdGUgPSBmaWx0ZXJFZmZlY3Quc3ByaXRlO1xuICAgICAgICBzcHJpdGUudGV4dHVyZSA9IGZpbHRlclRleHR1cmU7XG4gICAgICAgIHNwcml0ZS53b3JsZFRyYW5zZm9ybS50eCA9IGJvdW5kcy5taW5YO1xuICAgICAgICBzcHJpdGUud29ybGRUcmFuc2Zvcm0udHkgPSBib3VuZHMubWluWTtcbiAgICAgICAgdGhpcy5fYWN0aXZlTWFza1N0YWdlLnB1c2goe1xuICAgICAgICAgIGZpbHRlckVmZmVjdCxcbiAgICAgICAgICBtYXNrZWRDb250YWluZXI6IGluc3RydWN0aW9uLm1hc2tlZENvbnRhaW5lcixcbiAgICAgICAgICBmaWx0ZXJUZXh0dXJlXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZmlsdGVyRWZmZWN0LnNwcml0ZSA9IGluc3RydWN0aW9uLm1hc2subWFzaztcbiAgICAgICAgdGhpcy5fYWN0aXZlTWFza1N0YWdlLnB1c2goe1xuICAgICAgICAgIGZpbHRlckVmZmVjdCxcbiAgICAgICAgICBtYXNrZWRDb250YWluZXI6IGluc3RydWN0aW9uLm1hc2tlZENvbnRhaW5lclxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGluc3RydWN0aW9uLmFjdGlvbiA9PT0gXCJwdXNoTWFza0VuZFwiKSB7XG4gICAgICBjb25zdCBtYXNrRGF0YSA9IHRoaXMuX2FjdGl2ZU1hc2tTdGFnZVt0aGlzLl9hY3RpdmVNYXNrU3RhZ2UubGVuZ3RoIC0gMV07XG4gICAgICBpZiAocmVuZGVyTWFzaykge1xuICAgICAgICBpZiAocmVuZGVyZXIudHlwZSA9PT0gUmVuZGVyZXJUeXBlLldFQkdMKSB7XG4gICAgICAgICAgcmVuZGVyZXIucmVuZGVyVGFyZ2V0LmZpbmlzaFJlbmRlclBhc3MoKTtcbiAgICAgICAgfVxuICAgICAgICByZW5kZXJlci5yZW5kZXJUYXJnZXQucG9wKCk7XG4gICAgICAgIHJlbmRlcmVyLmdsb2JhbFVuaWZvcm1zLnBvcCgpO1xuICAgICAgfVxuICAgICAgcmVuZGVyZXIuZmlsdGVyLnB1c2goe1xuICAgICAgICByZW5kZXJQaXBlSWQ6IFwiZmlsdGVyXCIsXG4gICAgICAgIGFjdGlvbjogXCJwdXNoRmlsdGVyXCIsXG4gICAgICAgIGNvbnRhaW5lcjogbWFza0RhdGEubWFza2VkQ29udGFpbmVyLFxuICAgICAgICBmaWx0ZXJFZmZlY3Q6IG1hc2tEYXRhLmZpbHRlckVmZmVjdCxcbiAgICAgICAgY2FuQnVuZGxlOiBmYWxzZVxuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmIChpbnN0cnVjdGlvbi5hY3Rpb24gPT09IFwicG9wTWFza0VuZFwiKSB7XG4gICAgICByZW5kZXJlci5maWx0ZXIucG9wKCk7XG4gICAgICBjb25zdCBtYXNrRGF0YSA9IHRoaXMuX2FjdGl2ZU1hc2tTdGFnZS5wb3AoKTtcbiAgICAgIGlmIChyZW5kZXJNYXNrKSB7XG4gICAgICAgIFRleHR1cmVQb29sLnJldHVyblRleHR1cmUobWFza0RhdGEuZmlsdGVyVGV4dHVyZSk7XG4gICAgICB9XG4gICAgICB0aGlzLl91c2VkRWZmZWN0cy5wdXNoKG1hc2tEYXRhLmZpbHRlckVmZmVjdCk7XG4gICAgfVxuICB9XG4gIHBvc3RyZW5kZXIoKSB7XG4gICAgY29uc3QgZWZmZWN0cyA9IHRoaXMuX3VzZWRFZmZlY3RzO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZWZmZWN0cy5sZW5ndGg7IGkrKykge1xuICAgICAgQmlnUG9vbC5yZXR1cm4oZWZmZWN0c1tpXSk7XG4gICAgfVxuICAgIGVmZmVjdHMubGVuZ3RoID0gMDtcbiAgfVxuICBkZXN0cm95KCkge1xuICAgIHRoaXMucG9zdHJlbmRlcigpO1xuICAgIHRoaXMuX3JlbmRlcmVyLnJ1bm5lcnMucG9zdHJlbmRlci5yZW1vdmUodGhpcyk7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSBudWxsO1xuICAgIHRoaXMuX2FjdGl2ZU1hc2tTdGFnZSA9IG51bGw7XG4gICAgdGhpcy5fdXNlZEVmZmVjdHMgPSBudWxsO1xuICB9XG59XG4vKiogQGlnbm9yZSAqL1xuQWxwaGFNYXNrUGlwZS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMUGlwZXMsXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHUFVQaXBlcyxcbiAgICBFeHRlbnNpb25UeXBlLkNhbnZhc1BpcGVzXG4gIF0sXG4gIG5hbWU6IFwiYWxwaGFNYXNrXCJcbn07XG5cbmV4cG9ydCB7IEFscGhhTWFza1BpcGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUFscGhhTWFza1BpcGUubWpzLm1hcFxuIiwiaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIENvbG9yTWFza1BpcGUge1xuICBjb25zdHJ1Y3RvcihyZW5kZXJlcikge1xuICAgIHRoaXMuX2NvbG9yU3RhY2sgPSBbXTtcbiAgICB0aGlzLl9jb2xvclN0YWNrSW5kZXggPSAwO1xuICAgIHRoaXMuX2N1cnJlbnRDb2xvciA9IDA7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSByZW5kZXJlcjtcbiAgfVxuICBidWlsZFN0YXJ0KCkge1xuICAgIHRoaXMuX2NvbG9yU3RhY2tbMF0gPSAxNTtcbiAgICB0aGlzLl9jb2xvclN0YWNrSW5kZXggPSAxO1xuICAgIHRoaXMuX2N1cnJlbnRDb2xvciA9IDE1O1xuICB9XG4gIHB1c2gobWFzaywgX2NvbnRhaW5lciwgaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICBjb25zdCByZW5kZXJlciA9IHRoaXMuX3JlbmRlcmVyO1xuICAgIHJlbmRlcmVyLnJlbmRlclBpcGVzLmJhdGNoLmJyZWFrKGluc3RydWN0aW9uU2V0KTtcbiAgICBjb25zdCBjb2xvclN0YWNrID0gdGhpcy5fY29sb3JTdGFjaztcbiAgICBjb2xvclN0YWNrW3RoaXMuX2NvbG9yU3RhY2tJbmRleF0gPSBjb2xvclN0YWNrW3RoaXMuX2NvbG9yU3RhY2tJbmRleCAtIDFdICYgbWFzay5tYXNrO1xuICAgIGNvbnN0IGN1cnJlbnRDb2xvciA9IHRoaXMuX2NvbG9yU3RhY2tbdGhpcy5fY29sb3JTdGFja0luZGV4XTtcbiAgICBpZiAoY3VycmVudENvbG9yICE9PSB0aGlzLl9jdXJyZW50Q29sb3IpIHtcbiAgICAgIHRoaXMuX2N1cnJlbnRDb2xvciA9IGN1cnJlbnRDb2xvcjtcbiAgICAgIGluc3RydWN0aW9uU2V0LmFkZCh7XG4gICAgICAgIHJlbmRlclBpcGVJZDogXCJjb2xvck1hc2tcIixcbiAgICAgICAgY29sb3JNYXNrOiBjdXJyZW50Q29sb3IsXG4gICAgICAgIGNhbkJ1bmRsZTogZmFsc2VcbiAgICAgIH0pO1xuICAgIH1cbiAgICB0aGlzLl9jb2xvclN0YWNrSW5kZXgrKztcbiAgfVxuICBwb3AoX21hc2ssIF9jb250YWluZXIsIGluc3RydWN0aW9uU2V0KSB7XG4gICAgY29uc3QgcmVuZGVyZXIgPSB0aGlzLl9yZW5kZXJlcjtcbiAgICByZW5kZXJlci5yZW5kZXJQaXBlcy5iYXRjaC5icmVhayhpbnN0cnVjdGlvblNldCk7XG4gICAgY29uc3QgY29sb3JTdGFjayA9IHRoaXMuX2NvbG9yU3RhY2s7XG4gICAgdGhpcy5fY29sb3JTdGFja0luZGV4LS07XG4gICAgY29uc3QgY3VycmVudENvbG9yID0gY29sb3JTdGFja1t0aGlzLl9jb2xvclN0YWNrSW5kZXggLSAxXTtcbiAgICBpZiAoY3VycmVudENvbG9yICE9PSB0aGlzLl9jdXJyZW50Q29sb3IpIHtcbiAgICAgIHRoaXMuX2N1cnJlbnRDb2xvciA9IGN1cnJlbnRDb2xvcjtcbiAgICAgIGluc3RydWN0aW9uU2V0LmFkZCh7XG4gICAgICAgIHJlbmRlclBpcGVJZDogXCJjb2xvck1hc2tcIixcbiAgICAgICAgY29sb3JNYXNrOiBjdXJyZW50Q29sb3IsXG4gICAgICAgIGNhbkJ1bmRsZTogZmFsc2VcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBleGVjdXRlKGluc3RydWN0aW9uKSB7XG4gICAgY29uc3QgcmVuZGVyZXIgPSB0aGlzLl9yZW5kZXJlcjtcbiAgICByZW5kZXJlci5jb2xvck1hc2suc2V0TWFzayhpbnN0cnVjdGlvbi5jb2xvck1hc2spO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSBudWxsO1xuICAgIHRoaXMuX2NvbG9yU3RhY2sgPSBudWxsO1xuICB9XG59XG4vKiogQGlnbm9yZSAqL1xuQ29sb3JNYXNrUGlwZS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMUGlwZXMsXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHUFVQaXBlc1xuICBdLFxuICBuYW1lOiBcImNvbG9yTWFza1wiXG59O1xuXG5leHBvcnQgeyBDb2xvck1hc2tQaXBlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1Db2xvck1hc2tQaXBlLm1qcy5tYXBcbiIsImltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IENMRUFSIH0gZnJvbSAnLi4vLi4vcmVuZGVyZXJzL2dsL2NvbnN0Lm1qcyc7XG5pbXBvcnQgeyBTVEVOQ0lMX01PREVTIH0gZnJvbSAnLi4vLi4vcmVuZGVyZXJzL3NoYXJlZC9zdGF0ZS9jb25zdC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIFN0ZW5jaWxNYXNrUGlwZSB7XG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgdGhpcy5fbWFza0hhc2ggPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbiAgICB0aGlzLl9yZW5kZXJlciA9IHJlbmRlcmVyO1xuICB9XG4gIHB1c2gobWFzaywgX2NvbnRhaW5lciwgaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICBjb25zdCBlZmZlY3QgPSBtYXNrO1xuICAgIGNvbnN0IHJlbmRlcmVyID0gdGhpcy5fcmVuZGVyZXI7XG4gICAgcmVuZGVyZXIucmVuZGVyUGlwZXMuYmF0Y2guYnJlYWsoaW5zdHJ1Y3Rpb25TZXQpO1xuICAgIHJlbmRlcmVyLnJlbmRlclBpcGVzLmJsZW5kTW9kZS5zZXRCbGVuZE1vZGUoZWZmZWN0Lm1hc2ssIFwibm9uZVwiLCBpbnN0cnVjdGlvblNldCk7XG4gICAgaW5zdHJ1Y3Rpb25TZXQuYWRkKHtcbiAgICAgIHJlbmRlclBpcGVJZDogXCJzdGVuY2lsTWFza1wiLFxuICAgICAgYWN0aW9uOiBcInB1c2hNYXNrQmVnaW5cIixcbiAgICAgIG1hc2ssXG4gICAgICBpbnZlcnNlOiBfY29udGFpbmVyLl9tYXNrT3B0aW9ucy5pbnZlcnNlLFxuICAgICAgY2FuQnVuZGxlOiBmYWxzZVxuICAgIH0pO1xuICAgIGNvbnN0IG1hc2tDb250YWluZXIgPSBlZmZlY3QubWFzaztcbiAgICBtYXNrQ29udGFpbmVyLmluY2x1ZGVJbkJ1aWxkID0gdHJ1ZTtcbiAgICBpZiAoIXRoaXMuX21hc2tIYXNoLmhhcyhlZmZlY3QpKSB7XG4gICAgICB0aGlzLl9tYXNrSGFzaC5zZXQoZWZmZWN0LCB7XG4gICAgICAgIGluc3RydWN0aW9uc1N0YXJ0OiAwLFxuICAgICAgICBpbnN0cnVjdGlvbnNMZW5ndGg6IDBcbiAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBtYXNrRGF0YSA9IHRoaXMuX21hc2tIYXNoLmdldChlZmZlY3QpO1xuICAgIG1hc2tEYXRhLmluc3RydWN0aW9uc1N0YXJ0ID0gaW5zdHJ1Y3Rpb25TZXQuaW5zdHJ1Y3Rpb25TaXplO1xuICAgIG1hc2tDb250YWluZXIuY29sbGVjdFJlbmRlcmFibGVzKFxuICAgICAgaW5zdHJ1Y3Rpb25TZXQsXG4gICAgICByZW5kZXJlcixcbiAgICAgIG51bGxcbiAgICApO1xuICAgIG1hc2tDb250YWluZXIuaW5jbHVkZUluQnVpbGQgPSBmYWxzZTtcbiAgICByZW5kZXJlci5yZW5kZXJQaXBlcy5iYXRjaC5icmVhayhpbnN0cnVjdGlvblNldCk7XG4gICAgaW5zdHJ1Y3Rpb25TZXQuYWRkKHtcbiAgICAgIHJlbmRlclBpcGVJZDogXCJzdGVuY2lsTWFza1wiLFxuICAgICAgYWN0aW9uOiBcInB1c2hNYXNrRW5kXCIsXG4gICAgICBtYXNrLFxuICAgICAgaW52ZXJzZTogX2NvbnRhaW5lci5fbWFza09wdGlvbnMuaW52ZXJzZSxcbiAgICAgIGNhbkJ1bmRsZTogZmFsc2VcbiAgICB9KTtcbiAgICBjb25zdCBpbnN0cnVjdGlvbnNMZW5ndGggPSBpbnN0cnVjdGlvblNldC5pbnN0cnVjdGlvblNpemUgLSBtYXNrRGF0YS5pbnN0cnVjdGlvbnNTdGFydCAtIDE7XG4gICAgbWFza0RhdGEuaW5zdHJ1Y3Rpb25zTGVuZ3RoID0gaW5zdHJ1Y3Rpb25zTGVuZ3RoO1xuICB9XG4gIHBvcChtYXNrLCBfY29udGFpbmVyLCBpbnN0cnVjdGlvblNldCkge1xuICAgIGNvbnN0IGVmZmVjdCA9IG1hc2s7XG4gICAgY29uc3QgcmVuZGVyZXIgPSB0aGlzLl9yZW5kZXJlcjtcbiAgICByZW5kZXJlci5yZW5kZXJQaXBlcy5iYXRjaC5icmVhayhpbnN0cnVjdGlvblNldCk7XG4gICAgcmVuZGVyZXIucmVuZGVyUGlwZXMuYmxlbmRNb2RlLnNldEJsZW5kTW9kZShlZmZlY3QubWFzaywgXCJub25lXCIsIGluc3RydWN0aW9uU2V0KTtcbiAgICBpbnN0cnVjdGlvblNldC5hZGQoe1xuICAgICAgcmVuZGVyUGlwZUlkOiBcInN0ZW5jaWxNYXNrXCIsXG4gICAgICBhY3Rpb246IFwicG9wTWFza0JlZ2luXCIsXG4gICAgICBpbnZlcnNlOiBfY29udGFpbmVyLl9tYXNrT3B0aW9ucy5pbnZlcnNlLFxuICAgICAgY2FuQnVuZGxlOiBmYWxzZVxuICAgIH0pO1xuICAgIGNvbnN0IG1hc2tEYXRhID0gdGhpcy5fbWFza0hhc2guZ2V0KG1hc2spO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbWFza0RhdGEuaW5zdHJ1Y3Rpb25zTGVuZ3RoOyBpKyspIHtcbiAgICAgIGluc3RydWN0aW9uU2V0Lmluc3RydWN0aW9uc1tpbnN0cnVjdGlvblNldC5pbnN0cnVjdGlvblNpemUrK10gPSBpbnN0cnVjdGlvblNldC5pbnN0cnVjdGlvbnNbbWFza0RhdGEuaW5zdHJ1Y3Rpb25zU3RhcnQrK107XG4gICAgfVxuICAgIGluc3RydWN0aW9uU2V0LmFkZCh7XG4gICAgICByZW5kZXJQaXBlSWQ6IFwic3RlbmNpbE1hc2tcIixcbiAgICAgIGFjdGlvbjogXCJwb3BNYXNrRW5kXCIsXG4gICAgICBjYW5CdW5kbGU6IGZhbHNlXG4gICAgfSk7XG4gIH1cbiAgZXhlY3V0ZShpbnN0cnVjdGlvbikge1xuICAgIGNvbnN0IHJlbmRlcmVyID0gdGhpcy5fcmVuZGVyZXI7XG4gICAgY29uc3QgZ3B1UmVuZGVyZXIgPSByZW5kZXJlcjtcbiAgICBjb25zdCBncHVSZW5kZXJUYXJnZXQgPSBncHVSZW5kZXJlci5yZW5kZXJUYXJnZXQuZ2V0R3B1UmVuZGVyVGFyZ2V0KGdwdVJlbmRlcmVyLnJlbmRlclRhcmdldC5yZW5kZXJUYXJnZXQpO1xuICAgIGxldCBtYXNrU3RhY2tJbmRleCA9IGdwdVJlbmRlclRhcmdldC5tYXNrU3RhY2tJbmRleDtcbiAgICBpZiAoaW5zdHJ1Y3Rpb24uYWN0aW9uID09PSBcInB1c2hNYXNrQmVnaW5cIikge1xuICAgICAgZ3B1UmVuZGVyZXIucmVuZGVyVGFyZ2V0LmVuc3VyZURlcHRoU3RlbmNpbCgpO1xuICAgICAgZ3B1UmVuZGVyZXIuc3RlbmNpbC5zZXRTdGVuY2lsTW9kZShTVEVOQ0lMX01PREVTLlJFTkRFUklOR19NQVNLX0FERCwgbWFza1N0YWNrSW5kZXgpO1xuICAgICAgbWFza1N0YWNrSW5kZXgrKztcbiAgICAgIGdwdVJlbmRlcmVyLmNvbG9yTWFzay5zZXRNYXNrKDApO1xuICAgIH0gZWxzZSBpZiAoaW5zdHJ1Y3Rpb24uYWN0aW9uID09PSBcInB1c2hNYXNrRW5kXCIpIHtcbiAgICAgIGlmIChpbnN0cnVjdGlvbi5pbnZlcnNlKSB7XG4gICAgICAgIGdwdVJlbmRlcmVyLnN0ZW5jaWwuc2V0U3RlbmNpbE1vZGUoU1RFTkNJTF9NT0RFUy5JTlZFUlNFX01BU0tfQUNUSVZFLCBtYXNrU3RhY2tJbmRleCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBncHVSZW5kZXJlci5zdGVuY2lsLnNldFN0ZW5jaWxNb2RlKFNURU5DSUxfTU9ERVMuTUFTS19BQ1RJVkUsIG1hc2tTdGFja0luZGV4KTtcbiAgICAgIH1cbiAgICAgIGdwdVJlbmRlcmVyLmNvbG9yTWFzay5zZXRNYXNrKDE1KTtcbiAgICB9IGVsc2UgaWYgKGluc3RydWN0aW9uLmFjdGlvbiA9PT0gXCJwb3BNYXNrQmVnaW5cIikge1xuICAgICAgZ3B1UmVuZGVyZXIuY29sb3JNYXNrLnNldE1hc2soMCk7XG4gICAgICBpZiAobWFza1N0YWNrSW5kZXggIT09IDApIHtcbiAgICAgICAgZ3B1UmVuZGVyZXIuc3RlbmNpbC5zZXRTdGVuY2lsTW9kZShTVEVOQ0lMX01PREVTLlJFTkRFUklOR19NQVNLX1JFTU9WRSwgbWFza1N0YWNrSW5kZXgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZ3B1UmVuZGVyZXIucmVuZGVyVGFyZ2V0LmNsZWFyKG51bGwsIENMRUFSLlNURU5DSUwpO1xuICAgICAgICBncHVSZW5kZXJlci5zdGVuY2lsLnNldFN0ZW5jaWxNb2RlKFNURU5DSUxfTU9ERVMuRElTQUJMRUQsIG1hc2tTdGFja0luZGV4KTtcbiAgICAgIH1cbiAgICAgIG1hc2tTdGFja0luZGV4LS07XG4gICAgfSBlbHNlIGlmIChpbnN0cnVjdGlvbi5hY3Rpb24gPT09IFwicG9wTWFza0VuZFwiKSB7XG4gICAgICBpZiAoaW5zdHJ1Y3Rpb24uaW52ZXJzZSkge1xuICAgICAgICBncHVSZW5kZXJlci5zdGVuY2lsLnNldFN0ZW5jaWxNb2RlKFNURU5DSUxfTU9ERVMuSU5WRVJTRV9NQVNLX0FDVElWRSwgbWFza1N0YWNrSW5kZXgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZ3B1UmVuZGVyZXIuc3RlbmNpbC5zZXRTdGVuY2lsTW9kZShTVEVOQ0lMX01PREVTLk1BU0tfQUNUSVZFLCBtYXNrU3RhY2tJbmRleCk7XG4gICAgICB9XG4gICAgICBncHVSZW5kZXJlci5jb2xvck1hc2suc2V0TWFzaygxNSk7XG4gICAgfVxuICAgIGdwdVJlbmRlclRhcmdldC5tYXNrU3RhY2tJbmRleCA9IG1hc2tTdGFja0luZGV4O1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSBudWxsO1xuICAgIHRoaXMuX21hc2tIYXNoID0gbnVsbDtcbiAgfVxufVxuU3RlbmNpbE1hc2tQaXBlLmV4dGVuc2lvbiA9IHtcbiAgdHlwZTogW1xuICAgIEV4dGVuc2lvblR5cGUuV2ViR0xQaXBlcyxcbiAgICBFeHRlbnNpb25UeXBlLldlYkdQVVBpcGVzXG4gIF0sXG4gIG5hbWU6IFwic3RlbmNpbE1hc2tcIlxufTtcblxuZXhwb3J0IHsgU3RlbmNpbE1hc2tQaXBlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1TdGVuY2lsTWFza1BpcGUubWpzLm1hcFxuIiwiaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIEN1c3RvbVJlbmRlclBpcGUge1xuICBjb25zdHJ1Y3RvcihyZW5kZXJlcikge1xuICAgIHRoaXMuX3JlbmRlcmVyID0gcmVuZGVyZXI7XG4gIH1cbiAgdXBkYXRlUmVuZGVyYWJsZSgpIHtcbiAgfVxuICBkZXN0cm95UmVuZGVyYWJsZSgpIHtcbiAgfVxuICB2YWxpZGF0ZVJlbmRlcmFibGUoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGFkZFJlbmRlcmFibGUoY29udGFpbmVyLCBpbnN0cnVjdGlvblNldCkge1xuICAgIHRoaXMuX3JlbmRlcmVyLnJlbmRlclBpcGVzLmJhdGNoLmJyZWFrKGluc3RydWN0aW9uU2V0KTtcbiAgICBpbnN0cnVjdGlvblNldC5hZGQoY29udGFpbmVyKTtcbiAgfVxuICBleGVjdXRlKGNvbnRhaW5lcikge1xuICAgIGlmICghY29udGFpbmVyLmlzUmVuZGVyYWJsZSkgcmV0dXJuO1xuICAgIGNvbnRhaW5lci5yZW5kZXIodGhpcy5fcmVuZGVyZXIpO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSBudWxsO1xuICB9XG59XG5DdXN0b21SZW5kZXJQaXBlLmV4dGVuc2lvbiA9IHtcbiAgdHlwZTogW1xuICAgIEV4dGVuc2lvblR5cGUuV2ViR0xQaXBlcyxcbiAgICBFeHRlbnNpb25UeXBlLldlYkdQVVBpcGVzLFxuICAgIEV4dGVuc2lvblR5cGUuQ2FudmFzUGlwZXNcbiAgXSxcbiAgbmFtZTogXCJjdXN0b21SZW5kZXJcIlxufTtcblxuZXhwb3J0IHsgQ3VzdG9tUmVuZGVyUGlwZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Q3VzdG9tUmVuZGVyUGlwZS5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIGV4ZWN1dGVJbnN0cnVjdGlvbnMocmVuZGVyR3JvdXAsIHJlbmRlcmVyKSB7XG4gIGNvbnN0IGluc3RydWN0aW9uU2V0ID0gcmVuZGVyR3JvdXAuaW5zdHJ1Y3Rpb25TZXQ7XG4gIGNvbnN0IGluc3RydWN0aW9ucyA9IGluc3RydWN0aW9uU2V0Lmluc3RydWN0aW9ucztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbnN0cnVjdGlvblNldC5pbnN0cnVjdGlvblNpemU7IGkrKykge1xuICAgIGNvbnN0IGluc3RydWN0aW9uID0gaW5zdHJ1Y3Rpb25zW2ldO1xuICAgIHJlbmRlcmVyW2luc3RydWN0aW9uLnJlbmRlclBpcGVJZF0uZXhlY3V0ZShpbnN0cnVjdGlvbik7XG4gIH1cbn1cblxuZXhwb3J0IHsgZXhlY3V0ZUluc3RydWN0aW9ucyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXhlY3V0ZUluc3RydWN0aW9ucy5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBNYXRyaXggfSBmcm9tICcuLi8uLi9tYXRocy9tYXRyaXgvTWF0cml4Lm1qcyc7XG5pbXBvcnQgeyBCaWdQb29sIH0gZnJvbSAnLi4vLi4vdXRpbHMvcG9vbC9Qb29sR3JvdXAubWpzJztcbmltcG9ydCB7IEJhdGNoYWJsZVNwcml0ZSB9IGZyb20gJy4uL3Nwcml0ZS9CYXRjaGFibGVTcHJpdGUubWpzJztcbmltcG9ydCB7IGV4ZWN1dGVJbnN0cnVjdGlvbnMgfSBmcm9tICcuL3V0aWxzL2V4ZWN1dGVJbnN0cnVjdGlvbnMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBSZW5kZXJHcm91cFBpcGUge1xuICBjb25zdHJ1Y3RvcihyZW5kZXJlcikge1xuICAgIHRoaXMuX3JlbmRlcmVyID0gcmVuZGVyZXI7XG4gIH1cbiAgYWRkUmVuZGVyR3JvdXAocmVuZGVyR3JvdXAsIGluc3RydWN0aW9uU2V0KSB7XG4gICAgaWYgKHJlbmRlckdyb3VwLmlzQ2FjaGVkQXNUZXh0dXJlKSB7XG4gICAgICB0aGlzLl9hZGRSZW5kZXJhYmxlQ2FjaGVBc1RleHR1cmUocmVuZGVyR3JvdXAsIGluc3RydWN0aW9uU2V0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fYWRkUmVuZGVyYWJsZURpcmVjdChyZW5kZXJHcm91cCwgaW5zdHJ1Y3Rpb25TZXQpO1xuICAgIH1cbiAgfVxuICBleGVjdXRlKHJlbmRlckdyb3VwKSB7XG4gICAgaWYgKCFyZW5kZXJHcm91cC5pc1JlbmRlcmFibGUpIHJldHVybjtcbiAgICBpZiAocmVuZGVyR3JvdXAuaXNDYWNoZWRBc1RleHR1cmUpIHtcbiAgICAgIHRoaXMuX2V4ZWN1dGVDYWNoZUFzVGV4dHVyZShyZW5kZXJHcm91cCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2V4ZWN1dGVEaXJlY3QocmVuZGVyR3JvdXApO1xuICAgIH1cbiAgfVxuICBkZXN0cm95KCkge1xuICAgIHRoaXMuX3JlbmRlcmVyID0gbnVsbDtcbiAgfVxuICBfYWRkUmVuZGVyYWJsZURpcmVjdChyZW5kZXJHcm91cCwgaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICB0aGlzLl9yZW5kZXJlci5yZW5kZXJQaXBlcy5iYXRjaC5icmVhayhpbnN0cnVjdGlvblNldCk7XG4gICAgaWYgKHJlbmRlckdyb3VwLl9iYXRjaGFibGVSZW5kZXJHcm91cCkge1xuICAgICAgQmlnUG9vbC5yZXR1cm4ocmVuZGVyR3JvdXAuX2JhdGNoYWJsZVJlbmRlckdyb3VwKTtcbiAgICAgIHJlbmRlckdyb3VwLl9iYXRjaGFibGVSZW5kZXJHcm91cCA9IG51bGw7XG4gICAgfVxuICAgIGluc3RydWN0aW9uU2V0LmFkZChyZW5kZXJHcm91cCk7XG4gIH1cbiAgX2FkZFJlbmRlcmFibGVDYWNoZUFzVGV4dHVyZShyZW5kZXJHcm91cCwgaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICBjb25zdCBiYXRjaGFibGVSZW5kZXJHcm91cCA9IHJlbmRlckdyb3VwLl9iYXRjaGFibGVSZW5kZXJHcm91cCA/PyAocmVuZGVyR3JvdXAuX2JhdGNoYWJsZVJlbmRlckdyb3VwID0gQmlnUG9vbC5nZXQoQmF0Y2hhYmxlU3ByaXRlKSk7XG4gICAgYmF0Y2hhYmxlUmVuZGVyR3JvdXAucmVuZGVyYWJsZSA9IHJlbmRlckdyb3VwLnJvb3Q7XG4gICAgYmF0Y2hhYmxlUmVuZGVyR3JvdXAudHJhbnNmb3JtID0gcmVuZGVyR3JvdXAucm9vdC5yZWxhdGl2ZUdyb3VwVHJhbnNmb3JtO1xuICAgIGJhdGNoYWJsZVJlbmRlckdyb3VwLnRleHR1cmUgPSByZW5kZXJHcm91cC50ZXh0dXJlO1xuICAgIGJhdGNoYWJsZVJlbmRlckdyb3VwLmJvdW5kcyA9IHJlbmRlckdyb3VwLl90ZXh0dXJlQm91bmRzO1xuICAgIGluc3RydWN0aW9uU2V0LmFkZChyZW5kZXJHcm91cCk7XG4gICAgdGhpcy5fcmVuZGVyZXIucmVuZGVyUGlwZXMuYmxlbmRNb2RlLnB1c2hCbGVuZE1vZGUocmVuZGVyR3JvdXAsIHJlbmRlckdyb3VwLnJvb3QuZ3JvdXBCbGVuZE1vZGUsIGluc3RydWN0aW9uU2V0KTtcbiAgICB0aGlzLl9yZW5kZXJlci5yZW5kZXJQaXBlcy5iYXRjaC5hZGRUb0JhdGNoKGJhdGNoYWJsZVJlbmRlckdyb3VwLCBpbnN0cnVjdGlvblNldCk7XG4gICAgdGhpcy5fcmVuZGVyZXIucmVuZGVyUGlwZXMuYmxlbmRNb2RlLnBvcEJsZW5kTW9kZShpbnN0cnVjdGlvblNldCk7XG4gIH1cbiAgX2V4ZWN1dGVDYWNoZUFzVGV4dHVyZShyZW5kZXJHcm91cCkge1xuICAgIGlmIChyZW5kZXJHcm91cC50ZXh0dXJlTmVlZHNVcGRhdGUpIHtcbiAgICAgIHJlbmRlckdyb3VwLnRleHR1cmVOZWVkc1VwZGF0ZSA9IGZhbHNlO1xuICAgICAgY29uc3Qgd29ybGRUcmFuc2Zvcm1NYXRyaXggPSBuZXcgTWF0cml4KCkudHJhbnNsYXRlKFxuICAgICAgICAtcmVuZGVyR3JvdXAuX3RleHR1cmVCb3VuZHMueCxcbiAgICAgICAgLXJlbmRlckdyb3VwLl90ZXh0dXJlQm91bmRzLnlcbiAgICAgICk7XG4gICAgICB0aGlzLl9yZW5kZXJlci5yZW5kZXJUYXJnZXQucHVzaCh7XG4gICAgICAgIHRhcmdldDogcmVuZGVyR3JvdXAudGV4dHVyZSxcbiAgICAgICAgY2xlYXI6IHRydWUsXG4gICAgICAgIGZyYW1lOiByZW5kZXJHcm91cC50ZXh0dXJlLmZyYW1lXG4gICAgICB9KTtcbiAgICAgIHRoaXMuX3JlbmRlcmVyLmdsb2JhbFVuaWZvcm1zLnB1c2goe1xuICAgICAgICB3b3JsZFRyYW5zZm9ybU1hdHJpeCxcbiAgICAgICAgd29ybGRDb2xvcjogNDI5NDk2NzI5NSxcbiAgICAgICAgb2Zmc2V0OiB7IHg6IDAsIHk6IDAgfVxuICAgICAgfSk7XG4gICAgICBleGVjdXRlSW5zdHJ1Y3Rpb25zKHJlbmRlckdyb3VwLCB0aGlzLl9yZW5kZXJlci5yZW5kZXJQaXBlcyk7XG4gICAgICB0aGlzLl9yZW5kZXJlci5yZW5kZXJUYXJnZXQuZmluaXNoUmVuZGVyUGFzcygpO1xuICAgICAgdGhpcy5fcmVuZGVyZXIucmVuZGVyVGFyZ2V0LnBvcCgpO1xuICAgICAgdGhpcy5fcmVuZGVyZXIuZ2xvYmFsVW5pZm9ybXMucG9wKCk7XG4gICAgfVxuICAgIHJlbmRlckdyb3VwLl9iYXRjaGFibGVSZW5kZXJHcm91cC5fYmF0Y2hlci51cGRhdGVFbGVtZW50KHJlbmRlckdyb3VwLl9iYXRjaGFibGVSZW5kZXJHcm91cCk7XG4gICAgcmVuZGVyR3JvdXAuX2JhdGNoYWJsZVJlbmRlckdyb3VwLl9iYXRjaGVyLmdlb21ldHJ5LmJ1ZmZlcnNbMF0udXBkYXRlKCk7XG4gIH1cbiAgX2V4ZWN1dGVEaXJlY3QocmVuZGVyR3JvdXApIHtcbiAgICB0aGlzLl9yZW5kZXJlci5nbG9iYWxVbmlmb3Jtcy5wdXNoKHtcbiAgICAgIHdvcmxkVHJhbnNmb3JtTWF0cml4OiByZW5kZXJHcm91cC5pbnZlcnNlUGFyZW50VGV4dHVyZVRyYW5zZm9ybSxcbiAgICAgIHdvcmxkQ29sb3I6IHJlbmRlckdyb3VwLndvcmxkQ29sb3JBbHBoYVxuICAgIH0pO1xuICAgIGV4ZWN1dGVJbnN0cnVjdGlvbnMocmVuZGVyR3JvdXAsIHRoaXMuX3JlbmRlcmVyLnJlbmRlclBpcGVzKTtcbiAgICB0aGlzLl9yZW5kZXJlci5nbG9iYWxVbmlmb3Jtcy5wb3AoKTtcbiAgfVxufVxuUmVuZGVyR3JvdXBQaXBlLmV4dGVuc2lvbiA9IHtcbiAgdHlwZTogW1xuICAgIEV4dGVuc2lvblR5cGUuV2ViR0xQaXBlcyxcbiAgICBFeHRlbnNpb25UeXBlLldlYkdQVVBpcGVzLFxuICAgIEV4dGVuc2lvblR5cGUuQ2FudmFzUGlwZXNcbiAgXSxcbiAgbmFtZTogXCJyZW5kZXJHcm91cFwiXG59O1xuXG5leHBvcnQgeyBSZW5kZXJHcm91cFBpcGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVJlbmRlckdyb3VwUGlwZS5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBCYXRjaGFibGVTcHJpdGUgfSBmcm9tICcuL0JhdGNoYWJsZVNwcml0ZS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIFNwcml0ZVBpcGUge1xuICBjb25zdHJ1Y3RvcihyZW5kZXJlcikge1xuICAgIHRoaXMuX3JlbmRlcmVyID0gcmVuZGVyZXI7XG4gIH1cbiAgYWRkUmVuZGVyYWJsZShzcHJpdGUsIGluc3RydWN0aW9uU2V0KSB7XG4gICAgY29uc3QgZ3B1U3ByaXRlID0gdGhpcy5fZ2V0R3B1U3ByaXRlKHNwcml0ZSk7XG4gICAgaWYgKHNwcml0ZS5kaWRWaWV3VXBkYXRlKSB0aGlzLl91cGRhdGVCYXRjaGFibGVTcHJpdGUoc3ByaXRlLCBncHVTcHJpdGUpO1xuICAgIHRoaXMuX3JlbmRlcmVyLnJlbmRlclBpcGVzLmJhdGNoLmFkZFRvQmF0Y2goZ3B1U3ByaXRlLCBpbnN0cnVjdGlvblNldCk7XG4gIH1cbiAgdXBkYXRlUmVuZGVyYWJsZShzcHJpdGUpIHtcbiAgICBjb25zdCBncHVTcHJpdGUgPSB0aGlzLl9nZXRHcHVTcHJpdGUoc3ByaXRlKTtcbiAgICBpZiAoc3ByaXRlLmRpZFZpZXdVcGRhdGUpIHRoaXMuX3VwZGF0ZUJhdGNoYWJsZVNwcml0ZShzcHJpdGUsIGdwdVNwcml0ZSk7XG4gICAgZ3B1U3ByaXRlLl9iYXRjaGVyLnVwZGF0ZUVsZW1lbnQoZ3B1U3ByaXRlKTtcbiAgfVxuICB2YWxpZGF0ZVJlbmRlcmFibGUoc3ByaXRlKSB7XG4gICAgY29uc3QgZ3B1U3ByaXRlID0gdGhpcy5fZ2V0R3B1U3ByaXRlKHNwcml0ZSk7XG4gICAgcmV0dXJuICFncHVTcHJpdGUuX2JhdGNoZXIuY2hlY2tBbmRVcGRhdGVUZXh0dXJlKFxuICAgICAgZ3B1U3ByaXRlLFxuICAgICAgc3ByaXRlLl90ZXh0dXJlXG4gICAgKTtcbiAgfVxuICBfdXBkYXRlQmF0Y2hhYmxlU3ByaXRlKHNwcml0ZSwgYmF0Y2hhYmxlU3ByaXRlKSB7XG4gICAgYmF0Y2hhYmxlU3ByaXRlLmJvdW5kcyA9IHNwcml0ZS52aXN1YWxCb3VuZHM7XG4gICAgYmF0Y2hhYmxlU3ByaXRlLnRleHR1cmUgPSBzcHJpdGUuX3RleHR1cmU7XG4gIH1cbiAgX2dldEdwdVNwcml0ZShzcHJpdGUpIHtcbiAgICByZXR1cm4gc3ByaXRlLl9ncHVEYXRhW3RoaXMuX3JlbmRlcmVyLnVpZF0gfHwgdGhpcy5faW5pdEdQVVNwcml0ZShzcHJpdGUpO1xuICB9XG4gIF9pbml0R1BVU3ByaXRlKHNwcml0ZSkge1xuICAgIGNvbnN0IGJhdGNoYWJsZVNwcml0ZSA9IG5ldyBCYXRjaGFibGVTcHJpdGUoKTtcbiAgICBiYXRjaGFibGVTcHJpdGUucmVuZGVyYWJsZSA9IHNwcml0ZTtcbiAgICBiYXRjaGFibGVTcHJpdGUudHJhbnNmb3JtID0gc3ByaXRlLmdyb3VwVHJhbnNmb3JtO1xuICAgIGJhdGNoYWJsZVNwcml0ZS50ZXh0dXJlID0gc3ByaXRlLl90ZXh0dXJlO1xuICAgIGJhdGNoYWJsZVNwcml0ZS5ib3VuZHMgPSBzcHJpdGUudmlzdWFsQm91bmRzO1xuICAgIGJhdGNoYWJsZVNwcml0ZS5yb3VuZFBpeGVscyA9IHRoaXMuX3JlbmRlcmVyLl9yb3VuZFBpeGVscyB8IHNwcml0ZS5fcm91bmRQaXhlbHM7XG4gICAgc3ByaXRlLl9ncHVEYXRhW3RoaXMuX3JlbmRlcmVyLnVpZF0gPSBiYXRjaGFibGVTcHJpdGU7XG4gICAgcmV0dXJuIGJhdGNoYWJsZVNwcml0ZTtcbiAgfVxuICBkZXN0cm95KCkge1xuICAgIHRoaXMuX3JlbmRlcmVyID0gbnVsbDtcbiAgfVxufVxuLyoqIEBpZ25vcmUgKi9cblNwcml0ZVBpcGUuZXh0ZW5zaW9uID0ge1xuICB0eXBlOiBbXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHTFBpcGVzLFxuICAgIEV4dGVuc2lvblR5cGUuV2ViR1BVUGlwZXMsXG4gICAgRXh0ZW5zaW9uVHlwZS5DYW52YXNQaXBlc1xuICBdLFxuICBuYW1lOiBcInNwcml0ZVwiXG59O1xuXG5leHBvcnQgeyBTcHJpdGVQaXBlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1TcHJpdGVQaXBlLm1qcy5tYXBcbiIsImltcG9ydCB7IGV4dGVuc2lvbnMsIEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi8uLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IEZpbHRlckVmZmVjdCB9IGZyb20gJy4uLy4uLy4uLy4uL2ZpbHRlcnMvRmlsdGVyRWZmZWN0Lm1qcyc7XG5pbXBvcnQgeyBSZW5kZXJHcm91cCB9IGZyb20gJy4uLy4uLy4uLy4uL3NjZW5lL2NvbnRhaW5lci9SZW5kZXJHcm91cC5tanMnO1xuaW1wb3J0IHsgd2FybiB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2xvZ2dpbmcvd2Fybi5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IEJMRU5EX01PREVfRklMVEVSUyA9IHt9O1xuZXh0ZW5zaW9ucy5oYW5kbGUoRXh0ZW5zaW9uVHlwZS5CbGVuZE1vZGUsICh2YWx1ZSkgPT4ge1xuICBpZiAoIXZhbHVlLm5hbWUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJCbGVuZE1vZGUgZXh0ZW5zaW9uIG11c3QgaGF2ZSBhIG5hbWUgcHJvcGVydHlcIik7XG4gIH1cbiAgQkxFTkRfTU9ERV9GSUxURVJTW3ZhbHVlLm5hbWVdID0gdmFsdWUucmVmO1xufSwgKHZhbHVlKSA9PiB7XG4gIGRlbGV0ZSBCTEVORF9NT0RFX0ZJTFRFUlNbdmFsdWUubmFtZV07XG59KTtcbmNsYXNzIEJsZW5kTW9kZVBpcGUge1xuICBjb25zdHJ1Y3RvcihyZW5kZXJlcikge1xuICAgIHRoaXMuX2JsZW5kTW9kZVN0YWNrID0gW107XG4gICAgdGhpcy5faXNBZHZhbmNlZCA9IGZhbHNlO1xuICAgIHRoaXMuX2ZpbHRlckhhc2ggPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB0aGlzLl9yZW5kZXJlciA9IHJlbmRlcmVyO1xuICAgIHRoaXMuX3JlbmRlcmVyLnJ1bm5lcnMucHJlcmVuZGVyLmFkZCh0aGlzKTtcbiAgfVxuICBwcmVyZW5kZXIoKSB7XG4gICAgdGhpcy5fYWN0aXZlQmxlbmRNb2RlID0gXCJub3JtYWxcIjtcbiAgICB0aGlzLl9pc0FkdmFuY2VkID0gZmFsc2U7XG4gIH1cbiAgLyoqXG4gICAqIFB1c2ggYSBibGVuZCBtb2RlIG9udG8gdGhlIGludGVybmFsIHN0YWNrIGFuZCBhcHBseSBpdCB0byB0aGUgaW5zdHJ1Y3Rpb24gc2V0IGlmIG5lZWRlZC5cbiAgICogQHBhcmFtIHJlbmRlcmFibGUgLSBUaGUgcmVuZGVyYWJsZSBvciB7QGxpbmsgUmVuZGVyR3JvdXB9IGFzc29jaWF0ZWQgd2l0aCB0aGUgY2hhbmdlLlxuICAgKiBAcGFyYW0gYmxlbmRNb2RlIC0gVGhlIGJsZW5kIG1vZGUgdG8gYWN0aXZhdGUuXG4gICAqIEBwYXJhbSBpbnN0cnVjdGlvblNldCAtIFRoZSBpbnN0cnVjdGlvbiBzZXQgYmVpbmcgYnVpbHQuXG4gICAqL1xuICBwdXNoQmxlbmRNb2RlKHJlbmRlcmFibGUsIGJsZW5kTW9kZSwgaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICB0aGlzLl9ibGVuZE1vZGVTdGFjay5wdXNoKGJsZW5kTW9kZSk7XG4gICAgdGhpcy5zZXRCbGVuZE1vZGUocmVuZGVyYWJsZSwgYmxlbmRNb2RlLCBpbnN0cnVjdGlvblNldCk7XG4gIH1cbiAgLyoqXG4gICAqIFBvcCB0aGUgbGFzdCBibGVuZCBtb2RlIGZyb20gdGhlIHN0YWNrIGFuZCBhcHBseSB0aGUgbmV3IHRvcC1vZi1zdGFjayBtb2RlLlxuICAgKiBAcGFyYW0gaW5zdHJ1Y3Rpb25TZXQgLSBUaGUgaW5zdHJ1Y3Rpb24gc2V0IGJlaW5nIGJ1aWx0LlxuICAgKi9cbiAgcG9wQmxlbmRNb2RlKGluc3RydWN0aW9uU2V0KSB7XG4gICAgdGhpcy5fYmxlbmRNb2RlU3RhY2sucG9wKCk7XG4gICAgY29uc3QgYmxlbmRNb2RlID0gdGhpcy5fYmxlbmRNb2RlU3RhY2tbdGhpcy5fYWN0aXZlQmxlbmRNb2RlLmxlbmd0aCAtIDFdID8/IFwibm9ybWFsXCI7XG4gICAgdGhpcy5zZXRCbGVuZE1vZGUobnVsbCwgYmxlbmRNb2RlLCBpbnN0cnVjdGlvblNldCk7XG4gIH1cbiAgLyoqXG4gICAqIEVuc3VyZSBhIGJsZW5kIG1vZGUgc3dpdGNoIGlzIGFkZGVkIHRvIHRoZSBpbnN0cnVjdGlvbiBzZXQgd2hlbiB0aGUgbW9kZSBjaGFuZ2VzLlxuICAgKiBJZiBhbiBhZHZhbmNlZCBibGVuZCBtb2RlIGlzIGFjdGl2ZSwgc3Vic2VxdWVudCByZW5kZXJhYmxlcyB3aWxsIGJlIGNvbGxlY3RlZCBzbyB0aGV5IGNhbiBiZVxuICAgKiByZW5kZXJlZCB3aXRoaW4gYSBzaW5nbGUgZmlsdGVyIHBhc3MuXG4gICAqIEBwYXJhbSByZW5kZXJhYmxlIC0gVGhlIHJlbmRlcmFibGUgb3Ige0BsaW5rIFJlbmRlckdyb3VwfSB0byBhc3NvY2lhdGUgd2l0aCB0aGUgY2hhbmdlLCBvciBudWxsIHdoZW4gdW53aW5kaW5nLlxuICAgKiBAcGFyYW0gYmxlbmRNb2RlIC0gVGhlIHRhcmdldCBibGVuZCBtb2RlLlxuICAgKiBAcGFyYW0gaW5zdHJ1Y3Rpb25TZXQgLSBUaGUgaW5zdHJ1Y3Rpb24gc2V0IGJlaW5nIGJ1aWx0LlxuICAgKi9cbiAgc2V0QmxlbmRNb2RlKHJlbmRlcmFibGUsIGJsZW5kTW9kZSwgaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICBjb25zdCBpc1JlbmRlckdyb3VwID0gcmVuZGVyYWJsZSBpbnN0YW5jZW9mIFJlbmRlckdyb3VwO1xuICAgIGlmICh0aGlzLl9hY3RpdmVCbGVuZE1vZGUgPT09IGJsZW5kTW9kZSkge1xuICAgICAgaWYgKHRoaXMuX2lzQWR2YW5jZWQgJiYgcmVuZGVyYWJsZSAmJiAhaXNSZW5kZXJHcm91cCkge1xuICAgICAgICB0aGlzLl9yZW5kZXJhYmxlTGlzdD8ucHVzaChyZW5kZXJhYmxlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHRoaXMuX2lzQWR2YW5jZWQpIHRoaXMuX2VuZEFkdmFuY2VkQmxlbmRNb2RlKGluc3RydWN0aW9uU2V0KTtcbiAgICB0aGlzLl9hY3RpdmVCbGVuZE1vZGUgPSBibGVuZE1vZGU7XG4gICAgaWYgKCFyZW5kZXJhYmxlKSByZXR1cm47XG4gICAgdGhpcy5faXNBZHZhbmNlZCA9ICEhQkxFTkRfTU9ERV9GSUxURVJTW2JsZW5kTW9kZV07XG4gICAgaWYgKHRoaXMuX2lzQWR2YW5jZWQpIHRoaXMuX2JlZ2luQWR2YW5jZWRCbGVuZE1vZGUocmVuZGVyYWJsZSwgaW5zdHJ1Y3Rpb25TZXQpO1xuICB9XG4gIF9iZWdpbkFkdmFuY2VkQmxlbmRNb2RlKHJlbmRlcmFibGUsIGluc3RydWN0aW9uU2V0KSB7XG4gICAgdGhpcy5fcmVuZGVyZXIucmVuZGVyUGlwZXMuYmF0Y2guYnJlYWsoaW5zdHJ1Y3Rpb25TZXQpO1xuICAgIGNvbnN0IGJsZW5kTW9kZSA9IHRoaXMuX2FjdGl2ZUJsZW5kTW9kZTtcbiAgICBpZiAoIUJMRU5EX01PREVfRklMVEVSU1tibGVuZE1vZGVdKSB7XG4gICAgICB3YXJuKGBVbmFibGUgdG8gYXNzaWduIEJsZW5kTW9kZTogJyR7YmxlbmRNb2RlfScuIFlvdSBtYXkgd2FudCB0byBpbmNsdWRlOiBpbXBvcnQgJ3BpeGkuanMvYWR2YW5jZWQtYmxlbmQtbW9kZXMnYCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGZpbHRlckVmZmVjdCA9IHRoaXMuX2Vuc3VyZUZpbHRlckVmZmVjdChibGVuZE1vZGUpO1xuICAgIGNvbnN0IGlzUmVuZGVyR3JvdXAgPSByZW5kZXJhYmxlIGluc3RhbmNlb2YgUmVuZGVyR3JvdXA7XG4gICAgY29uc3QgaW5zdHJ1Y3Rpb24gPSB7XG4gICAgICByZW5kZXJQaXBlSWQ6IFwiZmlsdGVyXCIsXG4gICAgICBhY3Rpb246IFwicHVzaEZpbHRlclwiLFxuICAgICAgZmlsdGVyRWZmZWN0LFxuICAgICAgcmVuZGVyYWJsZXM6IGlzUmVuZGVyR3JvdXAgPyBudWxsIDogW3JlbmRlcmFibGVdLFxuICAgICAgY29udGFpbmVyOiBpc1JlbmRlckdyb3VwID8gcmVuZGVyYWJsZS5yb290IDogbnVsbCxcbiAgICAgIGNhbkJ1bmRsZTogZmFsc2VcbiAgICB9O1xuICAgIHRoaXMuX3JlbmRlcmFibGVMaXN0ID0gaW5zdHJ1Y3Rpb24ucmVuZGVyYWJsZXM7XG4gICAgaW5zdHJ1Y3Rpb25TZXQuYWRkKGluc3RydWN0aW9uKTtcbiAgfVxuICBfZW5zdXJlRmlsdGVyRWZmZWN0KGJsZW5kTW9kZSkge1xuICAgIGxldCBmaWx0ZXJFZmZlY3QgPSB0aGlzLl9maWx0ZXJIYXNoW2JsZW5kTW9kZV07XG4gICAgaWYgKCFmaWx0ZXJFZmZlY3QpIHtcbiAgICAgIGZpbHRlckVmZmVjdCA9IHRoaXMuX2ZpbHRlckhhc2hbYmxlbmRNb2RlXSA9IG5ldyBGaWx0ZXJFZmZlY3QoKTtcbiAgICAgIGZpbHRlckVmZmVjdC5maWx0ZXJzID0gW25ldyBCTEVORF9NT0RFX0ZJTFRFUlNbYmxlbmRNb2RlXSgpXTtcbiAgICB9XG4gICAgcmV0dXJuIGZpbHRlckVmZmVjdDtcbiAgfVxuICBfZW5kQWR2YW5jZWRCbGVuZE1vZGUoaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICB0aGlzLl9pc0FkdmFuY2VkID0gZmFsc2U7XG4gICAgdGhpcy5fcmVuZGVyYWJsZUxpc3QgPSBudWxsO1xuICAgIHRoaXMuX3JlbmRlcmVyLnJlbmRlclBpcGVzLmJhdGNoLmJyZWFrKGluc3RydWN0aW9uU2V0KTtcbiAgICBpbnN0cnVjdGlvblNldC5hZGQoe1xuICAgICAgcmVuZGVyUGlwZUlkOiBcImZpbHRlclwiLFxuICAgICAgYWN0aW9uOiBcInBvcEZpbHRlclwiLFxuICAgICAgY2FuQnVuZGxlOiBmYWxzZVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBjYWxsZWQgd2hlbiB0aGUgaW5zdHJ1Y3Rpb24gYnVpbGQgcHJvY2VzcyBpcyBzdGFydGluZyB0aGlzIHdpbGwgcmVzZXQgaW50ZXJuYWxseSB0byB0aGUgZGVmYXVsdCBibGVuZCBtb2RlXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgYnVpbGRTdGFydCgpIHtcbiAgICB0aGlzLl9pc0FkdmFuY2VkID0gZmFsc2U7XG4gIH1cbiAgLyoqXG4gICAqIGNhbGxlZCB3aGVuIHRoZSBpbnN0cnVjdGlvbiBidWlsZCBwcm9jZXNzIGlzIGZpbmlzaGVkLCBlbnN1cmluZyB0aGF0IGlmIHRoZXJlIGlzIGFuIGFkdmFuY2VkIGJsZW5kIG1vZGVcbiAgICogYWN0aXZlLCB3ZSBhZGQgdGhlIGZpbmFsIHJlbmRlciBpbnN0cnVjdGlvbnMgYWRkZWQgdG8gdGhlIGluc3RydWN0aW9uIHNldFxuICAgKiBAcGFyYW0gaW5zdHJ1Y3Rpb25TZXQgLSBUaGUgaW5zdHJ1Y3Rpb24gc2V0IHdlIGFyZSBhZGRpbmcgdG9cbiAgICogQGludGVybmFsXG4gICAqL1xuICBidWlsZEVuZChpbnN0cnVjdGlvblNldCkge1xuICAgIGlmICghdGhpcy5faXNBZHZhbmNlZCkgcmV0dXJuO1xuICAgIHRoaXMuX2VuZEFkdmFuY2VkQmxlbmRNb2RlKGluc3RydWN0aW9uU2V0KTtcbiAgfVxuICAvKiogQGludGVybmFsICovXG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSBudWxsO1xuICAgIHRoaXMuX3JlbmRlcmFibGVMaXN0ID0gbnVsbDtcbiAgICBmb3IgKGNvbnN0IGkgaW4gdGhpcy5fZmlsdGVySGFzaCkge1xuICAgICAgdGhpcy5fZmlsdGVySGFzaFtpXS5kZXN0cm95KCk7XG4gICAgfVxuICAgIHRoaXMuX2ZpbHRlckhhc2ggPSBudWxsO1xuICB9XG59XG4vKiogQGlnbm9yZSAqL1xuQmxlbmRNb2RlUGlwZS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMUGlwZXMsXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHUFVQaXBlcyxcbiAgICBFeHRlbnNpb25UeXBlLkNhbnZhc1BpcGVzXG4gIF0sXG4gIG5hbWU6IFwiYmxlbmRNb2RlXCJcbn07XG5cbmV4cG9ydCB7IEJsZW5kTW9kZVBpcGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUJsZW5kTW9kZVBpcGUubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBjbGVhckxpc3QobGlzdCwgaW5kZXgpIHtcbiAgaW5kZXggfHwgKGluZGV4ID0gMCk7XG4gIGZvciAobGV0IGogPSBpbmRleDsgaiA8IGxpc3QubGVuZ3RoOyBqKyspIHtcbiAgICBpZiAobGlzdFtqXSkge1xuICAgICAgbGlzdFtqXSA9IG51bGw7XG4gICAgfSBlbHNlIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgeyBjbGVhckxpc3QgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNsZWFyTGlzdC5tanMubWFwXG4iLCJpbXBvcnQgeyBDb250YWluZXIsIFVQREFURV9WSVNJQkxFLCBVUERBVEVfQ09MT1IsIFVQREFURV9CTEVORCB9IGZyb20gJy4uL0NvbnRhaW5lci5tanMnO1xuaW1wb3J0IHsgY2xlYXJMaXN0IH0gZnJvbSAnLi9jbGVhckxpc3QubWpzJztcbmltcG9ydCB7IG11bHRpcGx5Q29sb3JzIH0gZnJvbSAnLi9tdWx0aXBseUNvbG9ycy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IHRlbXBDb250YWluZXIgPSBuZXcgQ29udGFpbmVyKCk7XG5jb25zdCBVUERBVEVfQkxFTkRfQ09MT1JfVklTSUJMRSA9IFVQREFURV9WSVNJQkxFIHwgVVBEQVRFX0NPTE9SIHwgVVBEQVRFX0JMRU5EO1xuZnVuY3Rpb24gdXBkYXRlUmVuZGVyR3JvdXBUcmFuc2Zvcm1zKHJlbmRlckdyb3VwLCB1cGRhdGVDaGlsZFJlbmRlckdyb3VwcyA9IGZhbHNlKSB7XG4gIHVwZGF0ZVJlbmRlckdyb3VwVHJhbnNmb3JtKHJlbmRlckdyb3VwKTtcbiAgY29uc3QgY2hpbGRyZW5Ub1VwZGF0ZSA9IHJlbmRlckdyb3VwLmNoaWxkcmVuVG9VcGRhdGU7XG4gIGNvbnN0IHVwZGF0ZVRpY2sgPSByZW5kZXJHcm91cC51cGRhdGVUaWNrKys7XG4gIGZvciAoY29uc3QgaiBpbiBjaGlsZHJlblRvVXBkYXRlKSB7XG4gICAgY29uc3QgcmVuZGVyR3JvdXBEZXB0aCA9IE51bWJlcihqKTtcbiAgICBjb25zdCBjaGlsZHJlbkF0RGVwdGggPSBjaGlsZHJlblRvVXBkYXRlW2pdO1xuICAgIGNvbnN0IGxpc3QgPSBjaGlsZHJlbkF0RGVwdGgubGlzdDtcbiAgICBjb25zdCBpbmRleCA9IGNoaWxkcmVuQXREZXB0aC5pbmRleDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGluZGV4OyBpKyspIHtcbiAgICAgIGNvbnN0IGNoaWxkID0gbGlzdFtpXTtcbiAgICAgIGlmIChjaGlsZC5wYXJlbnRSZW5kZXJHcm91cCA9PT0gcmVuZGVyR3JvdXAgJiYgY2hpbGQucmVsYXRpdmVSZW5kZXJHcm91cERlcHRoID09PSByZW5kZXJHcm91cERlcHRoKSB7XG4gICAgICAgIHVwZGF0ZVRyYW5zZm9ybUFuZENoaWxkcmVuKGNoaWxkLCB1cGRhdGVUaWNrLCAwKTtcbiAgICAgIH1cbiAgICB9XG4gICAgY2xlYXJMaXN0KGxpc3QsIGluZGV4KTtcbiAgICBjaGlsZHJlbkF0RGVwdGguaW5kZXggPSAwO1xuICB9XG4gIGlmICh1cGRhdGVDaGlsZFJlbmRlckdyb3Vwcykge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVuZGVyR3JvdXAucmVuZGVyR3JvdXBDaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgdXBkYXRlUmVuZGVyR3JvdXBUcmFuc2Zvcm1zKHJlbmRlckdyb3VwLnJlbmRlckdyb3VwQ2hpbGRyZW5baV0sIHVwZGF0ZUNoaWxkUmVuZGVyR3JvdXBzKTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIHVwZGF0ZVJlbmRlckdyb3VwVHJhbnNmb3JtKHJlbmRlckdyb3VwKSB7XG4gIGNvbnN0IHJvb3QgPSByZW5kZXJHcm91cC5yb290O1xuICBsZXQgd29ybGRBbHBoYTtcbiAgaWYgKHJlbmRlckdyb3VwLnJlbmRlckdyb3VwUGFyZW50KSB7XG4gICAgY29uc3QgcmVuZGVyR3JvdXBQYXJlbnQgPSByZW5kZXJHcm91cC5yZW5kZXJHcm91cFBhcmVudDtcbiAgICByZW5kZXJHcm91cC53b3JsZFRyYW5zZm9ybS5hcHBlbmRGcm9tKFxuICAgICAgcm9vdC5yZWxhdGl2ZUdyb3VwVHJhbnNmb3JtLFxuICAgICAgcmVuZGVyR3JvdXBQYXJlbnQud29ybGRUcmFuc2Zvcm1cbiAgICApO1xuICAgIHJlbmRlckdyb3VwLndvcmxkQ29sb3IgPSBtdWx0aXBseUNvbG9ycyhcbiAgICAgIHJvb3QuZ3JvdXBDb2xvcixcbiAgICAgIHJlbmRlckdyb3VwUGFyZW50LndvcmxkQ29sb3JcbiAgICApO1xuICAgIHdvcmxkQWxwaGEgPSByb290Lmdyb3VwQWxwaGEgKiByZW5kZXJHcm91cFBhcmVudC53b3JsZEFscGhhO1xuICB9IGVsc2Uge1xuICAgIHJlbmRlckdyb3VwLndvcmxkVHJhbnNmb3JtLmNvcHlGcm9tKHJvb3QubG9jYWxUcmFuc2Zvcm0pO1xuICAgIHJlbmRlckdyb3VwLndvcmxkQ29sb3IgPSByb290LmxvY2FsQ29sb3I7XG4gICAgd29ybGRBbHBoYSA9IHJvb3QubG9jYWxBbHBoYTtcbiAgfVxuICB3b3JsZEFscGhhID0gd29ybGRBbHBoYSA8IDAgPyAwIDogd29ybGRBbHBoYSA+IDEgPyAxIDogd29ybGRBbHBoYTtcbiAgcmVuZGVyR3JvdXAud29ybGRBbHBoYSA9IHdvcmxkQWxwaGE7XG4gIHJlbmRlckdyb3VwLndvcmxkQ29sb3JBbHBoYSA9IHJlbmRlckdyb3VwLndvcmxkQ29sb3IgKyAoKHdvcmxkQWxwaGEgKiAyNTUgfCAwKSA8PCAyNCk7XG59XG5mdW5jdGlvbiB1cGRhdGVUcmFuc2Zvcm1BbmRDaGlsZHJlbihjb250YWluZXIsIHVwZGF0ZVRpY2ssIHVwZGF0ZUZsYWdzKSB7XG4gIGlmICh1cGRhdGVUaWNrID09PSBjb250YWluZXIudXBkYXRlVGljaykgcmV0dXJuO1xuICBjb250YWluZXIudXBkYXRlVGljayA9IHVwZGF0ZVRpY2s7XG4gIGNvbnRhaW5lci5kaWRDaGFuZ2UgPSBmYWxzZTtcbiAgY29uc3QgbG9jYWxUcmFuc2Zvcm0gPSBjb250YWluZXIubG9jYWxUcmFuc2Zvcm07XG4gIGNvbnRhaW5lci51cGRhdGVMb2NhbFRyYW5zZm9ybSgpO1xuICBjb25zdCBwYXJlbnQgPSBjb250YWluZXIucGFyZW50O1xuICBpZiAocGFyZW50ICYmICFwYXJlbnQucmVuZGVyR3JvdXApIHtcbiAgICB1cGRhdGVGbGFncyB8PSBjb250YWluZXIuX3VwZGF0ZUZsYWdzO1xuICAgIGNvbnRhaW5lci5yZWxhdGl2ZUdyb3VwVHJhbnNmb3JtLmFwcGVuZEZyb20oXG4gICAgICBsb2NhbFRyYW5zZm9ybSxcbiAgICAgIHBhcmVudC5yZWxhdGl2ZUdyb3VwVHJhbnNmb3JtXG4gICAgKTtcbiAgICBpZiAodXBkYXRlRmxhZ3MgJiBVUERBVEVfQkxFTkRfQ09MT1JfVklTSUJMRSkge1xuICAgICAgdXBkYXRlQ29sb3JCbGVuZFZpc2liaWxpdHkoY29udGFpbmVyLCBwYXJlbnQsIHVwZGF0ZUZsYWdzKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgdXBkYXRlRmxhZ3MgPSBjb250YWluZXIuX3VwZGF0ZUZsYWdzO1xuICAgIGNvbnRhaW5lci5yZWxhdGl2ZUdyb3VwVHJhbnNmb3JtLmNvcHlGcm9tKGxvY2FsVHJhbnNmb3JtKTtcbiAgICBpZiAodXBkYXRlRmxhZ3MgJiBVUERBVEVfQkxFTkRfQ09MT1JfVklTSUJMRSkge1xuICAgICAgdXBkYXRlQ29sb3JCbGVuZFZpc2liaWxpdHkoY29udGFpbmVyLCB0ZW1wQ29udGFpbmVyLCB1cGRhdGVGbGFncyk7XG4gICAgfVxuICB9XG4gIGlmICghY29udGFpbmVyLnJlbmRlckdyb3VwKSB7XG4gICAgY29uc3QgY2hpbGRyZW4gPSBjb250YWluZXIuY2hpbGRyZW47XG4gICAgY29uc3QgbGVuZ3RoID0gY2hpbGRyZW4ubGVuZ3RoO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAgIHVwZGF0ZVRyYW5zZm9ybUFuZENoaWxkcmVuKGNoaWxkcmVuW2ldLCB1cGRhdGVUaWNrLCB1cGRhdGVGbGFncyk7XG4gICAgfVxuICAgIGNvbnN0IHJlbmRlckdyb3VwID0gY29udGFpbmVyLnBhcmVudFJlbmRlckdyb3VwO1xuICAgIGNvbnN0IHJlbmRlcmFibGUgPSBjb250YWluZXI7XG4gICAgaWYgKHJlbmRlcmFibGUucmVuZGVyUGlwZUlkICYmICFyZW5kZXJHcm91cC5zdHJ1Y3R1cmVEaWRDaGFuZ2UpIHtcbiAgICAgIHJlbmRlckdyb3VwLnVwZGF0ZVJlbmRlcmFibGUocmVuZGVyYWJsZSk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiB1cGRhdGVDb2xvckJsZW5kVmlzaWJpbGl0eShjb250YWluZXIsIHBhcmVudCwgdXBkYXRlRmxhZ3MpIHtcbiAgaWYgKHVwZGF0ZUZsYWdzICYgVVBEQVRFX0NPTE9SKSB7XG4gICAgY29udGFpbmVyLmdyb3VwQ29sb3IgPSBtdWx0aXBseUNvbG9ycyhcbiAgICAgIGNvbnRhaW5lci5sb2NhbENvbG9yLFxuICAgICAgcGFyZW50Lmdyb3VwQ29sb3JcbiAgICApO1xuICAgIGxldCBncm91cEFscGhhID0gY29udGFpbmVyLmxvY2FsQWxwaGEgKiBwYXJlbnQuZ3JvdXBBbHBoYTtcbiAgICBncm91cEFscGhhID0gZ3JvdXBBbHBoYSA8IDAgPyAwIDogZ3JvdXBBbHBoYSA+IDEgPyAxIDogZ3JvdXBBbHBoYTtcbiAgICBjb250YWluZXIuZ3JvdXBBbHBoYSA9IGdyb3VwQWxwaGE7XG4gICAgY29udGFpbmVyLmdyb3VwQ29sb3JBbHBoYSA9IGNvbnRhaW5lci5ncm91cENvbG9yICsgKChncm91cEFscGhhICogMjU1IHwgMCkgPDwgMjQpO1xuICB9XG4gIGlmICh1cGRhdGVGbGFncyAmIFVQREFURV9CTEVORCkge1xuICAgIGNvbnRhaW5lci5ncm91cEJsZW5kTW9kZSA9IGNvbnRhaW5lci5sb2NhbEJsZW5kTW9kZSA9PT0gXCJpbmhlcml0XCIgPyBwYXJlbnQuZ3JvdXBCbGVuZE1vZGUgOiBjb250YWluZXIubG9jYWxCbGVuZE1vZGU7XG4gIH1cbiAgaWYgKHVwZGF0ZUZsYWdzICYgVVBEQVRFX1ZJU0lCTEUpIHtcbiAgICBjb250YWluZXIuZ2xvYmFsRGlzcGxheVN0YXR1cyA9IGNvbnRhaW5lci5sb2NhbERpc3BsYXlTdGF0dXMgJiBwYXJlbnQuZ2xvYmFsRGlzcGxheVN0YXR1cztcbiAgfVxuICBjb250YWluZXIuX3VwZGF0ZUZsYWdzID0gMDtcbn1cblxuZXhwb3J0IHsgdXBkYXRlUmVuZGVyR3JvdXBUcmFuc2Zvcm0sIHVwZGF0ZVJlbmRlckdyb3VwVHJhbnNmb3JtcywgdXBkYXRlVHJhbnNmb3JtQW5kQ2hpbGRyZW4gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVwZGF0ZVJlbmRlckdyb3VwVHJhbnNmb3Jtcy5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmZ1bmN0aW9uIHZhbGlkYXRlUmVuZGVyYWJsZXMocmVuZGVyR3JvdXAsIHJlbmRlclBpcGVzKSB7XG4gIGNvbnN0IHsgbGlzdCB9ID0gcmVuZGVyR3JvdXAuY2hpbGRyZW5SZW5kZXJhYmxlc1RvVXBkYXRlO1xuICBsZXQgcmVidWlsZFJlcXVpcmVkID0gZmFsc2U7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcmVuZGVyR3JvdXAuY2hpbGRyZW5SZW5kZXJhYmxlc1RvVXBkYXRlLmluZGV4OyBpKyspIHtcbiAgICBjb25zdCBjb250YWluZXIgPSBsaXN0W2ldO1xuICAgIGNvbnN0IHJlbmRlcmFibGUgPSBjb250YWluZXI7XG4gICAgY29uc3QgcGlwZSA9IHJlbmRlclBpcGVzW3JlbmRlcmFibGUucmVuZGVyUGlwZUlkXTtcbiAgICByZWJ1aWxkUmVxdWlyZWQgPSBwaXBlLnZhbGlkYXRlUmVuZGVyYWJsZShjb250YWluZXIpO1xuICAgIGlmIChyZWJ1aWxkUmVxdWlyZWQpIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICByZW5kZXJHcm91cC5zdHJ1Y3R1cmVEaWRDaGFuZ2UgPSByZWJ1aWxkUmVxdWlyZWQ7XG4gIHJldHVybiByZWJ1aWxkUmVxdWlyZWQ7XG59XG5cbmV4cG9ydCB7IHZhbGlkYXRlUmVuZGVyYWJsZXMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXZhbGlkYXRlUmVuZGVyYWJsZXMubWpzLm1hcFxuIiwiaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVBvb2wgfSBmcm9tICcuLi8uLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL1RleHR1cmVQb29sLm1qcyc7XG5pbXBvcnQgeyBCb3VuZHMgfSBmcm9tICcuL2JvdW5kcy9Cb3VuZHMubWpzJztcbmltcG9ydCB7IGNsZWFyTGlzdCB9IGZyb20gJy4vdXRpbHMvY2xlYXJMaXN0Lm1qcyc7XG5pbXBvcnQgeyBleGVjdXRlSW5zdHJ1Y3Rpb25zIH0gZnJvbSAnLi91dGlscy9leGVjdXRlSW5zdHJ1Y3Rpb25zLm1qcyc7XG5pbXBvcnQgeyB1cGRhdGVSZW5kZXJHcm91cFRyYW5zZm9ybXMgfSBmcm9tICcuL3V0aWxzL3VwZGF0ZVJlbmRlckdyb3VwVHJhbnNmb3Jtcy5tanMnO1xuaW1wb3J0IHsgdmFsaWRhdGVSZW5kZXJhYmxlcyB9IGZyb20gJy4vdXRpbHMvdmFsaWRhdGVSZW5kZXJhYmxlcy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IHRlbXBNYXRyaXggPSBuZXcgTWF0cml4KCk7XG5jbGFzcyBSZW5kZXJHcm91cFN5c3RlbSB7XG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSByZW5kZXJlcjtcbiAgfVxuICByZW5kZXIoeyBjb250YWluZXIsIHRyYW5zZm9ybSB9KSB7XG4gICAgY29uc3QgcGFyZW50ID0gY29udGFpbmVyLnBhcmVudDtcbiAgICBjb25zdCByZW5kZXJHcm91cFBhcmVudCA9IGNvbnRhaW5lci5yZW5kZXJHcm91cC5yZW5kZXJHcm91cFBhcmVudDtcbiAgICBjb250YWluZXIucGFyZW50ID0gbnVsbDtcbiAgICBjb250YWluZXIucmVuZGVyR3JvdXAucmVuZGVyR3JvdXBQYXJlbnQgPSBudWxsO1xuICAgIGNvbnN0IHJlbmRlcmVyID0gdGhpcy5fcmVuZGVyZXI7XG4gICAgY29uc3Qgb3JpZ2luYWxMb2NhbFRyYW5zZm9ybSA9IHRlbXBNYXRyaXg7XG4gICAgaWYgKHRyYW5zZm9ybSkge1xuICAgICAgb3JpZ2luYWxMb2NhbFRyYW5zZm9ybS5jb3B5RnJvbShjb250YWluZXIucmVuZGVyR3JvdXAubG9jYWxUcmFuc2Zvcm0pO1xuICAgICAgY29udGFpbmVyLnJlbmRlckdyb3VwLmxvY2FsVHJhbnNmb3JtLmNvcHlGcm9tKHRyYW5zZm9ybSk7XG4gICAgfVxuICAgIGNvbnN0IHJlbmRlclBpcGVzID0gcmVuZGVyZXIucmVuZGVyUGlwZXM7XG4gICAgdGhpcy5fdXBkYXRlQ2FjaGVkUmVuZGVyR3JvdXBzKGNvbnRhaW5lci5yZW5kZXJHcm91cCwgbnVsbCk7XG4gICAgdGhpcy5fdXBkYXRlUmVuZGVyR3JvdXBzKGNvbnRhaW5lci5yZW5kZXJHcm91cCk7XG4gICAgcmVuZGVyZXIuZ2xvYmFsVW5pZm9ybXMuc3RhcnQoe1xuICAgICAgd29ybGRUcmFuc2Zvcm1NYXRyaXg6IHRyYW5zZm9ybSA/IGNvbnRhaW5lci5yZW5kZXJHcm91cC5sb2NhbFRyYW5zZm9ybSA6IGNvbnRhaW5lci5yZW5kZXJHcm91cC53b3JsZFRyYW5zZm9ybSxcbiAgICAgIHdvcmxkQ29sb3I6IGNvbnRhaW5lci5yZW5kZXJHcm91cC53b3JsZENvbG9yQWxwaGFcbiAgICB9KTtcbiAgICBleGVjdXRlSW5zdHJ1Y3Rpb25zKGNvbnRhaW5lci5yZW5kZXJHcm91cCwgcmVuZGVyUGlwZXMpO1xuICAgIGlmIChyZW5kZXJQaXBlcy51bmlmb3JtQmF0Y2gpIHtcbiAgICAgIHJlbmRlclBpcGVzLnVuaWZvcm1CYXRjaC5yZW5kZXJFbmQoKTtcbiAgICB9XG4gICAgaWYgKHRyYW5zZm9ybSkge1xuICAgICAgY29udGFpbmVyLnJlbmRlckdyb3VwLmxvY2FsVHJhbnNmb3JtLmNvcHlGcm9tKG9yaWdpbmFsTG9jYWxUcmFuc2Zvcm0pO1xuICAgIH1cbiAgICBjb250YWluZXIucGFyZW50ID0gcGFyZW50O1xuICAgIGNvbnRhaW5lci5yZW5kZXJHcm91cC5yZW5kZXJHcm91cFBhcmVudCA9IHJlbmRlckdyb3VwUGFyZW50O1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSBudWxsO1xuICB9XG4gIF91cGRhdGVDYWNoZWRSZW5kZXJHcm91cHMocmVuZGVyR3JvdXAsIGNsb3Nlc3RDYWNoZUFzVGV4dHVyZSkge1xuICAgIHJlbmRlckdyb3VwLl9wYXJlbnRDYWNoZUFzVGV4dHVyZVJlbmRlckdyb3VwID0gY2xvc2VzdENhY2hlQXNUZXh0dXJlO1xuICAgIGlmIChyZW5kZXJHcm91cC5pc0NhY2hlZEFzVGV4dHVyZSkge1xuICAgICAgaWYgKCFyZW5kZXJHcm91cC50ZXh0dXJlTmVlZHNVcGRhdGUpIHJldHVybjtcbiAgICAgIGNsb3Nlc3RDYWNoZUFzVGV4dHVyZSA9IHJlbmRlckdyb3VwO1xuICAgIH1cbiAgICBmb3IgKGxldCBpID0gcmVuZGVyR3JvdXAucmVuZGVyR3JvdXBDaGlsZHJlbi5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgdGhpcy5fdXBkYXRlQ2FjaGVkUmVuZGVyR3JvdXBzKHJlbmRlckdyb3VwLnJlbmRlckdyb3VwQ2hpbGRyZW5baV0sIGNsb3Nlc3RDYWNoZUFzVGV4dHVyZSk7XG4gICAgfVxuICAgIHJlbmRlckdyb3VwLmludmFsaWRhdGVNYXRyaWNlcygpO1xuICAgIGlmIChyZW5kZXJHcm91cC5pc0NhY2hlZEFzVGV4dHVyZSkge1xuICAgICAgaWYgKHJlbmRlckdyb3VwLnRleHR1cmVOZWVkc1VwZGF0ZSkge1xuICAgICAgICBjb25zdCBib3VuZHMgPSByZW5kZXJHcm91cC5yb290LmdldExvY2FsQm91bmRzKCk7XG4gICAgICAgIGNvbnN0IHJlbmRlcmVyID0gdGhpcy5fcmVuZGVyZXI7XG4gICAgICAgIGNvbnN0IHJlc29sdXRpb24gPSByZW5kZXJHcm91cC50ZXh0dXJlT3B0aW9ucy5yZXNvbHV0aW9uIHx8IHJlbmRlcmVyLnZpZXcucmVzb2x1dGlvbjtcbiAgICAgICAgY29uc3QgYW50aWFsaWFzID0gcmVuZGVyR3JvdXAudGV4dHVyZU9wdGlvbnMuYW50aWFsaWFzID8/IHJlbmRlcmVyLnZpZXcuYW50aWFsaWFzO1xuICAgICAgICBjb25zdCBzY2FsZU1vZGUgPSByZW5kZXJHcm91cC50ZXh0dXJlT3B0aW9ucy5zY2FsZU1vZGUgPz8gXCJsaW5lYXJcIjtcbiAgICAgICAgY29uc3QgbGFzdFRleHR1cmUgPSByZW5kZXJHcm91cC50ZXh0dXJlO1xuICAgICAgICBib3VuZHMuY2VpbCgpO1xuICAgICAgICBpZiAocmVuZGVyR3JvdXAudGV4dHVyZSkge1xuICAgICAgICAgIFRleHR1cmVQb29sLnJldHVyblRleHR1cmUocmVuZGVyR3JvdXAudGV4dHVyZSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdGV4dHVyZSA9IFRleHR1cmVQb29sLmdldE9wdGltYWxUZXh0dXJlKHtcbiAgICAgICAgICB3aWR0aDogYm91bmRzLndpZHRoLFxuICAgICAgICAgIGhlaWdodDogYm91bmRzLmhlaWdodCxcbiAgICAgICAgICByZXNvbHV0aW9uLFxuICAgICAgICAgIGFudGlhbGlhcyxcbiAgICAgICAgICBzY2FsZU1vZGVcbiAgICAgICAgfSk7XG4gICAgICAgIHJlbmRlckdyb3VwLnRleHR1cmUgPSB0ZXh0dXJlO1xuICAgICAgICByZW5kZXJHcm91cC5fdGV4dHVyZUJvdW5kcyB8fCAocmVuZGVyR3JvdXAuX3RleHR1cmVCb3VuZHMgPSBuZXcgQm91bmRzKCkpO1xuICAgICAgICByZW5kZXJHcm91cC5fdGV4dHVyZUJvdW5kcy5jb3B5RnJvbShib3VuZHMpO1xuICAgICAgICBpZiAobGFzdFRleHR1cmUgIT09IHJlbmRlckdyb3VwLnRleHR1cmUpIHtcbiAgICAgICAgICBpZiAocmVuZGVyR3JvdXAucmVuZGVyR3JvdXBQYXJlbnQpIHtcbiAgICAgICAgICAgIHJlbmRlckdyb3VwLnJlbmRlckdyb3VwUGFyZW50LnN0cnVjdHVyZURpZENoYW5nZSA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChyZW5kZXJHcm91cC50ZXh0dXJlKSB7XG4gICAgICBUZXh0dXJlUG9vbC5yZXR1cm5UZXh0dXJlKHJlbmRlckdyb3VwLnRleHR1cmUpO1xuICAgICAgcmVuZGVyR3JvdXAudGV4dHVyZSA9IG51bGw7XG4gICAgfVxuICB9XG4gIF91cGRhdGVSZW5kZXJHcm91cHMocmVuZGVyR3JvdXApIHtcbiAgICBjb25zdCByZW5kZXJlciA9IHRoaXMuX3JlbmRlcmVyO1xuICAgIGNvbnN0IHJlbmRlclBpcGVzID0gcmVuZGVyZXIucmVuZGVyUGlwZXM7XG4gICAgcmVuZGVyR3JvdXAucnVuT25SZW5kZXIocmVuZGVyZXIpO1xuICAgIHJlbmRlckdyb3VwLmluc3RydWN0aW9uU2V0LnJlbmRlclBpcGVzID0gcmVuZGVyUGlwZXM7XG4gICAgaWYgKCFyZW5kZXJHcm91cC5zdHJ1Y3R1cmVEaWRDaGFuZ2UpIHtcbiAgICAgIHZhbGlkYXRlUmVuZGVyYWJsZXMocmVuZGVyR3JvdXAsIHJlbmRlclBpcGVzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2xlYXJMaXN0KHJlbmRlckdyb3VwLmNoaWxkcmVuUmVuZGVyYWJsZXNUb1VwZGF0ZS5saXN0LCAwKTtcbiAgICB9XG4gICAgdXBkYXRlUmVuZGVyR3JvdXBUcmFuc2Zvcm1zKHJlbmRlckdyb3VwKTtcbiAgICBpZiAocmVuZGVyR3JvdXAuc3RydWN0dXJlRGlkQ2hhbmdlKSB7XG4gICAgICByZW5kZXJHcm91cC5zdHJ1Y3R1cmVEaWRDaGFuZ2UgPSBmYWxzZTtcbiAgICAgIHRoaXMuX2J1aWxkSW5zdHJ1Y3Rpb25zKHJlbmRlckdyb3VwLCByZW5kZXJlcik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX3VwZGF0ZVJlbmRlcmFibGVzKHJlbmRlckdyb3VwKTtcbiAgICB9XG4gICAgcmVuZGVyR3JvdXAuY2hpbGRyZW5SZW5kZXJhYmxlc1RvVXBkYXRlLmluZGV4ID0gMDtcbiAgICByZW5kZXJlci5yZW5kZXJQaXBlcy5iYXRjaC51cGxvYWQocmVuZGVyR3JvdXAuaW5zdHJ1Y3Rpb25TZXQpO1xuICAgIGlmIChyZW5kZXJHcm91cC5pc0NhY2hlZEFzVGV4dHVyZSAmJiAhcmVuZGVyR3JvdXAudGV4dHVyZU5lZWRzVXBkYXRlKSByZXR1cm47XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZW5kZXJHcm91cC5yZW5kZXJHcm91cENoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICB0aGlzLl91cGRhdGVSZW5kZXJHcm91cHMocmVuZGVyR3JvdXAucmVuZGVyR3JvdXBDaGlsZHJlbltpXSk7XG4gICAgfVxuICB9XG4gIF91cGRhdGVSZW5kZXJhYmxlcyhyZW5kZXJHcm91cCkge1xuICAgIGNvbnN0IHsgbGlzdCwgaW5kZXggfSA9IHJlbmRlckdyb3VwLmNoaWxkcmVuUmVuZGVyYWJsZXNUb1VwZGF0ZTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGluZGV4OyBpKyspIHtcbiAgICAgIGNvbnN0IGNvbnRhaW5lciA9IGxpc3RbaV07XG4gICAgICBpZiAoY29udGFpbmVyLmRpZFZpZXdVcGRhdGUpIHtcbiAgICAgICAgcmVuZGVyR3JvdXAudXBkYXRlUmVuZGVyYWJsZShjb250YWluZXIpO1xuICAgICAgfVxuICAgIH1cbiAgICBjbGVhckxpc3QobGlzdCwgaW5kZXgpO1xuICB9XG4gIF9idWlsZEluc3RydWN0aW9ucyhyZW5kZXJHcm91cCwgcmVuZGVyZXJPclBpcGVzKSB7XG4gICAgY29uc3Qgcm9vdCA9IHJlbmRlckdyb3VwLnJvb3Q7XG4gICAgY29uc3QgaW5zdHJ1Y3Rpb25TZXQgPSByZW5kZXJHcm91cC5pbnN0cnVjdGlvblNldDtcbiAgICBpbnN0cnVjdGlvblNldC5yZXNldCgpO1xuICAgIGNvbnN0IHJlbmRlcmVyID0gcmVuZGVyZXJPclBpcGVzLnJlbmRlclBpcGVzID8gcmVuZGVyZXJPclBpcGVzIDogcmVuZGVyZXJPclBpcGVzLmJhdGNoLnJlbmRlcmVyO1xuICAgIGNvbnN0IHJlbmRlclBpcGVzID0gcmVuZGVyZXIucmVuZGVyUGlwZXM7XG4gICAgcmVuZGVyUGlwZXMuYmF0Y2guYnVpbGRTdGFydChpbnN0cnVjdGlvblNldCk7XG4gICAgcmVuZGVyUGlwZXMuYmxlbmRNb2RlLmJ1aWxkU3RhcnQoKTtcbiAgICByZW5kZXJQaXBlcy5jb2xvck1hc2suYnVpbGRTdGFydCgpO1xuICAgIGlmIChyb290LnNvcnRhYmxlQ2hpbGRyZW4pIHtcbiAgICAgIHJvb3Quc29ydENoaWxkcmVuKCk7XG4gICAgfVxuICAgIHJvb3QuY29sbGVjdFJlbmRlcmFibGVzV2l0aEVmZmVjdHMoaW5zdHJ1Y3Rpb25TZXQsIHJlbmRlcmVyLCBudWxsKTtcbiAgICByZW5kZXJQaXBlcy5iYXRjaC5idWlsZEVuZChpbnN0cnVjdGlvblNldCk7XG4gICAgcmVuZGVyUGlwZXMuYmxlbmRNb2RlLmJ1aWxkRW5kKGluc3RydWN0aW9uU2V0KTtcbiAgfVxufVxuLyoqIEBpZ25vcmUgKi9cblJlbmRlckdyb3VwU3lzdGVtLmV4dGVuc2lvbiA9IHtcbiAgdHlwZTogW1xuICAgIEV4dGVuc2lvblR5cGUuV2ViR0xTeXN0ZW0sXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHUFVTeXN0ZW0sXG4gICAgRXh0ZW5zaW9uVHlwZS5DYW52YXNTeXN0ZW1cbiAgXSxcbiAgbmFtZTogXCJyZW5kZXJHcm91cFwiXG59O1xuXG5leHBvcnQgeyBSZW5kZXJHcm91cFN5c3RlbSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9UmVuZGVyR3JvdXBTeXN0ZW0ubWpzLm1hcFxuIiwiaW1wb3J0IHsgQ29sb3IgfSBmcm9tICcuLi8uLi8uLi8uLi9jb2xvci9Db2xvci5tanMnO1xuaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgd2FybiB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2xvZ2dpbmcvd2Fybi5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IF9CYWNrZ3JvdW5kU3lzdGVtID0gY2xhc3MgX0JhY2tncm91bmRTeXN0ZW0ge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmNsZWFyQmVmb3JlUmVuZGVyID0gdHJ1ZTtcbiAgICB0aGlzLl9iYWNrZ3JvdW5kQ29sb3IgPSBuZXcgQ29sb3IoMCk7XG4gICAgdGhpcy5jb2xvciA9IHRoaXMuX2JhY2tncm91bmRDb2xvcjtcbiAgICB0aGlzLmFscGhhID0gMTtcbiAgfVxuICAvKipcbiAgICogaW5pdGlhdGVzIHRoZSBiYWNrZ3JvdW5kIHN5c3RlbVxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIHRoZSBvcHRpb25zIGZvciB0aGUgYmFja2dyb3VuZCBjb2xvcnNcbiAgICovXG4gIGluaXQob3B0aW9ucykge1xuICAgIG9wdGlvbnMgPSB7IC4uLl9CYWNrZ3JvdW5kU3lzdGVtLmRlZmF1bHRPcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgdGhpcy5jbGVhckJlZm9yZVJlbmRlciA9IG9wdGlvbnMuY2xlYXJCZWZvcmVSZW5kZXI7XG4gICAgdGhpcy5jb2xvciA9IG9wdGlvbnMuYmFja2dyb3VuZCB8fCBvcHRpb25zLmJhY2tncm91bmRDb2xvciB8fCB0aGlzLl9iYWNrZ3JvdW5kQ29sb3I7XG4gICAgdGhpcy5hbHBoYSA9IG9wdGlvbnMuYmFja2dyb3VuZEFscGhhO1xuICAgIHRoaXMuX2JhY2tncm91bmRDb2xvci5zZXRBbHBoYShvcHRpb25zLmJhY2tncm91bmRBbHBoYSk7XG4gIH1cbiAgLyoqIFRoZSBiYWNrZ3JvdW5kIGNvbG9yIHRvIGZpbGwgaWYgbm90IHRyYW5zcGFyZW50ICovXG4gIGdldCBjb2xvcigpIHtcbiAgICByZXR1cm4gdGhpcy5fYmFja2dyb3VuZENvbG9yO1xuICB9XG4gIHNldCBjb2xvcih2YWx1ZSkge1xuICAgIGNvbnN0IGluY29taW5nID0gQ29sb3Iuc2hhcmVkLnNldFZhbHVlKHZhbHVlKTtcbiAgICBpZiAoaW5jb21pbmcuYWxwaGEgPCAxICYmIHRoaXMuX2JhY2tncm91bmRDb2xvci5hbHBoYSA9PT0gMSkge1xuICAgICAgd2FybihcbiAgICAgICAgXCJDYW5ub3Qgc2V0IGEgdHJhbnNwYXJlbnQgYmFja2dyb3VuZCBvbiBhbiBvcGFxdWUgY2FudmFzLiBUbyBlbmFibGUgdHJhbnNwYXJlbmN5LCBzZXQgYmFja2dyb3VuZEFscGhhIDwgMSB3aGVuIGluaXRpYWxpemluZyB5b3VyIEFwcGxpY2F0aW9uLlwiXG4gICAgICApO1xuICAgIH1cbiAgICB0aGlzLl9iYWNrZ3JvdW5kQ29sb3Iuc2V0VmFsdWUodmFsdWUpO1xuICB9XG4gIC8qKiBUaGUgYmFja2dyb3VuZCBjb2xvciBhbHBoYS4gU2V0dGluZyB0aGlzIHRvIDAgd2lsbCBtYWtlIHRoZSBjYW52YXMgdHJhbnNwYXJlbnQuICovXG4gIGdldCBhbHBoYSgpIHtcbiAgICByZXR1cm4gdGhpcy5fYmFja2dyb3VuZENvbG9yLmFscGhhO1xuICB9XG4gIHNldCBhbHBoYSh2YWx1ZSkge1xuICAgIHRoaXMuX2JhY2tncm91bmRDb2xvci5zZXRBbHBoYSh2YWx1ZSk7XG4gIH1cbiAgLyoqIFRoZSBiYWNrZ3JvdW5kIGNvbG9yIGFzIGFuIFtSLCBHLCBCLCBBXSBhcnJheS4gKi9cbiAgZ2V0IGNvbG9yUmdiYSgpIHtcbiAgICByZXR1cm4gdGhpcy5fYmFja2dyb3VuZENvbG9yLnRvQXJyYXkoKTtcbiAgfVxuICAvKipcbiAgICogZGVzdHJveXMgdGhlIGJhY2tncm91bmQgc3lzdGVtXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgfVxufTtcbi8qKiBAaWdub3JlICovXG5fQmFja2dyb3VuZFN5c3RlbS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuV2ViR1BVU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuQ2FudmFzU3lzdGVtXG4gIF0sXG4gIG5hbWU6IFwiYmFja2dyb3VuZFwiLFxuICBwcmlvcml0eTogMFxufTtcbi8qKiBkZWZhdWx0IG9wdGlvbnMgdXNlZCBieSB0aGUgc3lzdGVtICovXG5fQmFja2dyb3VuZFN5c3RlbS5kZWZhdWx0T3B0aW9ucyA9IHtcbiAgLyoqXG4gICAqIHtAbGluayBXZWJHTE9wdGlvbnMuYmFja2dyb3VuZEFscGhhfVxuICAgKiBAZGVmYXVsdCAxXG4gICAqL1xuICBiYWNrZ3JvdW5kQWxwaGE6IDEsXG4gIC8qKlxuICAgKiB7QGxpbmsgV2ViR0xPcHRpb25zLmJhY2tncm91bmRDb2xvcn1cbiAgICogQGRlZmF1bHQgMHgwMDAwMDBcbiAgICovXG4gIGJhY2tncm91bmRDb2xvcjogMCxcbiAgLyoqXG4gICAqIHtAbGluayBXZWJHTE9wdGlvbnMuY2xlYXJCZWZvcmVSZW5kZXJ9XG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIGNsZWFyQmVmb3JlUmVuZGVyOiB0cnVlXG59O1xubGV0IEJhY2tncm91bmRTeXN0ZW0gPSBfQmFja2dyb3VuZFN5c3RlbTtcblxuZXhwb3J0IHsgQmFja2dyb3VuZFN5c3RlbSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QmFja2dyb3VuZFN5c3RlbS5tanMubWFwXG4iLCJpbXBvcnQgeyBET01BZGFwdGVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vZW52aXJvbm1lbnQvYWRhcHRlci5tanMnO1xuaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgQ29udGFpbmVyIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2NlbmUvY29udGFpbmVyL0NvbnRhaW5lci5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4uL3RleHR1cmUvVGV4dHVyZS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IGltYWdlVHlwZXMgPSB7XG4gIHBuZzogXCJpbWFnZS9wbmdcIixcbiAganBnOiBcImltYWdlL2pwZWdcIixcbiAgd2VicDogXCJpbWFnZS93ZWJwXCJcbn07XG5jb25zdCBfRXh0cmFjdFN5c3RlbSA9IGNsYXNzIF9FeHRyYWN0U3lzdGVtIHtcbiAgLyoqIEBwYXJhbSByZW5kZXJlciAtIFRoZSByZW5kZXJlciB0aGlzIFN5c3RlbSB3b3JrcyBmb3IuICovXG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSByZW5kZXJlcjtcbiAgfVxuICBfbm9ybWFsaXplT3B0aW9ucyhvcHRpb25zLCBkZWZhdWx0cyA9IHt9KSB7XG4gICAgaWYgKG9wdGlvbnMgaW5zdGFuY2VvZiBDb250YWluZXIgfHwgb3B0aW9ucyBpbnN0YW5jZW9mIFRleHR1cmUpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHRhcmdldDogb3B0aW9ucyxcbiAgICAgICAgLi4uZGVmYXVsdHNcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAuLi5kZWZhdWx0cyxcbiAgICAgIC4uLm9wdGlvbnNcbiAgICB9O1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIElJbWFnZSBmcm9tIGEgZGlzcGxheSBvYmplY3Qgb3IgdGV4dHVyZS5cbiAgICogQHBhcmFtIG9wdGlvbnMgLSBPcHRpb25zIGZvciBjcmVhdGluZyB0aGUgaW1hZ2UsIG9yIHRoZSB0YXJnZXQgdG8gZXh0cmFjdFxuICAgKiBAcmV0dXJucyBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgZ2VuZXJhdGVkIElJbWFnZVxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyB1c2FnZSB3aXRoIGEgc3ByaXRlXG4gICAqIGNvbnN0IHNwcml0ZSA9IG5ldyBTcHJpdGUodGV4dHVyZSk7XG4gICAqIGNvbnN0IGltYWdlID0gYXdhaXQgcmVuZGVyZXIuZXh0cmFjdC5pbWFnZShzcHJpdGUpO1xuICAgKiBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGltYWdlKTtcbiAgICpcbiAgICogLy8gQWR2YW5jZWQgdXNhZ2Ugd2l0aCBvcHRpb25zXG4gICAqIGNvbnN0IGltYWdlID0gYXdhaXQgcmVuZGVyZXIuZXh0cmFjdC5pbWFnZSh7XG4gICAqICAgICB0YXJnZXQ6IGNvbnRhaW5lcixcbiAgICogICAgIGZvcm1hdDogJ3dlYnAnLFxuICAgKiAgICAgcXVhbGl0eTogMC44LFxuICAgKiAgICAgZnJhbWU6IG5ldyBSZWN0YW5nbGUoMCwgMCwgMTAwLCAxMDApLFxuICAgKiAgICAgcmVzb2x1dGlvbjogMixcbiAgICogICAgIGNsZWFyQ29sb3I6ICcjZmYwMDAwJyxcbiAgICogICAgIGFudGlhbGlhczogdHJ1ZVxuICAgKiB9KTtcbiAgICpcbiAgICogLy8gRXh0cmFjdCBkaXJlY3RseSBmcm9tIGEgdGV4dHVyZVxuICAgKiBjb25zdCB0ZXh0dXJlID0gVGV4dHVyZS5mcm9tKCdteVRleHR1cmUucG5nJyk7XG4gICAqIGNvbnN0IGltYWdlID0gYXdhaXQgcmVuZGVyZXIuZXh0cmFjdC5pbWFnZSh0ZXh0dXJlKTtcbiAgICogYGBgXG4gICAqIEBzZWUge0BsaW5rIEV4dHJhY3RJbWFnZU9wdGlvbnN9IEZvciBkZXRhaWxlZCBvcHRpb25zXG4gICAqIEBzZWUge0BsaW5rIEV4dHJhY3RTeXN0ZW0uYmFzZTY0fSBGb3IgYmFzZTY0IHN0cmluZyBvdXRwdXRcbiAgICogQHNlZSB7QGxpbmsgRXh0cmFjdFN5c3RlbS5jYW52YXN9IEZvciBjYW52YXMgb3V0cHV0XG4gICAqIEBzZWUge0BsaW5rIEltYWdlTGlrZX0gRm9yIHRoZSBpbWFnZSBpbnRlcmZhY2VcbiAgICogQGNhdGVnb3J5IHJlbmRlcmluZ1xuICAgKi9cbiAgYXN5bmMgaW1hZ2Uob3B0aW9ucykge1xuICAgIGNvbnN0IGltYWdlID0gRE9NQWRhcHRlci5nZXQoKS5jcmVhdGVJbWFnZSgpO1xuICAgIGltYWdlLnNyYyA9IGF3YWl0IHRoaXMuYmFzZTY0KG9wdGlvbnMpO1xuICAgIHJldHVybiBpbWFnZTtcbiAgfVxuICAvKipcbiAgICogQ29udmVydHMgdGhlIHRhcmdldCBpbnRvIGEgYmFzZTY0IGVuY29kZWQgc3RyaW5nLlxuICAgKlxuICAgKiBUaGlzIG1ldGhvZCB3b3JrcyBieSBmaXJzdCBjcmVhdGluZ1xuICAgKiBhIGNhbnZhcyB1c2luZyBgRXh0cmFjdC5jYW52YXNgIGFuZCB0aGVuIGNvbnZlcnRpbmcgaXQgdG8gYSBiYXNlNjQgc3RyaW5nLlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvcHRpb25zIGZvciBjcmVhdGluZyB0aGUgYmFzZTY0IHN0cmluZywgb3IgdGhlIHRhcmdldCB0byBleHRyYWN0XG4gICAqIEByZXR1cm5zIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBiYXNlNjQgZW5jb2RlZCBzdHJpbmdcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgdXNhZ2Ugd2l0aCBhIHNwcml0ZVxuICAgKiBjb25zdCBzcHJpdGUgPSBuZXcgU3ByaXRlKHRleHR1cmUpO1xuICAgKiBjb25zdCBiYXNlNjQgPSBhd2FpdCByZW5kZXJlci5leHRyYWN0LmJhc2U2NChzcHJpdGUpO1xuICAgKiBjb25zb2xlLmxvZyhiYXNlNjQpOyAvLyBkYXRhOmltYWdlL3BuZztiYXNlNjQsLi4uXG4gICAqXG4gICAqIC8vIEFkdmFuY2VkIHVzYWdlIHdpdGggb3B0aW9uc1xuICAgKiBjb25zdCBiYXNlNjQgPSBhd2FpdCByZW5kZXJlci5leHRyYWN0LmJhc2U2NCh7XG4gICAqICAgICB0YXJnZXQ6IGNvbnRhaW5lcixcbiAgICogICAgIGZvcm1hdDogJ3dlYnAnLFxuICAgKiAgICAgcXVhbGl0eTogMC44LFxuICAgKiAgICAgZnJhbWU6IG5ldyBSZWN0YW5nbGUoMCwgMCwgMTAwLCAxMDApLFxuICAgKiAgICAgcmVzb2x1dGlvbjogMlxuICAgKiB9KTtcbiAgICogYGBgXG4gICAqIEB0aHJvd3MgV2lsbCB0aHJvdyBhbiBlcnJvciBpZiB0aGUgcGxhdGZvcm0gZG9lc24ndCBzdXBwb3J0IGFueSBvZjpcbiAgICogLSBJQ2FudmFzLnRvRGF0YVVSTFxuICAgKiAtIElDYW52YXMudG9CbG9iXG4gICAqIC0gSUNhbnZhcy5jb252ZXJ0VG9CbG9iXG4gICAqIEBzZWUge0BsaW5rIEV4dHJhY3RJbWFnZU9wdGlvbnN9IEZvciBkZXRhaWxlZCBvcHRpb25zXG4gICAqIEBzZWUge0BsaW5rIEV4dHJhY3RTeXN0ZW0uY2FudmFzfSBGb3IgY2FudmFzIG91dHB1dFxuICAgKiBAc2VlIHtAbGluayBFeHRyYWN0U3lzdGVtLmltYWdlfSBGb3IgSFRNTEltYWdlIG91dHB1dFxuICAgKiBAY2F0ZWdvcnkgcmVuZGVyaW5nXG4gICAqL1xuICBhc3luYyBiYXNlNjQob3B0aW9ucykge1xuICAgIG9wdGlvbnMgPSB0aGlzLl9ub3JtYWxpemVPcHRpb25zKFxuICAgICAgb3B0aW9ucyxcbiAgICAgIF9FeHRyYWN0U3lzdGVtLmRlZmF1bHRJbWFnZU9wdGlvbnNcbiAgICApO1xuICAgIGNvbnN0IHsgZm9ybWF0LCBxdWFsaXR5IH0gPSBvcHRpb25zO1xuICAgIGNvbnN0IGNhbnZhcyA9IHRoaXMuY2FudmFzKG9wdGlvbnMpO1xuICAgIGlmIChjYW52YXMudG9CbG9iICE9PSB2b2lkIDApIHtcbiAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIGNhbnZhcy50b0Jsb2IoKGJsb2IpID0+IHtcbiAgICAgICAgICBpZiAoIWJsb2IpIHtcbiAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJJQ2FudmFzLnRvQmxvYiBmYWlsZWQhXCIpKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgICAgICByZWFkZXIub25sb2FkID0gKCkgPT4gcmVzb2x2ZShyZWFkZXIucmVzdWx0KTtcbiAgICAgICAgICByZWFkZXIub25lcnJvciA9IHJlamVjdDtcbiAgICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChibG9iKTtcbiAgICAgICAgfSwgaW1hZ2VUeXBlc1tmb3JtYXRdLCBxdWFsaXR5KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoY2FudmFzLnRvRGF0YVVSTCAhPT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm4gY2FudmFzLnRvRGF0YVVSTChpbWFnZVR5cGVzW2Zvcm1hdF0sIHF1YWxpdHkpO1xuICAgIH1cbiAgICBpZiAoY2FudmFzLmNvbnZlcnRUb0Jsb2IgIT09IHZvaWQgMCkge1xuICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IGNhbnZhcy5jb252ZXJ0VG9CbG9iKHsgdHlwZTogaW1hZ2VUeXBlc1tmb3JtYXRdLCBxdWFsaXR5IH0pO1xuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICAgICAgcmVhZGVyLm9ubG9hZCA9ICgpID0+IHJlc29sdmUocmVhZGVyLnJlc3VsdCk7XG4gICAgICAgIHJlYWRlci5vbmVycm9yID0gcmVqZWN0O1xuICAgICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChibG9iKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJFeHRyYWN0LmJhc2U2NCgpIHJlcXVpcmVzIElDYW52YXMudG9EYXRhVVJMLCBJQ2FudmFzLnRvQmxvYiwgb3IgSUNhbnZhcy5jb252ZXJ0VG9CbG9iIHRvIGJlIGltcGxlbWVudGVkXCIpO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgQ2FudmFzIGVsZW1lbnQsIHJlbmRlcnMgdGhlIHRhcmdldCB0byBpdCBhbmQgcmV0dXJucyBpdC5cbiAgICogVGhpcyBtZXRob2QgaXMgdXNlZnVsIGZvciBjcmVhdGluZyBzdGF0aWMgaW1hZ2VzIG9yIHdoZW4geW91IG5lZWQgZGlyZWN0IGNhbnZhcyBhY2Nlc3MuXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgZm9yIGNyZWF0aW5nIHRoZSBjYW52YXMsIG9yIHRoZSB0YXJnZXQgdG8gZXh0cmFjdFxuICAgKiBAcmV0dXJucyBBIENhbnZhcyBlbGVtZW50IHdpdGggdGhlIHRleHR1cmUgcmVuZGVyZWQgb25cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgY2FudmFzIGV4dHJhY3Rpb24gZnJvbSBhIHNwcml0ZVxuICAgKiBjb25zdCBzcHJpdGUgPSBuZXcgU3ByaXRlKHRleHR1cmUpO1xuICAgKiBjb25zdCBjYW52YXMgPSByZW5kZXJlci5leHRyYWN0LmNhbnZhcyhzcHJpdGUpO1xuICAgKiBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGNhbnZhcyk7XG4gICAqXG4gICAqIC8vIEV4dHJhY3Qgd2l0aCBjdXN0b20gcmVnaW9uXG4gICAqIGNvbnN0IGNhbnZhcyA9IHJlbmRlcmVyLmV4dHJhY3QuY2FudmFzKHtcbiAgICogICAgIHRhcmdldDogY29udGFpbmVyLFxuICAgKiAgICAgZnJhbWU6IG5ldyBSZWN0YW5nbGUoMCwgMCwgMTAwLCAxMDApXG4gICAqIH0pO1xuICAgKlxuICAgKiAvLyBFeHRyYWN0IHdpdGggaGlnaCByZXNvbHV0aW9uXG4gICAqIGNvbnN0IGNhbnZhcyA9IHJlbmRlcmVyLmV4dHJhY3QuY2FudmFzKHtcbiAgICogICAgIHRhcmdldDogc3ByaXRlLFxuICAgKiAgICAgcmVzb2x1dGlvbjogMixcbiAgICogICAgIGNsZWFyQ29sb3I6ICcjZmYwMDAwJ1xuICAgKiB9KTtcbiAgICpcbiAgICogLy8gRXh0cmFjdCBkaXJlY3RseSBmcm9tIGEgdGV4dHVyZVxuICAgKiBjb25zdCB0ZXh0dXJlID0gVGV4dHVyZS5mcm9tKCdteVRleHR1cmUucG5nJyk7XG4gICAqIGNvbnN0IGNhbnZhcyA9IHJlbmRlcmVyLmV4dHJhY3QuY2FudmFzKHRleHR1cmUpO1xuICAgKlxuICAgKiAvLyBFeHRyYWN0IHdpdGggYW50aS1hbGlhc2luZ1xuICAgKiBjb25zdCBjYW52YXMgPSByZW5kZXJlci5leHRyYWN0LmNhbnZhcyh7XG4gICAqICAgICB0YXJnZXQ6IGdyYXBoaWNzLFxuICAgKiAgICAgYW50aWFsaWFzOiB0cnVlXG4gICAqIH0pO1xuICAgKiBgYGBcbiAgICogQHNlZSB7QGxpbmsgRXh0cmFjdE9wdGlvbnN9IEZvciBkZXRhaWxlZCBvcHRpb25zXG4gICAqIEBzZWUge0BsaW5rIEV4dHJhY3RTeXN0ZW0uaW1hZ2V9IEZvciBIVE1MSW1hZ2Ugb3V0cHV0XG4gICAqIEBzZWUge0BsaW5rIEV4dHJhY3RTeXN0ZW0ucGl4ZWxzfSBGb3IgcmF3IHBpeGVsIGRhdGFcbiAgICogQGNhdGVnb3J5IHJlbmRlcmluZ1xuICAgKi9cbiAgY2FudmFzKG9wdGlvbnMpIHtcbiAgICBvcHRpb25zID0gdGhpcy5fbm9ybWFsaXplT3B0aW9ucyhvcHRpb25zKTtcbiAgICBjb25zdCB0YXJnZXQgPSBvcHRpb25zLnRhcmdldDtcbiAgICBjb25zdCByZW5kZXJlciA9IHRoaXMuX3JlbmRlcmVyO1xuICAgIGlmICh0YXJnZXQgaW5zdGFuY2VvZiBUZXh0dXJlKSB7XG4gICAgICByZXR1cm4gcmVuZGVyZXIudGV4dHVyZS5nZW5lcmF0ZUNhbnZhcyh0YXJnZXQpO1xuICAgIH1cbiAgICBjb25zdCB0ZXh0dXJlID0gcmVuZGVyZXIudGV4dHVyZUdlbmVyYXRvci5nZW5lcmF0ZVRleHR1cmUob3B0aW9ucyk7XG4gICAgY29uc3QgY2FudmFzID0gcmVuZGVyZXIudGV4dHVyZS5nZW5lcmF0ZUNhbnZhcyh0ZXh0dXJlKTtcbiAgICB0ZXh0dXJlLmRlc3Ryb3kodHJ1ZSk7XG4gICAgcmV0dXJuIGNhbnZhcztcbiAgfVxuICAvKipcbiAgICogUmV0dXJucyBhIG9uZS1kaW1lbnNpb25hbCBhcnJheSBjb250YWluaW5nIHRoZSBwaXhlbCBkYXRhIG9mIHRoZSBlbnRpcmUgdGV4dHVyZSBpbiBSR0JBIG9yZGVyLFxuICAgKiB3aXRoIGludGVnZXIgdmFsdWVzIGJldHdlZW4gMCBhbmQgMjU1IChpbmNsdXNpdmUpLlxuICAgKiA+IFshTk9FXSBUaGUgcmV0dXJuZWQgYXJyYXkgaXMgYSBmbGF0IFVpbnQ4QXJyYXkgd2hlcmUgZXZlcnkgNCB2YWx1ZXMgcmVwcmVzZW50IFJHQkFcbiAgICogQHBhcmFtIG9wdGlvbnMgLSBUaGUgb3B0aW9ucyBmb3IgZXh0cmFjdGluZyB0aGUgaW1hZ2UsIG9yIHRoZSB0YXJnZXQgdG8gZXh0cmFjdFxuICAgKiBAcmV0dXJucyBPbmUtZGltZW5zaW9uYWwgVWludDhBcnJheSBjb250YWluaW5nIHRoZSBwaXhlbCBkYXRhIGluIFJHQkEgZm9ybWF0XG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHBpeGVsIGV4dHJhY3Rpb25cbiAgICogY29uc3Qgc3ByaXRlID0gbmV3IFNwcml0ZSh0ZXh0dXJlKTtcbiAgICogY29uc3QgcGl4ZWxzID0gcmVuZGVyZXIuZXh0cmFjdC5waXhlbHMoc3ByaXRlKTtcbiAgICogY29uc29sZS5sb2cocGl4ZWxzWzBdLCBwaXhlbHNbMV0sIHBpeGVsc1syXSwgcGl4ZWxzWzNdKTsgLy8gUixHLEIsQSB2YWx1ZXNcbiAgICpcbiAgICogLy8gRXh0cmFjdCB3aXRoIGN1c3RvbSByZWdpb25cbiAgICogY29uc3QgcGl4ZWxzID0gcmVuZGVyZXIuZXh0cmFjdC5waXhlbHMoe1xuICAgKiAgICAgdGFyZ2V0OiBzcHJpdGUsXG4gICAqICAgICBmcmFtZTogbmV3IFJlY3RhbmdsZSgwLCAwLCAxMDAsIDEwMClcbiAgICogfSk7XG4gICAqXG4gICAqIC8vIEV4dHJhY3Qgd2l0aCBoaWdoIHJlc29sdXRpb25cbiAgICogY29uc3QgcGl4ZWxzID0gcmVuZGVyZXIuZXh0cmFjdC5waXhlbHMoe1xuICAgKiAgICAgdGFyZ2V0OiBzcHJpdGUsXG4gICAqICAgICByZXNvbHV0aW9uOiAyXG4gICAqIH0pO1xuICAgKiBgYGBcbiAgICogQHNlZSB7QGxpbmsgRXh0cmFjdE9wdGlvbnN9IEZvciBkZXRhaWxlZCBvcHRpb25zXG4gICAqIEBzZWUge0BsaW5rIEV4dHJhY3RTeXN0ZW0uY2FudmFzfSBGb3IgY2FudmFzIG91dHB1dFxuICAgKiBAc2VlIHtAbGluayBFeHRyYWN0U3lzdGVtLmltYWdlfSBGb3IgaW1hZ2Ugb3V0cHV0XG4gICAqIEBjYXRlZ29yeSByZW5kZXJpbmdcbiAgICovXG4gIHBpeGVscyhvcHRpb25zKSB7XG4gICAgb3B0aW9ucyA9IHRoaXMuX25vcm1hbGl6ZU9wdGlvbnMob3B0aW9ucyk7XG4gICAgY29uc3QgdGFyZ2V0ID0gb3B0aW9ucy50YXJnZXQ7XG4gICAgY29uc3QgcmVuZGVyZXIgPSB0aGlzLl9yZW5kZXJlcjtcbiAgICBjb25zdCB0ZXh0dXJlID0gdGFyZ2V0IGluc3RhbmNlb2YgVGV4dHVyZSA/IHRhcmdldCA6IHJlbmRlcmVyLnRleHR1cmVHZW5lcmF0b3IuZ2VuZXJhdGVUZXh0dXJlKG9wdGlvbnMpO1xuICAgIGNvbnN0IHBpeGVsSW5mbyA9IHJlbmRlcmVyLnRleHR1cmUuZ2V0UGl4ZWxzKHRleHR1cmUpO1xuICAgIGlmICh0YXJnZXQgaW5zdGFuY2VvZiBDb250YWluZXIpIHtcbiAgICAgIHRleHR1cmUuZGVzdHJveSh0cnVlKTtcbiAgICB9XG4gICAgcmV0dXJuIHBpeGVsSW5mbztcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyBhIHRleHR1cmUgZnJvbSBhIGRpc3BsYXkgb2JqZWN0IG9yIGV4aXN0aW5nIHRleHR1cmUuXG4gICAqXG4gICAqIFRoaXMgaXMgdXNlZnVsIGZvciBjcmVhdGluZ1xuICAgKiByZXVzYWJsZSB0ZXh0dXJlcyBmcm9tIHJlbmRlcmVkIGNvbnRlbnQgb3IgbWFraW5nIGNvcGllcyBvZiBleGlzdGluZyB0ZXh0dXJlcy5cbiAgICogPiBbIU5PVEVdIFRoZSByZXR1cm5lZCB0ZXh0dXJlIHNob3VsZCBiZSBkZXN0cm95ZWQgd2hlbiBubyBsb25nZXIgbmVlZGVkXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gVGhlIG9wdGlvbnMgZm9yIGNyZWF0aW5nIHRoZSB0ZXh0dXJlLCBvciB0aGUgdGFyZ2V0IHRvIGV4dHJhY3RcbiAgICogQHJldHVybnMgQSBuZXcgdGV4dHVyZSBjb250YWluaW5nIHRoZSBleHRyYWN0ZWQgY29udGVudFxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyB0ZXh0dXJlIGV4dHJhY3Rpb24gZnJvbSBhIHNwcml0ZVxuICAgKiBjb25zdCBzcHJpdGUgPSBuZXcgU3ByaXRlKHRleHR1cmUpO1xuICAgKiBjb25zdCBleHRyYWN0ZWRUZXh0dXJlID0gcmVuZGVyZXIuZXh0cmFjdC50ZXh0dXJlKHNwcml0ZSk7XG4gICAqXG4gICAqIC8vIEV4dHJhY3Qgd2l0aCBjdXN0b20gcmVnaW9uXG4gICAqIGNvbnN0IHJlZ2lvblRleHR1cmUgPSByZW5kZXJlci5leHRyYWN0LnRleHR1cmUoe1xuICAgKiAgICAgdGFyZ2V0OiBjb250YWluZXIsXG4gICAqICAgICBmcmFtZTogbmV3IFJlY3RhbmdsZSgwLCAwLCAxMDAsIDEwMClcbiAgICogfSk7XG4gICAqXG4gICAqIC8vIEV4dHJhY3Qgd2l0aCBoaWdoIHJlc29sdXRpb25cbiAgICogY29uc3QgaGlSZXNUZXh0dXJlID0gcmVuZGVyZXIuZXh0cmFjdC50ZXh0dXJlKHtcbiAgICogICAgIHRhcmdldDogc3ByaXRlLFxuICAgKiAgICAgcmVzb2x1dGlvbjogMixcbiAgICogICAgIGNsZWFyQ29sb3I6ICcjZmYwMDAwJ1xuICAgKiB9KTtcbiAgICpcbiAgICogLy8gQ3JlYXRlIGEgbmV3IHNwcml0ZSBmcm9tIGV4dHJhY3RlZCB0ZXh0dXJlXG4gICAqIGNvbnN0IG5ld1Nwcml0ZSA9IG5ldyBTcHJpdGUoXG4gICAqICAgICByZW5kZXJlci5leHRyYWN0LnRleHR1cmUoe1xuICAgKiAgICAgICAgIHRhcmdldDogZ3JhcGhpY3MsXG4gICAqICAgICAgICAgYW50aWFsaWFzOiB0cnVlXG4gICAqICAgICB9KVxuICAgKiApO1xuICAgKlxuICAgKiAvLyBDbGVhbiB1cCB3aGVuIGRvbmVcbiAgICogZXh0cmFjdGVkVGV4dHVyZS5kZXN0cm95KHRydWUpO1xuICAgKiBgYGBcbiAgICogQHNlZSB7QGxpbmsgRXh0cmFjdE9wdGlvbnN9IEZvciBkZXRhaWxlZCBvcHRpb25zXG4gICAqIEBzZWUge0BsaW5rIFRleHR1cmV9IEZvciB0ZXh0dXJlIG1hbmFnZW1lbnRcbiAgICogQHNlZSB7QGxpbmsgR2VuZXJhdGVUZXh0dXJlU3lzdGVtfSBGb3IgdGV4dHVyZSBnZW5lcmF0aW9uXG4gICAqIEBjYXRlZ29yeSByZW5kZXJpbmdcbiAgICovXG4gIHRleHR1cmUob3B0aW9ucykge1xuICAgIG9wdGlvbnMgPSB0aGlzLl9ub3JtYWxpemVPcHRpb25zKG9wdGlvbnMpO1xuICAgIGlmIChvcHRpb25zLnRhcmdldCBpbnN0YW5jZW9mIFRleHR1cmUpIHJldHVybiBvcHRpb25zLnRhcmdldDtcbiAgICByZXR1cm4gdGhpcy5fcmVuZGVyZXIudGV4dHVyZUdlbmVyYXRvci5nZW5lcmF0ZVRleHR1cmUob3B0aW9ucyk7XG4gIH1cbiAgLyoqXG4gICAqIEV4dHJhY3RzIGFuZCBkb3dubG9hZHMgY29udGVudCBmcm9tIHRoZSByZW5kZXJlciBhcyBhbiBpbWFnZSBmaWxlLlxuICAgKiBUaGlzIGlzIGEgY29udmVuaWVudCB3YXkgdG8gc2F2ZSBzY3JlZW5zaG90cyBvciBleHBvcnQgcmVuZGVyZWQgY29udGVudC5cbiAgICogPiBbIU5PVEVdIFRoZSBkb3dubG9hZCB3aWxsIHVzZSBQTkcgZm9ybWF0IHJlZ2FyZGxlc3Mgb2YgdGhlIGZpbGVuYW1lIGV4dGVuc2lvblxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvcHRpb25zIGZvciBkb3dubG9hZGluZyBhbmQgZXh0cmFjdGluZyB0aGUgaW1hZ2UsIG9yIHRoZSB0YXJnZXQgdG8gZXh0cmFjdFxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyBkb3dubG9hZCB3aXRoIGRlZmF1bHQgZmlsZW5hbWVcbiAgICogY29uc3Qgc3ByaXRlID0gbmV3IFNwcml0ZSh0ZXh0dXJlKTtcbiAgICogcmVuZGVyZXIuZXh0cmFjdC5kb3dubG9hZChzcHJpdGUpOyAvLyBEb3dubG9hZHMgYXMgJ2ltYWdlLnBuZydcbiAgICpcbiAgICogLy8gRG93bmxvYWQgd2l0aCBjdXN0b20gZmlsZW5hbWVcbiAgICogcmVuZGVyZXIuZXh0cmFjdC5kb3dubG9hZCh7XG4gICAqICAgICB0YXJnZXQ6IHNwcml0ZSxcbiAgICogICAgIGZpbGVuYW1lOiAnc2NyZWVuc2hvdC5wbmcnXG4gICAqIH0pO1xuICAgKlxuICAgKiAvLyBEb3dubG9hZCB3aXRoIGN1c3RvbSByZWdpb25cbiAgICogcmVuZGVyZXIuZXh0cmFjdC5kb3dubG9hZCh7XG4gICAqICAgICB0YXJnZXQ6IGNvbnRhaW5lcixcbiAgICogICAgIGZpbGVuYW1lOiAncmVnaW9uLnBuZycsXG4gICAqICAgICBmcmFtZTogbmV3IFJlY3RhbmdsZSgwLCAwLCAxMDAsIDEwMClcbiAgICogfSk7XG4gICAqXG4gICAqIC8vIERvd25sb2FkIHdpdGggaGlnaCByZXNvbHV0aW9uIGFuZCBiYWNrZ3JvdW5kXG4gICAqIHJlbmRlcmVyLmV4dHJhY3QuZG93bmxvYWQoe1xuICAgKiAgICAgdGFyZ2V0OiBzdGFnZSxcbiAgICogICAgIGZpbGVuYW1lOiAnaGQtc2NyZWVuc2hvdC5wbmcnLFxuICAgKiAgICAgcmVzb2x1dGlvbjogMixcbiAgICogICAgIGNsZWFyQ29sb3I6ICcjZmYwMDAwJ1xuICAgKiB9KTtcbiAgICpcbiAgICogLy8gRG93bmxvYWQgd2l0aCBhbnRpLWFsaWFzaW5nXG4gICAqIHJlbmRlcmVyLmV4dHJhY3QuZG93bmxvYWQoe1xuICAgKiAgICAgdGFyZ2V0OiBncmFwaGljcyxcbiAgICogICAgIGZpbGVuYW1lOiAnc21vb3RoLnBuZycsXG4gICAqICAgICBhbnRpYWxpYXM6IHRydWVcbiAgICogfSk7XG4gICAqIGBgYFxuICAgKiBAc2VlIHtAbGluayBFeHRyYWN0RG93bmxvYWRPcHRpb25zfSBGb3IgZGV0YWlsZWQgb3B0aW9uc1xuICAgKiBAc2VlIHtAbGluayBFeHRyYWN0U3lzdGVtLmltYWdlfSBGb3IgY3JlYXRpbmcgaW1hZ2VzIHdpdGhvdXQgZG93bmxvYWRcbiAgICogQHNlZSB7QGxpbmsgRXh0cmFjdFN5c3RlbS5jYW52YXN9IEZvciBjYW52YXMgb3V0cHV0XG4gICAqIEBjYXRlZ29yeSByZW5kZXJpbmdcbiAgICovXG4gIGRvd25sb2FkKG9wdGlvbnMpIHtcbiAgICBvcHRpb25zID0gdGhpcy5fbm9ybWFsaXplT3B0aW9ucyhvcHRpb25zKTtcbiAgICBjb25zdCBjYW52YXMgPSB0aGlzLmNhbnZhcyhvcHRpb25zKTtcbiAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImFcIik7XG4gICAgbGluay5kb3dubG9hZCA9IG9wdGlvbnMuZmlsZW5hbWUgPz8gXCJpbWFnZS5wbmdcIjtcbiAgICBsaW5rLmhyZWYgPSBjYW52YXMudG9EYXRhVVJMKFwiaW1hZ2UvcG5nXCIpO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluayk7XG4gICAgbGluay5jbGljaygpO1xuICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQobGluayk7XG4gIH1cbiAgLyoqXG4gICAqIExvZ3MgdGhlIHRhcmdldCB0byB0aGUgY29uc29sZSBhcyBhbiBpbWFnZS4gVGhpcyBpcyBhIHVzZWZ1bCB3YXkgdG8gZGVidWcgd2hhdCdzIGhhcHBlbmluZyBpbiB0aGUgcmVuZGVyZXIuXG4gICAqIFRoZSBpbWFnZSB3aWxsIGJlIGRpc3BsYXllZCBpbiB0aGUgYnJvd3NlcidzIGNvbnNvbGUgdXNpbmcgQ1NTIGJhY2tncm91bmQgaW1hZ2VzLlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIFRoZSBvcHRpb25zIGZvciBsb2dnaW5nIHRoZSBpbWFnZSwgb3IgdGhlIHRhcmdldCB0byBsb2dcbiAgICogQHBhcmFtIG9wdGlvbnMud2lkdGggLSBUaGUgd2lkdGggb2YgdGhlIGxvZ2dlZCBpbWFnZSBwcmV2aWV3IGluIHRoZSBjb25zb2xlIChpbiBwaXhlbHMpXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEJhc2ljIHVzYWdlXG4gICAqIGNvbnN0IHNwcml0ZSA9IG5ldyBTcHJpdGUodGV4dHVyZSk7XG4gICAqIHJlbmRlcmVyLmV4dHJhY3QubG9nKHNwcml0ZSk7XG4gICAqIGBgYFxuICAgKiBAc2VlIHtAbGluayBFeHRyYWN0U3lzdGVtLmNhbnZhc30gRm9yIGdldHRpbmcgcmF3IGNhbnZhcyBvdXRwdXRcbiAgICogQHNlZSB7QGxpbmsgRXh0cmFjdFN5c3RlbS5waXhlbHN9IEZvciByYXcgcGl4ZWwgZGF0YVxuICAgKiBAY2F0ZWdvcnkgcmVuZGVyaW5nXG4gICAqIEBhZHZhbmNlZFxuICAgKi9cbiAgbG9nKG9wdGlvbnMpIHtcbiAgICBjb25zdCB3aWR0aCA9IG9wdGlvbnMud2lkdGggPz8gMjAwO1xuICAgIG9wdGlvbnMgPSB0aGlzLl9ub3JtYWxpemVPcHRpb25zKG9wdGlvbnMpO1xuICAgIGNvbnN0IGNhbnZhcyA9IHRoaXMuY2FudmFzKG9wdGlvbnMpO1xuICAgIGNvbnN0IGJhc2U2NCA9IGNhbnZhcy50b0RhdGFVUkwoKTtcbiAgICBjb25zb2xlLmxvZyhgW1BpeGkgVGV4dHVyZV0gJHtjYW52YXMud2lkdGh9cHggJHtjYW52YXMuaGVpZ2h0fXB4YCk7XG4gICAgY29uc3Qgc3R5bGUgPSBbXG4gICAgICBcImZvbnQtc2l6ZTogMXB4O1wiLFxuICAgICAgYHBhZGRpbmc6ICR7d2lkdGh9cHggJHszMDB9cHg7YCxcbiAgICAgIGBiYWNrZ3JvdW5kOiB1cmwoJHtiYXNlNjR9KSBuby1yZXBlYXQ7YCxcbiAgICAgIFwiYmFja2dyb3VuZC1zaXplOiBjb250YWluO1wiXG4gICAgXS5qb2luKFwiIFwiKTtcbiAgICBjb25zb2xlLmxvZyhcIiVjIFwiLCBzdHlsZSk7XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IG51bGw7XG4gIH1cbn07XG4vKiogQGlnbm9yZSAqL1xuX0V4dHJhY3RTeXN0ZW0uZXh0ZW5zaW9uID0ge1xuICB0eXBlOiBbXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHTFN5c3RlbSxcbiAgICBFeHRlbnNpb25UeXBlLldlYkdQVVN5c3RlbSxcbiAgICBFeHRlbnNpb25UeXBlLkNhbnZhc1N5c3RlbVxuICBdLFxuICBuYW1lOiBcImV4dHJhY3RcIlxufTtcbi8qKlxuICogRGVmYXVsdCBvcHRpb25zIGZvciBpbWFnZSBleHRyYWN0aW9uLlxuICogQGV4YW1wbGVcbiAqIGBgYHRzXG4gKiAvLyBDdXN0b21pemUgZGVmYXVsdCBvcHRpb25zXG4gKiBFeHRyYWN0U3lzdGVtLmRlZmF1bHRJbWFnZU9wdGlvbnMuZm9ybWF0ID0gJ3dlYnAnO1xuICogRXh0cmFjdFN5c3RlbS5kZWZhdWx0SW1hZ2VPcHRpb25zLnF1YWxpdHkgPSAwLjg7XG4gKlxuICogLy8gVXNlIGRlZmF1bHRzXG4gKiBjb25zdCBpbWFnZSA9IGF3YWl0IHJlbmRlcmVyLmV4dHJhY3QuaW1hZ2Uoc3ByaXRlKTtcbiAqIGBgYFxuICovXG5fRXh0cmFjdFN5c3RlbS5kZWZhdWx0SW1hZ2VPcHRpb25zID0ge1xuICBmb3JtYXQ6IFwicG5nXCIsXG4gIHF1YWxpdHk6IDFcbn07XG5sZXQgRXh0cmFjdFN5c3RlbSA9IF9FeHRyYWN0U3lzdGVtO1xuXG5leHBvcnQgeyBFeHRyYWN0U3lzdGVtIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1FeHRyYWN0U3lzdGVtLm1qcy5tYXBcbiIsImltcG9ydCB7IFRleHR1cmVTb3VyY2UgfSBmcm9tICcuL3NvdXJjZXMvVGV4dHVyZVNvdXJjZS5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4vVGV4dHVyZS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIFJlbmRlclRleHR1cmUgZXh0ZW5kcyBUZXh0dXJlIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBSZW5kZXJUZXh0dXJlLiBQYXNzIGBkeW5hbWljOiB0cnVlYCBpbiBvcHRpb25zIHRvIGFsbG93IHJlc2l6aW5nIGFmdGVyIGNyZWF0aW9uLlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIE9wdGlvbnMgZm9yIHRoZSBSZW5kZXJUZXh0dXJlLCBpbmNsdWRpbmcgd2lkdGgsIGhlaWdodCwgdGV4dHVyZU9wdGlvbnMsIGFuZCBkeW5hbWljLlxuICAgKiBAcmV0dXJucyBBIG5ldyBSZW5kZXJUZXh0dXJlIGluc3RhbmNlLlxuICAgKiBAZXhhbXBsZVxuICAgKiBjb25zdCB0ZXh0dXJlT3B0aW9ucyA9IHsgZGVmYXVsdEFuY2hvcjogeyB4OiAwLjUsIHk6IDAuNSB9IH07XG4gICAqIGNvbnN0IHJ0ID0gUmVuZGVyVGV4dHVyZS5jcmVhdGUoeyB3aWR0aDogMTAwLCBoZWlnaHQ6IDEwMCwgZHluYW1pYzogdHJ1ZSwgdGV4dHVyZU9wdGlvbnMgfSk7XG4gICAqIHJ0LnJlc2l6ZSg1MDAsIDUwMCk7XG4gICAqL1xuICBzdGF0aWMgY3JlYXRlKG9wdGlvbnMpIHtcbiAgICBjb25zdCB7IGR5bmFtaWMsIHRleHR1cmVPcHRpb25zLCAuLi5yZXN0IH0gPSBvcHRpb25zO1xuICAgIHJldHVybiBuZXcgUmVuZGVyVGV4dHVyZSh7XG4gICAgICAuLi50ZXh0dXJlT3B0aW9ucyxcbiAgICAgIHNvdXJjZTogbmV3IFRleHR1cmVTb3VyY2UocmVzdCksXG4gICAgICBkeW5hbWljOiBkeW5hbWljID8/IGZhbHNlXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFJlc2l6ZXMgdGhlIHJlbmRlciB0ZXh0dXJlLlxuICAgKiBAcGFyYW0gd2lkdGggLSBUaGUgbmV3IHdpZHRoIG9mIHRoZSByZW5kZXIgdGV4dHVyZS5cbiAgICogQHBhcmFtIGhlaWdodCAtIFRoZSBuZXcgaGVpZ2h0IG9mIHRoZSByZW5kZXIgdGV4dHVyZS5cbiAgICogQHBhcmFtIHJlc29sdXRpb24gLSBUaGUgbmV3IHJlc29sdXRpb24gb2YgdGhlIHJlbmRlciB0ZXh0dXJlLlxuICAgKiBAcmV0dXJucyBUaGlzIHRleHR1cmUuXG4gICAqL1xuICByZXNpemUod2lkdGgsIGhlaWdodCwgcmVzb2x1dGlvbikge1xuICAgIHRoaXMuc291cmNlLnJlc2l6ZSh3aWR0aCwgaGVpZ2h0LCByZXNvbHV0aW9uKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxufVxuXG5leHBvcnQgeyBSZW5kZXJUZXh0dXJlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1SZW5kZXJUZXh0dXJlLm1qcy5tYXBcbiIsImltcG9ydCB7IENvbG9yIH0gZnJvbSAnLi4vLi4vLi4vLi4vY29sb3IvQ29sb3IubWpzJztcbmltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi8uLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IE1hdHJpeCB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL21hdHJpeC9NYXRyaXgubWpzJztcbmltcG9ydCB7IFJlY3RhbmdsZSB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL3NoYXBlcy9SZWN0YW5nbGUubWpzJztcbmltcG9ydCB7IEJvdW5kcyB9IGZyb20gJy4uLy4uLy4uLy4uL3NjZW5lL2NvbnRhaW5lci9ib3VuZHMvQm91bmRzLm1qcyc7XG5pbXBvcnQgeyBnZXRMb2NhbEJvdW5kcyB9IGZyb20gJy4uLy4uLy4uLy4uL3NjZW5lL2NvbnRhaW5lci9ib3VuZHMvZ2V0TG9jYWxCb3VuZHMubWpzJztcbmltcG9ydCB7IENvbnRhaW5lciB9IGZyb20gJy4uLy4uLy4uLy4uL3NjZW5lL2NvbnRhaW5lci9Db250YWluZXIubWpzJztcbmltcG9ydCB7IFJlbmRlclRleHR1cmUgfSBmcm9tICcuLi90ZXh0dXJlL1JlbmRlclRleHR1cmUubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCB0ZW1wUmVjdCA9IG5ldyBSZWN0YW5nbGUoKTtcbmNvbnN0IHRlbXBCb3VuZHMgPSBuZXcgQm91bmRzKCk7XG5jb25zdCBub0NvbG9yID0gWzAsIDAsIDAsIDBdO1xuY2xhc3MgR2VuZXJhdGVUZXh0dXJlU3lzdGVtIHtcbiAgY29uc3RydWN0b3IocmVuZGVyZXIpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IHJlbmRlcmVyO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgdGV4dHVyZSBmcm9tIGEgZGlzcGxheSBvYmplY3QgdGhhdCBjYW4gYmUgdXNlZCBmb3IgY3JlYXRpbmcgc3ByaXRlcyBhbmQgb3RoZXIgdGV4dHVyZXMuXG4gICAqIFRoaXMgaXMgcGFydGljdWxhcmx5IHVzZWZ1bCBmb3Igb3B0aW1pemluZyBwZXJmb3JtYW5jZSB3aGVuIGEgY29tcGxleCBjb250YWluZXIgbmVlZHMgdG8gYmUgcmV1c2VkLlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIEdlbmVyYXRlIHRleHR1cmUgb3B0aW9ucyBvciBhIGNvbnRhaW5lciB0byBjb252ZXJ0IHRvIHRleHR1cmVcbiAgICogQHJldHVybnMgQSBuZXcgUmVuZGVyVGV4dHVyZSBjb250YWluaW5nIHRoZSByZW5kZXJlZCBkaXNwbGF5IG9iamVjdFxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBCYXNpYyB1c2FnZSB3aXRoIGEgY29udGFpbmVyXG4gICAqIGNvbnN0IGNvbnRhaW5lciA9IG5ldyBDb250YWluZXIoKTtcbiAgICogY29udGFpbmVyLmFkZENoaWxkKFxuICAgKiAgICAgbmV3IEdyYXBoaWNzKClcbiAgICogICAgICAgICAuY2lyY2xlKDAsIDAsIDUwKVxuICAgKiAgICAgICAgIC5maWxsKCdyZWQnKVxuICAgKiApO1xuICAgKlxuICAgKiBjb25zdCB0ZXh0dXJlID0gcmVuZGVyZXIudGV4dHVyZUdlbmVyYXRvci5nZW5lcmF0ZVRleHR1cmUoY29udGFpbmVyKTtcbiAgICpcbiAgICogLy8gQWR2YW5jZWQgdXNhZ2Ugd2l0aCBvcHRpb25zXG4gICAqIGNvbnN0IHRleHR1cmUgPSByZW5kZXJlci50ZXh0dXJlR2VuZXJhdG9yLmdlbmVyYXRlVGV4dHVyZSh7XG4gICAqICAgICB0YXJnZXQ6IGNvbnRhaW5lcixcbiAgICogICAgIGZyYW1lOiBuZXcgUmVjdGFuZ2xlKDAsIDAsIDEwMCwgMTAwKSwgLy8gU3BlY2lmaWMgcmVnaW9uXG4gICAqICAgICByZXNvbHV0aW9uOiAyLCAgICAgICAgICAgICAgICAgICAgICAgIC8vIEhpZ2ggRFBJXG4gICAqICAgICBjbGVhckNvbG9yOiAnI2ZmMDAwMCcsICAgICAgICAgICAgICAgLy8gUmVkIGJhY2tncm91bmRcbiAgICogICAgIGFudGlhbGlhczogdHJ1ZSAgICAgICAgICAgICAgICAgICAgICAvLyBTbW9vdGggZWRnZXNcbiAgICogfSk7XG4gICAqXG4gICAqIC8vIENyZWF0ZSBhIHNwcml0ZSBmcm9tIHRoZSBnZW5lcmF0ZWQgdGV4dHVyZVxuICAgKiBjb25zdCBzcHJpdGUgPSBuZXcgU3ByaXRlKHRleHR1cmUpO1xuICAgKlxuICAgKiAvLyBDbGVhbiB1cCB3aGVuIGRvbmVcbiAgICogdGV4dHVyZS5kZXN0cm95KHRydWUpO1xuICAgKiBgYGBcbiAgICogQHNlZSB7QGxpbmsgR2VuZXJhdGVUZXh0dXJlT3B0aW9uc30gRm9yIGRldGFpbGVkIHRleHR1cmUgZ2VuZXJhdGlvbiBvcHRpb25zXG4gICAqIEBzZWUge0BsaW5rIFJlbmRlclRleHR1cmV9IEZvciB0aGUgdHlwZSBvZiB0ZXh0dXJlIGNyZWF0ZWRcbiAgICogQGNhdGVnb3J5IHJlbmRlcmluZ1xuICAgKi9cbiAgZ2VuZXJhdGVUZXh0dXJlKG9wdGlvbnMpIHtcbiAgICBpZiAob3B0aW9ucyBpbnN0YW5jZW9mIENvbnRhaW5lcikge1xuICAgICAgb3B0aW9ucyA9IHtcbiAgICAgICAgdGFyZ2V0OiBvcHRpb25zLFxuICAgICAgICBmcmFtZTogdm9pZCAwLFxuICAgICAgICB0ZXh0dXJlU291cmNlT3B0aW9uczoge30sXG4gICAgICAgIHJlc29sdXRpb246IHZvaWQgMFxuICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgcmVzb2x1dGlvbiA9IG9wdGlvbnMucmVzb2x1dGlvbiB8fCB0aGlzLl9yZW5kZXJlci5yZXNvbHV0aW9uO1xuICAgIGNvbnN0IGFudGlhbGlhcyA9IG9wdGlvbnMuYW50aWFsaWFzIHx8IHRoaXMuX3JlbmRlcmVyLnZpZXcuYW50aWFsaWFzO1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IG9wdGlvbnMudGFyZ2V0O1xuICAgIGxldCBjbGVhckNvbG9yID0gb3B0aW9ucy5jbGVhckNvbG9yO1xuICAgIGlmIChjbGVhckNvbG9yKSB7XG4gICAgICBjb25zdCBpc1JHQkFBcnJheSA9IEFycmF5LmlzQXJyYXkoY2xlYXJDb2xvcikgJiYgY2xlYXJDb2xvci5sZW5ndGggPT09IDQ7XG4gICAgICBjbGVhckNvbG9yID0gaXNSR0JBQXJyYXkgPyBjbGVhckNvbG9yIDogQ29sb3Iuc2hhcmVkLnNldFZhbHVlKGNsZWFyQ29sb3IpLnRvQXJyYXkoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2xlYXJDb2xvciA9IG5vQ29sb3I7XG4gICAgfVxuICAgIGNvbnN0IHJlZ2lvbiA9IG9wdGlvbnMuZnJhbWU/LmNvcHlUbyh0ZW1wUmVjdCkgfHwgZ2V0TG9jYWxCb3VuZHMoY29udGFpbmVyLCB0ZW1wQm91bmRzKS5yZWN0YW5nbGU7XG4gICAgY29uc3QgdGV4dHVyZU9wdGlvbnMgPSBvcHRpb25zLmRlZmF1bHRBbmNob3IgJiYge1xuICAgICAgZGVmYXVsdEFuY2hvcjogb3B0aW9ucy5kZWZhdWx0QW5jaG9yXG4gICAgfTtcbiAgICByZWdpb24ud2lkdGggPSBNYXRoLm1heChyZWdpb24ud2lkdGgsIDEgLyByZXNvbHV0aW9uKSB8IDA7XG4gICAgcmVnaW9uLmhlaWdodCA9IE1hdGgubWF4KHJlZ2lvbi5oZWlnaHQsIDEgLyByZXNvbHV0aW9uKSB8IDA7XG4gICAgY29uc3QgdGFyZ2V0ID0gUmVuZGVyVGV4dHVyZS5jcmVhdGUoe1xuICAgICAgLi4ub3B0aW9ucy50ZXh0dXJlU291cmNlT3B0aW9ucyxcbiAgICAgIHdpZHRoOiByZWdpb24ud2lkdGgsXG4gICAgICBoZWlnaHQ6IHJlZ2lvbi5oZWlnaHQsXG4gICAgICByZXNvbHV0aW9uLFxuICAgICAgYW50aWFsaWFzLFxuICAgICAgdGV4dHVyZU9wdGlvbnNcbiAgICB9KTtcbiAgICBjb25zdCB0cmFuc2Zvcm0gPSBNYXRyaXguc2hhcmVkLnRyYW5zbGF0ZSgtcmVnaW9uLngsIC1yZWdpb24ueSk7XG4gICAgdGhpcy5fcmVuZGVyZXIucmVuZGVyKHtcbiAgICAgIGNvbnRhaW5lcixcbiAgICAgIHRyYW5zZm9ybSxcbiAgICAgIHRhcmdldCxcbiAgICAgIGNsZWFyQ29sb3JcbiAgICB9KTtcbiAgICB0YXJnZXQuc291cmNlLnVwZGF0ZU1pcG1hcHMoKTtcbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSBudWxsO1xuICB9XG59XG4vKiogQGlnbm9yZSAqL1xuR2VuZXJhdGVUZXh0dXJlU3lzdGVtLmV4dGVuc2lvbiA9IHtcbiAgdHlwZTogW1xuICAgIEV4dGVuc2lvblR5cGUuV2ViR0xTeXN0ZW0sXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHUFVTeXN0ZW0sXG4gICAgRXh0ZW5zaW9uVHlwZS5DYW52YXNTeXN0ZW1cbiAgXSxcbiAgbmFtZTogXCJ0ZXh0dXJlR2VuZXJhdG9yXCJcbn07XG5cbmV4cG9ydCB7IEdlbmVyYXRlVGV4dHVyZVN5c3RlbSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9R2VuZXJhdGVUZXh0dXJlU3lzdGVtLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gY2xlYW5IYXNoKGhhc2gpIHtcbiAgbGV0IGNsZWFuID0gZmFsc2U7XG4gIGZvciAoY29uc3QgaSBpbiBoYXNoKSB7XG4gICAgaWYgKGhhc2hbaV0gPT0gdm9pZCAwKSB7XG4gICAgICBjbGVhbiA9IHRydWU7XG4gICAgICBicmVhaztcbiAgICB9XG4gIH1cbiAgaWYgKCFjbGVhbikgcmV0dXJuIGhhc2g7XG4gIGNvbnN0IGNsZWFuSGFzaDIgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgZm9yIChjb25zdCBpIGluIGhhc2gpIHtcbiAgICBjb25zdCB2YWx1ZSA9IGhhc2hbaV07XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICBjbGVhbkhhc2gyW2ldID0gdmFsdWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBjbGVhbkhhc2gyO1xufVxuZnVuY3Rpb24gY2xlYW5BcnJheShhcnIpIHtcbiAgbGV0IG9mZnNldCA9IDA7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYXJyLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKGFycltpXSA9PSB2b2lkIDApIHtcbiAgICAgIG9mZnNldCsrO1xuICAgIH0gZWxzZSB7XG4gICAgICBhcnJbaSAtIG9mZnNldF0gPSBhcnJbaV07XG4gICAgfVxuICB9XG4gIGFyci5sZW5ndGggLT0gb2Zmc2V0O1xuICByZXR1cm4gYXJyO1xufVxuXG5leHBvcnQgeyBjbGVhbkFycmF5LCBjbGVhbkhhc2ggfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNsZWFuLm1qcy5tYXBcbiIsImltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IGNsZWFuSGFzaCwgY2xlYW5BcnJheSB9IGZyb20gJy4uLy4uLy4uL3V0aWxzL2RhdGEvY2xlYW4ubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBfR0NTeXN0ZW0gPSBjbGFzcyBfR0NTeXN0ZW0ge1xuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBHQ1N5c3RlbSBpbnN0YW5jZS5cbiAgICogQHBhcmFtIHJlbmRlcmVyIC0gVGhlIHJlbmRlcmVyIHRoaXMgZ2FyYmFnZSBjb2xsZWN0aW9uIHN5c3RlbSB3b3JrcyBmb3JcbiAgICovXG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgLyoqIEFycmF5IG9mIHJlc291cmNlcyBiZWluZyB0cmFja2VkIGZvciBnYXJiYWdlIGNvbGxlY3Rpb24gKi9cbiAgICB0aGlzLl9tYW5hZ2VkUmVzb3VyY2VzID0gW107XG4gICAgdGhpcy5fbWFuYWdlZFJlc291cmNlSGFzaGVzID0gW107XG4gICAgdGhpcy5fbWFuYWdlZENvbGxlY3Rpb25zID0gW107XG4gICAgdGhpcy5fcmVhZHkgPSBmYWxzZTtcbiAgICB0aGlzLl9ydW5uaW5nID0gZmFsc2U7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSByZW5kZXJlcjtcbiAgfVxuICAvKipcbiAgICogSW5pdGlhbGl6ZXMgdGhlIGdhcmJhZ2UgY29sbGVjdGlvbiBzeXN0ZW0gd2l0aCB0aGUgcHJvdmlkZWQgb3B0aW9ucy5cbiAgICogQHBhcmFtIG9wdGlvbnMgLSBDb25maWd1cmF0aW9uIG9wdGlvbnNcbiAgICovXG4gIGluaXQob3B0aW9ucykge1xuICAgIG9wdGlvbnMgPSB7IC4uLl9HQ1N5c3RlbS5kZWZhdWx0T3B0aW9ucywgLi4ub3B0aW9ucyB9O1xuICAgIHRoaXMubWF4VW51c2VkVGltZSA9IG9wdGlvbnMuZ2NNYXhVbnVzZWRUaW1lO1xuICAgIHRoaXMuX2ZyZXF1ZW5jeSA9IG9wdGlvbnMuZ2NGcmVxdWVuY3k7XG4gICAgdGhpcy5lbmFibGVkID0gb3B0aW9ucy5nY0FjdGl2ZTtcbiAgICB0aGlzLm5vdyA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICB9XG4gIC8qKlxuICAgKiBHZXRzIHdoZXRoZXIgdGhlIGdhcmJhZ2UgY29sbGVjdGlvbiBzeXN0ZW0gaXMgY3VycmVudGx5IGVuYWJsZWQuXG4gICAqIEByZXR1cm5zIFRydWUgaWYgR0MgaXMgZW5hYmxlZCwgZmFsc2Ugb3RoZXJ3aXNlXG4gICAqL1xuICBnZXQgZW5hYmxlZCgpIHtcbiAgICByZXR1cm4gISF0aGlzLl9oYW5kbGVyO1xuICB9XG4gIC8qKlxuICAgKiBFbmFibGVzIG9yIGRpc2FibGVzIHRoZSBnYXJiYWdlIGNvbGxlY3Rpb24gc3lzdGVtLlxuICAgKiBXaGVuIGVuYWJsZWQsIHNjaGVkdWxlcyBwZXJpb2RpYyBjbGVhbnVwIG9mIHJlc291cmNlcy5cbiAgICogV2hlbiBkaXNhYmxlZCwgY2FuY2VscyBhbGwgc2NoZWR1bGVkIGNsZWFudXBzLlxuICAgKi9cbiAgc2V0IGVuYWJsZWQodmFsdWUpIHtcbiAgICBpZiAodGhpcy5lbmFibGVkID09PSB2YWx1ZSkgcmV0dXJuO1xuICAgIGlmICh2YWx1ZSkge1xuICAgICAgdGhpcy5faGFuZGxlciA9IHRoaXMuX3JlbmRlcmVyLnNjaGVkdWxlci5yZXBlYXQoXG4gICAgICAgICgpID0+IHtcbiAgICAgICAgICB0aGlzLl9yZWFkeSA9IHRydWU7XG4gICAgICAgIH0sXG4gICAgICAgIHRoaXMuX2ZyZXF1ZW5jeSxcbiAgICAgICAgZmFsc2VcbiAgICAgICk7XG4gICAgICB0aGlzLl9jb2xsZWN0aW9uc0hhbmRsZXIgPSB0aGlzLl9yZW5kZXJlci5zY2hlZHVsZXIucmVwZWF0KFxuICAgICAgICAoKSA9PiB7XG4gICAgICAgICAgZm9yIChjb25zdCBoYXNoIG9mIHRoaXMuX21hbmFnZWRDb2xsZWN0aW9ucykge1xuICAgICAgICAgICAgY29uc3QgeyBjb250ZXh0LCBjb2xsZWN0aW9uLCB0eXBlIH0gPSBoYXNoO1xuICAgICAgICAgICAgaWYgKHR5cGUgPT09IFwiaGFzaFwiKSB7XG4gICAgICAgICAgICAgIGNvbnRleHRbY29sbGVjdGlvbl0gPSBjbGVhbkhhc2goY29udGV4dFtjb2xsZWN0aW9uXSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBjb250ZXh0W2NvbGxlY3Rpb25dID0gY2xlYW5BcnJheShjb250ZXh0W2NvbGxlY3Rpb25dKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHRoaXMuX2ZyZXF1ZW5jeVxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fcmVuZGVyZXIuc2NoZWR1bGVyLmNhbmNlbCh0aGlzLl9oYW5kbGVyKTtcbiAgICAgIHRoaXMuX3JlbmRlcmVyLnNjaGVkdWxlci5jYW5jZWwodGhpcy5fY29sbGVjdGlvbnNIYW5kbGVyKTtcbiAgICAgIHRoaXMuX2hhbmRsZXIgPSAwO1xuICAgICAgdGhpcy5fY29sbGVjdGlvbnNIYW5kbGVyID0gMDtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIENhbGxlZCBiZWZvcmUgcmVuZGVyaW5nLiBVcGRhdGVzIHRoZSBjdXJyZW50IHRpbWVzdGFtcC5cbiAgICogQHBhcmFtIG9wdGlvbnMgLSBUaGUgcmVuZGVyIG9wdGlvbnNcbiAgICogQHBhcmFtIG9wdGlvbnMuY29udGFpbmVyIC0gVGhlIGNvbnRhaW5lciB0byByZW5kZXJcbiAgICovXG4gIHByZXJlbmRlcih7IGNvbnRhaW5lciB9KSB7XG4gICAgdGhpcy5ub3cgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICBjb250YWluZXIucmVuZGVyR3JvdXAuZ2NUaWNrID0gdGhpcy5fcmVuZGVyZXIudGljaysrO1xuICAgIHRoaXMuX3VwZGF0ZUluc3RydWN0aW9uR0NUaWNrKGNvbnRhaW5lci5yZW5kZXJHcm91cCwgY29udGFpbmVyLnJlbmRlckdyb3VwLmdjVGljayk7XG4gIH1cbiAgLyoqIFBlcmZvcm1zIGdhcmJhZ2UgY29sbGVjdGlvbiBhZnRlciByZW5kZXJpbmcuICovXG4gIHBvc3RyZW5kZXIoKSB7XG4gICAgaWYgKCF0aGlzLl9yZWFkeSB8fCAhdGhpcy5lbmFibGVkKSByZXR1cm47XG4gICAgdGhpcy5ydW4oKTtcbiAgICB0aGlzLl9yZWFkeSA9IGZhbHNlO1xuICB9XG4gIC8qKlxuICAgKiBVcGRhdGVzIHRoZSBHQyB0aWNrIGNvdW50ZXIgZm9yIGEgcmVuZGVyIGdyb3VwIGFuZCBpdHMgY2hpbGRyZW4uXG4gICAqIEBwYXJhbSByZW5kZXJHcm91cCAtIFRoZSByZW5kZXIgZ3JvdXAgdG8gdXBkYXRlXG4gICAqIEBwYXJhbSBnY1RpY2sgLSBUaGUgbmV3IHRpY2sgdmFsdWVcbiAgICovXG4gIF91cGRhdGVJbnN0cnVjdGlvbkdDVGljayhyZW5kZXJHcm91cCwgZ2NUaWNrKSB7XG4gICAgcmVuZGVyR3JvdXAuaW5zdHJ1Y3Rpb25TZXQuZ2NUaWNrID0gZ2NUaWNrO1xuICAgIHJlbmRlckdyb3VwLmdjVGljayA9IGdjVGljaztcbiAgICBmb3IgKGNvbnN0IGNoaWxkIG9mIHJlbmRlckdyb3VwLnJlbmRlckdyb3VwQ2hpbGRyZW4pIHtcbiAgICAgIHRoaXMuX3VwZGF0ZUluc3RydWN0aW9uR0NUaWNrKGNoaWxkLCBnY1RpY2spO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogUmVnaXN0ZXJzIGEgY29sbGVjdGlvbiBmb3IgZ2FyYmFnZSBjb2xsZWN0aW9uIHRyYWNraW5nLlxuICAgKiBAcGFyYW0gY29udGV4dCAtIFRoZSBvYmplY3QgY29udGFpbmluZyB0aGUgY29sbGVjdGlvblxuICAgKiBAcGFyYW0gY29sbGVjdGlvbiAtIFRoZSBwcm9wZXJ0eSBuYW1lIG9uIGNvbnRleHQgdGhhdCBob2xkcyB0aGUgY29sbGVjdGlvblxuICAgKiBAcGFyYW0gdHlwZSAtIFRoZSB0eXBlIG9mIGNvbGxlY3Rpb24gdG8gdHJhY2sgKCdoYXNoJyBvciAnYXJyYXknKVxuICAgKi9cbiAgYWRkQ29sbGVjdGlvbihjb250ZXh0LCBjb2xsZWN0aW9uLCB0eXBlKSB7XG4gICAgdGhpcy5fbWFuYWdlZENvbGxlY3Rpb25zLnB1c2goe1xuICAgICAgY29udGV4dCxcbiAgICAgIGNvbGxlY3Rpb24sXG4gICAgICB0eXBlXG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFJlZ2lzdGVycyBhIHJlc291cmNlIGZvciBnYXJiYWdlIGNvbGxlY3Rpb24gdHJhY2tpbmcuXG4gICAqIEBwYXJhbSByZXNvdXJjZSAtIFRoZSByZXNvdXJjZSB0byB0cmFja1xuICAgKiBAcGFyYW0gdHlwZSAtIFRoZSB0eXBlIG9mIHJlc291cmNlIHRvIHRyYWNrXG4gICAqL1xuICBhZGRSZXNvdXJjZShyZXNvdXJjZSwgdHlwZSkge1xuICAgIGlmIChyZXNvdXJjZS5fZ2NMYXN0VXNlZCAhPT0gLTEpIHtcbiAgICAgIHJlc291cmNlLl9nY0xhc3RVc2VkID0gdGhpcy5ub3c7XG4gICAgICByZXNvdXJjZS5fb25Ub3VjaD8uKHRoaXMubm93KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLl9tYW5hZ2VkUmVzb3VyY2VzLmxlbmd0aDtcbiAgICByZXNvdXJjZS5fZ2NEYXRhID0ge1xuICAgICAgaW5kZXgsXG4gICAgICB0eXBlXG4gICAgfTtcbiAgICByZXNvdXJjZS5fZ2NMYXN0VXNlZCA9IHRoaXMubm93O1xuICAgIHJlc291cmNlLl9vblRvdWNoPy4odGhpcy5ub3cpO1xuICAgIHJlc291cmNlLm9uY2UoXCJ1bmxvYWRcIiwgdGhpcy5yZW1vdmVSZXNvdXJjZSwgdGhpcyk7XG4gICAgdGhpcy5fbWFuYWdlZFJlc291cmNlcy5wdXNoKHJlc291cmNlKTtcbiAgfVxuICAvKipcbiAgICogUmVtb3ZlcyBhIHJlc291cmNlIGZyb20gZ2FyYmFnZSBjb2xsZWN0aW9uIHRyYWNraW5nLlxuICAgKiBDYWxsIHRoaXMgd2hlbiBtYW51YWxseSBkZXN0cm95aW5nIGEgcmVzb3VyY2UuXG4gICAqIEBwYXJhbSByZXNvdXJjZSAtIFRoZSByZXNvdXJjZSB0byBzdG9wIHRyYWNraW5nXG4gICAqL1xuICByZW1vdmVSZXNvdXJjZShyZXNvdXJjZSkge1xuICAgIGNvbnN0IGdjRGF0YSA9IHJlc291cmNlLl9nY0RhdGE7XG4gICAgaWYgKCFnY0RhdGEpIHJldHVybjtcbiAgICBjb25zdCBpbmRleCA9IGdjRGF0YS5pbmRleDtcbiAgICBjb25zdCBsYXN0ID0gdGhpcy5fbWFuYWdlZFJlc291cmNlcy5sZW5ndGggLSAxO1xuICAgIGlmICh0aGlzLl9ydW5uaW5nKSB7XG4gICAgICB0aGlzLl9tYW5hZ2VkUmVzb3VyY2VzW2luZGV4XSA9IG51bGw7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChpbmRleCAhPT0gbGFzdCkge1xuICAgICAgICBjb25zdCBsYXN0UmVzb3VyY2UgPSB0aGlzLl9tYW5hZ2VkUmVzb3VyY2VzW2xhc3RdO1xuICAgICAgICB0aGlzLl9tYW5hZ2VkUmVzb3VyY2VzW2luZGV4XSA9IGxhc3RSZXNvdXJjZTtcbiAgICAgICAgbGFzdFJlc291cmNlLl9nY0RhdGEuaW5kZXggPSBpbmRleDtcbiAgICAgIH1cbiAgICAgIHRoaXMuX21hbmFnZWRSZXNvdXJjZXMubGVuZ3RoLS07XG4gICAgfVxuICAgIHJlc291cmNlLl9nY0RhdGEgPSBudWxsO1xuICAgIHJlc291cmNlLl9nY0xhc3RVc2VkID0gLTE7XG4gIH1cbiAgLyoqXG4gICAqIFJlZ2lzdGVycyBhIGhhc2gtYmFzZWQgcmVzb3VyY2UgY29sbGVjdGlvbiBmb3IgZ2FyYmFnZSBjb2xsZWN0aW9uIHRyYWNraW5nLlxuICAgKiBSZXNvdXJjZXMgaW4gdGhlIGhhc2ggd2lsbCBiZSBhdXRvbWF0aWNhbGx5IHRyYWNrZWQgYW5kIGNsZWFuZWQgdXAgd2hlbiB1bnVzZWQuXG4gICAqIEBwYXJhbSBjb250ZXh0IC0gVGhlIG9iamVjdCBjb250YWluaW5nIHRoZSBoYXNoIHByb3BlcnR5XG4gICAqIEBwYXJhbSBoYXNoIC0gVGhlIHByb3BlcnR5IG5hbWUgb24gY29udGV4dCB0aGF0IGhvbGRzIHRoZSByZXNvdXJjZSBoYXNoXG4gICAqIEBwYXJhbSB0eXBlIC0gVGhlIHR5cGUgb2YgcmVzb3VyY2VzIGluIHRoZSBoYXNoICgncmVzb3VyY2UnIG9yICdyZW5kZXJhYmxlJylcbiAgICogQHBhcmFtIHByaW9yaXR5IC0gUHJvY2Vzc2luZyBwcmlvcml0eSAobG93ZXIgdmFsdWVzIGFyZSBwcm9jZXNzZWQgZmlyc3QpXG4gICAqL1xuICBhZGRSZXNvdXJjZUhhc2goY29udGV4dCwgaGFzaCwgdHlwZSwgcHJpb3JpdHkgPSAwKSB7XG4gICAgdGhpcy5fbWFuYWdlZFJlc291cmNlSGFzaGVzLnB1c2goe1xuICAgICAgY29udGV4dCxcbiAgICAgIGhhc2gsXG4gICAgICB0eXBlLFxuICAgICAgcHJpb3JpdHlcbiAgICB9KTtcbiAgICB0aGlzLl9tYW5hZ2VkUmVzb3VyY2VIYXNoZXMuc29ydCgoYSwgYikgPT4gYS5wcmlvcml0eSAtIGIucHJpb3JpdHkpO1xuICB9XG4gIC8qKlxuICAgKiBQZXJmb3JtcyBnYXJiYWdlIGNvbGxlY3Rpb24gYnkgY2xlYW5pbmcgdXAgdW51c2VkIHJlc291cmNlcy5cbiAgICogUmVtb3ZlcyByZXNvdXJjZXMgdGhhdCBoYXZlbid0IGJlZW4gdXNlZCBmb3IgbG9uZ2VyIHRoYW4gbWF4VW51c2VkVGltZS5cbiAgICovXG4gIHJ1bigpIHtcbiAgICBpZiAodGhpcy5fcnVubmluZykgcmV0dXJuO1xuICAgIGNvbnN0IG5vdyA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgIGNvbnN0IG1hbmFnZWRSZXNvdXJjZUhhc2hlcyA9IHRoaXMuX21hbmFnZWRSZXNvdXJjZUhhc2hlcztcbiAgICBjb25zdCBtYW5hZ2VkUmVzb3VyY2VzID0gdGhpcy5fbWFuYWdlZFJlc291cmNlcztcbiAgICB0aGlzLl9ydW5uaW5nID0gdHJ1ZTtcbiAgICB0cnkge1xuICAgICAgZm9yIChjb25zdCBoYXNoRW50cnkgb2YgbWFuYWdlZFJlc291cmNlSGFzaGVzKSB7XG4gICAgICAgIHRoaXMucnVuT25IYXNoKGhhc2hFbnRyeSwgbm93KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGxlbmd0aCA9IG1hbmFnZWRSZXNvdXJjZXMubGVuZ3RoO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCByZXNvdXJjZSA9IG1hbmFnZWRSZXNvdXJjZXNbaV07XG4gICAgICAgIGlmIChyZXNvdXJjZSkgdGhpcy5ydW5PblJlc291cmNlKHJlc291cmNlLCBub3cpO1xuICAgICAgfVxuICAgIH0gZmluYWxseSB7XG4gICAgICBsZXQgd3JpdGVJbmRleCA9IDA7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1hbmFnZWRSZXNvdXJjZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgcmVzb3VyY2UgPSBtYW5hZ2VkUmVzb3VyY2VzW2ldO1xuICAgICAgICBpZiAoIXJlc291cmNlKSBjb250aW51ZTtcbiAgICAgICAgaWYgKHdyaXRlSW5kZXggIT09IGkpIHtcbiAgICAgICAgICBtYW5hZ2VkUmVzb3VyY2VzW3dyaXRlSW5kZXhdID0gcmVzb3VyY2U7XG4gICAgICAgICAgcmVzb3VyY2UuX2djRGF0YS5pbmRleCA9IHdyaXRlSW5kZXg7XG4gICAgICAgIH1cbiAgICAgICAgd3JpdGVJbmRleCsrO1xuICAgICAgfVxuICAgICAgbWFuYWdlZFJlc291cmNlcy5sZW5ndGggPSB3cml0ZUluZGV4O1xuICAgICAgdGhpcy5fcnVubmluZyA9IGZhbHNlO1xuICAgIH1cbiAgfVxuICB1cGRhdGVSZW5kZXJhYmxlR0NUaWNrKHJlbmRlcmFibGUsIG5vdykge1xuICAgIGNvbnN0IHJlbmRlckdyb3VwID0gcmVuZGVyYWJsZS5yZW5kZXJHcm91cCA/PyByZW5kZXJhYmxlLnBhcmVudFJlbmRlckdyb3VwO1xuICAgIGNvbnN0IGN1cnJlbnRUaWNrID0gcmVuZGVyR3JvdXA/Lmluc3RydWN0aW9uU2V0Py5nY1RpY2sgPz8gLTE7XG4gICAgaWYgKChyZW5kZXJHcm91cD8uZ2NUaWNrID8/IDApID09PSBjdXJyZW50VGljaykge1xuICAgICAgcmVuZGVyYWJsZS5fZ2NMYXN0VXNlZCA9IG5vdztcbiAgICAgIHJlbmRlcmFibGUuX29uVG91Y2g/Lihub3cpO1xuICAgIH1cbiAgfVxuICBydW5PblJlc291cmNlKHJlc291cmNlLCBub3cpIHtcbiAgICBpZiAocmVzb3VyY2UuX2djRGF0YS50eXBlID09PSBcInJlbmRlcmFibGVcIikge1xuICAgICAgdGhpcy51cGRhdGVSZW5kZXJhYmxlR0NUaWNrKHJlc291cmNlLCBub3cpO1xuICAgIH1cbiAgICBjb25zdCBpc1JlY2VudGx5VXNlZCA9IG5vdyAtIHJlc291cmNlLl9nY0xhc3RVc2VkIDwgdGhpcy5tYXhVbnVzZWRUaW1lO1xuICAgIGlmIChpc1JlY2VudGx5VXNlZCB8fCAhcmVzb3VyY2UuYXV0b0dhcmJhZ2VDb2xsZWN0KSByZXR1cm47XG4gICAgcmVzb3VyY2Uub2ZmKFwidW5sb2FkXCIsIHRoaXMucmVtb3ZlUmVzb3VyY2UsIHRoaXMpO1xuICAgIHJlc291cmNlLnVubG9hZCgpO1xuICAgIHRoaXMucmVtb3ZlUmVzb3VyY2UocmVzb3VyY2UpO1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgY2xvbmUgb2YgdGhlIGhhc2gsIGNvcHlpbmcgYWxsIG5vbi1udWxsIGVudHJpZXMgdXAgdG8gKGJ1dCBub3QgaW5jbHVkaW5nKSB0aGUgc3RvcCBrZXkuXG4gICAqIEBwYXJhbSBoYXNoVmFsdWUgLSBUaGUgb3JpZ2luYWwgaGFzaCB0byBjbG9uZSBmcm9tXG4gICAqIEBwYXJhbSBzdG9wS2V5IC0gVGhlIGtleSB0byBzdG9wIGF0IChleGNsdXNpdmUpXG4gICAqIEByZXR1cm5zIEEgbmV3IGhhc2ggb2JqZWN0IHdpdGggY29waWVkIGVudHJpZXNcbiAgICovXG4gIF9jcmVhdGVIYXNoQ2xvbmUoaGFzaFZhbHVlLCBzdG9wS2V5KSB7XG4gICAgY29uc3QgaGFzaENsb25lID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgZm9yIChjb25zdCBrIGluIGhhc2hWYWx1ZSkge1xuICAgICAgaWYgKGsgPT09IHN0b3BLZXkpIGJyZWFrO1xuICAgICAgaWYgKGhhc2hWYWx1ZVtrXSAhPT0gbnVsbCkgaGFzaENsb25lW2tdID0gaGFzaFZhbHVlW2tdO1xuICAgIH1cbiAgICByZXR1cm4gaGFzaENsb25lO1xuICB9XG4gIHJ1bk9uSGFzaChoYXNoRW50cnksIG5vdykge1xuICAgIGNvbnN0IHsgY29udGV4dCwgaGFzaCwgdHlwZSB9ID0gaGFzaEVudHJ5O1xuICAgIGNvbnN0IGhhc2hWYWx1ZSA9IGNvbnRleHRbaGFzaF07XG4gICAgbGV0IGhhc2hDbG9uZSA9IG51bGw7XG4gICAgbGV0IG51bGxDb3VudCA9IDA7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gaGFzaFZhbHVlKSB7XG4gICAgICBjb25zdCByZXNvdXJjZSA9IGhhc2hWYWx1ZVtrZXldO1xuICAgICAgaWYgKHJlc291cmNlID09PSBudWxsKSB7XG4gICAgICAgIG51bGxDb3VudCsrO1xuICAgICAgICBpZiAobnVsbENvdW50ID09PSAxZTQgJiYgIWhhc2hDbG9uZSkge1xuICAgICAgICAgIGhhc2hDbG9uZSA9IHRoaXMuX2NyZWF0ZUhhc2hDbG9uZShoYXNoVmFsdWUsIGtleSk7XG4gICAgICAgIH1cbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAocmVzb3VyY2UuX2djTGFzdFVzZWQgPT09IC0xKSB7XG4gICAgICAgIHJlc291cmNlLl9nY0xhc3RVc2VkID0gbm93O1xuICAgICAgICByZXNvdXJjZS5fb25Ub3VjaD8uKG5vdyk7XG4gICAgICAgIGlmIChoYXNoQ2xvbmUpIGhhc2hDbG9uZVtrZXldID0gcmVzb3VyY2U7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYgKHR5cGUgPT09IFwicmVuZGVyYWJsZVwiKSB7XG4gICAgICAgIHRoaXMudXBkYXRlUmVuZGVyYWJsZUdDVGljayhyZXNvdXJjZSwgbm93KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGlzUmVjZW50bHlVc2VkID0gbm93IC0gcmVzb3VyY2UuX2djTGFzdFVzZWQgPCB0aGlzLm1heFVudXNlZFRpbWU7XG4gICAgICBpZiAoIWlzUmVjZW50bHlVc2VkICYmIHJlc291cmNlLmF1dG9HYXJiYWdlQ29sbGVjdCkge1xuICAgICAgICBpZiAodHlwZSA9PT0gXCJyZW5kZXJhYmxlXCIpIHtcbiAgICAgICAgICBjb25zdCByZXMgPSByZXNvdXJjZTtcbiAgICAgICAgICBjb25zdCByZW5kZXJHcm91cCA9IHJlcy5yZW5kZXJHcm91cCA/PyByZXMucGFyZW50UmVuZGVyR3JvdXA7XG4gICAgICAgICAgaWYgKHJlbmRlckdyb3VwKSByZW5kZXJHcm91cC5zdHJ1Y3R1cmVEaWRDaGFuZ2UgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHJlc291cmNlLnVubG9hZCgpO1xuICAgICAgICByZXNvdXJjZS5fZ2NEYXRhID0gbnVsbDtcbiAgICAgICAgcmVzb3VyY2UuX2djTGFzdFVzZWQgPSAtMTtcbiAgICAgICAgaWYgKCFoYXNoQ2xvbmUpIHtcbiAgICAgICAgICBpZiAobnVsbENvdW50ICsgMSAhPT0gMWU0KSB7XG4gICAgICAgICAgICBoYXNoVmFsdWVba2V5XSA9IG51bGw7XG4gICAgICAgICAgICBudWxsQ291bnQrKztcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaGFzaENsb25lID0gdGhpcy5fY3JlYXRlSGFzaENsb25lKGhhc2hWYWx1ZSwga2V5KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoaGFzaENsb25lKSB7XG4gICAgICAgIGhhc2hDbG9uZVtrZXldID0gcmVzb3VyY2U7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChoYXNoQ2xvbmUpIHtcbiAgICAgIGNvbnRleHRbaGFzaF0gPSBoYXNoQ2xvbmU7XG4gICAgfVxuICB9XG4gIC8qKiBDbGVhbnMgdXAgdGhlIGdhcmJhZ2UgY29sbGVjdGlvbiBzeXN0ZW0uIERpc2FibGVzIEdDIGFuZCByZW1vdmVzIGFsbCB0cmFja2VkIHJlc291cmNlcy4gKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLmVuYWJsZWQgPSBmYWxzZTtcbiAgICB0aGlzLl9tYW5hZ2VkUmVzb3VyY2VzLmZvckVhY2goKHJlc291cmNlKSA9PiB7XG4gICAgICByZXNvdXJjZT8ub2ZmKFwidW5sb2FkXCIsIHRoaXMucmVtb3ZlUmVzb3VyY2UsIHRoaXMpO1xuICAgIH0pO1xuICAgIHRoaXMuX21hbmFnZWRSZXNvdXJjZXMubGVuZ3RoID0gMDtcbiAgICB0aGlzLl9tYW5hZ2VkUmVzb3VyY2VIYXNoZXMubGVuZ3RoID0gMDtcbiAgICB0aGlzLl9tYW5hZ2VkQ29sbGVjdGlvbnMubGVuZ3RoID0gMDtcbiAgICB0aGlzLl9yZW5kZXJlciA9IG51bGw7XG4gIH1cbn07XG4vKiogQGlnbm9yZSAqL1xuX0dDU3lzdGVtLmV4dGVuc2lvbiA9IHtcbiAgdHlwZTogW1xuICAgIEV4dGVuc2lvblR5cGUuV2ViR0xTeXN0ZW0sXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHUFVTeXN0ZW0sXG4gICAgRXh0ZW5zaW9uVHlwZS5DYW52YXNTeXN0ZW1cbiAgXSxcbiAgbmFtZTogXCJnY1wiLFxuICBwcmlvcml0eTogMFxufTtcbi8qKiBEZWZhdWx0IG9wdGlvbnMgZm9yIHRoZSBHQ1N5c3RlbSAqL1xuX0dDU3lzdGVtLmRlZmF1bHRPcHRpb25zID0ge1xuICAvKiogRW5hYmxlL2Rpc2FibGUgdGhlIGdhcmJhZ2UgY29sbGVjdG9yICovXG4gIGdjQWN0aXZlOiB0cnVlLFxuICAvKiogVGltZSBpbiBtcyBiZWZvcmUgYW4gdW51c2VkIHJlc291cmNlIGlzIGNvbGxlY3RlZCAoZGVmYXVsdCAxIG1pbnV0ZSkgKi9cbiAgZ2NNYXhVbnVzZWRUaW1lOiA2ZTQsXG4gIC8qKiBIb3cgb2Z0ZW4gdG8gcnVuIGdhcmJhZ2UgY29sbGVjdGlvbiBpbiBtcyAoZGVmYXVsdCAzMCBzZWNvbmRzKSAqL1xuICBnY0ZyZXF1ZW5jeTogM2U0XG59O1xubGV0IEdDU3lzdGVtID0gX0dDU3lzdGVtO1xuXG5leHBvcnQgeyBHQ1N5c3RlbSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9R0NTeXN0ZW0ubWpzLm1hcFxuIiwiaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgUG9pbnQgfSBmcm9tICcuLi8uLi8uLi8uLi9tYXRocy9wb2ludC9Qb2ludC5tanMnO1xuaW1wb3J0IHsgY29sb3IzMkJpdFRvVW5pZm9ybSB9IGZyb20gJy4uLy4uLy4uLy4uL3NjZW5lL2dyYXBoaWNzL2dwdS9jb2xvclRvVW5pZm9ybS5tanMnO1xuaW1wb3J0IHsgQmluZEdyb3VwIH0gZnJvbSAnLi4vLi4vZ3B1L3NoYWRlci9CaW5kR3JvdXAubWpzJztcbmltcG9ydCB7IFJlbmRlcmVyVHlwZSB9IGZyb20gJy4uLy4uL3R5cGVzLm1qcyc7XG5pbXBvcnQgeyBVbmlmb3JtR3JvdXAgfSBmcm9tICcuLi9zaGFkZXIvVW5pZm9ybUdyb3VwLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgR2xvYmFsVW5pZm9ybVN5c3RlbSB7XG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgdGhpcy5fc3RhY2tJbmRleCA9IDA7XG4gICAgdGhpcy5fZ2xvYmFsVW5pZm9ybURhdGFTdGFjayA9IFtdO1xuICAgIHRoaXMuX3VuaWZvcm1zUG9vbCA9IFtdO1xuICAgIHRoaXMuX2FjdGl2ZVVuaWZvcm1zID0gW107XG4gICAgdGhpcy5fYmluZEdyb3VwUG9vbCA9IFtdO1xuICAgIHRoaXMuX2FjdGl2ZUJpbmRHcm91cHMgPSBbXTtcbiAgICB0aGlzLl9yZW5kZXJlciA9IHJlbmRlcmVyO1xuICB9XG4gIHJlc2V0KCkge1xuICAgIHRoaXMuX3N0YWNrSW5kZXggPSAwO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5fYWN0aXZlVW5pZm9ybXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHRoaXMuX3VuaWZvcm1zUG9vbC5wdXNoKHRoaXMuX2FjdGl2ZVVuaWZvcm1zW2ldKTtcbiAgICB9XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLl9hY3RpdmVCaW5kR3JvdXBzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB0aGlzLl9iaW5kR3JvdXBQb29sLnB1c2godGhpcy5fYWN0aXZlQmluZEdyb3Vwc1tpXSk7XG4gICAgfVxuICAgIHRoaXMuX2FjdGl2ZVVuaWZvcm1zLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5fYWN0aXZlQmluZEdyb3Vwcy5sZW5ndGggPSAwO1xuICB9XG4gIHN0YXJ0KG9wdGlvbnMpIHtcbiAgICB0aGlzLnJlc2V0KCk7XG4gICAgdGhpcy5wdXNoKG9wdGlvbnMpO1xuICB9XG4gIGJpbmQoe1xuICAgIHNpemUsXG4gICAgcHJvamVjdGlvbk1hdHJpeCxcbiAgICB3b3JsZFRyYW5zZm9ybU1hdHJpeCxcbiAgICB3b3JsZENvbG9yLFxuICAgIG9mZnNldFxuICB9KSB7XG4gICAgY29uc3QgcmVuZGVyVGFyZ2V0ID0gdGhpcy5fcmVuZGVyZXIucmVuZGVyVGFyZ2V0LnJlbmRlclRhcmdldDtcbiAgICBjb25zdCBjdXJyZW50R2xvYmFsVW5pZm9ybURhdGEgPSB0aGlzLl9zdGFja0luZGV4ID8gdGhpcy5fZ2xvYmFsVW5pZm9ybURhdGFTdGFja1t0aGlzLl9zdGFja0luZGV4IC0gMV0gOiB7XG4gICAgICBwcm9qZWN0aW9uRGF0YTogcmVuZGVyVGFyZ2V0LFxuICAgICAgd29ybGRUcmFuc2Zvcm1NYXRyaXg6IG5ldyBNYXRyaXgoKSxcbiAgICAgIHdvcmxkQ29sb3I6IDQyOTQ5NjcyOTUsXG4gICAgICBvZmZzZXQ6IG5ldyBQb2ludCgpXG4gICAgfTtcbiAgICBjb25zdCBnbG9iYWxVbmlmb3JtRGF0YSA9IHtcbiAgICAgIHByb2plY3Rpb25NYXRyaXg6IHByb2plY3Rpb25NYXRyaXggfHwgdGhpcy5fcmVuZGVyZXIucmVuZGVyVGFyZ2V0LnByb2plY3Rpb25NYXRyaXgsXG4gICAgICByZXNvbHV0aW9uOiBzaXplIHx8IHJlbmRlclRhcmdldC5zaXplLFxuICAgICAgd29ybGRUcmFuc2Zvcm1NYXRyaXg6IHdvcmxkVHJhbnNmb3JtTWF0cml4IHx8IGN1cnJlbnRHbG9iYWxVbmlmb3JtRGF0YS53b3JsZFRyYW5zZm9ybU1hdHJpeCxcbiAgICAgIHdvcmxkQ29sb3I6IHdvcmxkQ29sb3IgfHwgY3VycmVudEdsb2JhbFVuaWZvcm1EYXRhLndvcmxkQ29sb3IsXG4gICAgICBvZmZzZXQ6IG9mZnNldCB8fCBjdXJyZW50R2xvYmFsVW5pZm9ybURhdGEub2Zmc2V0LFxuICAgICAgYmluZEdyb3VwOiBudWxsXG4gICAgfTtcbiAgICBjb25zdCB1bmlmb3JtR3JvdXAgPSB0aGlzLl91bmlmb3Jtc1Bvb2wucG9wKCkgfHwgdGhpcy5fY3JlYXRlVW5pZm9ybXMoKTtcbiAgICB0aGlzLl9hY3RpdmVVbmlmb3Jtcy5wdXNoKHVuaWZvcm1Hcm91cCk7XG4gICAgY29uc3QgdW5pZm9ybXMgPSB1bmlmb3JtR3JvdXAudW5pZm9ybXM7XG4gICAgdW5pZm9ybXMudVByb2plY3Rpb25NYXRyaXggPSBnbG9iYWxVbmlmb3JtRGF0YS5wcm9qZWN0aW9uTWF0cml4O1xuICAgIHVuaWZvcm1zLnVSZXNvbHV0aW9uID0gZ2xvYmFsVW5pZm9ybURhdGEucmVzb2x1dGlvbjtcbiAgICB1bmlmb3Jtcy51V29ybGRUcmFuc2Zvcm1NYXRyaXguY29weUZyb20oZ2xvYmFsVW5pZm9ybURhdGEud29ybGRUcmFuc2Zvcm1NYXRyaXgpO1xuICAgIHVuaWZvcm1zLnVXb3JsZFRyYW5zZm9ybU1hdHJpeC50eCAtPSBnbG9iYWxVbmlmb3JtRGF0YS5vZmZzZXQueDtcbiAgICB1bmlmb3Jtcy51V29ybGRUcmFuc2Zvcm1NYXRyaXgudHkgLT0gZ2xvYmFsVW5pZm9ybURhdGEub2Zmc2V0Lnk7XG4gICAgY29sb3IzMkJpdFRvVW5pZm9ybShcbiAgICAgIGdsb2JhbFVuaWZvcm1EYXRhLndvcmxkQ29sb3IsXG4gICAgICB1bmlmb3Jtcy51V29ybGRDb2xvckFscGhhLFxuICAgICAgMFxuICAgICk7XG4gICAgdW5pZm9ybUdyb3VwLnVwZGF0ZSgpO1xuICAgIGxldCBiaW5kR3JvdXA7XG4gICAgaWYgKHRoaXMuX3JlbmRlcmVyLnJlbmRlclBpcGVzLnVuaWZvcm1CYXRjaCkge1xuICAgICAgYmluZEdyb3VwID0gdGhpcy5fcmVuZGVyZXIucmVuZGVyUGlwZXMudW5pZm9ybUJhdGNoLmdldFVuaWZvcm1CaW5kR3JvdXAodW5pZm9ybUdyb3VwLCBmYWxzZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGJpbmRHcm91cCA9IHRoaXMuX2JpbmRHcm91cFBvb2wucG9wKCkgfHwgbmV3IEJpbmRHcm91cCgpO1xuICAgICAgdGhpcy5fYWN0aXZlQmluZEdyb3Vwcy5wdXNoKGJpbmRHcm91cCk7XG4gICAgICBiaW5kR3JvdXAuc2V0UmVzb3VyY2UodW5pZm9ybUdyb3VwLCAwKTtcbiAgICB9XG4gICAgZ2xvYmFsVW5pZm9ybURhdGEuYmluZEdyb3VwID0gYmluZEdyb3VwO1xuICAgIHRoaXMuX2N1cnJlbnRHbG9iYWxVbmlmb3JtRGF0YSA9IGdsb2JhbFVuaWZvcm1EYXRhO1xuICB9XG4gIHB1c2gob3B0aW9ucykge1xuICAgIHRoaXMuYmluZChvcHRpb25zKTtcbiAgICB0aGlzLl9nbG9iYWxVbmlmb3JtRGF0YVN0YWNrW3RoaXMuX3N0YWNrSW5kZXgrK10gPSB0aGlzLl9jdXJyZW50R2xvYmFsVW5pZm9ybURhdGE7XG4gIH1cbiAgcG9wKCkge1xuICAgIHRoaXMuX2N1cnJlbnRHbG9iYWxVbmlmb3JtRGF0YSA9IHRoaXMuX2dsb2JhbFVuaWZvcm1EYXRhU3RhY2tbLS10aGlzLl9zdGFja0luZGV4IC0gMV07XG4gICAgaWYgKHRoaXMuX3JlbmRlcmVyLnR5cGUgPT09IFJlbmRlcmVyVHlwZS5XRUJHTCkge1xuICAgICAgdGhpcy5fY3VycmVudEdsb2JhbFVuaWZvcm1EYXRhLmJpbmRHcm91cC5yZXNvdXJjZXNbMF0udXBkYXRlKCk7XG4gICAgfVxuICB9XG4gIGdldCBiaW5kR3JvdXAoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2N1cnJlbnRHbG9iYWxVbmlmb3JtRGF0YS5iaW5kR3JvdXA7XG4gIH1cbiAgZ2V0IGdsb2JhbFVuaWZvcm1EYXRhKCkge1xuICAgIHJldHVybiB0aGlzLl9jdXJyZW50R2xvYmFsVW5pZm9ybURhdGE7XG4gIH1cbiAgZ2V0IHVuaWZvcm1Hcm91cCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY3VycmVudEdsb2JhbFVuaWZvcm1EYXRhLmJpbmRHcm91cC5yZXNvdXJjZXNbMF07XG4gIH1cbiAgX2NyZWF0ZVVuaWZvcm1zKCkge1xuICAgIGNvbnN0IGdsb2JhbFVuaWZvcm1zID0gbmV3IFVuaWZvcm1Hcm91cCh7XG4gICAgICB1UHJvamVjdGlvbk1hdHJpeDogeyB2YWx1ZTogbmV3IE1hdHJpeCgpLCB0eXBlOiBcIm1hdDN4MzxmMzI+XCIgfSxcbiAgICAgIHVXb3JsZFRyYW5zZm9ybU1hdHJpeDogeyB2YWx1ZTogbmV3IE1hdHJpeCgpLCB0eXBlOiBcIm1hdDN4MzxmMzI+XCIgfSxcbiAgICAgIC8vIFRPRE8gLSBzb21lb25lIHNtYXJ0IC0gc2V0IHRoaXMgdG8gYmUgYSB1bm9ybTh4NCByYXRoZXIgdGhhbiBhIHZlYzQ8ZjMyPlxuICAgICAgdVdvcmxkQ29sb3JBbHBoYTogeyB2YWx1ZTogbmV3IEZsb2F0MzJBcnJheSg0KSwgdHlwZTogXCJ2ZWM0PGYzMj5cIiB9LFxuICAgICAgdVJlc29sdXRpb246IHsgdmFsdWU6IFswLCAwXSwgdHlwZTogXCJ2ZWMyPGYzMj5cIiB9XG4gICAgfSwge1xuICAgICAgaXNTdGF0aWM6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gZ2xvYmFsVW5pZm9ybXM7XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IG51bGw7XG4gICAgdGhpcy5fZ2xvYmFsVW5pZm9ybURhdGFTdGFjay5sZW5ndGggPSAwO1xuICAgIHRoaXMuX3VuaWZvcm1zUG9vbC5sZW5ndGggPSAwO1xuICAgIHRoaXMuX2FjdGl2ZVVuaWZvcm1zLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5fYmluZEdyb3VwUG9vbC5sZW5ndGggPSAwO1xuICAgIHRoaXMuX2FjdGl2ZUJpbmRHcm91cHMubGVuZ3RoID0gMDtcbiAgICB0aGlzLl9jdXJyZW50R2xvYmFsVW5pZm9ybURhdGEgPSBudWxsO1xuICB9XG59XG4vKiogQGlnbm9yZSAqL1xuR2xvYmFsVW5pZm9ybVN5c3RlbS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuV2ViR1BVU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuQ2FudmFzU3lzdGVtXG4gIF0sXG4gIG5hbWU6IFwiZ2xvYmFsVW5pZm9ybXNcIlxufTtcblxuZXhwb3J0IHsgR2xvYmFsVW5pZm9ybVN5c3RlbSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9R2xvYmFsVW5pZm9ybVN5c3RlbS5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBUaWNrZXIgfSBmcm9tICcuLi8uLi8uLi90aWNrZXIvVGlja2VyLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xubGV0IHVpZCA9IDE7XG5jbGFzcyBTY2hlZHVsZXJTeXN0ZW0ge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLl90YXNrcyA9IFtdO1xuICAgIC8qKiBhIHNtYWxsIG9mZiBzZXQgdG8gYXBwbHkgdG8gdGhlIHJlcGVhdCBzY2hlZHVsZXMuIFRoaXMgaXMganVzdCB0byBtYWtlIHN1cmUgdGhleSBydW4gYXQgc2xpZ2h0bHkgZGlmZmVyZW50IHRpbWVzICovXG4gICAgdGhpcy5fb2Zmc2V0ID0gMDtcbiAgfVxuICAvKiogSW5pdGlhbGl6ZXMgdGhlIHNjaGVkdWxlciBzeXN0ZW0gYW5kIHN0YXJ0cyB0aGUgdGlja2VyLiAqL1xuICBpbml0KCkge1xuICAgIFRpY2tlci5zeXN0ZW0uYWRkKHRoaXMuX3VwZGF0ZSwgdGhpcyk7XG4gIH1cbiAgLyoqXG4gICAqIFNjaGVkdWxlcyBhIHJlcGVhdGluZyB0YXNrLlxuICAgKiBAcGFyYW0gZnVuYyAtIFRoZSBmdW5jdGlvbiB0byBleGVjdXRlLlxuICAgKiBAcGFyYW0gZHVyYXRpb24gLSBUaGUgaW50ZXJ2YWwgZHVyYXRpb24gaW4gbWlsbGlzZWNvbmRzLlxuICAgKiBAcGFyYW0gdXNlT2Zmc2V0IC0gdGhpcyB3aWxsIHNwcmVhZCBvdXQgdGFza3Mgc28gdGhhdCB0aGV5IGRvIG5vdCBhbGwgcnVuIGF0IHRoZSBzYW1lIHRpbWVcbiAgICogQHJldHVybnMgVGhlIHVuaXF1ZSBpZGVudGlmaWVyIGZvciB0aGUgc2NoZWR1bGVkIHRhc2suXG4gICAqL1xuICByZXBlYXQoZnVuYywgZHVyYXRpb24sIHVzZU9mZnNldCA9IHRydWUpIHtcbiAgICBjb25zdCBpZCA9IHVpZCsrO1xuICAgIGxldCBvZmZzZXQgPSAwO1xuICAgIGlmICh1c2VPZmZzZXQpIHtcbiAgICAgIHRoaXMuX29mZnNldCArPSAxZTM7XG4gICAgICBvZmZzZXQgPSB0aGlzLl9vZmZzZXQ7XG4gICAgfVxuICAgIHRoaXMuX3Rhc2tzLnB1c2goe1xuICAgICAgZnVuYyxcbiAgICAgIGR1cmF0aW9uLFxuICAgICAgc3RhcnQ6IHBlcmZvcm1hbmNlLm5vdygpLFxuICAgICAgb2Zmc2V0LFxuICAgICAgbGFzdDogcGVyZm9ybWFuY2Uubm93KCksXG4gICAgICByZXBlYXQ6IHRydWUsXG4gICAgICBpZFxuICAgIH0pO1xuICAgIHJldHVybiBpZDtcbiAgfVxuICAvKipcbiAgICogQ2FuY2VscyBhIHNjaGVkdWxlZCB0YXNrLlxuICAgKiBAcGFyYW0gaWQgLSBUaGUgdW5pcXVlIGlkZW50aWZpZXIgb2YgdGhlIHRhc2sgdG8gY2FuY2VsLlxuICAgKi9cbiAgY2FuY2VsKGlkKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLl90YXNrcy5sZW5ndGg7IGkrKykge1xuICAgICAgaWYgKHRoaXMuX3Rhc2tzW2ldLmlkID09PSBpZCkge1xuICAgICAgICB0aGlzLl90YXNrcy5zcGxpY2UoaSwgMSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIFVwZGF0ZXMgYW5kIGV4ZWN1dGVzIHRoZSBzY2hlZHVsZWQgdGFza3MuXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfdXBkYXRlKCkge1xuICAgIGNvbnN0IG5vdyA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5fdGFza3MubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IHRhc2sgPSB0aGlzLl90YXNrc1tpXTtcbiAgICAgIGlmIChub3cgLSB0YXNrLm9mZnNldCAtIHRhc2subGFzdCA+PSB0YXNrLmR1cmF0aW9uKSB7XG4gICAgICAgIGNvbnN0IGVsYXBzZWQgPSBub3cgLSB0YXNrLnN0YXJ0O1xuICAgICAgICB0YXNrLmZ1bmMoZWxhcHNlZCk7XG4gICAgICAgIHRhc2subGFzdCA9IG5vdztcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIERlc3Ryb3lzIHRoZSBzY2hlZHVsZXIgc3lzdGVtIGFuZCByZW1vdmVzIGFsbCB0YXNrcy5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBkZXN0cm95KCkge1xuICAgIFRpY2tlci5zeXN0ZW0ucmVtb3ZlKHRoaXMuX3VwZGF0ZSwgdGhpcyk7XG4gICAgdGhpcy5fdGFza3MubGVuZ3RoID0gMDtcbiAgfVxufVxuLyoqIEBpZ25vcmUgKi9cblNjaGVkdWxlclN5c3RlbS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuV2ViR1BVU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuQ2FudmFzU3lzdGVtXG4gIF0sXG4gIG5hbWU6IFwic2NoZWR1bGVyXCIsXG4gIHByaW9yaXR5OiAwXG59O1xuXG5leHBvcnQgeyBTY2hlZHVsZXJTeXN0ZW0gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVNjaGVkdWxlclN5c3RlbS5tanMubWFwXG4iLCJpbXBvcnQgeyBET01BZGFwdGVyIH0gZnJvbSAnLi4vZW52aXJvbm1lbnQvYWRhcHRlci5tanMnO1xuaW1wb3J0IHsgVkVSU0lPTiB9IGZyb20gJy4vY29uc3QubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5sZXQgc2FpZEhlbGxvID0gZmFsc2U7XG5mdW5jdGlvbiBzYXlIZWxsbyh0eXBlKSB7XG4gIGlmIChzYWlkSGVsbG8pIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKERPTUFkYXB0ZXIuZ2V0KCkuZ2V0TmF2aWdhdG9yKCkudXNlckFnZW50LnRvTG93ZXJDYXNlKCkuaW5kZXhPZihcImNocm9tZVwiKSA+IC0xKSB7XG4gICAgY29uc3QgYXJncyA9IFtcbiAgICAgIGAlYyAgJWMgICVjICAlYyAgJWMgUGl4aUpTICVjIHYke1ZFUlNJT059ICgke3R5cGV9KSBodHRwOi8vd3d3LnBpeGlqcy5jb20vXG5cbmAsXG4gICAgICBcImJhY2tncm91bmQ6ICNFNzIyNjQ7IHBhZGRpbmc6NXB4IDA7XCIsXG4gICAgICBcImJhY2tncm91bmQ6ICM2Q0EyRUE7IHBhZGRpbmc6NXB4IDA7XCIsXG4gICAgICBcImJhY2tncm91bmQ6ICNCNUQzM0Q7IHBhZGRpbmc6NXB4IDA7XCIsXG4gICAgICBcImJhY2tncm91bmQ6ICNGRUQyM0Y7IHBhZGRpbmc6NXB4IDA7XCIsXG4gICAgICBcImNvbG9yOiAjRkZGRkZGOyBiYWNrZ3JvdW5kOiAjRTcyMjY0OyBwYWRkaW5nOjVweCAwO1wiLFxuICAgICAgXCJjb2xvcjogI0U3MjI2NDsgYmFja2dyb3VuZDogI0ZGRkZGRjsgcGFkZGluZzo1cHggMDtcIlxuICAgIF07XG4gICAgZ2xvYmFsVGhpcy5jb25zb2xlLmxvZyguLi5hcmdzKTtcbiAgfSBlbHNlIGlmIChnbG9iYWxUaGlzLmNvbnNvbGUpIHtcbiAgICBnbG9iYWxUaGlzLmNvbnNvbGUubG9nKGBQaXhpSlMgJHtWRVJTSU9OfSAtICR7dHlwZX0gLSBodHRwOi8vd3d3LnBpeGlqcy5jb20vYCk7XG4gIH1cbiAgc2FpZEhlbGxvID0gdHJ1ZTtcbn1cblxuZXhwb3J0IHsgc2F5SGVsbG8gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNheUhlbGxvLm1qcy5tYXBcbiIsImltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi8uLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IHNheUhlbGxvIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvc2F5SGVsbG8ubWpzJztcbmltcG9ydCB7IFJlbmRlcmVyVHlwZSB9IGZyb20gJy4uLy4uL3R5cGVzLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgSGVsbG9TeXN0ZW0ge1xuICBjb25zdHJ1Y3RvcihyZW5kZXJlcikge1xuICAgIHRoaXMuX3JlbmRlcmVyID0gcmVuZGVyZXI7XG4gIH1cbiAgLyoqXG4gICAqIEl0IGFsbCBzdGFydHMgaGVyZSEgVGhpcyBpbml0aWF0ZXMgZXZlcnkgc3lzdGVtLCBwYXNzaW5nIGluIHRoZSBvcHRpb25zIGZvciBhbnkgc3lzdGVtIGJ5IG5hbWUuXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gdGhlIGNvbmZpZyBmb3IgdGhlIHJlbmRlcmVyIGFuZCBhbGwgaXRzIHN5c3RlbXNcbiAgICovXG4gIGluaXQob3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zLmhlbGxvKSB7XG4gICAgICBsZXQgbmFtZSA9IHRoaXMuX3JlbmRlcmVyLm5hbWU7XG4gICAgICBpZiAodGhpcy5fcmVuZGVyZXIudHlwZSA9PT0gUmVuZGVyZXJUeXBlLldFQkdMKSB7XG4gICAgICAgIG5hbWUgKz0gYCAke3RoaXMuX3JlbmRlcmVyLmNvbnRleHQud2ViR0xWZXJzaW9ufWA7XG4gICAgICB9XG4gICAgICBzYXlIZWxsbyhuYW1lKTtcbiAgICB9XG4gIH1cbn1cbi8qKiBAaWdub3JlICovXG5IZWxsb1N5c3RlbS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuV2ViR1BVU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuQ2FudmFzU3lzdGVtXG4gIF0sXG4gIG5hbWU6IFwiaGVsbG9cIixcbiAgcHJpb3JpdHk6IC0yXG59O1xuLyoqIFRoZSBkZWZhdWx0IG9wdGlvbnMgZm9yIHRoZSBzeXN0ZW0uICovXG5IZWxsb1N5c3RlbS5kZWZhdWx0T3B0aW9ucyA9IHtcbiAgLyoqIHtAbGluayBXZWJHTE9wdGlvbnMuaGVsbG99ICovXG4gIGhlbGxvOiBmYWxzZVxufTtcblxuZXhwb3J0IHsgSGVsbG9TeXN0ZW0gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUhlbGxvU3lzdGVtLm1qcy5tYXBcbiIsImltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi8uLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IGRlcHJlY2F0aW9uIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy9kZXByZWNhdGlvbi5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IF9SZW5kZXJhYmxlR0NTeXN0ZW0gPSBjbGFzcyBfUmVuZGVyYWJsZUdDU3lzdGVtIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgUmVuZGVyYWJsZUdDU3lzdGVtIGluc3RhbmNlLlxuICAgKiBAcGFyYW0gcmVuZGVyZXIgLSBUaGUgcmVuZGVyZXIgdGhpcyBnYXJiYWdlIGNvbGxlY3Rpb24gc3lzdGVtIHdvcmtzIGZvclxuICAgKi9cbiAgY29uc3RydWN0b3IocmVuZGVyZXIpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IHJlbmRlcmVyO1xuICB9XG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgZ2FyYmFnZSBjb2xsZWN0aW9uIHN5c3RlbSB3aXRoIHRoZSBwcm92aWRlZCBvcHRpb25zLlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIENvbmZpZ3VyYXRpb24gb3B0aW9ucyBmb3IgdGhlIHJlbmRlcmVyXG4gICAqL1xuICBpbml0KG9wdGlvbnMpIHtcbiAgICBvcHRpb25zID0geyAuLi5fUmVuZGVyYWJsZUdDU3lzdGVtLmRlZmF1bHRPcHRpb25zLCAuLi5vcHRpb25zIH07XG4gICAgdGhpcy5tYXhVbnVzZWRUaW1lID0gb3B0aW9ucy5yZW5kZXJhYmxlR0NNYXhVbnVzZWRUaW1lO1xuICB9XG4gIC8qKlxuICAgKiBHZXRzIHdoZXRoZXIgdGhlIGdhcmJhZ2UgY29sbGVjdGlvbiBzeXN0ZW0gaXMgY3VycmVudGx5IGVuYWJsZWQuXG4gICAqIEByZXR1cm5zIFRydWUgaWYgR0MgaXMgZW5hYmxlZCwgZmFsc2Ugb3RoZXJ3aXNlXG4gICAqL1xuICBnZXQgZW5hYmxlZCgpIHtcbiAgICBkZXByZWNhdGlvbihcIjguMTUuMFwiLCBcIlJlbmRlcmFibGVHQ1N5c3RlbS5lbmFibGVkIGlzIGRlcHJlY2F0ZWQsIHBsZWFzZSB1c2UgdGhlIEdDU3lzdGVtLmVuYWJsZWQgaW5zdGVhZC5cIik7XG4gICAgcmV0dXJuIHRoaXMuX3JlbmRlcmVyLmdjLmVuYWJsZWQ7XG4gIH1cbiAgLyoqXG4gICAqIEVuYWJsZXMgb3IgZGlzYWJsZXMgdGhlIGdhcmJhZ2UgY29sbGVjdGlvbiBzeXN0ZW0uXG4gICAqIFdoZW4gZW5hYmxlZCwgc2NoZWR1bGVzIHBlcmlvZGljIGNsZWFudXAgb2YgcmVzb3VyY2VzLlxuICAgKiBXaGVuIGRpc2FibGVkLCBjYW5jZWxzIGFsbCBzY2hlZHVsZWQgY2xlYW51cHMuXG4gICAqL1xuICBzZXQgZW5hYmxlZCh2YWx1ZSkge1xuICAgIGRlcHJlY2F0aW9uKFwiOC4xNS4wXCIsIFwiUmVuZGVyYWJsZUdDU3lzdGVtLmVuYWJsZWQgaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSB0aGUgR0NTeXN0ZW0uZW5hYmxlZCBpbnN0ZWFkLlwiKTtcbiAgICB0aGlzLl9yZW5kZXJlci5nYy5lbmFibGVkID0gdmFsdWU7XG4gIH1cbiAgLyoqXG4gICAqIEFkZHMgYSBoYXNoIHRhYmxlIHRvIGJlIG1hbmFnZWQgYnkgdGhlIGdhcmJhZ2UgY29sbGVjdG9yLlxuICAgKiBAcGFyYW0gY29udGV4dCAtIFRoZSBvYmplY3QgY29udGFpbmluZyB0aGUgaGFzaCB0YWJsZVxuICAgKiBAcGFyYW0gaGFzaCAtIFRoZSBwcm9wZXJ0eSBuYW1lIG9mIHRoZSBoYXNoIHRhYmxlXG4gICAqL1xuICBhZGRNYW5hZ2VkSGFzaChjb250ZXh0LCBoYXNoKSB7XG4gICAgZGVwcmVjYXRpb24oXCI4LjE1LjBcIiwgXCJSZW5kZXJhYmxlR0NTeXN0ZW0uYWRkTWFuYWdlZEhhc2ggaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSB0aGUgR0NTeXN0ZW0uYWRkQ29sbGVjdGlvbiBpbnN0ZWFkLlwiKTtcbiAgICB0aGlzLl9yZW5kZXJlci5nYy5hZGRDb2xsZWN0aW9uKGNvbnRleHQsIGhhc2gsIFwiaGFzaFwiKTtcbiAgfVxuICAvKipcbiAgICogQWRkcyBhbiBhcnJheSB0byBiZSBtYW5hZ2VkIGJ5IHRoZSBnYXJiYWdlIGNvbGxlY3Rvci5cbiAgICogQHBhcmFtIGNvbnRleHQgLSBUaGUgb2JqZWN0IGNvbnRhaW5pbmcgdGhlIGFycmF5XG4gICAqIEBwYXJhbSBoYXNoIC0gVGhlIHByb3BlcnR5IG5hbWUgb2YgdGhlIGFycmF5XG4gICAqL1xuICBhZGRNYW5hZ2VkQXJyYXkoY29udGV4dCwgaGFzaCkge1xuICAgIGRlcHJlY2F0aW9uKFwiOC4xNS4wXCIsIFwiUmVuZGVyYWJsZUdDU3lzdGVtLmFkZE1hbmFnZWRBcnJheSBpcyBkZXByZWNhdGVkLCBwbGVhc2UgdXNlIHRoZSBHQ1N5c3RlbS5hZGRDb2xsZWN0aW9uIGluc3RlYWQuXCIpO1xuICAgIHRoaXMuX3JlbmRlcmVyLmdjLmFkZENvbGxlY3Rpb24oY29udGV4dCwgaGFzaCwgXCJhcnJheVwiKTtcbiAgfVxuICAvKipcbiAgICogU3RhcnRzIHRyYWNraW5nIGEgcmVuZGVyYWJsZSBmb3IgZ2FyYmFnZSBjb2xsZWN0aW9uLlxuICAgKiBAcGFyYW0gX3JlbmRlcmFibGUgLSBUaGUgcmVuZGVyYWJsZSB0byB0cmFja1xuICAgKiBAZGVwcmVjYXRlZCBzaW5jZSA4LjE1LjBcbiAgICovXG4gIGFkZFJlbmRlcmFibGUoX3JlbmRlcmFibGUpIHtcbiAgICBkZXByZWNhdGlvbihcIjguMTUuMFwiLCBcIlJlbmRlcmFibGVHQ1N5c3RlbS5hZGRSZW5kZXJhYmxlIGlzIGRlcHJlY2F0ZWQsIHBsZWFzZSB1c2UgdGhlIEdDU3lzdGVtIGluc3RlYWQuXCIpO1xuICAgIHRoaXMuX3JlbmRlcmVyLmdjLmFkZFJlc291cmNlKF9yZW5kZXJhYmxlLCBcInJlbmRlcmFibGVcIik7XG4gIH1cbiAgLyoqXG4gICAqIFBlcmZvcm1zIGdhcmJhZ2UgY29sbGVjdGlvbiBieSBjbGVhbmluZyB1cCB1bnVzZWQgcmVuZGVyYWJsZXMuXG4gICAqIFJlbW92ZXMgcmVuZGVyYWJsZXMgdGhhdCBoYXZlbid0IGJlZW4gdXNlZCBmb3IgbG9uZ2VyIHRoYW4gbWF4VW51c2VkVGltZS5cbiAgICovXG4gIHJ1bigpIHtcbiAgICBkZXByZWNhdGlvbihcIjguMTUuMFwiLCBcIlJlbmRlcmFibGVHQ1N5c3RlbS5ydW4gaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSB0aGUgR0NTeXN0ZW0gaW5zdGVhZC5cIik7XG4gICAgdGhpcy5fcmVuZGVyZXIuZ2MucnVuKCk7XG4gIH1cbiAgLyoqIENsZWFucyB1cCB0aGUgZ2FyYmFnZSBjb2xsZWN0aW9uIHN5c3RlbS4gRGlzYWJsZXMgR0MgYW5kIHJlbW92ZXMgYWxsIHRyYWNrZWQgcmVzb3VyY2VzLiAqL1xuICBkZXN0cm95KCkge1xuICAgIHRoaXMuX3JlbmRlcmVyID0gbnVsbDtcbiAgfVxufTtcbi8qKlxuICogRXh0ZW5zaW9uIG1ldGFkYXRhIGZvciByZWdpc3RlcmluZyB0aGlzIHN5c3RlbSB3aXRoIHRoZSByZW5kZXJlci5cbiAqIEBpZ25vcmVcbiAqL1xuX1JlbmRlcmFibGVHQ1N5c3RlbS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuV2ViR1BVU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuQ2FudmFzU3lzdGVtXG4gIF0sXG4gIG5hbWU6IFwicmVuZGVyYWJsZUdDXCIsXG4gIHByaW9yaXR5OiAwXG59O1xuLyoqXG4gKiBEZWZhdWx0IGNvbmZpZ3VyYXRpb24gb3B0aW9ucyBmb3IgdGhlIGdhcmJhZ2UgY29sbGVjdGlvbiBzeXN0ZW0uXG4gKiBUaGVzZSBjYW4gYmUgb3ZlcnJpZGRlbiB3aGVuIGluaXRpYWxpemluZyB0aGUgcmVuZGVyZXIuXG4gKiBAZGVwcmVjYXRlZCBzaW5jZSA4LjE1LjBcbiAqL1xuX1JlbmRlcmFibGVHQ1N5c3RlbS5kZWZhdWx0T3B0aW9ucyA9IHtcbiAgLyoqIEVuYWJsZS9kaXNhYmxlIHRoZSBnYXJiYWdlIGNvbGxlY3RvciAqL1xuICByZW5kZXJhYmxlR0NBY3RpdmU6IHRydWUsXG4gIC8qKiBUaW1lIGluIG1zIGJlZm9yZSBhbiB1bnVzZWQgcmVzb3VyY2UgaXMgY29sbGVjdGVkIChkZWZhdWx0IDEgbWludXRlKSAqL1xuICByZW5kZXJhYmxlR0NNYXhVbnVzZWRUaW1lOiA2ZTQsXG4gIC8qKiBIb3cgb2Z0ZW4gdG8gcnVuIGdhcmJhZ2UgY29sbGVjdGlvbiBpbiBtcyAoZGVmYXVsdCAzMCBzZWNvbmRzKSAqL1xuICByZW5kZXJhYmxlR0NGcmVxdWVuY3k6IDNlNFxufTtcbmxldCBSZW5kZXJhYmxlR0NTeXN0ZW0gPSBfUmVuZGVyYWJsZUdDU3lzdGVtO1xuXG5leHBvcnQgeyBSZW5kZXJhYmxlR0NTeXN0ZW0gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVJlbmRlcmFibGVHQ1N5c3RlbS5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBkZXByZWNhdGlvbiB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2xvZ2dpbmcvZGVwcmVjYXRpb24ubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBfVGV4dHVyZUdDU3lzdGVtID0gY2xhc3MgX1RleHR1cmVHQ1N5c3RlbSB7XG4gIC8qKlxuICAgKiBGcmFtZSBjb3VudCBzaW5jZSBzdGFydGVkLlxuICAgKiBAcmVhZG9ubHlcbiAgICogQGRlcHJlY2F0ZWQgc2luY2UgOC4xNS4wXG4gICAqL1xuICBnZXQgY291bnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3JlbmRlcmVyLnRpY2s7XG4gIH1cbiAgLyoqXG4gICAqIEZyYW1lIGNvdW50IHNpbmNlIGxhc3QgZ2FyYmFnZSBjb2xsZWN0aW9uLlxuICAgKiBAcmVhZG9ubHlcbiAgICogQGRlcHJlY2F0ZWQgc2luY2UgOC4xNS4wXG4gICAqL1xuICBnZXQgY2hlY2tDb3VudCgpIHtcbiAgICByZXR1cm4gdGhpcy5fY2hlY2tDb3VudDtcbiAgfVxuICBzZXQgY2hlY2tDb3VudCh2YWx1ZSkge1xuICAgIGRlcHJlY2F0aW9uKFwiOC4xNS4wXCIsIFwiVGV4dHVyZUdDU3lzdGVtLnJ1biBpcyBkZXByZWNhdGVkLCBwbGVhc2UgdXNlIHRoZSBHQ1N5c3RlbSBpbnN0ZWFkLlwiKTtcbiAgICB0aGlzLl9jaGVja0NvdW50ID0gdmFsdWU7XG4gIH1cbiAgLyoqXG4gICAqIE1heGltdW0gaWRsZSBmcmFtZXMgYmVmb3JlIGEgdGV4dHVyZSBpcyBkZXN0cm95ZWQgYnkgZ2FyYmFnZSBjb2xsZWN0aW9uLlxuICAgKiBAc2VlIFRleHR1cmVHQ1N5c3RlbS5kZWZhdWx0TWF4SWRsZVxuICAgKiBAZGVwcmVjYXRlZCBzaW5jZSA4LjE1LjBcbiAgICovXG4gIGdldCBtYXhJZGxlKCkge1xuICAgIHJldHVybiB0aGlzLl9yZW5kZXJlci5nYy5tYXhVbnVzZWRUaW1lIC8gMWUzICogNjA7XG4gIH1cbiAgc2V0IG1heElkbGUodmFsdWUpIHtcbiAgICBkZXByZWNhdGlvbihcIjguMTUuMFwiLCBcIlRleHR1cmVHQ1N5c3RlbS5ydW4gaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSB0aGUgR0NTeXN0ZW0gaW5zdGVhZC5cIik7XG4gICAgdGhpcy5fcmVuZGVyZXIuZ2MubWF4VW51c2VkVGltZSA9IHZhbHVlIC8gNjAgKiAxZTM7XG4gIH1cbiAgLyoqXG4gICAqIEZyYW1lcyBiZXR3ZWVuIHR3byBnYXJiYWdlIGNvbGxlY3Rpb25zLlxuICAgKiBAc2VlIFRleHR1cmVHQ1N5c3RlbS5kZWZhdWx0Q2hlY2tDb3VudE1heFxuICAgKiBAZGVwcmVjYXRlZCBzaW5jZSA4LjE1LjBcbiAgICovXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBkb3Qtbm90YXRpb25cbiAgZ2V0IGNoZWNrQ291bnRNYXgoKSB7XG4gICAgcmV0dXJuIE1hdGguZmxvb3IodGhpcy5fcmVuZGVyZXIuZ2NbXCJfZnJlcXVlbmN5XCJdIC8gMWUzKTtcbiAgfVxuICBzZXQgY2hlY2tDb3VudE1heChfdmFsdWUpIHtcbiAgICBkZXByZWNhdGlvbihcIjguMTUuMFwiLCBcIlRleHR1cmVHQ1N5c3RlbS5ydW4gaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSB0aGUgR0NTeXN0ZW0gaW5zdGVhZC5cIik7XG4gIH1cbiAgLyoqXG4gICAqIEN1cnJlbnQgZ2FyYmFnZSBjb2xsZWN0aW9uIG1vZGUuXG4gICAqIEBzZWUgVGV4dHVyZUdDU3lzdGVtLmRlZmF1bHRNb2RlXG4gICAqIEBkZXByZWNhdGVkIHNpbmNlIDguMTUuMFxuICAgKi9cbiAgZ2V0IGFjdGl2ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVuZGVyZXIuZ2MuZW5hYmxlZDtcbiAgfVxuICBzZXQgYWN0aXZlKHZhbHVlKSB7XG4gICAgZGVwcmVjYXRpb24oXCI4LjE1LjBcIiwgXCJUZXh0dXJlR0NTeXN0ZW0ucnVuIGlzIGRlcHJlY2F0ZWQsIHBsZWFzZSB1c2UgdGhlIEdDU3lzdGVtIGluc3RlYWQuXCIpO1xuICAgIHRoaXMuX3JlbmRlcmVyLmdjLmVuYWJsZWQgPSB2YWx1ZTtcbiAgfVxuICAvKiogQHBhcmFtIHJlbmRlcmVyIC0gVGhlIHJlbmRlcmVyIHRoaXMgU3lzdGVtIHdvcmtzIGZvci4gKi9cbiAgY29uc3RydWN0b3IocmVuZGVyZXIpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IHJlbmRlcmVyO1xuICAgIHRoaXMuX2NoZWNrQ291bnQgPSAwO1xuICB9XG4gIGluaXQob3B0aW9ucykge1xuICAgIGlmIChvcHRpb25zLnRleHR1cmVHQ0FjdGl2ZSAhPT0gX1RleHR1cmVHQ1N5c3RlbS5kZWZhdWx0T3B0aW9ucy50ZXh0dXJlR0NBY3RpdmUpIHtcbiAgICAgIHRoaXMuYWN0aXZlID0gb3B0aW9ucy50ZXh0dXJlR0NBY3RpdmU7XG4gICAgfVxuICAgIGlmIChvcHRpb25zLnRleHR1cmVHQ01heElkbGUgIT09IF9UZXh0dXJlR0NTeXN0ZW0uZGVmYXVsdE9wdGlvbnMudGV4dHVyZUdDTWF4SWRsZSkge1xuICAgICAgdGhpcy5tYXhJZGxlID0gb3B0aW9ucy50ZXh0dXJlR0NNYXhJZGxlO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy50ZXh0dXJlR0NDaGVja0NvdW50TWF4ICE9PSBfVGV4dHVyZUdDU3lzdGVtLmRlZmF1bHRPcHRpb25zLnRleHR1cmVHQ0NoZWNrQ291bnRNYXgpIHtcbiAgICAgIHRoaXMuY2hlY2tDb3VudE1heCA9IG9wdGlvbnMudGV4dHVyZUdDQ2hlY2tDb3VudE1heDtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyB0byBzZWUgd2hlbiB0aGUgbGFzdCB0aW1lIGEgdGV4dHVyZSB3YXMgdXNlZC5cbiAgICogSWYgdGhlIHRleHR1cmUgaGFzIG5vdCBiZWVuIHVzZWQgZm9yIGEgc3BlY2lmaWVkIGFtb3VudCBvZiB0aW1lLCBpdCB3aWxsIGJlIHJlbW92ZWQgZnJvbSB0aGUgR1BVLlxuICAgKiBAZGVwcmVjYXRlZCBzaW5jZSA4LjE1LjBcbiAgICovXG4gIHJ1bigpIHtcbiAgICBkZXByZWNhdGlvbihcIjguMTUuMFwiLCBcIlRleHR1cmVHQ1N5c3RlbS5ydW4gaXMgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSB0aGUgR0NTeXN0ZW0gaW5zdGVhZC5cIik7XG4gICAgdGhpcy5fcmVuZGVyZXIuZ2MucnVuKCk7XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IG51bGw7XG4gIH1cbn07XG4vKiogQGlnbm9yZSAqL1xuX1RleHR1cmVHQ1N5c3RlbS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuV2ViR1BVU3lzdGVtXG4gIF0sXG4gIG5hbWU6IFwidGV4dHVyZUdDXCJcbn07XG4vKipcbiAqIERlZmF1bHQgb3B0aW9ucyBmb3IgdGhlIFRleHR1cmVHQ1N5c3RlbVxuICogQGRlcHJlY2F0ZWQgc2luY2UgOC4xNS4wXG4gKi9cbl9UZXh0dXJlR0NTeXN0ZW0uZGVmYXVsdE9wdGlvbnMgPSB7XG4gIC8qKlxuICAgKiBJZiBzZXQgdG8gdHJ1ZSwgdGhpcyB3aWxsIGVuYWJsZSB0aGUgZ2FyYmFnZSBjb2xsZWN0b3Igb24gdGhlIEdQVS5cbiAgICogQGRlZmF1bHQgdHJ1ZVxuICAgKi9cbiAgdGV4dHVyZUdDQWN0aXZlOiB0cnVlLFxuICAvKipcbiAgICogQGRlcHJlY2F0ZWQgc2luY2UgOC4zLjBcbiAgICogQHNlZSB7QGxpbmsgVGV4dHVyZUdDU3lzdGVtT3B0aW9ucy50ZXh0dXJlR0NNYXhJZGxlfVxuICAgKi9cbiAgdGV4dHVyZUdDQU1heElkbGU6IG51bGwsXG4gIC8qKlxuICAgKiBUaGUgbWF4aW11bSBpZGxlIGZyYW1lcyBiZWZvcmUgYSB0ZXh0dXJlIGlzIGRlc3Ryb3llZCBieSBnYXJiYWdlIGNvbGxlY3Rpb24uXG4gICAqIEBkZWZhdWx0IDYwICogNjBcbiAgICovXG4gIHRleHR1cmVHQ01heElkbGU6IDYwICogNjAsXG4gIC8qKlxuICAgKiBGcmFtZXMgYmV0d2VlbiB0d28gZ2FyYmFnZSBjb2xsZWN0aW9ucy5cbiAgICogQGRlZmF1bHQgNjAwXG4gICAqL1xuICB0ZXh0dXJlR0NDaGVja0NvdW50TWF4OiA2MDBcbn07XG5sZXQgVGV4dHVyZUdDU3lzdGVtID0gX1RleHR1cmVHQ1N5c3RlbTtcblxuZXhwb3J0IHsgVGV4dHVyZUdDU3lzdGVtIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1UZXh0dXJlR0NTeXN0ZW0ubWpzLm1hcFxuIiwiaW1wb3J0IEV2ZW50RW1pdHRlciBmcm9tICdldmVudGVtaXR0ZXIzJztcbmltcG9ydCB7IHVpZCB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2RhdGEvdWlkLm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlU291cmNlIH0gZnJvbSAnLi4vdGV4dHVyZS9zb3VyY2VzL1RleHR1cmVTb3VyY2UubWpzJztcbmltcG9ydCB7IFRleHR1cmUgfSBmcm9tICcuLi90ZXh0dXJlL1RleHR1cmUubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBfUmVuZGVyVGFyZ2V0ID0gY2xhc3MgX1JlbmRlclRhcmdldCBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIC8qKlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIE9wdGlvbnMgZm9yIGNyZWF0aW5nIGEgcmVuZGVyIHRhcmdldCwgb3IgYSBXZWJHUFUtZmxhdm9yZWQgZGVzY3JpcHRvci5cbiAgICovXG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMgPSB7fSkge1xuICAgIHN1cGVyKCk7XG4gICAgLyoqIHVuaXF1ZSBpZCBmb3IgdGhpcyByZW5kZXIgdGFyZ2V0ICovXG4gICAgdGhpcy51aWQgPSB1aWQoXCJyZW5kZXJUYXJnZXRcIik7XG4gICAgLyoqXG4gICAgICogQW4gYXJyYXkgb2YgYXR0YWNobWVudHMgdGhhdCBkZWZpbmUgZXhhY3RseSBob3cgdGhlIEdQVSBzaG91bGQgcmVuZGVyIHRvIHRoZSBjb2xvciB0ZXh0dXJlcy5cbiAgICAgKiBUaGlzIGluY2x1ZGVzIHRoZSB0ZXh0dXJlIGl0c2VsZiwgYXMgd2VsbCBhcyBsb2FkL3N0b3JlIG9wZXJhdGlvbnMgYW5kIGNsZWFyIHZhbHVlcy5cbiAgICAgKi9cbiAgICB0aGlzLmNvbG9yQXR0YWNobWVudHMgPSBbXTtcbiAgICB0aGlzLmRpcnR5SWQgPSAwO1xuICAgIHRoaXMuaXNSb290ID0gZmFsc2U7XG4gICAgdGhpcy5fc2l6ZSA9IG5ldyBGbG9hdDMyQXJyYXkoMik7XG4gICAgLyoqIGlmIHRydWUsIHRoZW4gd2hlbiB0aGUgcmVuZGVyIHRhcmdldCBpcyBkZXN0cm95ZWQsIGl0IHdpbGwgZGVzdHJveSBhbGwgdGhlIHRleHR1cmVzIHRoYXQgd2VyZSBjcmVhdGVkIGZvciBpdC4gKi9cbiAgICB0aGlzLl9tYW5hZ2VkQ29sb3JUZXh0dXJlcyA9IGZhbHNlO1xuICAgIC8qKiBkZXB0aCBjYXBhYmlsaXR5IHJlcXVlc3RlZCBmb3IgdGhpcyB0YXJnZXQg4oCUIHZpYSBvcHRpb25zLCBhdHRhY2htZW50IGZvcm1hdCwgb3IgdGhlIG1hc2sgc3lzdGVtIEBpbnRlcm5hbCAqL1xuICAgIHRoaXMuX2RlcHRoID0gZmFsc2U7XG4gICAgLyoqIHN0ZW5jaWwgY2FwYWJpbGl0eSByZXF1ZXN0ZWQgZm9yIHRoaXMgdGFyZ2V0IOKAlCB2aWEgb3B0aW9ucywgYXR0YWNobWVudCBmb3JtYXQsIG9yIHRoZSBtYXNrIHN5c3RlbSBAaW50ZXJuYWwgKi9cbiAgICB0aGlzLl9zdGVuY2lsID0gZmFsc2U7XG4gICAgdGhpcy5fY29sb3JUZXh0dXJlcyA9IG51bGw7XG4gICAgY29uc3QgZGVzY3JpcHRvciA9IFwiY29sb3JBdHRhY2htZW50c1wiIGluIG9wdGlvbnMgPyBvcHRpb25zIDogdGhpcy5fbm9ybWFsaXplT3B0aW9ucyhvcHRpb25zKTtcbiAgICB0aGlzLmlzUm9vdCA9IGRlc2NyaXB0b3IuaXNSb290ID8/IGZhbHNlO1xuICAgIHRoaXMubGFiZWwgPSBkZXNjcmlwdG9yLmxhYmVsO1xuICAgIHRoaXMuY29sb3JBdHRhY2htZW50cyA9IGRlc2NyaXB0b3IuY29sb3JBdHRhY2htZW50cztcbiAgICB0aGlzLmRlcHRoU3RlbmNpbEF0dGFjaG1lbnQgPSBkZXNjcmlwdG9yLmRlcHRoU3RlbmNpbEF0dGFjaG1lbnQ7XG4gICAgaWYgKHRoaXMuZGVwdGhTdGVuY2lsQXR0YWNobWVudCkge1xuICAgICAgY29uc3QgZm9ybWF0ID0gdGhpcy5kZXB0aFN0ZW5jaWxBdHRhY2htZW50LnRleHR1cmUuZm9ybWF0O1xuICAgICAgdGhpcy5fZGVwdGggfHwgKHRoaXMuX2RlcHRoID0gZm9ybWF0LmluY2x1ZGVzKFwiZGVwdGhcIikpO1xuICAgICAgdGhpcy5fc3RlbmNpbCB8fCAodGhpcy5fc3RlbmNpbCA9IGZvcm1hdC5pbmNsdWRlcyhcInN0ZW5jaWxcIikpO1xuICAgIH1cbiAgICBpZiAodGhpcy5jb2xvckF0dGFjaG1lbnRzLmxlbmd0aCA9PT0gMCAmJiAhdGhpcy5kZXB0aFN0ZW5jaWxBdHRhY2htZW50KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJbUmVuZGVyVGFyZ2V0XSBubyBjb2xvciB0ZXh0dXJlcyBvciBkZXB0aCB0ZXh0dXJlcyB3ZXJlIHByb3ZpZGVkLiBQcm92aWRlIGEgZGVwdGhTdGVuY2lsVGV4dHVyZSBvciBzZXQgZGVwdGgvc3RlbmNpbCB0byB0cnVlIHdoZW4gdXNpbmcgY29sb3JUZXh0dXJlczogMC5cIik7XG4gICAgfVxuICAgIGlmICh0aGlzLmNvbG9yQXR0YWNobWVudHMubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgY29sb3JTb3VyY2UgPSB0aGlzLmNvbG9yVGV4dHVyZTtcbiAgICAgIHRoaXMucmVzaXplKGNvbG9yU291cmNlLndpZHRoLCBjb2xvclNvdXJjZS5oZWlnaHQsIGNvbG9yU291cmNlLl9yZXNvbHV0aW9uKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuc2l6ZVNvdXJjZSkge1xuICAgICAgdGhpcy5zaXplU291cmNlLm9uKFwicmVzaXplXCIsIHRoaXMub25Tb3VyY2VSZXNpemUsIHRoaXMpO1xuICAgIH1cbiAgfVxuICBfbm9ybWFsaXplT3B0aW9ucyhvcHRpb25zKSB7XG4gICAgY29uc3Qgb3B0cyA9IHsgLi4uX1JlbmRlclRhcmdldC5kZWZhdWx0T3B0aW9ucywgLi4ub3B0aW9ucyB9O1xuICAgIGNvbnN0IGNvbG9yQXR0YWNobWVudHMgPSBbXTtcbiAgICBsZXQgZGVwdGhTdGVuY2lsQXR0YWNobWVudDtcbiAgICBpZiAodHlwZW9mIG9wdHMuY29sb3JUZXh0dXJlcyA9PT0gXCJudW1iZXJcIikge1xuICAgICAgaWYgKG9wdHMuY29sb3JUZXh0dXJlcyA+IDApIHtcbiAgICAgICAgdGhpcy5fbWFuYWdlZENvbG9yVGV4dHVyZXMgPSB0cnVlO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG9wdHMuY29sb3JUZXh0dXJlczsgaSsrKSB7XG4gICAgICAgICAgY29sb3JBdHRhY2htZW50cy5wdXNoKHtcbiAgICAgICAgICAgIHRleHR1cmU6IG5ldyBUZXh0dXJlU291cmNlKHtcbiAgICAgICAgICAgICAgd2lkdGg6IG9wdHMud2lkdGgsXG4gICAgICAgICAgICAgIGhlaWdodDogb3B0cy5oZWlnaHQsXG4gICAgICAgICAgICAgIHJlc29sdXRpb246IG9wdHMucmVzb2x1dGlvbixcbiAgICAgICAgICAgICAgYW50aWFsaWFzOiBvcHRzLmFudGlhbGlhc1xuICAgICAgICAgICAgfSksXG4gICAgICAgICAgICBsb2FkT3A6IFwiY2xlYXJcIixcbiAgICAgICAgICAgIHN0b3JlT3A6IFwic3RvcmVcIlxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIG9wdHMuY29sb3JUZXh0dXJlcy5mb3JFYWNoKCh0ZXh0dXJlKSA9PiB7XG4gICAgICAgIGNvbG9yQXR0YWNobWVudHMucHVzaCh7XG4gICAgICAgICAgdGV4dHVyZTogdGV4dHVyZS5zb3VyY2UsXG4gICAgICAgICAgbG9hZE9wOiBcImNsZWFyXCIsXG4gICAgICAgICAgc3RvcmVPcDogXCJzdG9yZVwiXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IHdhbnRzRGVwdGhTdGVuY2lsVGV4dHVyZSA9IG9wdHMuZGVwdGhTdGVuY2lsVGV4dHVyZSA9PT0gdHJ1ZTtcbiAgICB0aGlzLl9kZXB0aCA9ICEhKG9wdHMuZGVwdGggfHwgd2FudHNEZXB0aFN0ZW5jaWxUZXh0dXJlKTtcbiAgICB0aGlzLl9zdGVuY2lsID0gISEob3B0cy5zdGVuY2lsIHx8IHdhbnRzRGVwdGhTdGVuY2lsVGV4dHVyZSk7XG4gICAgaWYgKG9wdHMuZGVwdGhTdGVuY2lsVGV4dHVyZSBpbnN0YW5jZW9mIFRleHR1cmUgfHwgb3B0cy5kZXB0aFN0ZW5jaWxUZXh0dXJlIGluc3RhbmNlb2YgVGV4dHVyZVNvdXJjZSkge1xuICAgICAgaWYgKG9wdHMuaXNSb290KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIltSZW5kZXJUYXJnZXRdIGNhbm5vdCBhdHRhY2ggYSBkZXB0aC1zdGVuY2lsIHRleHR1cmUgdG8gdGhlIHNjcmVlbiBcXHUyMDE0IHRoZSBjYW52YXMgb3ducyBpdHMgb3duIGRlcHRoL3N0ZW5jaWwgYnVmZmVycy4gUmVuZGVyIHRvIGEgdGV4dHVyZSB0YXJnZXQgaW5zdGVhZC5cIik7XG4gICAgICB9XG4gICAgICBkZXB0aFN0ZW5jaWxBdHRhY2htZW50ID0ge1xuICAgICAgICB0ZXh0dXJlOiBvcHRzLmRlcHRoU3RlbmNpbFRleHR1cmUuc291cmNlXG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAod2FudHNEZXB0aFN0ZW5jaWxUZXh0dXJlICYmICFvcHRzLmlzUm9vdCB8fCAob3B0cy5zdGVuY2lsIHx8IG9wdHMuZGVwdGgpICYmIGNvbG9yQXR0YWNobWVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBkZXB0aFN0ZW5jaWxBdHRhY2htZW50ID0gdGhpcy5fY3JlYXRlRGVwdGhTdGVuY2lsVGV4dHVyZShvcHRzLndpZHRoLCBvcHRzLmhlaWdodCwgb3B0cy5yZXNvbHV0aW9uKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvbG9yQXR0YWNobWVudHMsXG4gICAgICBkZXB0aFN0ZW5jaWxBdHRhY2htZW50LFxuICAgICAgaXNSb290OiBvcHRzLmlzUm9vdCxcbiAgICAgIGxhYmVsOiBvcHRzLmxhYmVsXG4gICAgfTtcbiAgfVxuICBnZXQgc2l6ZSgpIHtcbiAgICBjb25zdCBfc2l6ZSA9IHRoaXMuX3NpemU7XG4gICAgX3NpemVbMF0gPSB0aGlzLnBpeGVsV2lkdGg7XG4gICAgX3NpemVbMV0gPSB0aGlzLnBpeGVsSGVpZ2h0O1xuICAgIHJldHVybiBfc2l6ZTtcbiAgfVxuICBnZXQgd2lkdGgoKSB7XG4gICAgcmV0dXJuIHRoaXMuc2l6ZVNvdXJjZS53aWR0aDtcbiAgfVxuICBnZXQgaGVpZ2h0KCkge1xuICAgIHJldHVybiB0aGlzLnNpemVTb3VyY2UuaGVpZ2h0O1xuICB9XG4gIGdldCBwaXhlbFdpZHRoKCkge1xuICAgIHJldHVybiB0aGlzLnNpemVTb3VyY2UucGl4ZWxXaWR0aDtcbiAgfVxuICBnZXQgcGl4ZWxIZWlnaHQoKSB7XG4gICAgcmV0dXJuIHRoaXMuc2l6ZVNvdXJjZS5waXhlbEhlaWdodDtcbiAgfVxuICBnZXQgcmVzb2x1dGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy5zaXplU291cmNlLl9yZXNvbHV0aW9uO1xuICB9XG4gIC8qKlxuICAgKiBBbiBhcnJheSBvZiB0ZXh0dXJlcyB0aGF0IGNhbiBiZSB3cml0dGVuIHRvIGJ5IHRoZSBHUFUgLSBtb3N0bHkgdGhpcyBoYXMgb25lIHRleHR1cmUgaW4gUGl4aSwgYnV0IHlvdSBjb3VsZFxuICAgKiB3cml0ZSB0byBtdWx0aXBsZSBpZiByZXF1aXJlZCEgKGVnIGRlZmVycmVkIGxpZ2h0aW5nKS5cbiAgICogVGhpcyBpcyBhIGJhY2t3YXJkcy1jb21wYXRpYmxlIGdldHRlciB0aGF0IGV4dHJhY3RzIHRoZSB0ZXh0dXJlcyBmcm9tIGBjb2xvckF0dGFjaG1lbnRzYC5cbiAgICovXG4gIGdldCBjb2xvclRleHR1cmVzKCkge1xuICAgIHRoaXMuX2NvbG9yVGV4dHVyZXMgfHwgKHRoaXMuX2NvbG9yVGV4dHVyZXMgPSB0aGlzLmNvbG9yQXR0YWNobWVudHMubWFwKChhKSA9PiBhLnRleHR1cmUpKTtcbiAgICByZXR1cm4gdGhpcy5fY29sb3JUZXh0dXJlcztcbiAgfVxuICAvKiogVGhlIHN0ZW5jaWwgYW5kIGRlcHRoIGJ1ZmZlciB3aWxsIHdyaXRlIHRvIHRoaXMgdGV4dHVyZSBpbiBXZWJHUFUuICovXG4gIGdldCBkZXB0aFN0ZW5jaWxUZXh0dXJlKCkge1xuICAgIHJldHVybiB0aGlzLmRlcHRoU3RlbmNpbEF0dGFjaG1lbnQ/LnRleHR1cmUgPz8gbnVsbDtcbiAgfVxuICAvKiogV2hldGhlciB0aGlzIHRhcmdldCBwcm92aWRlcyBhIGRlcHRoIGJ1ZmZlciDigJQgcmVxdWVzdGVkIHZpYSBvcHRpb25zIG9yIGltcGxpZWQgYnkgaXRzIGF0dGFjaG1lbnQncyBmb3JtYXQuICovXG4gIGdldCBkZXB0aCgpIHtcbiAgICByZXR1cm4gdGhpcy5fZGVwdGg7XG4gIH1cbiAgLyoqIFdoZXRoZXIgdGhpcyB0YXJnZXQgcHJvdmlkZXMgYSBzdGVuY2lsIGJ1ZmZlciDigJQgcmVxdWVzdGVkIHZpYSBvcHRpb25zIG9yIGltcGxpZWQgYnkgaXRzIGF0dGFjaG1lbnQncyBmb3JtYXQuICovXG4gIGdldCBzdGVuY2lsKCkge1xuICAgIHJldHVybiB0aGlzLl9zdGVuY2lsO1xuICB9XG4gIGdldCBjb2xvclRleHR1cmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29sb3JBdHRhY2htZW50c1swXT8udGV4dHVyZTtcbiAgfVxuICAvKipcbiAgICogVGhlIHRleHR1cmUgdGhhdCBkcml2ZXMgc2l6ZSwgcmVzb2x1dGlvbiwgYW5kIHJlc2l6ZSBldmVudHMuXG4gICAqIEZvciBzdGFuZGFyZCB0YXJnZXRzIHRoaXMgaXMgYGNvbG9yQXR0YWNobWVudHNbMF0udGV4dHVyZWA7XG4gICAqIGZvciBkZXB0aC1vbmx5IHRhcmdldHMgaXQgaXMgYGRlcHRoU3RlbmNpbEF0dGFjaG1lbnQudGV4dHVyZWAuXG4gICAqL1xuICBnZXQgc2l6ZVNvdXJjZSgpIHtcbiAgICByZXR1cm4gdGhpcy5jb2xvckF0dGFjaG1lbnRzWzBdPy50ZXh0dXJlID8/IHRoaXMuZGVwdGhTdGVuY2lsQXR0YWNobWVudD8udGV4dHVyZTtcbiAgfVxuICBvblNvdXJjZVJlc2l6ZShzb3VyY2UpIHtcbiAgICB0aGlzLnJlc2l6ZShzb3VyY2Uud2lkdGgsIHNvdXJjZS5oZWlnaHQsIHNvdXJjZS5fcmVzb2x1dGlvbiwgdHJ1ZSk7XG4gIH1cbiAgLyoqXG4gICAqIFRoaXMgd2lsbCBlbnN1cmUgYSBkZXB0aFN0ZW5jaWwgdGV4dHVyZSBpcyBjcmVhdGVkIGZvciB0aGlzIHJlbmRlciB0YXJnZXQuXG4gICAqIE1vc3QgbGlrZWx5IGNhbGxlZCBieSB0aGUgbWFzayBzeXN0ZW0gdG8gbWFrZSBzdXJlIHdlIGhhdmUgc3RlbmNpbCBidWZmZXIgYWRkZWQuXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgZW5zdXJlRGVwdGhTdGVuY2lsVGV4dHVyZSgpIHtcbiAgICB0aGlzLl9jcmVhdGVEZXB0aFN0ZW5jaWxUZXh0dXJlKHRoaXMuc2l6ZVNvdXJjZS53aWR0aCwgdGhpcy5zaXplU291cmNlLmhlaWdodCwgdGhpcy5zaXplU291cmNlLl9yZXNvbHV0aW9uKTtcbiAgICB0aGlzLl9kZXB0aCA9IHRydWU7XG4gICAgdGhpcy5fc3RlbmNpbCA9IHRydWU7XG4gIH1cbiAgcmVzaXplKHdpZHRoLCBoZWlnaHQsIHJlc29sdXRpb24gPSB0aGlzLnJlc29sdXRpb24sIHNraXBDb2xvclRleHR1cmUgPSBmYWxzZSkge1xuICAgIHRoaXMuZGlydHlJZCsrO1xuICAgIHRoaXMuY29sb3JBdHRhY2htZW50cy5mb3JFYWNoKChjb2xvckF0dGFjaG1lbnQsIGkpID0+IHtcbiAgICAgIGlmIChza2lwQ29sb3JUZXh0dXJlICYmIGkgPT09IDApIHJldHVybjtcbiAgICAgIGNvbG9yQXR0YWNobWVudC50ZXh0dXJlLnJlc2l6ZSh3aWR0aCwgaGVpZ2h0LCByZXNvbHV0aW9uKTtcbiAgICB9KTtcbiAgICBpZiAodGhpcy5kZXB0aFN0ZW5jaWxBdHRhY2htZW50KSB7XG4gICAgICBpZiAoc2tpcENvbG9yVGV4dHVyZSAmJiB0aGlzLmNvbG9yQXR0YWNobWVudHMubGVuZ3RoID09PSAwKSByZXR1cm47XG4gICAgICB0aGlzLmRlcHRoU3RlbmNpbEF0dGFjaG1lbnQudGV4dHVyZS5yZXNpemUod2lkdGgsIGhlaWdodCwgcmVzb2x1dGlvbik7XG4gICAgfVxuICB9XG4gIGRlc3Ryb3koKSB7XG4gICAgaWYgKCF0aGlzLmNvbG9yQXR0YWNobWVudHMgJiYgIXRoaXMuZGVwdGhTdGVuY2lsQXR0YWNobWVudCkgcmV0dXJuO1xuICAgIHRoaXMuZW1pdChcImRlc3Ryb3lcIiwgdGhpcyk7XG4gICAgdGhpcy5zaXplU291cmNlLm9mZihcInJlc2l6ZVwiLCB0aGlzLm9uU291cmNlUmVzaXplLCB0aGlzKTtcbiAgICBpZiAodGhpcy5fbWFuYWdlZENvbG9yVGV4dHVyZXMpIHtcbiAgICAgIHRoaXMuY29sb3JBdHRhY2htZW50cy5mb3JFYWNoKChhdHRhY2htZW50KSA9PiB7XG4gICAgICAgIGF0dGFjaG1lbnQudGV4dHVyZS5kZXN0cm95KCk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHRoaXMuZGVwdGhTdGVuY2lsQXR0YWNobWVudCkge1xuICAgICAgdGhpcy5kZXB0aFN0ZW5jaWxBdHRhY2htZW50LnRleHR1cmUuZGVzdHJveSgpO1xuICAgICAgZGVsZXRlIHRoaXMuZGVwdGhTdGVuY2lsQXR0YWNobWVudDtcbiAgICB9XG4gICAgdGhpcy5jb2xvckF0dGFjaG1lbnRzID0gbnVsbDtcbiAgICB0aGlzLl9jb2xvclRleHR1cmVzID0gbnVsbDtcbiAgICB0aGlzLnJlbW92ZUFsbExpc3RlbmVycygpO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgc2luZ2xlIHJlY2lwZSBmb3IgaW50ZXJuYWxseS1jcmVhdGVkIGRlcHRoLXN0ZW5jaWwgdGV4dHVyZXMuXG4gICAqIEBwYXJhbSB3aWR0aFxuICAgKiBAcGFyYW0gaGVpZ2h0XG4gICAqIEBwYXJhbSByZXNvbHV0aW9uXG4gICAqL1xuICBfY3JlYXRlRGVwdGhTdGVuY2lsVGV4dHVyZSh3aWR0aCwgaGVpZ2h0LCByZXNvbHV0aW9uKSB7XG4gICAgdGhpcy5kZXB0aFN0ZW5jaWxBdHRhY2htZW50ID8/ICh0aGlzLmRlcHRoU3RlbmNpbEF0dGFjaG1lbnQgPSB7XG4gICAgICB0ZXh0dXJlOiBuZXcgVGV4dHVyZVNvdXJjZSh7XG4gICAgICAgIHdpZHRoLFxuICAgICAgICBoZWlnaHQsXG4gICAgICAgIHJlc29sdXRpb24sXG4gICAgICAgIGZvcm1hdDogXCJkZXB0aDI0cGx1cy1zdGVuY2lsOFwiLFxuICAgICAgICBhdXRvR2VuZXJhdGVNaXBtYXBzOiBmYWxzZSxcbiAgICAgICAgYW50aWFsaWFzOiBmYWxzZSxcbiAgICAgICAgbWlwTGV2ZWxDb3VudDogMVxuICAgICAgICAvLyBzYW1wbGVDb3VudDogaGFuZGxlZCBieSB0aGUgcmVuZGVyIHRhcmdldCBzeXN0ZW0uLlxuICAgICAgfSlcbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcy5kZXB0aFN0ZW5jaWxBdHRhY2htZW50O1xuICB9XG59O1xuLyoqXG4gKiBlbWl0cyB3aGVuIHRoZSByZW5kZXIgdGFyZ2V0IGlzIGRlc3Ryb3llZCwgYmVmb3JlIGl0cyBhdHRhY2htZW50cyBhcmUgcmVsZWFzZWQuXG4gKiBsZXR0aW5nIHRoZSByZW5kZXJlciBrbm93IHRoYXQgaXQgbmVlZHMgdG8gZnJlZSB0aGUgZnJhbWVidWZmZXJzIGFuZCBNU0FBIGJ1ZmZlcnMgaXQgYnVpbHQgZm9yIGl0XG4gKiBAZXZlbnQgZGVzdHJveVxuICovXG4vKiogVGhlIGRlZmF1bHQgb3B0aW9ucyBmb3IgYSByZW5kZXIgdGFyZ2V0ICovXG5fUmVuZGVyVGFyZ2V0LmRlZmF1bHRPcHRpb25zID0ge1xuICAvKiogdGhlIHdpZHRoIG9mIHRoZSBSZW5kZXJUYXJnZXQgKi9cbiAgd2lkdGg6IDAsXG4gIC8qKiB0aGUgaGVpZ2h0IG9mIHRoZSBSZW5kZXJUYXJnZXQgKi9cbiAgaGVpZ2h0OiAwLFxuICAvKiogdGhlIHJlc29sdXRpb24gb2YgdGhlIFJlbmRlclRhcmdldCAqL1xuICByZXNvbHV0aW9uOiAxLFxuICAvKiogYW4gYXJyYXkgb2YgdGV4dHVyZXMsIG9yIGEgbnVtYmVyIGluZGljYXRpbmcgaG93IG1hbnkgY29sb3IgdGV4dHVyZXMgdGhlcmUgc2hvdWxkIGJlICovXG4gIGNvbG9yVGV4dHVyZXM6IDEsXG4gIC8qKiBzaG91bGQgdGhpcyByZW5kZXIgdGFyZ2V0IGhhdmUgYSBzdGVuY2lsIGJ1ZmZlcj8gKi9cbiAgc3RlbmNpbDogZmFsc2UsXG4gIC8qKiBzaG91bGQgdGhpcyByZW5kZXIgdGFyZ2V0IGhhdmUgYSBkZXB0aCBidWZmZXI/ICovXG4gIGRlcHRoOiBmYWxzZSxcbiAgLyoqIHNob3VsZCB0aGlzIHJlbmRlciB0YXJnZXQgYmUgYW50aWFsaWFzZWQ/ICovXG4gIGFudGlhbGlhczogZmFsc2UsXG4gIC8vIHNhdmUgb24gcGVyZiBieSBkZWZhdWx0IVxuICAvKiogaXMgdGhpcyBhIHJvb3QgZWxlbWVudCwgdHJ1ZSBpZiB0aGlzIGlzIGdsIGNvbnRleHQgb3duZXJzIHJlbmRlciB0YXJnZXQgKi9cbiAgaXNSb290OiBmYWxzZVxufTtcbmxldCBSZW5kZXJUYXJnZXQgPSBfUmVuZGVyVGFyZ2V0O1xuXG5leHBvcnQgeyBSZW5kZXJUYXJnZXQgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVJlbmRlclRhcmdldC5tanMubWFwXG4iLCJpbXBvcnQgeyBHbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5IH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vdXRpbHMvcG9vbC9HbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5Lm1qcyc7XG5pbXBvcnQgeyBDYW52YXNTb3VyY2UgfSBmcm9tICcuLi9zb3VyY2VzL0NhbnZhc1NvdXJjZS5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4uL1RleHR1cmUubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBjYW52YXNDYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5HbG9iYWxSZXNvdXJjZVJlZ2lzdHJ5LnJlZ2lzdGVyKGNhbnZhc0NhY2hlKTtcbmZ1bmN0aW9uIGdldENhbnZhc1RleHR1cmUoY2FudmFzLCBvcHRpb25zKSB7XG4gIGlmICghY2FudmFzQ2FjaGUuaGFzKGNhbnZhcykpIHtcbiAgICBjb25zdCB0ZXh0dXJlID0gbmV3IFRleHR1cmUoe1xuICAgICAgc291cmNlOiBuZXcgQ2FudmFzU291cmNlKHtcbiAgICAgICAgcmVzb3VyY2U6IGNhbnZhcyxcbiAgICAgICAgLi4ub3B0aW9uc1xuICAgICAgfSlcbiAgICB9KTtcbiAgICBjb25zdCBvbkRlc3Ryb3kgPSAoKSA9PiB7XG4gICAgICBpZiAoY2FudmFzQ2FjaGUuZ2V0KGNhbnZhcykgPT09IHRleHR1cmUpIHtcbiAgICAgICAgY2FudmFzQ2FjaGUuZGVsZXRlKGNhbnZhcyk7XG4gICAgICB9XG4gICAgfTtcbiAgICB0ZXh0dXJlLm9uY2UoXCJkZXN0cm95XCIsIG9uRGVzdHJveSk7XG4gICAgdGV4dHVyZS5zb3VyY2Uub25jZShcImRlc3Ryb3lcIiwgb25EZXN0cm95KTtcbiAgICBjYW52YXNDYWNoZS5zZXQoY2FudmFzLCB0ZXh0dXJlKTtcbiAgfVxuICByZXR1cm4gY2FudmFzQ2FjaGUuZ2V0KGNhbnZhcyk7XG59XG5mdW5jdGlvbiBoYXNDYWNoZWRDYW52YXNUZXh0dXJlKGNhbnZhcykge1xuICByZXR1cm4gY2FudmFzQ2FjaGUuaGFzKGNhbnZhcyk7XG59XG5cbmV4cG9ydCB7IGdldENhbnZhc1RleHR1cmUsIGhhc0NhY2hlZENhbnZhc1RleHR1cmUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWdldENhbnZhc1RleHR1cmUubWpzLm1hcFxuIiwiaW1wb3J0IHsgRE9NQWRhcHRlciB9IGZyb20gJy4uLy4uLy4uLy4uL2Vudmlyb25tZW50L2FkYXB0ZXIubWpzJztcbmltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi8uLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IFJlY3RhbmdsZSB9IGZyb20gJy4uLy4uLy4uLy4uL21hdGhzL3NoYXBlcy9SZWN0YW5nbGUubWpzJztcbmltcG9ydCB7IGRlcHJlY2F0aW9uLCB2OF8wXzAgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9sb2dnaW5nL2RlcHJlY2F0aW9uLm1qcyc7XG5pbXBvcnQgeyBSZW5kZXJUYXJnZXQgfSBmcm9tICcuLi9yZW5kZXJUYXJnZXQvUmVuZGVyVGFyZ2V0Lm1qcyc7XG5pbXBvcnQgeyBDYW52YXNQb29sIH0gZnJvbSAnLi4vdGV4dHVyZS9DYW52YXNQb29sLm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlUG9vbCB9IGZyb20gJy4uL3RleHR1cmUvVGV4dHVyZVBvb2wubWpzJztcbmltcG9ydCB7IGdldENhbnZhc1RleHR1cmUgfSBmcm9tICcuLi90ZXh0dXJlL3V0aWxzL2dldENhbnZhc1RleHR1cmUubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBfVmlld1N5c3RlbSA9IGNsYXNzIF9WaWV3U3lzdGVtIHtcbiAgLyoqXG4gICAqIFdoZXRoZXIgQ1NTIGRpbWVuc2lvbnMgb2YgY2FudmFzIHZpZXcgc2hvdWxkIGJlIHJlc2l6ZWQgdG8gc2NyZWVuIGRpbWVuc2lvbnMgYXV0b21hdGljYWxseS5cbiAgICogVGhpcyBpcyBvbmx5IHN1cHBvcnRlZCBmb3IgSFRNTENhbnZhc0VsZW1lbnQgYW5kIHdpbGwgYmUgaWdub3JlZCBpZiB0aGUgY2FudmFzIGlzIGFuIE9mZnNjcmVlbkNhbnZhcy5cbiAgICogQHR5cGUge2Jvb2xlYW59XG4gICAqL1xuICBnZXQgYXV0b0RlbnNpdHkoKSB7XG4gICAgcmV0dXJuIHRoaXMudGV4dHVyZS5zb3VyY2UuYXV0b0RlbnNpdHk7XG4gIH1cbiAgc2V0IGF1dG9EZW5zaXR5KHZhbHVlKSB7XG4gICAgdGhpcy50ZXh0dXJlLnNvdXJjZS5hdXRvRGVuc2l0eSA9IHZhbHVlO1xuICB9XG4gIC8qKiBUaGUgcmVzb2x1dGlvbiAvIGRldmljZSBwaXhlbCByYXRpbyBvZiB0aGUgcmVuZGVyZXIuICovXG4gIGdldCByZXNvbHV0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLnRleHR1cmUuc291cmNlLl9yZXNvbHV0aW9uO1xuICB9XG4gIHNldCByZXNvbHV0aW9uKHZhbHVlKSB7XG4gICAgdGhpcy50ZXh0dXJlLnNvdXJjZS5yZXNpemUoXG4gICAgICB0aGlzLnRleHR1cmUuc291cmNlLndpZHRoLFxuICAgICAgdGhpcy50ZXh0dXJlLnNvdXJjZS5oZWlnaHQsXG4gICAgICB2YWx1ZVxuICAgICk7XG4gIH1cbiAgY29uc3RydWN0b3IocmVuZGVyZXIpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IHJlbmRlcmVyO1xuICB9XG4gIC8qKlxuICAgKiBpbml0aWF0ZXMgdGhlIHZpZXcgc3lzdGVtXG4gICAqIEBwYXJhbSBvcHRpb25zIC0gdGhlIG9wdGlvbnMgZm9yIHRoZSB2aWV3XG4gICAqL1xuICBpbml0KG9wdGlvbnMpIHtcbiAgICBvcHRpb25zID0ge1xuICAgICAgLi4uX1ZpZXdTeXN0ZW0uZGVmYXVsdE9wdGlvbnMsXG4gICAgICAuLi5vcHRpb25zXG4gICAgfTtcbiAgICBpZiAob3B0aW9ucy52aWV3KSB7XG4gICAgICBkZXByZWNhdGlvbih2OF8wXzAsIFwiVmlld1N5c3RlbS52aWV3IGhhcyBiZWVuIHJlbmFtZWQgdG8gVmlld1N5c3RlbS5jYW52YXNcIik7XG4gICAgICBvcHRpb25zLmNhbnZhcyA9IG9wdGlvbnMudmlldztcbiAgICB9XG4gICAgdGhpcy5zY3JlZW4gPSBuZXcgUmVjdGFuZ2xlKDAsIDAsIG9wdGlvbnMud2lkdGgsIG9wdGlvbnMuaGVpZ2h0KTtcbiAgICB0aGlzLmNhbnZhcyA9IG9wdGlvbnMuY2FudmFzIHx8IERPTUFkYXB0ZXIuZ2V0KCkuY3JlYXRlQ2FudmFzKCk7XG4gICAgdGhpcy5hbnRpYWxpYXMgPSAhIW9wdGlvbnMuYW50aWFsaWFzO1xuICAgIGNvbnN0IHsgZGVwdGgsIC4uLmNhbnZhc09wdGlvbnMgfSA9IG9wdGlvbnM7XG4gICAgdGhpcy50ZXh0dXJlID0gZ2V0Q2FudmFzVGV4dHVyZSh0aGlzLmNhbnZhcywgY2FudmFzT3B0aW9ucyk7XG4gICAgdGhpcy5yZW5kZXJUYXJnZXQgPSBuZXcgUmVuZGVyVGFyZ2V0KHtcbiAgICAgIGNvbG9yVGV4dHVyZXM6IFt0aGlzLnRleHR1cmVdLFxuICAgICAgZGVwdGg6ICEhZGVwdGgsXG4gICAgICBpc1Jvb3Q6IHRydWVcbiAgICB9KTtcbiAgICB0aGlzLnRleHR1cmUuc291cmNlLnRyYW5zcGFyZW50ID0gb3B0aW9ucy5iYWNrZ3JvdW5kQWxwaGEgPCAxO1xuICAgIHRoaXMudGV4dHVyZS5zb3VyY2Uub24oXCJyZXNpemVcIiwgdGhpcy5fdXBkYXRlU2NyZWVuU2l6ZSwgdGhpcyk7XG4gICAgdGhpcy5yZXNvbHV0aW9uID0gb3B0aW9ucy5yZXNvbHV0aW9uO1xuICAgIHRoaXMuX3VwZGF0ZVNjcmVlblNpemUoKTtcbiAgfVxuICAvKipcbiAgICogUmVzaXplcyB0aGUgc2NyZWVuIGFuZCBjYW52YXMgdG8gdGhlIHNwZWNpZmllZCBkaW1lbnNpb25zLlxuICAgKiBAcGFyYW0gZGVzaXJlZFNjcmVlbldpZHRoIC0gVGhlIG5ldyB3aWR0aCBvZiB0aGUgc2NyZWVuLlxuICAgKiBAcGFyYW0gZGVzaXJlZFNjcmVlbkhlaWdodCAtIFRoZSBuZXcgaGVpZ2h0IG9mIHRoZSBzY3JlZW4uXG4gICAqIEBwYXJhbSByZXNvbHV0aW9uXG4gICAqL1xuICByZXNpemUoZGVzaXJlZFNjcmVlbldpZHRoLCBkZXNpcmVkU2NyZWVuSGVpZ2h0LCByZXNvbHV0aW9uKSB7XG4gICAgdGhpcy50ZXh0dXJlLnNvdXJjZS5yZXNpemUoZGVzaXJlZFNjcmVlbldpZHRoLCBkZXNpcmVkU2NyZWVuSGVpZ2h0LCByZXNvbHV0aW9uKTtcbiAgICB0aGlzLnNjcmVlbi53aWR0aCA9IHRoaXMudGV4dHVyZS5mcmFtZS53aWR0aDtcbiAgICB0aGlzLnNjcmVlbi5oZWlnaHQgPSB0aGlzLnRleHR1cmUuZnJhbWUuaGVpZ2h0O1xuICB9XG4gIC8qKlxuICAgKiBEZXN0cm95cyB0aGlzIFN5c3RlbSBhbmQgb3B0aW9uYWxseSByZW1vdmVzIHRoZSBjYW52YXMgZnJvbSB0aGUgZG9tLlxuICAgKiBAcGFyYW0ge29wdGlvbnMgfCBmYWxzZX0gb3B0aW9ucyAtIFRoZSBvcHRpb25zIGZvciBkZXN0cm95aW5nIHRoZSB2aWV3LCBvciBcImZhbHNlXCIuXG4gICAqIEBleGFtcGxlXG4gICAqIHZpZXdTeXN0ZW0uZGVzdHJveSgpO1xuICAgKiB2aWV3U3lzdGVtLmRlc3Ryb3kodHJ1ZSk7XG4gICAqIHZpZXdTeXN0ZW0uZGVzdHJveSh7IHJlbW92ZVZpZXc6IHRydWUgfSk7XG4gICAqL1xuICBkZXN0cm95KG9wdGlvbnMgPSBmYWxzZSkge1xuICAgIGNvbnN0IHJlbW92ZVZpZXcgPSB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJib29sZWFuXCIgPyBvcHRpb25zIDogISFvcHRpb25zPy5yZW1vdmVWaWV3O1xuICAgIGlmIChyZW1vdmVWaWV3ICYmIHRoaXMuY2FudmFzLnBhcmVudE5vZGUpIHtcbiAgICAgIHRoaXMuY2FudmFzLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQodGhpcy5jYW52YXMpO1xuICAgIH1cbiAgICB0aGlzLnRleHR1cmUuc291cmNlLm9mZihcInJlc2l6ZVwiLCB0aGlzLl91cGRhdGVTY3JlZW5TaXplLCB0aGlzKTtcbiAgICBUZXh0dXJlUG9vbC5yZW1vdmVTY3JlZW4odGhpcy5fcmVuZGVyZXIudWlkKTtcbiAgICBDYW52YXNQb29sLnJlbW92ZVNjcmVlbih0aGlzLl9yZW5kZXJlci51aWQpO1xuICAgIHRoaXMudGV4dHVyZS5kZXN0cm95KCk7XG4gIH1cbiAgLyoqXG4gICAqIFRlbGxzIHRoZSB0ZXh0dXJlIGFuZCBjYW52YXMgcG9vbHMgaG93IGJpZyB0aGlzIHJlbmRlcmVyJ3Mgc2NyZWVuIGlzLCBpbiBwaHlzaWNhbCBwaXhlbHMsIHNvIHRoZXlcbiAgICogY2FuIGhhbmQgb3V0IHNjcmVlbiBzaXplZCByZXNvdXJjZXMgaW5zdGVhZCBvZiByb3VuZGluZyBldmVyeSByZXF1ZXN0IHVwIHRvIGEgcG93ZXIgb2YgdHdvLlxuICAgKi9cbiAgX3VwZGF0ZVNjcmVlblNpemUoKSB7XG4gICAgY29uc3QgeyBwaXhlbFdpZHRoLCBwaXhlbEhlaWdodCB9ID0gdGhpcy50ZXh0dXJlLnNvdXJjZTtcbiAgICBjb25zdCB1aWQgPSB0aGlzLl9yZW5kZXJlci51aWQ7XG4gICAgVGV4dHVyZVBvb2wuc2V0U2NyZWVuU2l6ZSh1aWQsIHBpeGVsV2lkdGgsIHBpeGVsSGVpZ2h0KTtcbiAgICBDYW52YXNQb29sLnNldFNjcmVlblNpemUodWlkLCBwaXhlbFdpZHRoLCBwaXhlbEhlaWdodCk7XG4gIH1cbn07XG4vKiogQGlnbm9yZSAqL1xuX1ZpZXdTeXN0ZW0uZXh0ZW5zaW9uID0ge1xuICB0eXBlOiBbXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHTFN5c3RlbSxcbiAgICBFeHRlbnNpb25UeXBlLldlYkdQVVN5c3RlbSxcbiAgICBFeHRlbnNpb25UeXBlLkNhbnZhc1N5c3RlbVxuICBdLFxuICBuYW1lOiBcInZpZXdcIixcbiAgcHJpb3JpdHk6IDBcbn07XG4vKiogVGhlIGRlZmF1bHQgb3B0aW9ucyBmb3IgdGhlIHZpZXcgc3lzdGVtLiAqL1xuX1ZpZXdTeXN0ZW0uZGVmYXVsdE9wdGlvbnMgPSB7XG4gIC8qKlxuICAgKiB7QGxpbmsgV2ViR0xPcHRpb25zLndpZHRofVxuICAgKiBAZGVmYXVsdCA4MDBcbiAgICovXG4gIHdpZHRoOiA4MDAsXG4gIC8qKlxuICAgKiB7QGxpbmsgV2ViR0xPcHRpb25zLmhlaWdodH1cbiAgICogQGRlZmF1bHQgNjAwXG4gICAqL1xuICBoZWlnaHQ6IDYwMCxcbiAgLyoqXG4gICAqIHtAbGluayBXZWJHTE9wdGlvbnMuYXV0b0RlbnNpdHl9XG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBhdXRvRGVuc2l0eTogZmFsc2UsXG4gIC8qKlxuICAgKiB7QGxpbmsgV2ViR0xPcHRpb25zLmFudGlhbGlhc31cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIGFudGlhbGlhczogZmFsc2Vcbn07XG5sZXQgVmlld1N5c3RlbSA9IF9WaWV3U3lzdGVtO1xuXG5leHBvcnQgeyBWaWV3U3lzdGVtIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1WaWV3U3lzdGVtLm1qcy5tYXBcbiIsImltcG9ydCB7IEN1c3RvbVJlbmRlclBpcGUgfSBmcm9tICcuLi8uLi8uLi8uLi9zY2VuZS9jb250YWluZXIvQ3VzdG9tUmVuZGVyUGlwZS5tanMnO1xuaW1wb3J0IHsgUmVuZGVyR3JvdXBQaXBlIH0gZnJvbSAnLi4vLi4vLi4vLi4vc2NlbmUvY29udGFpbmVyL1JlbmRlckdyb3VwUGlwZS5tanMnO1xuaW1wb3J0IHsgUmVuZGVyR3JvdXBTeXN0ZW0gfSBmcm9tICcuLi8uLi8uLi8uLi9zY2VuZS9jb250YWluZXIvUmVuZGVyR3JvdXBTeXN0ZW0ubWpzJztcbmltcG9ydCB7IFNwcml0ZVBpcGUgfSBmcm9tICcuLi8uLi8uLi8uLi9zY2VuZS9zcHJpdGUvU3ByaXRlUGlwZS5tanMnO1xuaW1wb3J0IHsgUmVuZGVyZXJJbml0SG9vayB9IGZyb20gJy4uLy4uLy4uLy4uL3V0aWxzL2dsb2JhbC9nbG9iYWxIb29rcy5tanMnO1xuaW1wb3J0IHsgQmF0Y2hlclBpcGUgfSBmcm9tICcuLi8uLi8uLi9iYXRjaGVyL3NoYXJlZC9CYXRjaGVyUGlwZS5tanMnO1xuaW1wb3J0IHsgQWxwaGFNYXNrUGlwZSB9IGZyb20gJy4uLy4uLy4uL21hc2svYWxwaGEvQWxwaGFNYXNrUGlwZS5tanMnO1xuaW1wb3J0IHsgQ29sb3JNYXNrUGlwZSB9IGZyb20gJy4uLy4uLy4uL21hc2svY29sb3IvQ29sb3JNYXNrUGlwZS5tanMnO1xuaW1wb3J0IHsgU3RlbmNpbE1hc2tQaXBlIH0gZnJvbSAnLi4vLi4vLi4vbWFzay9zdGVuY2lsL1N0ZW5jaWxNYXNrUGlwZS5tanMnO1xuaW1wb3J0IHsgQmFja2dyb3VuZFN5c3RlbSB9IGZyb20gJy4uL2JhY2tncm91bmQvQmFja2dyb3VuZFN5c3RlbS5tanMnO1xuaW1wb3J0IHsgQmxlbmRNb2RlUGlwZSB9IGZyb20gJy4uL2JsZW5kTW9kZXMvQmxlbmRNb2RlUGlwZS5tanMnO1xuaW1wb3J0IHsgRXh0cmFjdFN5c3RlbSB9IGZyb20gJy4uL2V4dHJhY3QvRXh0cmFjdFN5c3RlbS5tanMnO1xuaW1wb3J0IHsgR2VuZXJhdGVUZXh0dXJlU3lzdGVtIH0gZnJvbSAnLi4vZXh0cmFjdC9HZW5lcmF0ZVRleHR1cmVTeXN0ZW0ubWpzJztcbmltcG9ydCB7IEdDU3lzdGVtIH0gZnJvbSAnLi4vR0NTeXN0ZW0ubWpzJztcbmltcG9ydCB7IEdsb2JhbFVuaWZvcm1TeXN0ZW0gfSBmcm9tICcuLi9yZW5kZXJUYXJnZXQvR2xvYmFsVW5pZm9ybVN5c3RlbS5tanMnO1xuaW1wb3J0IHsgU2NoZWR1bGVyU3lzdGVtIH0gZnJvbSAnLi4vU2NoZWR1bGVyU3lzdGVtLm1qcyc7XG5pbXBvcnQgeyBIZWxsb1N5c3RlbSB9IGZyb20gJy4uL3N0YXJ0dXAvSGVsbG9TeXN0ZW0ubWpzJztcbmltcG9ydCB7IFJlbmRlcmFibGVHQ1N5c3RlbSB9IGZyb20gJy4uL3RleHR1cmUvUmVuZGVyYWJsZUdDU3lzdGVtLm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlR0NTeXN0ZW0gfSBmcm9tICcuLi90ZXh0dXJlL1RleHR1cmVHQ1N5c3RlbS5tanMnO1xuaW1wb3J0IHsgVmlld1N5c3RlbSB9IGZyb20gJy4uL3ZpZXcvVmlld1N5c3RlbS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IFNoYXJlZFN5c3RlbXMgPSBbXG4gIEJhY2tncm91bmRTeXN0ZW0sXG4gIEdsb2JhbFVuaWZvcm1TeXN0ZW0sXG4gIEhlbGxvU3lzdGVtLFxuICBWaWV3U3lzdGVtLFxuICBSZW5kZXJHcm91cFN5c3RlbSxcbiAgR0NTeXN0ZW0sXG4gIFRleHR1cmVHQ1N5c3RlbSxcbiAgR2VuZXJhdGVUZXh0dXJlU3lzdGVtLFxuICBFeHRyYWN0U3lzdGVtLFxuICBSZW5kZXJlckluaXRIb29rLFxuICBSZW5kZXJhYmxlR0NTeXN0ZW0sXG4gIFNjaGVkdWxlclN5c3RlbVxuXTtcbmNvbnN0IFNoYXJlZFJlbmRlclBpcGVzID0gW1xuICBCbGVuZE1vZGVQaXBlLFxuICBCYXRjaGVyUGlwZSxcbiAgU3ByaXRlUGlwZSxcbiAgUmVuZGVyR3JvdXBQaXBlLFxuICBBbHBoYU1hc2tQaXBlLFxuICBTdGVuY2lsTWFza1BpcGUsXG4gIENvbG9yTWFza1BpcGUsXG4gIEN1c3RvbVJlbmRlclBpcGVcbl07XG5cbmV4cG9ydCB7IFNoYXJlZFJlbmRlclBpcGVzLCBTaGFyZWRTeXN0ZW1zIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1TaGFyZWRTeXN0ZW1zLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gY2FsY3VsYXRlUHJvamVjdGlvbihwbSwgeCwgeSwgd2lkdGgsIGhlaWdodCwgZmxpcFkpIHtcbiAgY29uc3Qgc2lnbiA9IGZsaXBZID8gMSA6IC0xO1xuICBwbS5pZGVudGl0eSgpO1xuICBwbS5hID0gMSAvIHdpZHRoICogMjtcbiAgcG0uZCA9IHNpZ24gKiAoMSAvIGhlaWdodCAqIDIpO1xuICBwbS50eCA9IC0xIC0geCAqIHBtLmE7XG4gIHBtLnR5ID0gLXNpZ24gLSB5ICogcG0uZDtcbiAgcmV0dXJuIHBtO1xufVxuXG5leHBvcnQgeyBjYWxjdWxhdGVQcm9qZWN0aW9uIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jYWxjdWxhdGVQcm9qZWN0aW9uLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gaXNSZW5kZXJpbmdUb1NjcmVlbihyZW5kZXJUYXJnZXQpIHtcbiAgaWYgKHJlbmRlclRhcmdldC5jb2xvckF0dGFjaG1lbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIGZhbHNlO1xuICBjb25zdCByZXNvdXJjZSA9IHJlbmRlclRhcmdldC5jb2xvclRleHR1cmUucmVzb3VyY2U7XG4gIHJldHVybiBnbG9iYWxUaGlzLkhUTUxDYW52YXNFbGVtZW50ICYmIHJlc291cmNlIGluc3RhbmNlb2YgSFRNTENhbnZhc0VsZW1lbnQgJiYgZG9jdW1lbnQuYm9keS5jb250YWlucyhyZXNvdXJjZSk7XG59XG5cbmV4cG9ydCB7IGlzUmVuZGVyaW5nVG9TY3JlZW4gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWlzUmVuZGVyaW5nVG9TY3JlZW4ubWpzLm1hcFxuIiwiaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgUmVjdGFuZ2xlIH0gZnJvbSAnLi4vLi4vLi4vLi4vbWF0aHMvc2hhcGVzL1JlY3RhbmdsZS5tanMnO1xuaW1wb3J0IHsgZGVwcmVjYXRpb24sIHY4XzIxXzAgfSBmcm9tICcuLi8uLi8uLi8uLi91dGlscy9sb2dnaW5nL2RlcHJlY2F0aW9uLm1qcyc7XG5pbXBvcnQgeyB3YXJuIH0gZnJvbSAnLi4vLi4vLi4vLi4vdXRpbHMvbG9nZ2luZy93YXJuLm1qcyc7XG5pbXBvcnQgeyBDTEVBUiB9IGZyb20gJy4uLy4uL2dsL2NvbnN0Lm1qcyc7XG5pbXBvcnQgeyBjYWxjdWxhdGVQcm9qZWN0aW9uIH0gZnJvbSAnLi4vLi4vZ3B1L3JlbmRlclRhcmdldC9jYWxjdWxhdGVQcm9qZWN0aW9uLm1qcyc7XG5pbXBvcnQgeyBSZW5kZXJlclR5cGUgfSBmcm9tICcuLi8uLi90eXBlcy5tanMnO1xuaW1wb3J0IHsgU3lzdGVtUnVubmVyIH0gZnJvbSAnLi4vc3lzdGVtL1N5c3RlbVJ1bm5lci5tanMnO1xuaW1wb3J0IHsgQ2FudmFzU291cmNlIH0gZnJvbSAnLi4vdGV4dHVyZS9zb3VyY2VzL0NhbnZhc1NvdXJjZS5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVNvdXJjZSB9IGZyb20gJy4uL3RleHR1cmUvc291cmNlcy9UZXh0dXJlU291cmNlLm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlIH0gZnJvbSAnLi4vdGV4dHVyZS9UZXh0dXJlLm1qcyc7XG5pbXBvcnQgeyBnZXRDYW52YXNUZXh0dXJlIH0gZnJvbSAnLi4vdGV4dHVyZS91dGlscy9nZXRDYW52YXNUZXh0dXJlLm1qcyc7XG5pbXBvcnQgeyBpc1JlbmRlcmluZ1RvU2NyZWVuIH0gZnJvbSAnLi9pc1JlbmRlcmluZ1RvU2NyZWVuLm1qcyc7XG5pbXBvcnQgeyBSZW5kZXJUYXJnZXQgfSBmcm9tICcuL1JlbmRlclRhcmdldC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIFJlbmRlclRhcmdldFN5c3RlbSB7XG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgLyoqIFRoaXMgaXMgdGhlIHJvb3Qgdmlld3BvcnQgZm9yIHRoZSByZW5kZXIgcGFzcyAqL1xuICAgIHRoaXMucm9vdFZpZXdQb3J0ID0gbmV3IFJlY3RhbmdsZSgpO1xuICAgIC8qKiB0aGUgY3VycmVudCB2aWV3cG9ydCB0aGF0IHRoZSBncHUgaXMgdXNpbmcgKi9cbiAgICB0aGlzLnZpZXdwb3J0ID0gbmV3IFJlY3RhbmdsZSgpO1xuICAgIC8qKlxuICAgICAqIGEgcnVubmVyIHRoYXQgbGV0cyBzeXN0ZW1zIGtub3cgaWYgdGhlIGFjdGl2ZSByZW5kZXIgdGFyZ2V0IGhhcyBjaGFuZ2VkLlxuICAgICAqIEVnIHRoZSBTdGVuY2lsIFN5c3RlbSBuZWVkcyB0byBrbm93IHNvIGl0IGNhbiBtYW5hZ2UgdGhlIHN0ZW5jaWwgYnVmZmVyXG4gICAgICovXG4gICAgdGhpcy5vblJlbmRlclRhcmdldENoYW5nZSA9IG5ldyBTeXN0ZW1SdW5uZXIoXCJvblJlbmRlclRhcmdldENoYW5nZVwiKTtcbiAgICAvKiogdGhlIHByb2plY3Rpb24gbWF0cml4IHRoYXQgaXMgdXNlZCBieSB0aGUgc2hhZGVycyBiYXNlZCBvbiB0aGUgYWN0aXZlIHJlbmRlciB0YXJnZXQgYW5kIHRoZSB2aWV3cG9ydCAqL1xuICAgIHRoaXMucHJvamVjdGlvbk1hdHJpeCA9IG5ldyBNYXRyaXgoKTtcbiAgICAvKiogdGhlIGRlZmF1bHQgY2xlYXIgY29sb3IgZm9yIHJlbmRlciB0YXJnZXRzICovXG4gICAgdGhpcy5kZWZhdWx0Q2xlYXJDb2xvciA9IFswLCAwLCAwLCAwXTtcbiAgICAvKipcbiAgICAgKiBhIGhhc2ggdGhhdCBzdG9yZXMgdGhlIHJlbmRlciB0YXJnZXQgZm9yIGEgZ2l2ZW4gcmVuZGVyIHN1cmZhY2UuIFdoZW4geW91IHBhc3MgaW4gYSB0ZXh0dXJlIHNvdXJjZSxcbiAgICAgKiBhIHJlbmRlciB0YXJnZXQgaXMgY3JlYXRlZCBmb3IgaXQuIFRoaXMgbWFwIHN0b3JlcyBhbmQgbWFrZXMgaXQgZWFzeSB0byByZXRyaWV2ZSB0aGUgcmVuZGVyIHRhcmdldFxuICAgICAqL1xuICAgIHRoaXMuX3JlbmRlclN1cmZhY2VUb1JlbmRlclRhcmdldEhhc2ggPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIC8qKiBBIGhhc2ggdGhhdCBzdG9yZXMgYSBncHUgcmVuZGVyIHRhcmdldCBmb3IgYSBnaXZlbiByZW5kZXIgdGFyZ2V0LiAqL1xuICAgIHRoaXMuX2dwdVJlbmRlclRhcmdldEhhc2ggPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAvKiogdGhlIHB1c2hlZCBiaW5kaW5nczsgZWFjaCBlbnRyeSBpcyBhIHJlcGxheWFibGUgQmluZE9wdGlvbnMgdGhhdCBwb3AoKSByZS1iaW5kcyAqL1xuICAgIHRoaXMuX3JlbmRlclRhcmdldFN0YWNrID0gW107XG4gICAgLyoqXG4gICAgICogdGhlIHN0YXRlIG9mIHRoZSBjdXJyZW50IGJpbmRpbmcsIHdyaXR0ZW4gb24gZXZlcnkgYmluZCDigJQgYmFja3MgdGhlIGByZW5kZXJTdXJmYWNlYCxcbiAgICAgKiBgbWlwTGV2ZWxgIGFuZCBgbGF5ZXJgIGdldHRlcnMgYW5kIGBnZXRCaW5kU3RhdGVgLiBJdHMgYGZyYW1lYCBhbGlhc2VzIGBfYmluZEZyYW1lYFxuICAgICAqIGFuZCBtdXN0IG5ldmVyIGJlIGhhbmRlZCBvdXQgYnkgcmVmZXJlbmNlLlxuICAgICAqL1xuICAgIHRoaXMuX2JpbmRTdGF0ZSA9IHtcbiAgICAgIHRhcmdldDogbnVsbCxcbiAgICAgIGZyYW1lOiB2b2lkIDAsXG4gICAgICBtaXBMZXZlbDogMCxcbiAgICAgIGxheWVyOiAwLFxuICAgICAgZmxpcFk6IGZhbHNlXG4gICAgfTtcbiAgICAvKiogc3lzdGVtLW93bmVkIHJlY3QgYmFja2luZyBgX2JpbmRTdGF0ZS5mcmFtZWA7IGFzLXBhc3NlZCBmcmFtZXMgYXJlIGNvcGllZCBpbnRvIGl0ICovXG4gICAgdGhpcy5fYmluZEZyYW1lID0gbmV3IFJlY3RhbmdsZSgpO1xuICAgIHRoaXMuX3JlbmRlcmVyID0gcmVuZGVyZXI7XG4gICAgcmVuZGVyZXIuZ2MuYWRkQ29sbGVjdGlvbih0aGlzLCBcIl9ncHVSZW5kZXJUYXJnZXRIYXNoXCIsIFwiaGFzaFwiKTtcbiAgfVxuICAvKiogdGhlIGN1cnJlbnQgYWN0aXZlIHJlbmRlciBzdXJmYWNlIHRoYXQgdGhlIHJlbmRlciB0YXJnZXQgaXMgY3JlYXRlZCBmcm9tICovXG4gIGdldCByZW5kZXJTdXJmYWNlKCkge1xuICAgIHJldHVybiB0aGlzLl9iaW5kU3RhdGUudGFyZ2V0O1xuICB9XG4gIC8qKiB0aGUgY3VycmVudCBtaXAgbGV2ZWwgYmVpbmcgcmVuZGVyZWQgdG8gKGZvciB0ZXh0dXJlIHN1YnJlc291cmNlcykgKi9cbiAgZ2V0IG1pcExldmVsKCkge1xuICAgIHJldHVybiB0aGlzLl9iaW5kU3RhdGUubWlwTGV2ZWw7XG4gIH1cbiAgLyoqIHRoZSBjdXJyZW50IGFycmF5IGxheWVyIGJlaW5nIHJlbmRlcmVkIHRvIChmb3IgYXJyYXktYmFja2VkIHRhcmdldHMpICovXG4gIGdldCBsYXllcigpIHtcbiAgICByZXR1cm4gdGhpcy5fYmluZFN0YXRlLmxheWVyO1xuICB9XG4gIC8qKiBjYWxsZWQgd2hlbiBkZXYgd2FudHMgdG8gZmluaXNoIGEgcmVuZGVyIHBhc3MgKi9cbiAgZmluaXNoUmVuZGVyUGFzcygpIHtcbiAgICB0aGlzLmFkYXB0b3IuZmluaXNoUmVuZGVyUGFzcyh0aGlzLnJlbmRlclRhcmdldCk7XG4gIH1cbiAgLyoqXG4gICAqIGNhbGxlZCB3aGVuIHRoZSByZW5kZXJlciBzdGFydHMgdG8gcmVuZGVyIGEgc2NlbmU6IHJlc2V0cyB0aGUgYmluZCBzdGFjayBhbmQgYmluZHMgdGhlXG4gICAqIHJvb3QgcmVuZGVyIHN1cmZhY2VcbiAgICogQHBhcmFtIG9wdGlvbnMgLSB0aGUge0BsaW5rIEJpbmRPcHRpb25zfSBmb3IgdGhlIHJvb3QgYmluZGluZ1xuICAgKi9cbiAgcmVuZGVyU3RhcnQob3B0aW9ucykge1xuICAgIHRoaXMuX3JlbmRlclRhcmdldFN0YWNrLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5wdXNoKG9wdGlvbnMpO1xuICAgIHRoaXMucm9vdFZpZXdQb3J0LmNvcHlGcm9tKHRoaXMudmlld3BvcnQpO1xuICAgIHRoaXMucm9vdFJlbmRlclRhcmdldCA9IHRoaXMucmVuZGVyVGFyZ2V0O1xuICAgIHRoaXMucmVuZGVyaW5nVG9TY3JlZW4gPSBpc1JlbmRlcmluZ1RvU2NyZWVuKHRoaXMucm9vdFJlbmRlclRhcmdldCk7XG4gICAgdGhpcy5hZGFwdG9yLnByZXJlbmRlcj8uKHRoaXMucm9vdFJlbmRlclRhcmdldCk7XG4gIH1cbiAgcG9zdHJlbmRlcigpIHtcbiAgICB0aGlzLmFkYXB0b3IucG9zdHJlbmRlcj8uKHRoaXMucm9vdFJlbmRlclRhcmdldCk7XG4gIH1cbiAgYmluZChzdXJmYWNlT3JPcHRpb25zLCBjbGVhciA9IHRydWUsIGNsZWFyQ29sb3IsIGZyYW1lLCBtaXBMZXZlbCA9IDAsIGxheWVyID0gMCwgZmxpcFkpIHtcbiAgICBsZXQgb3B0aW9ucztcbiAgICBpZiAoXCJ0YXJnZXRcIiBpbiBzdXJmYWNlT3JPcHRpb25zKSB7XG4gICAgICBvcHRpb25zID0gc3VyZmFjZU9yT3B0aW9ucztcbiAgICB9IGVsc2Uge1xuICAgICAgZGVwcmVjYXRpb24oXCI4LjIwLjBcIiwgXCJSZW5kZXJUYXJnZXRTeXN0ZW0uYmluZDogcG9zaXRpb25hbCBhcmd1bWVudHMgYXJlIGRlcHJlY2F0ZWQsIHBsZWFzZSB1c2UgYW4gb3B0aW9ucyBvYmplY3QgaW5zdGVhZDogYmluZCh7IHRhcmdldCwgY2xlYXIsIGNsZWFyQ29sb3IsIGZyYW1lLCBtaXBMZXZlbCwgbGF5ZXIsIGZsaXBZIH0pXCIpO1xuICAgICAgb3B0aW9ucyA9IHsgdGFyZ2V0OiBzdXJmYWNlT3JPcHRpb25zLCBjbGVhciwgY2xlYXJDb2xvciwgZnJhbWUsIG1pcExldmVsLCBsYXllciwgZmxpcFkgfTtcbiAgICB9XG4gICAgY29uc3QgcmVuZGVyU3VyZmFjZSA9IG9wdGlvbnMudGFyZ2V0O1xuICAgIGNsZWFyID0gb3B0aW9ucy5jbGVhciA/PyB0cnVlO1xuICAgIGNsZWFyQ29sb3IgPSBvcHRpb25zLmNsZWFyQ29sb3I7XG4gICAgbWlwTGV2ZWwgPSAob3B0aW9ucy5taXBMZXZlbCA/PyAwKSB8IDA7XG4gICAgbGF5ZXIgPSAob3B0aW9ucy5sYXllciA/PyAwKSB8IDA7XG4gICAgZmxpcFkgPSBvcHRpb25zLmZsaXBZO1xuICAgIGZyYW1lID0gb3B0aW9ucy5mcmFtZTtcbiAgICBjb25zdCByZW5kZXJUYXJnZXQgPSB0aGlzLmdldFJlbmRlclRhcmdldChyZW5kZXJTdXJmYWNlKTtcbiAgICBjb25zdCBkaWRDaGFuZ2UgPSB0aGlzLnJlbmRlclRhcmdldCAhPT0gcmVuZGVyVGFyZ2V0IHx8ICEhcmVuZGVyVGFyZ2V0LmZsaXBZICE9PSAhIWZsaXBZO1xuICAgIHRoaXMucmVuZGVyVGFyZ2V0ID0gcmVuZGVyVGFyZ2V0O1xuICAgIGNvbnN0IGdwdVJlbmRlclRhcmdldCA9IHRoaXMuZ2V0R3B1UmVuZGVyVGFyZ2V0KHJlbmRlclRhcmdldCk7XG4gICAgaWYgKHJlbmRlclRhcmdldC5waXhlbFdpZHRoICE9PSBncHVSZW5kZXJUYXJnZXQud2lkdGggfHwgcmVuZGVyVGFyZ2V0LnBpeGVsSGVpZ2h0ICE9PSBncHVSZW5kZXJUYXJnZXQuaGVpZ2h0KSB7XG4gICAgICB0aGlzLmFkYXB0b3IucmVzaXplR3B1UmVuZGVyVGFyZ2V0KHJlbmRlclRhcmdldCk7XG4gICAgICBncHVSZW5kZXJUYXJnZXQud2lkdGggPSByZW5kZXJUYXJnZXQucGl4ZWxXaWR0aDtcbiAgICAgIGdwdVJlbmRlclRhcmdldC5oZWlnaHQgPSByZW5kZXJUYXJnZXQucGl4ZWxIZWlnaHQ7XG4gICAgfVxuICAgIGNvbnN0IHNvdXJjZSA9IHJlbmRlclRhcmdldC5jb2xvckF0dGFjaG1lbnRzWzBdPy50ZXh0dXJlIHx8IHJlbmRlclRhcmdldC5kZXB0aFN0ZW5jaWxBdHRhY2htZW50Py50ZXh0dXJlO1xuICAgIGNvbnN0IHZpZXdwb3J0ID0gdGhpcy52aWV3cG9ydDtcbiAgICBjb25zdCBsYXllckNvdW50ID0gc291cmNlLmRpbWVuc2lvbiA9PT0gXCIzZFwiID8gTWF0aC5tYXgoc291cmNlLmRlcHRoID4+IG1pcExldmVsLCAxKSA6IHNvdXJjZS5kZXB0aE9yQXJyYXlMYXllcnM7XG4gICAgaWYgKGxheWVyIDwgMCB8fCBsYXllciA+PSBsYXllckNvdW50KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFtSZW5kZXJUYXJnZXRTeXN0ZW1dIGxheWVyICR7bGF5ZXJ9IGlzIG91dCBvZiBib3VuZHMgKGxheWVyIGNvdW50PSR7bGF5ZXJDb3VudH0pLmApO1xuICAgIH1cbiAgICBjb25zdCBiaW5kU3RhdGUgPSB0aGlzLl9iaW5kU3RhdGU7XG4gICAgYmluZFN0YXRlLnRhcmdldCA9IHJlbmRlclN1cmZhY2U7XG4gICAgYmluZFN0YXRlLmZyYW1lID0gZnJhbWUgPyB0aGlzLl9iaW5kRnJhbWUuY29weUZyb20oZnJhbWUpIDogdm9pZCAwO1xuICAgIGJpbmRTdGF0ZS5taXBMZXZlbCA9IG1pcExldmVsO1xuICAgIGJpbmRTdGF0ZS5sYXllciA9IGxheWVyO1xuICAgIGJpbmRTdGF0ZS5mbGlwWSA9IGZsaXBZO1xuICAgIGNvbnN0IHBpeGVsV2lkdGggPSBNYXRoLm1heChzb3VyY2UucGl4ZWxXaWR0aCA+PiBtaXBMZXZlbCwgMSk7XG4gICAgY29uc3QgcGl4ZWxIZWlnaHQgPSBNYXRoLm1heChzb3VyY2UucGl4ZWxIZWlnaHQgPj4gbWlwTGV2ZWwsIDEpO1xuICAgIGlmICghZnJhbWUgJiYgcmVuZGVyU3VyZmFjZSBpbnN0YW5jZW9mIFRleHR1cmUpIHtcbiAgICAgIGZyYW1lID0gcmVuZGVyU3VyZmFjZS5mcmFtZTtcbiAgICB9XG4gICAgaWYgKGZyYW1lKSB7XG4gICAgICBjb25zdCByZXNvbHV0aW9uID0gc291cmNlLl9yZXNvbHV0aW9uO1xuICAgICAgY29uc3Qgc2NhbGUgPSAxIDw8IE1hdGgubWF4KG1pcExldmVsLCAwKTtcbiAgICAgIGNvbnN0IGJhc2VYID0gZnJhbWUueCAqIHJlc29sdXRpb24gKyAwLjUgfCAwO1xuICAgICAgY29uc3QgYmFzZVkgPSBmcmFtZS55ICogcmVzb2x1dGlvbiArIDAuNSB8IDA7XG4gICAgICBjb25zdCBiYXNlVyA9IGZyYW1lLndpZHRoICogcmVzb2x1dGlvbiArIDAuNSB8IDA7XG4gICAgICBjb25zdCBiYXNlSCA9IGZyYW1lLmhlaWdodCAqIHJlc29sdXRpb24gKyAwLjUgfCAwO1xuICAgICAgbGV0IHggPSBNYXRoLmZsb29yKGJhc2VYIC8gc2NhbGUpO1xuICAgICAgbGV0IHkgPSBNYXRoLmZsb29yKGJhc2VZIC8gc2NhbGUpO1xuICAgICAgbGV0IHcgPSBNYXRoLmNlaWwoYmFzZVcgLyBzY2FsZSk7XG4gICAgICBsZXQgaCA9IE1hdGguY2VpbChiYXNlSCAvIHNjYWxlKTtcbiAgICAgIGlmICh4IDwgMCkge1xuICAgICAgICB3ICs9IHg7XG4gICAgICAgIHggPSAwO1xuICAgICAgfVxuICAgICAgaWYgKHkgPCAwKSB7XG4gICAgICAgIGggKz0geTtcbiAgICAgICAgeSA9IDA7XG4gICAgICB9XG4gICAgICB4ID0gTWF0aC5taW4oeCwgcGl4ZWxXaWR0aCAtIDEpO1xuICAgICAgeSA9IE1hdGgubWluKHksIHBpeGVsSGVpZ2h0IC0gMSk7XG4gICAgICB3ID0gTWF0aC5taW4odywgcGl4ZWxXaWR0aCAtIHgpO1xuICAgICAgaCA9IE1hdGgubWluKGgsIHBpeGVsSGVpZ2h0IC0geSk7XG4gICAgICB3ID0gTWF0aC5tYXgodywgMSk7XG4gICAgICBoID0gTWF0aC5tYXgoaCwgMSk7XG4gICAgICB2aWV3cG9ydC54ID0geDtcbiAgICAgIHZpZXdwb3J0LnkgPSB5O1xuICAgICAgdmlld3BvcnQud2lkdGggPSB3O1xuICAgICAgdmlld3BvcnQuaGVpZ2h0ID0gaDtcbiAgICB9IGVsc2Uge1xuICAgICAgdmlld3BvcnQueCA9IDA7XG4gICAgICB2aWV3cG9ydC55ID0gMDtcbiAgICAgIHZpZXdwb3J0LndpZHRoID0gcGl4ZWxXaWR0aDtcbiAgICAgIHZpZXdwb3J0LmhlaWdodCA9IHBpeGVsSGVpZ2h0O1xuICAgIH1cbiAgICByZW5kZXJUYXJnZXQuZmxpcFkgPSBmbGlwWTtcbiAgICBjYWxjdWxhdGVQcm9qZWN0aW9uKFxuICAgICAgdGhpcy5wcm9qZWN0aW9uTWF0cml4LFxuICAgICAgMCxcbiAgICAgIDAsXG4gICAgICB2aWV3cG9ydC53aWR0aCAvIHNvdXJjZS5yZXNvbHV0aW9uLFxuICAgICAgdmlld3BvcnQuaGVpZ2h0IC8gc291cmNlLnJlc29sdXRpb24sXG4gICAgICAhcmVuZGVyVGFyZ2V0LmlzUm9vdCAhPT0gISFyZW5kZXJUYXJnZXQuZmxpcFlcbiAgICApO1xuICAgIHRoaXMuYWRhcHRvci5zdGFydFJlbmRlclBhc3MocmVuZGVyVGFyZ2V0LCBjbGVhciwgY2xlYXJDb2xvciwgdmlld3BvcnQsIG1pcExldmVsLCBsYXllcik7XG4gICAgaWYgKGRpZENoYW5nZSkge1xuICAgICAgdGhpcy5vblJlbmRlclRhcmdldENoYW5nZS5lbWl0KHJlbmRlclRhcmdldCk7XG4gICAgfVxuICAgIHJldHVybiByZW5kZXJUYXJnZXQ7XG4gIH1cbiAgLyoqXG4gICAqIENhcHR1cmVzIHRoZSBjdXJyZW50IGJpbmRpbmcgYXMgYSB7QGxpbmsgQmluZE9wdGlvbnN9IHRoYXQgY2FuIGJlIHBhc3NlZCBiYWNrIHRvXG4gICAqIHtAbGluayBSZW5kZXJUYXJnZXRTeXN0ZW0uYmluZH0gdG8gcmVzdG9yZSBpdC4gVGhlIGNhcHR1cmUgcmVwbGF5cyBub24tZGVzdHJ1Y3RpdmVseTpcbiAgICogaXRzIGBjbGVhcmAgaXMgYENMRUFSLk5PTkVgLCBzbyByZXN0b3JpbmcgbmV2ZXIgd2lwZXMgdGhlIHRhcmdldC5cbiAgICpcbiAgICogYGBganNcbiAgICogY29uc3Qgc2F2ZWQgPSByZW5kZXJlci5yZW5kZXJUYXJnZXQuZ2V0QmluZFN0YXRlKCk7XG4gICAqXG4gICAqIHJlbmRlcmVyLnJlbmRlclRhcmdldC5iaW5kKHsgdGFyZ2V0OiBzY3JhdGNoVGV4dHVyZSwgY2xlYXI6IHRydWUgfSk7XG4gICAqIC8vIC4uLiBkcmF3IC4uLlxuICAgKiByZW5kZXJlci5yZW5kZXJUYXJnZXQuYmluZChzYXZlZCk7XG4gICAqXG4gICAqIC8vIG9yIGNvbXBvc2U6IHRoZSBzYXZlZCBiaW5kaW5nLCBidXQgaW50byBtaXAgMVxuICAgKiByZW5kZXJlci5yZW5kZXJUYXJnZXQuYmluZCh7IC4uLnNhdmVkLCBtaXBMZXZlbDogMSB9KTtcbiAgICogYGBgXG4gICAqXG4gICAqIFRoZSBjYXB0dXJlIGlzIGEgc25hcHNob3Qgb3duZWQgYnkgdGhlIGNhbGxlciDigJQgbGF0ZXIgYmluZHMgY2Fubm90IGNoYW5nZSBpdCDigJQgYW5kIGhvbGRzXG4gICAqIGB0YXJnZXRgIGFuZCBgZnJhbWVgIGFzIHRoZXkgd2VyZSBwYXNzZWQsIHNvIGEgVGV4dHVyZSBib3VuZCB3aXRob3V0IGFuIGV4cGxpY2l0IGZyYW1lXG4gICAqIHJlcGxheXMgdGhyb3VnaCBpdHMgZnJhbWUgZmFsbGJhY2suIEl0IHN0YXlzIHZhbGlkIGZvciBhcyBsb25nIGFzIGl0cyB0YXJnZXQgZG9lcy5cbiAgICogUGFzcyBgb3V0YCB0byByZXVzZSBvbmUgb2JqZWN0IGFjcm9zcyBjYXB0dXJlczsgZXZlcnkgZmllbGQgb2YgaXQgaXMgb3ZlcndyaXR0ZW4uXG4gICAqIEBwYXJhbSBvdXQgLSBhbiBvcHRpb25hbCBvYmplY3QgdG8gd3JpdGUgdGhlIGJpbmQgc3RhdGUgaW50bzsgYWxsb2NhdGVkIHdoZW4gb21pdHRlZFxuICAgKiBAcmV0dXJucyB0aGUgY2FwdHVyZWQgYmluZCBzdGF0ZSAoYG91dGAgd2hlbiBwcm92aWRlZClcbiAgICovXG4gIGdldEJpbmRTdGF0ZShvdXQpIHtcbiAgICBpZiAoIXRoaXMucmVuZGVyVGFyZ2V0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJbUmVuZGVyVGFyZ2V0U3lzdGVtXSBnZXRCaW5kU3RhdGUgaXMgb25seSB2YWxpZCB3aGlsZSBhIHJlbmRlciBzdXJmYWNlIGlzIGJvdW5kXCIpO1xuICAgIH1cbiAgICBjb25zdCBiaW5kU3RhdGUgPSB0aGlzLl9iaW5kU3RhdGU7XG4gICAgb3V0ID8/IChvdXQgPSB7fSk7XG4gICAgb3V0LnRhcmdldCA9IGJpbmRTdGF0ZS50YXJnZXQ7XG4gICAgb3V0LmNsZWFyID0gQ0xFQVIuTk9ORTtcbiAgICBvdXQuY2xlYXJDb2xvciA9IHZvaWQgMDtcbiAgICBpZiAoIWJpbmRTdGF0ZS5mcmFtZSkge1xuICAgICAgb3V0LmZyYW1lID0gdm9pZCAwO1xuICAgIH0gZWxzZSBpZiAob3V0LmZyYW1lKSB7XG4gICAgICBvdXQuZnJhbWUuY29weUZyb20oYmluZFN0YXRlLmZyYW1lKTtcbiAgICB9IGVsc2Uge1xuICAgICAgb3V0LmZyYW1lID0gYmluZFN0YXRlLmZyYW1lLmNsb25lKCk7XG4gICAgfVxuICAgIG91dC5taXBMZXZlbCA9IGJpbmRTdGF0ZS5taXBMZXZlbDtcbiAgICBvdXQubGF5ZXIgPSBiaW5kU3RhdGUubGF5ZXI7XG4gICAgb3V0LmZsaXBZID0gISFiaW5kU3RhdGUuZmxpcFk7XG4gICAgcmV0dXJuIG91dDtcbiAgfVxuICAvKipcbiAgICogV2hldGhlciBwaXhpIGludmVydHMgdGhlIGZyb250IGZhY2UgZm9yIGEgYmluZCDigJQgYHRydWVgIHdoZW4gYSBmcm9udC1mYWNpbmcgdHJpYW5nbGUgZW5kcyB1cFxuICAgKiB3b3VuZCB0aGUgb3Bwb3NpdGUgd2F5IG9uIHRoZSBzdXJmYWNlLCBzbyB0aGUgd2luZGluZy9jdWxsIGhhcyBiZWVuIGludmVydGVkIHRvIGNvbXBlbnNhdGUuXG4gICAqXG4gICAqIFdpdGggbm8gYXJndW1lbnRzLCBhbnN3ZXJzIGZvciB0aGUgY3VycmVudCBiaW5kLiBXaXRoIGEgdGFyZ2V0LCBhbnN3ZXJzIGZvciB0aGF0IHRhcmdldCBhcyBpZlxuICAgKiBpdCB3ZXJlIGJvdW5kIHdpdGggdGhlIGdpdmVuIGBmbGlwWWAgKGRlZmF1bHRpbmcgdG8gYGZhbHNlYCwgZXhhY3RseSBhcyB7QGxpbmsgYmluZH0gd291bGQpLCBzb1xuICAgKiBhIGNvbnN1bWVyIGNhbiBjaG9vc2UgYSBwcm9qZWN0aW9uIG9yIGEgYGZsaXBZYCBiZWZvcmUgYmluZGluZy5cbiAgICpcbiAgICogVGhpcyBpcyB0aGUgcmVxdWVzdGVkIGBmbGlwWWAgY29tYmluZWQgd2l0aCB0aGUgYmFja2VuZCdzIGluaGVyZW50IG9yaWVudGF0aW9uLCBub3QgdGhlIHJhdyByZXF1ZXN0OlxuICAgKlxuICAgKiBgYGB0ZXh0XG4gICAqIGludmVydGVkID0gZmxpcFkgWE9SIChpc1dlYkdMICYmICFpc1Jvb3QpXG4gICAqIGBgYFxuICAgKlxuICAgKiBXZWJHTCdzIG5vbi1yb290IEZCT3MgY2FycnkgYW4gaW5oZXJlbnQgWS1mbGlwIHZzIHRoZSByb290ICh0aGUgY2xhc3NpYyByZW5kZXItdGV4dHVyZSBmbGlwKSwgc28gdGhlXG4gICAqIHNhbWUgcmVxdWVzdGVkIGBmbGlwWWAgbGFuZHMgd2l0aCB0aGUgb3Bwb3NpdGUgd2luZGluZyBkZXBlbmRpbmcgb24gYGlzUm9vdGAuIFdlYkdQVSBoYXMgbm8gc3VjaFxuICAgKiBpbmhlcmVudCBmbGlwLCBzbyB0aGVyZSBpdCBpcyBzaW1wbHkgYGZsaXBZYC4gVGhpcyBpcyB0aGUgb25lIHNwZWxsaW5nIG9mIHRoZSBydWxlOiB0aGUgd2luZGluZyBlYWNoXG4gICAqIGJhY2tlbmQgYmFrZXMgYXQgYmluZCAoe0BsaW5rIEdsU3RhdGVTeXN0ZW19IC8ge0BsaW5rIFBpcGVsaW5lU3lzdGVtfSkgY29tZXMgZnJvbSBoZXJlIHRvbywgc29cbiAgICogY29uc3VtZXJzIChlLmcuIDNEIHBpcGVsaW5lcykgcmVhZCB0aGUgcmVzb2x2ZWQgb3JpZW50YXRpb24gaW5zdGVhZCBvZiByZS1kZXJpdmluZyBpdC5cbiAgICogQHBhcmFtIHJlbmRlclRhcmdldCAtIHRoZSB0YXJnZXQgdG8gYXNrIGFib3V0OyBvbWl0IGZvciB0aGUgY3VycmVudCBiaW5kXG4gICAqIEBwYXJhbSBmbGlwWSAtIHRoZSBgZmxpcFlgIHRoZSB0YXJnZXQgd291bGQgYmUgYm91bmQgd2l0aDsgaWdub3JlZCB3aGVuIGByZW5kZXJUYXJnZXRgIGlzIG9taXR0ZWRcbiAgICogQHJldHVybnMgd2hldGhlciB0aGUgZnJvbnQgZmFjZSBpcyBpbnZlcnRlZFxuICAgKi9cbiAgaXNGcm9udEZhY2VJbnZlcnRlZChyZW5kZXJUYXJnZXQsIGZsaXBZKSB7XG4gICAgaWYgKCFyZW5kZXJUYXJnZXQpIHtcbiAgICAgIHJlbmRlclRhcmdldCA9IHRoaXMucmVuZGVyVGFyZ2V0O1xuICAgICAgaWYgKCFyZW5kZXJUYXJnZXQpIHJldHVybiBmYWxzZTtcbiAgICAgIGZsaXBZID0gcmVuZGVyVGFyZ2V0LmZsaXBZO1xuICAgIH1cbiAgICByZXR1cm4gISFmbGlwWSAhPT0gKHRoaXMuX3JlbmRlcmVyLnR5cGUgPT09IFJlbmRlcmVyVHlwZS5XRUJHTCAmJiAhcmVuZGVyVGFyZ2V0LmlzUm9vdCk7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBlZmZlY3RpdmUgZnJvbnQtZmFjZSBvcmllbnRhdGlvbiBvZiB0aGUgY3VycmVudCBiaW5kLlxuICAgKiBAZGVwcmVjYXRlZCBzaW5jZSA4LjIxLjAsIHVzZSB7QGxpbmsgaXNGcm9udEZhY2VJbnZlcnRlZH0gaW5zdGVhZFxuICAgKiBAcmV0dXJucyB3aGV0aGVyIHRoZSBjdXJyZW50IGJpbmQncyBmcm9udCBmYWNlIGlzIGludmVydGVkXG4gICAqL1xuICBnZXQgZnJvbnRGYWNlSW52ZXJ0ZWQoKSB7XG4gICAgZGVwcmVjYXRpb24odjhfMjFfMCwgXCJSZW5kZXJUYXJnZXRTeXN0ZW0uZnJvbnRGYWNlSW52ZXJ0ZWQgaXMgZGVwcmVjYXRlZCwgdXNlIGlzRnJvbnRGYWNlSW52ZXJ0ZWQoKSBpbnN0ZWFkXCIpO1xuICAgIHJldHVybiB0aGlzLmlzRnJvbnRGYWNlSW52ZXJ0ZWQoKTtcbiAgfVxuICBjbGVhcih0YXJnZXQsIGNsZWFyID0gQ0xFQVIuQUxMLCBjbGVhckNvbG9yLCBtaXBMZXZlbCA9IHRoaXMubWlwTGV2ZWwsIGxheWVyID0gdGhpcy5sYXllcikge1xuICAgIGlmICghY2xlYXIpIHJldHVybjtcbiAgICBpZiAodGFyZ2V0KSB7XG4gICAgICB0YXJnZXQgPSB0aGlzLmdldFJlbmRlclRhcmdldCh0YXJnZXQpO1xuICAgIH1cbiAgICB0aGlzLmFkYXB0b3IuY2xlYXIoXG4gICAgICB0YXJnZXQgfHwgdGhpcy5yZW5kZXJUYXJnZXQsXG4gICAgICBjbGVhcixcbiAgICAgIGNsZWFyQ29sb3IsXG4gICAgICB0aGlzLnZpZXdwb3J0LFxuICAgICAgbWlwTGV2ZWwsXG4gICAgICBsYXllclxuICAgICk7XG4gIH1cbiAgY29udGV4dENoYW5nZSgpIHtcbiAgICB0aGlzLl9ncHVSZW5kZXJUYXJnZXRIYXNoID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIH1cbiAgcHVzaChzdXJmYWNlT3JPcHRpb25zLCBjbGVhciA9IENMRUFSLkFMTCwgY2xlYXJDb2xvciwgZnJhbWUsIG1pcExldmVsID0gMCwgbGF5ZXIgPSAwLCBmbGlwWSkge1xuICAgIGxldCBvcHRpb25zO1xuICAgIGlmIChcInRhcmdldFwiIGluIHN1cmZhY2VPck9wdGlvbnMpIHtcbiAgICAgIG9wdGlvbnMgPSBzdXJmYWNlT3JPcHRpb25zO1xuICAgIH0gZWxzZSB7XG4gICAgICBkZXByZWNhdGlvbihcIjguMjAuMFwiLCBcIlJlbmRlclRhcmdldFN5c3RlbS5wdXNoOiBwb3NpdGlvbmFsIGFyZ3VtZW50cyBhcmUgZGVwcmVjYXRlZCwgcGxlYXNlIHVzZSBhbiBvcHRpb25zIG9iamVjdCBpbnN0ZWFkOiBwdXNoKHsgdGFyZ2V0LCBjbGVhciwgY2xlYXJDb2xvciwgZnJhbWUsIG1pcExldmVsLCBsYXllciwgZmxpcFkgfSlcIik7XG4gICAgICBvcHRpb25zID0geyB0YXJnZXQ6IHN1cmZhY2VPck9wdGlvbnMsIGNsZWFyLCBjbGVhckNvbG9yLCBmcmFtZSwgbWlwTGV2ZWwsIGxheWVyLCBmbGlwWSB9O1xuICAgIH1cbiAgICBjb25zdCByZW5kZXJUYXJnZXQgPSB0aGlzLmJpbmQob3B0aW9ucyk7XG4gICAgdGhpcy5fcmVuZGVyVGFyZ2V0U3RhY2sucHVzaCh7XG4gICAgICB0YXJnZXQ6IG9wdGlvbnMudGFyZ2V0LFxuICAgICAgY2xlYXI6IGZhbHNlLFxuICAgICAgY2xlYXJDb2xvcjogdm9pZCAwLFxuICAgICAgZnJhbWU6IG9wdGlvbnMuZnJhbWUgPyBvcHRpb25zLmZyYW1lLmNsb25lKCkgOiB2b2lkIDAsXG4gICAgICBtaXBMZXZlbDogb3B0aW9ucy5taXBMZXZlbCxcbiAgICAgIGxheWVyOiBvcHRpb25zLmxheWVyLFxuICAgICAgZmxpcFk6IG9wdGlvbnMuZmxpcFlcbiAgICB9KTtcbiAgICByZXR1cm4gcmVuZGVyVGFyZ2V0O1xuICB9XG4gIC8qKlxuICAgKiBQb3BzIHRoZSBjdXJyZW50IHJlbmRlciB0YXJnZXQgYW5kIHJlc3RvcmVzIHRoZSBwcmV2aW91cyBiaW5kaW5nLlxuICAgKiBAcmV0dXJucyB0aGUgcmVuZGVyIHRhcmdldCB0aGF0IHdhcyByZXN0b3JlZFxuICAgKi9cbiAgcG9wKCkge1xuICAgIHRoaXMuX3JlbmRlclRhcmdldFN0YWNrLnBvcCgpO1xuICAgIGNvbnN0IHByZXZpb3VzID0gdGhpcy5fcmVuZGVyVGFyZ2V0U3RhY2tbdGhpcy5fcmVuZGVyVGFyZ2V0U3RhY2subGVuZ3RoIC0gMV07XG4gICAgaWYgKCFwcmV2aW91cykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiW1JlbmRlclRhcmdldFN5c3RlbV0gcG9wOiBubyBwcmV2aW91cyBiaW5kaW5nIHRvIHJlc3RvcmUgKHVuYmFsYW5jZWQgcG9wKVwiKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuYmluZChwcmV2aW91cyk7XG4gIH1cbiAgLyoqXG4gICAqIEdldHMgdGhlIHJlbmRlciB0YXJnZXQgZnJvbSB0aGUgcHJvdmlkZSByZW5kZXIgc3VyZmFjZS4gRWcgaWYgaXRzIGEgdGV4dHVyZSxcbiAgICogaXQgd2lsbCByZXR1cm4gdGhlIHJlbmRlciB0YXJnZXQgZm9yIHRoZSB0ZXh0dXJlLlxuICAgKiBJZiBpdHMgYSByZW5kZXIgdGFyZ2V0LCBpdCB3aWxsIHJldHVybiB0aGUgc2FtZSByZW5kZXIgdGFyZ2V0LlxuICAgKiBAcGFyYW0gcmVuZGVyU3VyZmFjZSAtIHRoZSByZW5kZXIgc3VyZmFjZSB0byBnZXQgdGhlIHJlbmRlciB0YXJnZXQgZm9yXG4gICAqIEByZXR1cm5zIHRoZSByZW5kZXIgdGFyZ2V0IGZvciB0aGUgcmVuZGVyIHN1cmZhY2VcbiAgICovXG4gIGdldFJlbmRlclRhcmdldChyZW5kZXJTdXJmYWNlKSB7XG4gICAgaWYgKHJlbmRlclN1cmZhY2UuaXNUZXh0dXJlKSB7XG4gICAgICByZW5kZXJTdXJmYWNlID0gcmVuZGVyU3VyZmFjZS5zb3VyY2U7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9yZW5kZXJTdXJmYWNlVG9SZW5kZXJUYXJnZXRIYXNoLmdldChyZW5kZXJTdXJmYWNlKSA/PyB0aGlzLl9pbml0UmVuZGVyVGFyZ2V0KHJlbmRlclN1cmZhY2UpO1xuICB9XG4gIC8qKlxuICAgKiBDb3BpZXMgYSByZW5kZXIgc3VyZmFjZSB0byBhbm90aGVyIHRleHR1cmUuXG4gICAqXG4gICAqIE5PVEU6XG4gICAqIGZvciBzb3VyY2VSZW5kZXJTdXJmYWNlVGV4dHVyZSwgVGhlIHJlbmRlciB0YXJnZXQgbXVzdCBiZSBzb21ldGhpbmcgdGhhdCBpcyB3cml0dGVuIHRvbyBieSB0aGUgcmVuZGVyZXJcbiAgICpcbiAgICogVGhlIGZvbGxvd2luZyBpcyBub3QgdmFsaWQ6XG4gICAqIEBleGFtcGxlXG4gICAqIGNvbnN0IGNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpXG4gICAqIGNhbnZhcy53aWR0aCA9IDIwMDtcbiAgICogY2FudmFzLmhlaWdodCA9IDIwMDtcbiAgICpcbiAgICogY29uc3QgY3R4ID0gY2FudmFzMi5nZXRDb250ZXh0KCcyZCcpIVxuICAgKiBjdHguZmlsbFN0eWxlID0gJ3JlZCdcbiAgICogY3R4LmZpbGxSZWN0KDAsIDAsIDIwMCwgMjAwKTtcbiAgICpcbiAgICogY29uc3QgdGV4dHVyZSA9IFJlbmRlclRleHR1cmUuY3JlYXRlKHtcbiAgICogICB3aWR0aDogMjAwLFxuICAgKiAgIGhlaWdodDogMjAwLFxuICAgKiB9KVxuICAgKiBjb25zdCByZW5kZXJUYXJnZXQgPSByZW5kZXJlci5yZW5kZXJUYXJnZXQuZ2V0UmVuZGVyVGFyZ2V0KGNhbnZhczIpO1xuICAgKlxuICAgKiByZW5kZXJlci5yZW5kZXJUYXJnZXQuY29weVRvVGV4dHVyZShyZW5kZXJUYXJnZXQsdGV4dHVyZSwge3g6MCx5OjB9LHt3aWR0aDoyMDAsaGVpZ2h0OjIwMH0se3g6MCx5OjB9KTtcbiAgICpcbiAgICogVGhlIGJlc3Qgd2F5IHRvIGNvcHkgYSBjYW52YXMgaXMgdG8gY3JlYXRlIGEgdGV4dHVyZSBmcm9tIGl0LiBUaGVuIHJlbmRlciB3aXRoIHRoYXQuXG4gICAqXG4gICAqIFBhcnNpbmcgaW4gYSBSZW5kZXJUYXJnZXQgY2FudmFzIGNvbnRleHQgKHdpdGggYSAyZCBjb250ZXh0KVxuICAgKiBAcGFyYW0gc291cmNlUmVuZGVyU3VyZmFjZSAtIHRoZSByZW5kZXIgc3VyZmFjZSAocmVuZGVyIHRhcmdldCwgdGV4dHVyZSwgb3IgY2FudmFzKSB0byBjb3B5IGZyb21cbiAgICogQHBhcmFtIHtUZXh0dXJlfSBkZXN0aW5hdGlvblRleHR1cmUgLSB0aGUgdGV4dHVyZSB0byBjb3B5IHRvXG4gICAqIEBwYXJhbSB7b2JqZWN0fSBvcmlnaW5TcmMgLSB0aGUgb3JpZ2luIG9mIHRoZSBjb3B5XG4gICAqIEBwYXJhbSB7bnVtYmVyfSBvcmlnaW5TcmMueCAtIHRoZSB4IG9yaWdpbiBvZiB0aGUgY29weVxuICAgKiBAcGFyYW0ge251bWJlcn0gb3JpZ2luU3JjLnkgLSB0aGUgeSBvcmlnaW4gb2YgdGhlIGNvcHlcbiAgICogQHBhcmFtIHtvYmplY3R9IHNpemUgLSB0aGUgc2l6ZSBvZiB0aGUgY29weVxuICAgKiBAcGFyYW0ge251bWJlcn0gc2l6ZS53aWR0aCAtIHRoZSB3aWR0aCBvZiB0aGUgY29weVxuICAgKiBAcGFyYW0ge251bWJlcn0gc2l6ZS5oZWlnaHQgLSB0aGUgaGVpZ2h0IG9mIHRoZSBjb3B5XG4gICAqIEBwYXJhbSB7b2JqZWN0fSBvcmlnaW5EZXN0IC0gdGhlIGRlc3RpbmF0aW9uIG9yaWdpbiAodG9wIGxlZnQgdG8gcGFzdGUgZnJvbSEpXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBvcmlnaW5EZXN0LnggLSB0aGUgeCBvcmlnaW4gb2YgdGhlIHBhc3RlXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBvcmlnaW5EZXN0LnkgLSB0aGUgeSBvcmlnaW4gb2YgdGhlIHBhc3RlXG4gICAqL1xuICBjb3B5VG9UZXh0dXJlKHNvdXJjZVJlbmRlclN1cmZhY2UsIGRlc3RpbmF0aW9uVGV4dHVyZSwgb3JpZ2luU3JjLCBzaXplLCBvcmlnaW5EZXN0KSB7XG4gICAgY29uc3Qgc291cmNlUmVuZGVyVGFyZ2V0ID0gdGhpcy5nZXRSZW5kZXJUYXJnZXQoc291cmNlUmVuZGVyU3VyZmFjZSk7XG4gICAgaWYgKG9yaWdpblNyYy54IDwgMCkge1xuICAgICAgc2l6ZS53aWR0aCArPSBvcmlnaW5TcmMueDtcbiAgICAgIG9yaWdpbkRlc3QueCAtPSBvcmlnaW5TcmMueDtcbiAgICAgIG9yaWdpblNyYy54ID0gMDtcbiAgICB9XG4gICAgaWYgKG9yaWdpblNyYy55IDwgMCkge1xuICAgICAgc2l6ZS5oZWlnaHQgKz0gb3JpZ2luU3JjLnk7XG4gICAgICBvcmlnaW5EZXN0LnkgLT0gb3JpZ2luU3JjLnk7XG4gICAgICBvcmlnaW5TcmMueSA9IDA7XG4gICAgfVxuICAgIGNvbnN0IHsgcGl4ZWxXaWR0aCwgcGl4ZWxIZWlnaHQgfSA9IHNvdXJjZVJlbmRlclRhcmdldDtcbiAgICBzaXplLndpZHRoID0gTWF0aC5taW4oc2l6ZS53aWR0aCwgcGl4ZWxXaWR0aCAtIG9yaWdpblNyYy54KTtcbiAgICBzaXplLmhlaWdodCA9IE1hdGgubWluKHNpemUuaGVpZ2h0LCBwaXhlbEhlaWdodCAtIG9yaWdpblNyYy55KTtcbiAgICByZXR1cm4gdGhpcy5hZGFwdG9yLmNvcHlUb1RleHR1cmUoXG4gICAgICBzb3VyY2VSZW5kZXJUYXJnZXQsXG4gICAgICBkZXN0aW5hdGlvblRleHR1cmUsXG4gICAgICBvcmlnaW5TcmMsXG4gICAgICBzaXplLFxuICAgICAgb3JpZ2luRGVzdFxuICAgICk7XG4gIH1cbiAgLyoqXG4gICAqIENvcGllcyB0aGUgZGVwdGggYXR0YWNobWVudCBmcm9tIG9uZSByZW5kZXIgdGFyZ2V0IHRvIGFub3RoZXIuXG4gICAqIEJvdGggc291cmNlIGFuZCBkZXN0aW5hdGlvbiBtdXN0IGhhdmUgYSBkZXB0aFN0ZW5jaWxBdHRhY2htZW50LlxuICAgKlxuICAgKiAqKkltcG9ydGFudCBOb3RlOioqIFdoZW4gdXNpbmcgdGhlIGNvcGllZCBkZXB0aCBidWZmZXIgaW4gYSBzdWJzZXF1ZW50IHJlbmRlciBwYXNzLFxuICAgKiB5b3UgbXVzdCBlbnN1cmUgeW91IGRvIG5vdCBjbGVhciB0aGUgZGVwdGggYnVmZmVyIGFnYWluLiBJZiB5b3UgbmVlZCB0byBjbGVhciB0aGUgY29sb3JcbiAgICogYnVmZmVyIG9mIHRoZSBkZXN0aW5hdGlvbiByZW5kZXIgdGFyZ2V0LCB1c2UgYGNsZWFyOiBDTEVBUi5DT0xPUmAgdG8gcHJlc2VydmUgdGhlIGNvcGllZCBkZXB0aCBkYXRhLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGBqc1xuICAgKiByZW5kZXJlci5yZW5kZXJUYXJnZXQuY29weURlcHRoVGV4dHVyZShcbiAgICogICBzb3VyY2VSVCwgZGVzdFJULCB7IHg6IDAsIHk6IDAgfSwgeyB3aWR0aDogMjAwLCBoZWlnaHQ6IDIwMCB9LCB7IHg6IDAsIHk6IDAgfVxuICAgKiApO1xuICAgKlxuICAgKiAvLyBJbiB0aGUgc3Vic2VxdWVudCByZW5kZXIgcGFzcywgY2xlYXIgT05MWSB0aGUgY29sb3IgYnVmZmVyIVxuICAgKiByZW5kZXJlci5yZW5kZXIoe1xuICAgKiAgIHRhcmdldDogZGVzdFJULFxuICAgKiAgIGNvbnRhaW5lcjogbXlNZXNoLFxuICAgKiAgIGNsZWFyOiBDTEVBUi5DT0xPUiwgLy8gUHJlc2VydmVzIHRoZSBjb3BpZWQgZGVwdGhcbiAgICogICBjbGVhckNvbG9yOiBbMCwgMCwgMCwgMV1cbiAgICogfSk7XG4gICAqIGBgYFxuICAgKiBAcGFyYW0gc291cmNlIC0gdGhlIHJlbmRlciBzdXJmYWNlIChyZW5kZXIgdGFyZ2V0LCBkZXB0aCB0ZXh0dXJlLCBvciBjYW52YXMpIHRvIGNvcHkgZGVwdGggZnJvbVxuICAgKiBAcGFyYW0gZGVzdGluYXRpb24gLSB0aGUgZGVwdGgvc3RlbmNpbCB0ZXh0dXJlIHRvIGNvcHkgZGVwdGggdG9cbiAgICogQHBhcmFtIHtvYmplY3R9IG9yaWdpblNyYyAtIHRoZSBvcmlnaW4gb2YgdGhlIGNvcHlcbiAgICogQHBhcmFtIHtudW1iZXJ9IG9yaWdpblNyYy54IC0gdGhlIHggb3JpZ2luIG9mIHRoZSBjb3B5XG4gICAqIEBwYXJhbSB7bnVtYmVyfSBvcmlnaW5TcmMueSAtIHRoZSB5IG9yaWdpbiBvZiB0aGUgY29weVxuICAgKiBAcGFyYW0ge29iamVjdH0gc2l6ZSAtIHRoZSBzaXplIG9mIHRoZSBjb3B5XG4gICAqIEBwYXJhbSB7bnVtYmVyfSBzaXplLndpZHRoIC0gdGhlIHdpZHRoIG9mIHRoZSBjb3B5XG4gICAqIEBwYXJhbSB7bnVtYmVyfSBzaXplLmhlaWdodCAtIHRoZSBoZWlnaHQgb2YgdGhlIGNvcHlcbiAgICogQHBhcmFtIHtvYmplY3R9IG9yaWdpbkRlc3QgLSB0aGUgZGVzdGluYXRpb24gb3JpZ2luICh0b3AgbGVmdCB0byBwYXN0ZSBmcm9tISlcbiAgICogQHBhcmFtIHtudW1iZXJ9IG9yaWdpbkRlc3QueCAtIHRoZSB4IG9yaWdpbiBvZiB0aGUgcGFzdGVcbiAgICogQHBhcmFtIHtudW1iZXJ9IG9yaWdpbkRlc3QueSAtIHRoZSB5IG9yaWdpbiBvZiB0aGUgcGFzdGVcbiAgICovXG4gIGNvcHlEZXB0aFRleHR1cmUoc291cmNlLCBkZXN0aW5hdGlvbiwgb3JpZ2luU3JjLCBzaXplLCBvcmlnaW5EZXN0ID0geyB4OiAwLCB5OiAwIH0pIHtcbiAgICBjb25zdCBzb3VyY2VSZW5kZXJUYXJnZXQgPSB0aGlzLmdldFJlbmRlclRhcmdldChzb3VyY2UpO1xuICAgIGlmICghc291cmNlUmVuZGVyVGFyZ2V0LmRlcHRoU3RlbmNpbEF0dGFjaG1lbnQpIHtcbiAgICAgIHdhcm4oXCJbUmVuZGVyVGFyZ2V0U3lzdGVtXSBjb3B5RGVwdGhUZXh0dXJlOiB0aGUgc291cmNlIHJlbmRlciB0YXJnZXQgaGFzIG5vIGRlcHRoIGF0dGFjaG1lbnQgdG8gY29weSBmcm9tXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBkZXN0U291cmNlID0gZGVzdGluYXRpb24uc291cmNlO1xuICAgIGlmICghZGVzdFNvdXJjZS5mb3JtYXQuaW5jbHVkZXMoXCJkZXB0aFwiKSAmJiAhZGVzdFNvdXJjZS5mb3JtYXQuaW5jbHVkZXMoXCJzdGVuY2lsXCIpKSB7XG4gICAgICB3YXJuKGBbUmVuZGVyVGFyZ2V0U3lzdGVtXSBjb3B5RGVwdGhUZXh0dXJlOiB0aGUgZGVzdGluYXRpb24gdGV4dHVyZSBtdXN0IGhhdmUgYSBkZXB0aC9zdGVuY2lsIGZvcm1hdCAoZ290ICcke2Rlc3RTb3VyY2UuZm9ybWF0fScpYCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCBzcmNYID0gb3JpZ2luU3JjLng7XG4gICAgbGV0IHNyY1kgPSBvcmlnaW5TcmMueTtcbiAgICBsZXQgZGVzdFggPSBvcmlnaW5EZXN0Lng7XG4gICAgbGV0IGRlc3RZID0gb3JpZ2luRGVzdC55O1xuICAgIGxldCB3aWR0aCA9IHNpemUud2lkdGg7XG4gICAgbGV0IGhlaWdodCA9IHNpemUuaGVpZ2h0O1xuICAgIGlmIChzcmNYIDwgMCkge1xuICAgICAgd2lkdGggKz0gc3JjWDtcbiAgICAgIGRlc3RYIC09IHNyY1g7XG4gICAgICBzcmNYID0gMDtcbiAgICB9XG4gICAgaWYgKHNyY1kgPCAwKSB7XG4gICAgICBoZWlnaHQgKz0gc3JjWTtcbiAgICAgIGRlc3RZIC09IHNyY1k7XG4gICAgICBzcmNZID0gMDtcbiAgICB9XG4gICAgd2lkdGggPSBNYXRoLm1pbih3aWR0aCwgc291cmNlUmVuZGVyVGFyZ2V0LnBpeGVsV2lkdGggLSBzcmNYKTtcbiAgICBoZWlnaHQgPSBNYXRoLm1pbihoZWlnaHQsIHNvdXJjZVJlbmRlclRhcmdldC5waXhlbEhlaWdodCAtIHNyY1kpO1xuICAgIHdpZHRoID0gTWF0aC5taW4od2lkdGgsIGRlc3RTb3VyY2UucGl4ZWxXaWR0aCAtIGRlc3RYKTtcbiAgICBoZWlnaHQgPSBNYXRoLm1pbihoZWlnaHQsIGRlc3RTb3VyY2UucGl4ZWxIZWlnaHQgLSBkZXN0WSk7XG4gICAgaWYgKHdpZHRoIDw9IDAgfHwgaGVpZ2h0IDw9IDApIHJldHVybjtcbiAgICB0aGlzLmFkYXB0b3IuY29weURlcHRoVGV4dHVyZShcbiAgICAgIHNvdXJjZVJlbmRlclRhcmdldCxcbiAgICAgIGRlc3RpbmF0aW9uLFxuICAgICAgeyB4OiBzcmNYLCB5OiBzcmNZIH0sXG4gICAgICB7IHdpZHRoLCBoZWlnaHQgfSxcbiAgICAgIHsgeDogZGVzdFgsIHk6IGRlc3RZIH1cbiAgICApO1xuICB9XG4gIC8qKlxuICAgKiBlbnN1cmVzIHRoYXQgd2UgaGF2ZSBhIGRlcHRoIHN0ZW5jaWwgYnVmZmVyIGF2YWlsYWJsZSB0byByZW5kZXIgdG9cbiAgICogVGhpcyBpcyB1c2VkIGJ5IHRoZSBtYXNrIHN5c3RlbSB0byBtYWtlIHN1cmUgd2UgaGF2ZSBhIHN0ZW5jaWwgYnVmZmVyLlxuICAgKi9cbiAgZW5zdXJlRGVwdGhTdGVuY2lsKCkge1xuICAgIGlmICghdGhpcy5yZW5kZXJUYXJnZXQuc3RlbmNpbCkge1xuICAgICAgaWYgKHRoaXMucmVuZGVyVGFyZ2V0LmRlcHRoU3RlbmNpbFRleHR1cmUpIHtcbiAgICAgICAgd2FybihgW1JlbmRlclRhcmdldFN5c3RlbV0gYSBzdGVuY2lsIG1hc2sgaXMgYmVpbmcgdXNlZCwgYnV0IHRoZSByZW5kZXIgdGFyZ2V0J3MgZGVwdGhTdGVuY2lsVGV4dHVyZSBmb3JtYXQgJyR7dGhpcy5yZW5kZXJUYXJnZXQuZGVwdGhTdGVuY2lsVGV4dHVyZS5mb3JtYXR9JyBoYXMgbm8gc3RlbmNpbCBhc3BlY3QsIHNvIG1hc2tpbmcgY2Fubm90IHdvcmsgaGVyZS4gVXNlIGEgJ2RlcHRoMjRwbHVzLXN0ZW5jaWw4JyB0ZXh0dXJlIGluc3RlYWQuYCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHRoaXMucmVuZGVyVGFyZ2V0Ll9kZXB0aCA9IHRydWU7XG4gICAgICB0aGlzLnJlbmRlclRhcmdldC5fc3RlbmNpbCA9IHRydWU7XG4gICAgICB0aGlzLmFkYXB0b3Iuc3RhcnRSZW5kZXJQYXNzKHRoaXMucmVuZGVyVGFyZ2V0LCBmYWxzZSwgbnVsbCwgdGhpcy52aWV3cG9ydCwgMCwgdGhpcy5sYXllcik7XG4gICAgfVxuICB9XG4gIC8qKiBudWtlcyB0aGUgcmVuZGVyIHRhcmdldCBzeXN0ZW0gKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IG51bGw7XG4gICAgdGhpcy5fcmVuZGVyU3VyZmFjZVRvUmVuZGVyVGFyZ2V0SGFzaC5mb3JFYWNoKChyZW5kZXJUYXJnZXQsIGtleSkgPT4ge1xuICAgICAgaWYgKHJlbmRlclRhcmdldCAhPT0ga2V5KSB7XG4gICAgICAgIHRoaXMuX3JlbGVhc2VSZW5kZXJUYXJnZXQoa2V5LCByZW5kZXJUYXJnZXQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVuZGVyVGFyZ2V0Lm9mZihcImRlc3Ryb3lcIiwgdGhpcy5fb25SZW5kZXJUYXJnZXREZXN0cm95LCB0aGlzKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICB0aGlzLl9yZW5kZXJTdXJmYWNlVG9SZW5kZXJUYXJnZXRIYXNoLmNsZWFyKCk7XG4gICAgZm9yIChjb25zdCBncHVSZW5kZXJUYXJnZXQgb2YgT2JqZWN0LnZhbHVlcyh0aGlzLl9ncHVSZW5kZXJUYXJnZXRIYXNoKSkge1xuICAgICAgaWYgKGdwdVJlbmRlclRhcmdldCkgdGhpcy5hZGFwdG9yLmRlc3Ryb3lHcHVSZW5kZXJUYXJnZXQoZ3B1UmVuZGVyVGFyZ2V0KTtcbiAgICB9XG4gICAgdGhpcy5fZ3B1UmVuZGVyVGFyZ2V0SGFzaCA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICB9XG4gIF9pbml0UmVuZGVyVGFyZ2V0KHJlbmRlclN1cmZhY2UpIHtcbiAgICBsZXQgcmVuZGVyVGFyZ2V0ID0gbnVsbDtcbiAgICBpZiAoQ2FudmFzU291cmNlLnRlc3QocmVuZGVyU3VyZmFjZSkpIHtcbiAgICAgIHJlbmRlclN1cmZhY2UgPSBnZXRDYW52YXNUZXh0dXJlKHJlbmRlclN1cmZhY2UpLnNvdXJjZTtcbiAgICB9XG4gICAgaWYgKHJlbmRlclN1cmZhY2UgaW5zdGFuY2VvZiBSZW5kZXJUYXJnZXQpIHtcbiAgICAgIHJlbmRlclRhcmdldCA9IHJlbmRlclN1cmZhY2U7XG4gICAgICByZW5kZXJTdXJmYWNlLm9uY2UoXCJkZXN0cm95XCIsIHRoaXMuX29uUmVuZGVyVGFyZ2V0RGVzdHJveSwgdGhpcyk7XG4gICAgfSBlbHNlIGlmIChyZW5kZXJTdXJmYWNlIGluc3RhbmNlb2YgVGV4dHVyZVNvdXJjZSkge1xuICAgICAgY29uc3QgZm9ybWF0ID0gcmVuZGVyU3VyZmFjZS5mb3JtYXQ7XG4gICAgICBjb25zdCBpc0RlcHRoU3RlbmNpbCA9IGZvcm1hdC5pbmNsdWRlcyhcImRlcHRoXCIpIHx8IGZvcm1hdC5pbmNsdWRlcyhcInN0ZW5jaWxcIik7XG4gICAgICByZW5kZXJUYXJnZXQgPSBpc0RlcHRoU3RlbmNpbCA/IG5ldyBSZW5kZXJUYXJnZXQoeyBjb2xvclRleHR1cmVzOiAwLCBkZXB0aFN0ZW5jaWxUZXh0dXJlOiByZW5kZXJTdXJmYWNlIH0pIDogbmV3IFJlbmRlclRhcmdldCh7IGNvbG9yVGV4dHVyZXM6IFtyZW5kZXJTdXJmYWNlXSB9KTtcbiAgICAgIGlmIChyZW5kZXJTdXJmYWNlLnNvdXJjZSBpbnN0YW5jZW9mIENhbnZhc1NvdXJjZSkge1xuICAgICAgICByZW5kZXJUYXJnZXQuaXNSb290ID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIHJlbmRlclN1cmZhY2Uub25jZShcImRlc3Ryb3lcIiwgdGhpcy5fb25SZW5kZXJTdXJmYWNlRGVzdHJveSwgdGhpcyk7XG4gICAgfVxuICAgIHRoaXMuX3JlbmRlclN1cmZhY2VUb1JlbmRlclRhcmdldEhhc2guc2V0KHJlbmRlclN1cmZhY2UsIHJlbmRlclRhcmdldCk7XG4gICAgcmV0dXJuIHJlbmRlclRhcmdldDtcbiAgfVxuICBfb25SZW5kZXJTdXJmYWNlRGVzdHJveShyZW5kZXJTdXJmYWNlKSB7XG4gICAgY29uc3QgcmVuZGVyVGFyZ2V0ID0gdGhpcy5fcmVuZGVyU3VyZmFjZVRvUmVuZGVyVGFyZ2V0SGFzaC5nZXQocmVuZGVyU3VyZmFjZSk7XG4gICAgaWYgKHJlbmRlclRhcmdldCkgdGhpcy5fcmVsZWFzZVJlbmRlclRhcmdldChyZW5kZXJTdXJmYWNlLCByZW5kZXJUYXJnZXQpO1xuICB9XG4gIC8qKlxuICAgKiBBIGNhbGxlci1vd25lZCByZW5kZXIgdGFyZ2V0IGlzIHRlYXJpbmcgaXRzZWxmIGRvd24uIEl0IHJlbGVhc2VzIGl0cyBvd24gYXR0YWNobWVudHMsXG4gICAqIHNvIG9ubHkgdGhlIHN5c3RlbSdzIHJlZmVyZW5jZXMgdG8gaXQgYW5kIHRoZSBiYWNrZW5kIG9iamVjdHMgYnVpbHQgZm9yIGl0IGdvIGhlcmUuXG4gICAqIEBwYXJhbSByZW5kZXJUYXJnZXQgLSB0aGUgcmVuZGVyIHRhcmdldCBiZWluZyBkZXN0cm95ZWRcbiAgICovXG4gIF9vblJlbmRlclRhcmdldERlc3Ryb3kocmVuZGVyVGFyZ2V0KSB7XG4gICAgdGhpcy5fcmVuZGVyU3VyZmFjZVRvUmVuZGVyVGFyZ2V0SGFzaC5kZWxldGUocmVuZGVyVGFyZ2V0KTtcbiAgICB0aGlzLl9yZWxlYXNlR3B1UmVuZGVyVGFyZ2V0KHJlbmRlclRhcmdldCk7XG4gIH1cbiAgLyoqXG4gICAqIFRlYXJzIGRvd24gYSByZW5kZXIgdGFyZ2V0IHRoYXQgd3JhcHMgYSB0ZXh0dXJlIHNvdXJjZSwgcmVtb3ZpbmcgZXZlcnkgcmVmZXJlbmNlIHRoZVxuICAgKiBzeXN0ZW0gaG9sZHMgdG8gaXQgc28gbmVpdGhlciB0aGUgc3lzdGVtJ3Mgb3duIHRlYXJkb3duIG5vciB0aGUgc291cmNlJ3MgYGRlc3Ryb3lgXG4gICAqIGV2ZW50IGNhbiBkZXN0cm95IGl0IGEgc2Vjb25kIHRpbWUuXG4gICAqIEBwYXJhbSByZW5kZXJTdXJmYWNlIC0gdGhlIHRleHR1cmUgc291cmNlIHRoZSByZW5kZXIgdGFyZ2V0IHdyYXBzXG4gICAqIEBwYXJhbSByZW5kZXJUYXJnZXQgLSB0aGUgcmVuZGVyIHRhcmdldCB0byByZWxlYXNlXG4gICAqL1xuICBfcmVsZWFzZVJlbmRlclRhcmdldChyZW5kZXJTdXJmYWNlLCByZW5kZXJUYXJnZXQpIHtcbiAgICByZW5kZXJUYXJnZXQuZGVzdHJveSgpO1xuICAgIHRoaXMuX3JlbmRlclN1cmZhY2VUb1JlbmRlclRhcmdldEhhc2guZGVsZXRlKHJlbmRlclN1cmZhY2UpO1xuICAgIHJlbmRlclN1cmZhY2Uub2ZmKFwiZGVzdHJveVwiLCB0aGlzLl9vblJlbmRlclN1cmZhY2VEZXN0cm95LCB0aGlzKTtcbiAgICB0aGlzLl9yZWxlYXNlR3B1UmVuZGVyVGFyZ2V0KHJlbmRlclRhcmdldCk7XG4gIH1cbiAgLyoqXG4gICAqIEZyZWVzIHRoZSBiYWNrZW5kIG9iamVjdHMgKGZyYW1lYnVmZmVycywgcmVuZGVyYnVmZmVycywgTVNBQSB0ZXh0dXJlcykgY2FjaGVkIGZvciBhIHJlbmRlciB0YXJnZXQuXG4gICAqIEBwYXJhbSByZW5kZXJUYXJnZXQgLSB0aGUgcmVuZGVyIHRhcmdldCB3aG9zZSBiYWNrZW5kIGNvdW50ZXJwYXJ0IGlzIG5vIGxvbmdlciBuZWVkZWRcbiAgICovXG4gIF9yZWxlYXNlR3B1UmVuZGVyVGFyZ2V0KHJlbmRlclRhcmdldCkge1xuICAgIGNvbnN0IGdwdVJlbmRlclRhcmdldCA9IHRoaXMuX2dwdVJlbmRlclRhcmdldEhhc2hbcmVuZGVyVGFyZ2V0LnVpZF07XG4gICAgaWYgKGdwdVJlbmRlclRhcmdldCkge1xuICAgICAgdGhpcy5fZ3B1UmVuZGVyVGFyZ2V0SGFzaFtyZW5kZXJUYXJnZXQudWlkXSA9IG51bGw7XG4gICAgICB0aGlzLmFkYXB0b3IuZGVzdHJveUdwdVJlbmRlclRhcmdldChncHVSZW5kZXJUYXJnZXQpO1xuICAgIH1cbiAgfVxuICBnZXRHcHVSZW5kZXJUYXJnZXQocmVuZGVyVGFyZ2V0KSB7XG4gICAgcmV0dXJuIHRoaXMuX2dwdVJlbmRlclRhcmdldEhhc2hbcmVuZGVyVGFyZ2V0LnVpZF0gfHwgKHRoaXMuX2dwdVJlbmRlclRhcmdldEhhc2hbcmVuZGVyVGFyZ2V0LnVpZF0gPSB0aGlzLmFkYXB0b3IuaW5pdEdwdVJlbmRlclRhcmdldChyZW5kZXJUYXJnZXQpKTtcbiAgfVxuICByZXNldFN0YXRlKCkge1xuICAgIHRoaXMucmVuZGVyVGFyZ2V0ID0gbnVsbDtcbiAgICB0aGlzLl9iaW5kU3RhdGUudGFyZ2V0ID0gbnVsbDtcbiAgfVxufVxuXG5leHBvcnQgeyBSZW5kZXJUYXJnZXRTeXN0ZW0gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVJlbmRlclRhcmdldFN5c3RlbS5tanMubWFwXG4iXSwibWFwcGluZ3MiOiI7Ozs7QUFHQSxJQUFNLGVBQWUsQ0FBQztBQUN0QixXQUFXLGtCQUFrQixjQUFjLGFBQWEsWUFBWTtBQUNwRSxlQUFlLDBCQUEwQixNQUFNO0NBQzdDLElBQUksTUFBTTtDQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxhQUFhLFFBQVEsS0FBSztFQUM1QyxNQUFNLE1BQU0sYUFBYTtFQUN6QixJQUFJLElBQUksTUFBTSxLQUFLLEdBQUc7R0FDcEIsTUFBTSxJQUFJLE1BQU0sS0FBSztHQUNyQjtFQUNGO0NBQ0Y7QUFDRjtBQUNBLGVBQWUsc0JBQXNCLEtBQUs7Q0FDeEMsT0FBTywwQkFBMEIsQ0FBQyxHQUFHO0FBQ3ZDOzs7QUNoQkEsSUFBSTtBQUNKLFNBQVMsc0JBQXNCO0NBQzdCLElBQUksT0FBTyxlQUFlLFdBQ3hCLE9BQU87Q0FFVCxJQUFJO0VBRUYsYUFBYSxJQURJLFNBQVMsVUFBVSxVQUFVLFVBQVUsbUNBQ3hDLENBQUMsQ0FBQyxFQUFFLEdBQUcsSUFBSSxHQUFHLEtBQUssR0FBRyxNQUFNO0NBQzlDLFNBQVMsSUFBSTtFQUNYLGFBQWE7Q0FDZjtDQUNBLE9BQU87QUFDVDs7O0FDWkEsSUFBSSxRQUF3QixrQkFBRSxXQUFXO0NBQ3ZDLE9BQU8sT0FBTyxVQUFVLEtBQUs7Q0FDN0IsT0FBTyxPQUFPLFdBQVcsU0FBUztDQUNsQyxPQUFPLE9BQU8sYUFBYSxRQUFRO0NBQ25DLE9BQU8sT0FBTyxXQUFXLE9BQU87Q0FDaEMsT0FBTyxPQUFPLGlCQUFpQixTQUFTO0NBQ3hDLE9BQU8sT0FBTyxtQkFBbUIsU0FBUztDQUMxQyxPQUFPLE9BQU8sbUJBQW1CLFFBQVE7Q0FDekMsT0FBTyxPQUFPLFNBQVMsU0FBUztDQUNoQyxPQUFPO0FBQ1QsRUFBQSxDQUFHLFNBQVMsQ0FBQyxDQUFDOzs7QUNWZCxJQUFNLGVBQU4sTUFBbUI7Ozs7Q0FJakIsWUFBWSxNQUFNO0VBQ2hCLEtBQUssUUFBUSxDQUFDO0VBQ2QsS0FBSyxRQUFRO0NBQ2Y7Ozs7O0NBT0EsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7RUFDbkMsTUFBTSxFQUFFLE1BQU0sVUFBVTtFQUN4QixLQUFLLElBQUksSUFBSSxHQUFHLE1BQU0sTUFBTSxRQUFRLElBQUksS0FBSyxLQUMzQyxNQUFNLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFO0VBRS9DLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW1CQSxJQUFJLE1BQU07RUFDUixJQUFJLEtBQUssS0FBSyxRQUFRO0dBQ3BCLEtBQUssT0FBTyxJQUFJO0dBQ2hCLEtBQUssTUFBTSxLQUFLLElBQUk7RUFDdEI7RUFDQSxPQUFPO0NBQ1Q7Ozs7O0NBS0EsT0FBTyxNQUFNO0VBQ1gsTUFBTSxRQUFRLEtBQUssTUFBTSxRQUFRLElBQUk7RUFDckMsSUFBSSxVQUFVLElBQ1osS0FBSyxNQUFNLE9BQU8sT0FBTyxDQUFDO0VBRTVCLE9BQU87Q0FDVDs7Ozs7Q0FLQSxTQUFTLE1BQU07RUFDYixPQUFPLEtBQUssTUFBTSxRQUFRLElBQUksTUFBTTtDQUN0Qzs7Q0FFQSxZQUFZO0VBQ1YsS0FBSyxNQUFNLFNBQVM7RUFDcEIsT0FBTztDQUNUOztDQUVBLFVBQVU7RUFDUixLQUFLLFVBQVU7RUFDZixLQUFLLFFBQVE7RUFDYixLQUFLLFFBQVE7Q0FDZjs7Ozs7Q0FLQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUssTUFBTSxXQUFXO0NBQy9COzs7OztDQUtBLElBQUksT0FBTztFQUNULE9BQU8sS0FBSztDQUNkO0FBQ0Y7OztBQzdFQSxJQUFNLGlCQUFpQjtDQUNyQjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Y7QUFDQSxJQUFNLG9CQUFvQixNQUFNLDBCQUEwQkEsc0JBQWE7Ozs7OztDQU1yRSxZQUFZLFFBQVE7RUFDbEIsTUFBTTs7RUFFTixLQUFLLE9BQU87O0VBRVosS0FBSyxNQUFNQyxNQUFJLFVBQVU7O0VBRXpCLEtBQUssVUFBMEIsdUJBQU8sT0FBTyxJQUFJOztFQUVqRCxLQUFLLGNBQThCLHVCQUFPLE9BQU8sSUFBSTtFQUNyRCxLQUFLLGVBQWUsQ0FBQztFQUNyQixLQUFLLGVBQStCLHVCQUFPLE9BQU8sSUFBSTtFQUN0RCxLQUFLLE9BQU8sT0FBTztFQUNuQixLQUFLLE9BQU8sT0FBTztFQUNuQixLQUFLLFNBQVM7RUFDZCxNQUFNLGtCQUFrQixDQUFDLEdBQUcsZ0JBQWdCLEdBQUcsS0FBSyxPQUFPLFdBQVcsQ0FBQyxDQUFDO0VBQ3hFLEtBQUssWUFBWSxHQUFHLGVBQWU7RUFDbkMsS0FBSyxpQkFBaUI7Q0FDeEI7Ozs7O0NBS0EsTUFBTSxLQUFLLFVBQVUsQ0FBQyxHQUFHO0VBQ3ZCLE1BQU0sT0FBTyxRQUFRLHlCQUF5QixPQUFPLE9BQU8sUUFBUSxrQkFBa0I7RUFDdEYsTUFBTSwwQkFBMEIsSUFBSTtFQUNwQyxJQUFJLENBQUMsUUFBUSxLQUFLLE9BQU8sU0FDdkIsTUFBTSxRQUFRLElBQUksS0FBSyxPQUFPLFFBQVEsS0FBSyxXQUFXLE9BQU8sTUFBTSxLQUFLLENBQUMsQ0FBQztFQUU1RSxLQUFLLFlBQVksS0FBSyxPQUFPLE9BQU87RUFDcEMsS0FBSyxVQUFVLEtBQUssT0FBTyxhQUFhLEtBQUssT0FBTyxrQkFBa0I7RUFDdEUsS0FBSyxNQUFNLGNBQWMsS0FBSyxjQUc1QixVQUFVO0dBQUUsR0FGRyxLQUFLLGFBQWEsV0FDRSxDQUFDLFlBQVk7R0FDWCxHQUFHO0VBQVE7RUFFbEQsVUFBVTtHQUFFLEdBQUcsa0JBQWtCO0dBQWdCLEdBQUc7RUFBUTtFQUM1RCxLQUFLLGVBQWUsUUFBUSxjQUFjLElBQUk7RUFDOUMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLLE1BQU0sUUFBUSxLQUNsRCxNQUFNLEtBQUssUUFBUSxLQUFLLE1BQU0sRUFBRSxDQUFDLEtBQUssT0FBTztFQUUvQyxLQUFLLGVBQWU7Q0FDdEI7Q0FDQSxPQUFPLE1BQU0sWUFBWTtFQUN2QixLQUFLO0VBQ0wsSUFBSSxVQUFVO0VBQ2QsSUFBSSxtQkFBbUIsV0FBVztHQUNoQyxVQUFVLEVBQUUsV0FBVyxRQUFRO0dBQy9CLElBQUksWUFBWTtJQUNkLFlBQVksUUFBUSw0RUFBNEU7SUFDaEcsUUFBUSxTQUFTLFdBQVc7R0FDOUI7RUFDRjtFQUNBLFFBQVEsV0FBVyxRQUFRLFNBQVMsS0FBSyxLQUFLO0VBQzlDLElBQUksUUFBUSxXQUFXLEtBQUssS0FBSyxjQUFjO0dBQzdDLEtBQUssc0JBQXNCLFFBQVE7R0FDbkMsUUFBUSxlQUFlLFFBQVEsYUFBYSxLQUFLLFdBQVc7R0FDNUQsUUFBUSxVQUFVLFFBQVEsUUFBUSxLQUFLLFdBQVc7RUFDcEQ7RUFDQSxJQUFJLFFBQVEsWUFBWTtHQUN0QixNQUFNLGNBQWMsTUFBTSxRQUFRLFFBQVEsVUFBVSxLQUFLLFFBQVEsV0FBVyxXQUFXO0dBQ3ZGLFFBQVEsYUFBYSxjQUFjLFFBQVEsYUFBYSxNQUFNLE9BQU8sU0FBUyxRQUFRLFVBQVUsQ0FBQyxDQUFDLFFBQVE7RUFDNUc7RUFDQSxJQUFJLENBQUMsUUFBUSxXQUFXO0dBQ3RCLFFBQVEsVUFBVSxxQkFBcUI7R0FDdkMsUUFBUSxZQUFZLFFBQVEsVUFBVTtFQUN4QztFQUNBLElBQUksQ0FBQyxRQUFRLFVBQVUsU0FDckI7RUFFRixRQUFRLFVBQVUsa0JBQWtCO0VBQ3BDLEtBQUssUUFBUSxVQUFVLEtBQUssT0FBTztFQUNuQyxLQUFLLFFBQVEsWUFBWSxLQUFLLE9BQU87RUFDckMsS0FBSyxRQUFRLE9BQU8sS0FBSyxPQUFPO0VBQ2hDLEtBQUssUUFBUSxVQUFVLEtBQUssT0FBTztFQUNuQyxLQUFLLFFBQVEsV0FBVyxLQUFLLE9BQU87Q0FDdEM7Ozs7Ozs7Q0FPQSxPQUFPLG9CQUFvQixxQkFBcUIsWUFBWTtFQUMxRCxNQUFNLHFCQUFxQixLQUFLLEtBQUs7RUFDckMsS0FBSyxLQUFLLE9BQU8sb0JBQW9CLHFCQUFxQixVQUFVO0VBQ3BFLEtBQUssS0FBSyxVQUFVLEtBQUssS0FBSyxPQUFPLE9BQU8sS0FBSyxLQUFLLE9BQU8sUUFBUSxLQUFLLEtBQUssVUFBVTtFQUN6RixJQUFJLGVBQWUsS0FBSyxLQUFLLGVBQWUsb0JBQzFDLEtBQUssUUFBUSxpQkFBaUIsS0FBSyxVQUFVO0NBRWpEOzs7Ozs7Ozs7Q0FTQSxNQUFNLFVBQVUsQ0FBQyxHQUFHO0VBQ2xCLE1BQU0sV0FBVztFQUNqQixRQUFRLFdBQVcsUUFBUSxTQUFTLFNBQVMsYUFBYTtFQUMxRCxRQUFRLGVBQWUsUUFBUSxhQUFhLEtBQUssV0FBVztFQUM1RCxRQUFRLFVBQVUsUUFBUSxRQUFRLE1BQU07RUFDeEMsTUFBTSxFQUFFLE9BQU8sWUFBWSxRQUFRLFVBQVUsVUFBVTtFQUN2RCxNQUFNLE9BQU8sU0FBUyxjQUFjLEtBQUssV0FBVyxTQUFTO0VBQzdELFNBQVMsYUFBYSxNQUFNLFFBQVEsT0FBTyxNQUFNLE9BQU8sUUFBUSxHQUFHLFlBQVksR0FBRyxTQUFTLENBQUM7Q0FDOUY7O0NBRUEsSUFBSSxhQUFhO0VBQ2YsT0FBTyxLQUFLLEtBQUs7Q0FDbkI7Q0FDQSxJQUFJLFdBQVcsT0FBTztFQUNwQixLQUFLLEtBQUssYUFBYTtFQUN2QixLQUFLLFFBQVEsaUJBQWlCLEtBQUssS0FBSztDQUMxQzs7Ozs7OztDQU9BLElBQUksUUFBUTtFQUNWLE9BQU8sS0FBSyxLQUFLLFFBQVEsTUFBTTtDQUNqQzs7Ozs7Q0FLQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUssS0FBSyxRQUFRLE1BQU07Q0FDakM7Ozs7O0NBTUEsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLLEtBQUs7Q0FDbkI7Ozs7O0NBS0EsSUFBSSxxQkFBcUI7RUFDdkIsT0FBTyxLQUFLO0NBQ2Q7Ozs7OztDQU1BLElBQUksb0JBQW9CO0VBRXRCLE9BQU8sS0FBUyxhQUFhO0NBQy9COzs7Ozs7Q0FNQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUssS0FBSztDQUNuQjs7Ozs7Q0FLQSxZQUFZLEdBQUcsV0FBVztFQUN4QixVQUFVLFNBQVMsYUFBYTtHQUM5QixLQUFLLFFBQVEsWUFBWSxJQUFJLGFBQWEsUUFBUTtFQUNwRCxDQUFDO0NBQ0g7Q0FDQSxZQUFZLFNBQVM7RUFDbkIsSUFBSTtFQUNKLEtBQUssS0FBSyxTQUFTO0dBQ2pCLE1BQU0sTUFBTSxRQUFRO0dBQ3BCLEtBQUssV0FBVyxJQUFJLE9BQU8sSUFBSSxJQUFJO0VBQ3JDO0NBQ0Y7Ozs7Ozs7Ozs7Q0FVQSxXQUFXLFVBQVUsTUFBTTtFQUN6QixNQUFNLFNBQVMsSUFBSSxTQUFTLElBQUk7RUFDaEMsSUFBSSxLQUFLLE9BQ1AsTUFBTSxJQUFJLE1BQU0scUJBQXFCLEtBQUssb0JBQW9CO0VBRWhFLEtBQUssUUFBUTtFQUNiLEtBQUssYUFBYSxRQUFRO0VBQzFCLEtBQUssTUFBTSxLQUFLLEtBQUssU0FDbkIsS0FBSyxRQUFRLEVBQUUsQ0FBQyxJQUFJLE1BQU07RUFFNUIsT0FBTztDQUNUO0NBQ0EsVUFBVSxPQUFPLGNBQWM7RUFDN0IsTUFBTSxXQUFXLGFBQWEsUUFBUSxLQUFLLFlBQVk7R0FDckQsSUFBSSxRQUFRLFFBQVEsUUFBUTtHQUM1QixPQUFPO0VBQ1QsR0FBRyxDQUFDLENBQUM7RUFDTCxNQUFNLFNBQVMsU0FBUztHQUN0QixNQUFNLFlBQVksS0FBSztHQUN2QixNQUFNLE9BQU8sS0FBSztHQUNsQixNQUFNLFVBQVUsU0FBUztHQUN6QixLQUFLLFlBQVksUUFBUSxJQUFJLFVBQzNCLE1BQ0EsVUFBVSxJQUFJLFFBQVEsSUFBSSxJQUM1QjtHQUNBLEtBQUssUUFBUSxRQUFRLElBQUksS0FBSyxZQUFZLEtBQUs7RUFDakQsQ0FBQztDQUNIO0NBQ0EsUUFBUSxVQUFVLE9BQU87RUFDdkIsS0FBSyxRQUFRLFFBQVEsTUFBTSxRQUFRO0VBQ25DLEtBQUssUUFBUSxRQUFRLEtBQUssT0FBTztFQUNqQyxJQUFJLFlBQVksUUFBUSxPQUFPLFlBQVksWUFBWSxRQUFRLHdCQUM3RCx1QkFBdUIsUUFBUTtFQUVqQyxPQUFPLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLFdBQVc7R0FDOUMsT0FBTyxRQUFRO0VBQ2pCLENBQUM7RUFDRCxLQUFLLGVBQWU7RUFDcEIsS0FBSyxjQUFjO0VBQ25CLEtBQUssbUJBQW1CO0NBQzFCOzs7Ozs7Q0FNQSxnQkFBZ0IsU0FBUztFQUN2QixPQUFPLEtBQUssaUJBQWlCLGdCQUFnQixPQUFPO0NBQ3REOzs7OztDQUtBLElBQUksY0FBYztFQUNoQixPQUFPLENBQUMsQ0FBQyxLQUFLO0NBQ2hCOzs7Ozs7O0NBT0EsbUJBQW1CO0VBQ2pCLElBQUksQ0FBQyxvQkFBb0IsR0FDdkIsTUFBTSxJQUFJLE1BQU0sMEdBQTBHO0NBRTlIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXVCQSxhQUFhO0VBQ1gsS0FBSyxRQUFRLFdBQVcsS0FBSztDQUMvQjtBQUNGOztBQUVBLGtCQUFrQixpQkFBaUI7Ozs7O0NBS2pDLFlBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJaLDhCQUE4Qjs7Ozs7Q0FLOUIsYUFBYTtBQUNmO0FBQ0EsSUFBSSxtQkFBbUI7OztBQzNWdkIsSUFBTSxXQUFXO0FBQ2pCLElBQU0sVUFBVTs7O0FDQWhCLElBQU0sc0JBQU4sTUFBMEI7Q0FDeEIsT0FBTyxPQUFPO0VBQ1osV0FBVyxvQkFBb0IsTUFBTSxPQUFPO0NBQzlDO0NBQ0EsT0FBTyxVQUFVLENBQ2pCO0FBQ0Y7O0FBRUEsb0JBQW9CLFlBQVksY0FBYztBQUM5QyxJQUFNLG1CQUFOLE1BQXVCO0NBQ3JCLFlBQVksVUFBVTtFQUNwQixLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxPQUFPO0VBQ0wsV0FBVyx5QkFBeUIsS0FBSyxXQUFXLE9BQU87Q0FDN0Q7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxZQUFZO0NBQ25CO0FBQ0Y7O0FBRUEsaUJBQWlCLFlBQVk7Q0FDM0IsTUFBTSxDQUNKLGNBQWMsYUFDZCxjQUFjLFlBQ2hCO0NBQ0EsTUFBTTtDQUNOLFVBQVU7QUFDWjs7O0FDaENBLElBQUksV0FBVzs7O0FDQWYsSUFBSSxTQUFTOzs7QUNBYixJQUFJLFNBQVM7OztBQ2FiLElBQU0sYUFBTixjQUF5QixPQUFPO0NBQzlCLFlBQVksU0FBUztFQUNuQixNQUFNLEVBQUUsUUFBUSxHQUFHLFNBQVM7RUFDNUIsTUFBTSxnQkFBZ0IsSUFBSSxjQUFjLE9BQU8sT0FBTztFQUN0RCxNQUFNLGlCQUFpQixJQUFJLGFBQWE7R0FDdEMsZUFBZTtJQUFFLE9BQU8sSUFBSSxPQUFPO0lBQUcsTUFBTTtHQUFjO0dBQzFELFlBQVk7SUFBRSxPQUFPLGNBQWM7SUFBYSxNQUFNO0dBQVk7R0FDbEUsUUFBUTtJQUFFLE9BQU87SUFBRyxNQUFNO0dBQU07R0FDaEMsVUFBVTtJQUFFLE9BQU8sUUFBUSxVQUFVLElBQUk7SUFBRyxNQUFNO0dBQU07R0FDeEQsVUFBVTtJQUFFLE9BQU8sUUFBUSxZQUFZLFVBQVUsSUFBSTtJQUFHLE1BQU07R0FBTTtFQUN0RSxDQUFDO0VBQ0QsTUFBTSxhQUFhLFdBQVcsS0FBSztHQUNqQyxRQUFRO0lBQ047SUFDQSxZQUFZO0dBQ2Q7R0FDQSxVQUFVO0lBQ1I7SUFDQSxZQUFZO0dBQ2Q7RUFDRixDQUFDO0VBQ0QsTUFBTSxZQUFZLFVBQVUsS0FBSztHQUMvQjtHQUNBO0dBQ0EsTUFBTTtFQUNSLENBQUM7RUFDRCxNQUFNO0dBQ0osR0FBRztHQUNIO0dBQ0E7R0FDQSxnQkFBZ0I7R0FDaEIsV0FBVztJQUNUO0lBQ0EsY0FBYyxPQUFPLFFBQVE7R0FDL0I7RUFDRixDQUFDO0VBQ0QsS0FBSyxTQUFTO0VBQ2QsS0FBSyxpQkFBaUI7Q0FDeEI7Ozs7Ozs7OztDQVNBLFVBQVUsUUFBUTtFQUNoQixLQUFLLFNBQVM7RUFDZCxNQUFNLFVBQVUsS0FBSyxnQkFBZ0I7RUFDckMsS0FBSyxlQUFlLFVBQVU7RUFDOUIsS0FBSyxVQUFVLGVBQWUsUUFBUTtDQUN4QztDQUNBLElBQUksUUFBUSxPQUFPO0VBQ2pCLEtBQUssVUFBVSxlQUFlLFNBQVMsV0FBVyxRQUFRLElBQUk7Q0FDaEU7Q0FDQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUssVUFBVSxlQUFlLFNBQVMsYUFBYTtDQUM3RDtDQUNBLElBQUksUUFBUSxPQUFPO0VBQ2pCLEtBQUssVUFBVSxlQUFlLFNBQVMsV0FBVyxVQUFVLFVBQVUsSUFBSTtDQUM1RTtDQUNBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxVQUFVLGVBQWUsU0FBUyxhQUFhLElBQUksVUFBVTtDQUMzRTtDQUNBLE1BQU0sZUFBZSxPQUFPLFFBQVEsV0FBVztFQUM3QyxNQUFNLFVBQVUsS0FBSyxnQkFBZ0I7RUFDckMsS0FBSyxlQUFlLFVBQVU7RUFDOUIsY0FBYyxzQkFDWixLQUFLLFVBQVUsZUFBZSxTQUFTLGVBQ3ZDLEtBQUssTUFDUCxDQUFDLENBQUMsUUFBUSxLQUFLLGVBQWUsUUFBUTtFQUN0QyxLQUFLLFVBQVUsZUFBZSxRQUFRO0VBQ3RDLGNBQWMsWUFBWSxNQUFNLE9BQU8sUUFBUSxTQUFTO0NBQzFEOzs7Ozs7Q0FNQSxrQkFBa0I7RUFDaEIsTUFBTSxVQUFVLEtBQUssT0FBTztFQUM1QixJQUFJLFFBQVEsYUFBYSxDQUFDLFFBQVEsVUFBVSxRQUFRLE9BQU8sV0FBVztHQUNwRSxLQUFLLDRIQUE0SDtHQUNqSSxPQUFPLFFBQVE7RUFDakI7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxRQUFRLGtCQUFrQixPQUFPO0VBQy9CLEtBQUssZUFBZSxRQUFRO0VBQzVCLE1BQU0sUUFBUSxlQUFlO0NBQy9CO0FBQ0Y7OztBQ3hHQSxTQUFTLGVBQWUsS0FBSyxPQUFPLEtBQUssUUFBUTtDQUMvQyxJQUFJLGFBQWEsT0FBTyxLQUFLLE9BQU87Q0FDcEMsSUFBSSxhQUFhLE9BQU8sSUFBSSxPQUFPO0NBQ25DLElBQUksYUFBYSxNQUFNLE9BQU87Q0FDOUIsSUFBSSxZQUFZO0FBQ2xCO0FBQ0EsU0FBUyxvQkFBb0IsTUFBTSxLQUFLLFFBQVE7Q0FDOUMsTUFBTSxTQUFTLFFBQVEsS0FBSyxPQUFPO0NBQ25DLElBQUksYUFBYSxPQUFPLE9BQU8sTUFBTTtDQUNyQyxJQUFJLGFBQWEsUUFBUSxJQUFJLE9BQU8sTUFBTTtDQUMxQyxJQUFJLGFBQWEsUUFBUSxLQUFLLE9BQU8sTUFBTTtDQUMzQyxJQUFJLFlBQVk7QUFDbEI7OztBQ1pBLElBQU0sa0JBQU4sTUFBc0I7Q0FDcEIsY0FBYztFQUNaLEtBQUssY0FBYztFQUNuQixLQUFLLFdBQVc7RUFFaEIsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssYUFBYTtFQUNsQixLQUFLLGNBQWM7RUFDbkIsS0FBSyxrQkFBa0I7RUFFdkIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssU0FBUztDQUNoQjtDQUNBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSyxXQUFXO0NBQ3pCO0NBQ0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLFdBQVc7Q0FDekI7Q0FDQSxRQUFRO0VBQ04sS0FBSyxhQUFhO0VBQ2xCLEtBQUssVUFBVTtFQUNmLEtBQUssV0FBVztFQUNoQixLQUFLLFNBQVM7RUFDZCxLQUFLLFNBQVM7Q0FDaEI7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxNQUFNO0NBQ2I7QUFDRjs7O0FDMUJBLElBQU0sZUFBZSxNQUFNLGFBQWE7Q0FDdEMsWUFBWSxVQUFVLFNBQVM7RUFDN0IsS0FBSyxRQUFRLE1BQU0sTUFBTTtFQUN6QixLQUFLLDRCQUE0Qyx1QkFBTyxPQUFPLElBQUk7O0VBRW5FLEtBQUssaUJBQWlDLHVCQUFPLE9BQU8sSUFBSTtFQUN4RCxLQUFLLFdBQVc7RUFDaEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssU0FBUyxPQUFPLElBQUk7Q0FDM0I7Q0FDQSxPQUFPLFdBQVcsTUFBTSxhQUFhO0VBQ25DLE9BQU8sSUFBSSxLQUFLLG1CQUFtQixNQUFNLEVBQUUsWUFBWSxDQUFDO0NBQzFEO0NBQ0EsV0FBVyxnQkFBZ0I7RUFDekIsSUFBSSxXQUFXLEtBQUssMEJBQTBCLGVBQWU7RUFDN0QsSUFBSSxDQUFDLFVBQVU7R0FDYixXQUFXLEtBQUssMEJBQTBCLGVBQWUsT0FBdUIsdUJBQU8sT0FBTyxJQUFJO0dBQ2xHLFNBQVMsWUFBWSxTQUFTLFVBQVUsSUFBSSxlQUFlLEVBQ3pELGFBQWEsS0FBSyxTQUFTLE9BQU8scUJBQ3BDLENBQUM7RUFDSDtFQUNBLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssZUFBZSxLQUFLLGVBQWU7RUFDeEMsS0FBSyxNQUFNLEtBQUssS0FBSyxnQkFDbkIsS0FBSyxlQUFlLEVBQUUsQ0FBQyxNQUFNO0NBRWpDO0NBQ0EsV0FBVyxpQkFBaUIsZ0JBQWdCO0VBQzFDLElBQUksS0FBSyxhQUFhLFNBQVMsZ0JBQWdCLGFBQWE7R0FDMUQsS0FBSyxhQUFhLE1BQU0sY0FBYztHQUN0QyxJQUFJLFFBQVEsS0FBSyxlQUFlLGdCQUFnQjtHQUNoRCxJQUFJLENBQUMsT0FBTztJQUNWLFFBQVEsS0FBSyxlQUFlLGdCQUFnQixlQUFlLGFBQWEsV0FBVyxnQkFBZ0IsYUFBYSxLQUFLLFNBQVMsT0FBTyxvQkFBb0I7SUFDekosTUFBTSxNQUFNO0dBQ2Q7R0FDQSxLQUFLLGVBQWU7RUFDdEI7RUFDQSxLQUFLLGFBQWEsSUFBSSxlQUFlO0NBQ3ZDO0NBQ0EsTUFBTSxnQkFBZ0I7RUFDcEIsS0FBSyxhQUFhLE1BQU0sY0FBYztDQUN4QztDQUNBLFNBQVMsZ0JBQWdCO0VBQ3ZCLEtBQUssYUFBYSxNQUFNLGNBQWM7RUFDdEMsTUFBTSxVQUFVLEtBQUs7RUFDckIsS0FBSyxNQUFNLEtBQUssU0FBUztHQUN2QixNQUFNLFFBQVEsUUFBUTtHQUN0QixNQUFNLFdBQVcsTUFBTTtHQUN2QixTQUFTLFlBQVksZ0JBQWdCLE1BQU0sYUFBYSxNQUFNLFdBQVcsSUFBSTtHQUM3RSxTQUFTLFFBQVEsRUFBRSxDQUFDLGdCQUFnQixNQUFNLGdCQUFnQixhQUFhLE1BQU0sZUFBZSxLQUFLO0VBQ25HO0NBQ0Y7Q0FDQSxPQUFPLGdCQUFnQjtFQUNyQixNQUFNLFdBQVcsS0FBSywwQkFBMEIsZUFBZTtFQUMvRCxLQUFLLE1BQU0sS0FBSyxVQUFVO0dBQ3hCLE1BQU0sVUFBVSxTQUFTO0dBQ3pCLE1BQU0sV0FBVyxRQUFRO0dBQ3pCLElBQUksUUFBUSxPQUFPO0lBQ2pCLFFBQVEsUUFBUTtJQUNoQixTQUFTLFFBQVEsRUFBRSxDQUFDLE9BQU8sUUFBUSxnQkFBZ0IsQ0FBQztHQUN0RDtFQUNGO0NBQ0Y7Q0FDQSxRQUFRLE9BQU87RUFDYixJQUFJLE1BQU0sV0FBVyxjQUFjO0dBQ2pDLE1BQU0sVUFBVSxNQUFNO0dBQ3RCLE1BQU0sV0FBVyxRQUFRO0dBQ3pCLE1BQU0sU0FBUyxRQUFRO0dBQ3ZCLEtBQUssU0FBUyxNQUFNLE1BQU0sVUFBVSxNQUFNO0VBQzVDO0VBQ0EsS0FBSyxTQUFTLFFBQVEsTUFBTSxLQUFLO0NBQ25DOzs7Ozs7O0NBT0Esc0JBQXNCLGdCQUFnQjtFQUNwQyxNQUFNLFdBQVcsS0FBSywwQkFBMEIsZUFBZTtFQUMvRCxJQUFJLENBQUMsVUFBVTtFQUNmLEtBQUssTUFBTSxLQUFLLFVBQ2QsU0FBUyxFQUFFLENBQUMsUUFBUTtFQUV0QixPQUFPLEtBQUssMEJBQTBCLGVBQWU7RUFDckQsSUFBSSxLQUFLLG1CQUFtQixVQUFVO0dBQ3BDLEtBQUssaUJBQWlDLHVCQUFPLE9BQU8sSUFBSTtHQUN4RCxLQUFLLGVBQWU7RUFDdEI7Q0FDRjtDQUNBLFVBQVU7RUFDUixLQUFLLFFBQVE7RUFDYixLQUFLLFdBQVc7RUFDaEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssTUFBTSxLQUFLLEtBQUssZ0JBQ25CLEtBQUssZUFBZSxFQUFFLENBQUMsUUFBUTtFQUVqQyxLQUFLLGlCQUFpQjtDQUN4QjtBQUNGOztBQUVBLGFBQWEsWUFBWTtDQUN2QixNQUFNO0VBQ0osY0FBYztFQUNkLGNBQWM7RUFDZCxjQUFjO0NBQ2hCO0NBQ0EsTUFBTTtBQUNSO0FBQ0EsYUFBYSxxQkFBcUMsdUJBQU8sT0FBTyxJQUFJO0FBQ3BFLElBQUksY0FBYztBQUNsQixXQUFXLFlBQVksY0FBYyxTQUFTLFlBQVksa0JBQWtCO0FBQzVFLFdBQVcsSUFBSSxjQUFjOzs7QUN6RzdCLElBQU1DLGVBQWEsSUFBSSxPQUFPO0FBQzlCLElBQU0sa0JBQU4sY0FBOEIsYUFBYTtDQUN6QyxjQUFjO0VBQ1osTUFBTTs7RUFFTixLQUFLLHFCQUFxQixJQUFJLE9BQU8sUUFBUSxLQUFLO0VBQ2xELEtBQUssVUFBVSxDQUFDLElBQUksV0FBVztHQUM3QixRQUFRLEtBQUs7R0FDYixTQUFTO0dBQ1QsWUFBWTtHQUNaLFdBQVc7RUFDYixDQUFDLENBQUM7Q0FDSjtDQUNBLElBQUksU0FBUztFQUNYLE9BQU8sS0FBSyxRQUFRLEVBQUUsQ0FBQztDQUN6QjtDQUNBLElBQUksT0FBTyxPQUFPO0VBQ2hCLEtBQUssUUFBUSxFQUFFLENBQUMsVUFBVSxLQUFLO0NBQ2pDO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLLFFBQVEsRUFBRSxDQUFDO0NBQ3pCO0NBQ0EsSUFBSSxRQUFRLE9BQU87RUFDakIsS0FBSyxRQUFRLEVBQUUsQ0FBQyxVQUFVO0NBQzVCO0NBQ0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLLFFBQVEsRUFBRSxDQUFDO0NBQ3pCO0NBQ0EsSUFBSSxRQUFRLE9BQU87RUFDakIsS0FBSyxRQUFRLEVBQUUsQ0FBQyxVQUFVO0NBQzVCOzs7Ozs7OztDQVFBLFFBQVE7RUFDTixLQUFLLG1CQUFtQixVQUFVLFFBQVE7RUFDMUMsS0FBSyxTQUFTLEtBQUs7Q0FDckI7QUFDRjtBQUNBLElBQU0sZ0JBQU4sTUFBb0I7Q0FDbEIsWUFBWSxVQUFVO0VBQ3BCLEtBQUssbUJBQW1CLENBQUM7RUFDekIsS0FBSyxlQUFlLENBQUM7RUFDckIsS0FBSyxZQUFZO0VBQ2pCLFNBQVMsUUFBUSxXQUFXLElBQUksSUFBSTtDQUN0QztDQUNBLEtBQUssTUFBTSxpQkFBaUIsZ0JBQWdCO0VBQzFDLE1BQU0sV0FBVyxLQUFLO0VBQ3RCLFNBQVMsWUFBWSxNQUFNLE1BQU0sY0FBYztFQUMvQyxlQUFlLElBQUk7R0FDakIsY0FBYztHQUNkLFFBQVE7R0FDUjtHQUNBLFNBQVMsZ0JBQWdCLGFBQWE7R0FDdEMsV0FBVztHQUNYO0VBQ0YsQ0FBQztFQUNELEtBQUssVUFBVSxnQkFBZ0IsYUFBYTtFQUM1QyxLQUFLLFVBQVUsZ0JBQWdCLGFBQWEsV0FBVztFQUN2RCxJQUFJLEtBQUsscUJBQXFCO0dBQzVCLE1BQU0sZ0JBQWdCLEtBQUs7R0FDM0IsY0FBYyxpQkFBaUI7R0FDL0IsY0FBYyxtQkFDWixnQkFDQSxVQUNBLElBQ0Y7R0FDQSxjQUFjLGlCQUFpQjtFQUNqQztFQUNBLFNBQVMsWUFBWSxNQUFNLE1BQU0sY0FBYztFQUMvQyxlQUFlLElBQUk7R0FDakIsY0FBYztHQUNkLFFBQVE7R0FDUjtHQUNBO0dBQ0EsU0FBUyxnQkFBZ0IsYUFBYTtHQUN0QyxXQUFXO0VBQ2IsQ0FBQztDQUNIO0NBQ0EsSUFBSSxNQUFNLGtCQUFrQixnQkFBZ0I7RUFFMUMsS0FEc0IsVUFDYixZQUFZLE1BQU0sTUFBTSxjQUFjO0VBQy9DLGVBQWUsSUFBSTtHQUNqQixjQUFjO0dBQ2QsUUFBUTtHQUNSO0dBQ0EsU0FBUyxpQkFBaUIsYUFBYTtHQUN2QyxXQUFXO0VBQ2IsQ0FBQztDQUNIO0NBQ0EsUUFBUSxhQUFhO0VBQ25CLE1BQU0sV0FBVyxLQUFLO0VBQ3RCLE1BQU0sYUFBYSxZQUFZLEtBQUs7RUFDcEMsSUFBSSxZQUFZLFdBQVcsaUJBQWlCO0dBQzFDLE1BQU0sZUFBZSxRQUFRLElBQUksZUFBZTtHQUNoRCxhQUFhLFVBQVUsWUFBWTtHQUNuQyxhQUFhLFVBQVUsWUFBWSxLQUFLO0dBQ3hDLElBQUksWUFBWTtJQUNkLFlBQVksS0FBSyxLQUFLLGFBQWE7SUFDbkMsTUFBTSxTQUFTLGdCQUFnQixZQUFZLEtBQUssTUFBTSxNQUFNQSxZQUFVO0lBQ3RFLFlBQVksS0FBSyxLQUFLLGFBQWE7SUFDbkMsT0FBTyxLQUFLO0lBQ1osTUFBTSxxQkFBcUIsU0FBUyxhQUFhLGFBQWEsYUFBYTtJQUMzRSxNQUFNLGdCQUFnQixZQUFZLGtCQUFrQjtLQUNsRCxPQUFPLE9BQU87S0FDZCxRQUFRLE9BQU87S0FDZixZQUFZLG1CQUFtQjtLQUMvQixXQUFXLG1CQUFtQjtJQUNoQyxDQUFDO0lBQ0QsU0FBUyxhQUFhLEtBQUs7S0FBRSxRQUFRO0tBQWUsT0FBTztJQUFLLENBQUM7SUFDakUsU0FBUyxlQUFlLEtBQUs7S0FDM0IsUUFBUTtLQUNSLFlBQVk7SUFDZCxDQUFDO0lBQ0QsTUFBTSxTQUFTLGFBQWE7SUFDNUIsT0FBTyxVQUFVO0lBQ2pCLE9BQU8sZUFBZSxLQUFLLE9BQU87SUFDbEMsT0FBTyxlQUFlLEtBQUssT0FBTztJQUNsQyxLQUFLLGlCQUFpQixLQUFLO0tBQ3pCO0tBQ0EsaUJBQWlCLFlBQVk7S0FDN0I7SUFDRixDQUFDO0dBQ0gsT0FBTztJQUNMLGFBQWEsU0FBUyxZQUFZLEtBQUs7SUFDdkMsS0FBSyxpQkFBaUIsS0FBSztLQUN6QjtLQUNBLGlCQUFpQixZQUFZO0lBQy9CLENBQUM7R0FDSDtFQUNGLE9BQU8sSUFBSSxZQUFZLFdBQVcsZUFBZTtHQUMvQyxNQUFNLFdBQVcsS0FBSyxpQkFBaUIsS0FBSyxpQkFBaUIsU0FBUztHQUN0RSxJQUFJLFlBQVk7SUFDZCxJQUFJLFNBQVMsU0FBUyxhQUFhLE9BQ2pDLFNBQVMsYUFBYSxpQkFBaUI7SUFFekMsU0FBUyxhQUFhLElBQUk7SUFDMUIsU0FBUyxlQUFlLElBQUk7R0FDOUI7R0FDQSxTQUFTLE9BQU8sS0FBSztJQUNuQixjQUFjO0lBQ2QsUUFBUTtJQUNSLFdBQVcsU0FBUztJQUNwQixjQUFjLFNBQVM7SUFDdkIsV0FBVztHQUNiLENBQUM7RUFDSCxPQUFPLElBQUksWUFBWSxXQUFXLGNBQWM7R0FDOUMsU0FBUyxPQUFPLElBQUk7R0FDcEIsTUFBTSxXQUFXLEtBQUssaUJBQWlCLElBQUk7R0FDM0MsSUFBSSxZQUNGLFlBQVksY0FBYyxTQUFTLGFBQWE7R0FFbEQsS0FBSyxhQUFhLEtBQUssU0FBUyxZQUFZO0VBQzlDO0NBQ0Y7Q0FDQSxhQUFhO0VBQ1gsTUFBTSxVQUFVLEtBQUs7RUFDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUNsQyxRQUFRLE9BQU8sUUFBUSxFQUFFO0VBRTNCLFFBQVEsU0FBUztDQUNuQjtDQUNBLFVBQVU7RUFDUixLQUFLLFdBQVc7RUFDaEIsS0FBSyxVQUFVLFFBQVEsV0FBVyxPQUFPLElBQUk7RUFDN0MsS0FBSyxZQUFZO0VBQ2pCLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssZUFBZTtDQUN0QjtBQUNGOztBQUVBLGNBQWMsWUFBWTtDQUN4QixNQUFNO0VBQ0osY0FBYztFQUNkLGNBQWM7RUFDZCxjQUFjO0NBQ2hCO0NBQ0EsTUFBTTtBQUNSOzs7QUMvTEEsSUFBTSxnQkFBTixNQUFvQjtDQUNsQixZQUFZLFVBQVU7RUFDcEIsS0FBSyxjQUFjLENBQUM7RUFDcEIsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxZQUFZO0NBQ25CO0NBQ0EsYUFBYTtFQUNYLEtBQUssWUFBWSxLQUFLO0VBQ3RCLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssZ0JBQWdCO0NBQ3ZCO0NBQ0EsS0FBSyxNQUFNLFlBQVksZ0JBQWdCO0VBRXJDLEtBRHNCLFVBQ2IsWUFBWSxNQUFNLE1BQU0sY0FBYztFQUMvQyxNQUFNLGFBQWEsS0FBSztFQUN4QixXQUFXLEtBQUssb0JBQW9CLFdBQVcsS0FBSyxtQkFBbUIsS0FBSyxLQUFLO0VBQ2pGLE1BQU0sZUFBZSxLQUFLLFlBQVksS0FBSztFQUMzQyxJQUFJLGlCQUFpQixLQUFLLGVBQWU7R0FDdkMsS0FBSyxnQkFBZ0I7R0FDckIsZUFBZSxJQUFJO0lBQ2pCLGNBQWM7SUFDZCxXQUFXO0lBQ1gsV0FBVztHQUNiLENBQUM7RUFDSDtFQUNBLEtBQUs7Q0FDUDtDQUNBLElBQUksT0FBTyxZQUFZLGdCQUFnQjtFQUVyQyxLQURzQixVQUNiLFlBQVksTUFBTSxNQUFNLGNBQWM7RUFDL0MsTUFBTSxhQUFhLEtBQUs7RUFDeEIsS0FBSztFQUNMLE1BQU0sZUFBZSxXQUFXLEtBQUssbUJBQW1CO0VBQ3hELElBQUksaUJBQWlCLEtBQUssZUFBZTtHQUN2QyxLQUFLLGdCQUFnQjtHQUNyQixlQUFlLElBQUk7SUFDakIsY0FBYztJQUNkLFdBQVc7SUFDWCxXQUFXO0dBQ2IsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSxRQUFRLGFBQWE7RUFFbkIsS0FEc0IsVUFDYixVQUFVLFFBQVEsWUFBWSxTQUFTO0NBQ2xEO0NBQ0EsVUFBVTtFQUNSLEtBQUssWUFBWTtFQUNqQixLQUFLLGNBQWM7Q0FDckI7QUFDRjs7QUFFQSxjQUFjLFlBQVk7Q0FDeEIsTUFBTSxDQUNKLGNBQWMsWUFDZCxjQUFjLFdBQ2hCO0NBQ0EsTUFBTTtBQUNSOzs7QUN6REEsSUFBTSxrQkFBTixNQUFzQjtDQUNwQixZQUFZLFVBQVU7RUFDcEIsS0FBSyw0QkFBNEIsSUFBSSxRQUFRO0VBQzdDLEtBQUssWUFBWTtDQUNuQjtDQUNBLEtBQUssTUFBTSxZQUFZLGdCQUFnQjtFQUNyQyxNQUFNLFNBQVM7RUFDZixNQUFNLFdBQVcsS0FBSztFQUN0QixTQUFTLFlBQVksTUFBTSxNQUFNLGNBQWM7RUFDL0MsU0FBUyxZQUFZLFVBQVUsYUFBYSxPQUFPLE1BQU0sUUFBUSxjQUFjO0VBQy9FLGVBQWUsSUFBSTtHQUNqQixjQUFjO0dBQ2QsUUFBUTtHQUNSO0dBQ0EsU0FBUyxXQUFXLGFBQWE7R0FDakMsV0FBVztFQUNiLENBQUM7RUFDRCxNQUFNLGdCQUFnQixPQUFPO0VBQzdCLGNBQWMsaUJBQWlCO0VBQy9CLElBQUksQ0FBQyxLQUFLLFVBQVUsSUFBSSxNQUFNLEdBQzVCLEtBQUssVUFBVSxJQUFJLFFBQVE7R0FDekIsbUJBQW1CO0dBQ25CLG9CQUFvQjtFQUN0QixDQUFDO0VBRUgsTUFBTSxXQUFXLEtBQUssVUFBVSxJQUFJLE1BQU07RUFDMUMsU0FBUyxvQkFBb0IsZUFBZTtFQUM1QyxjQUFjLG1CQUNaLGdCQUNBLFVBQ0EsSUFDRjtFQUNBLGNBQWMsaUJBQWlCO0VBQy9CLFNBQVMsWUFBWSxNQUFNLE1BQU0sY0FBYztFQUMvQyxlQUFlLElBQUk7R0FDakIsY0FBYztHQUNkLFFBQVE7R0FDUjtHQUNBLFNBQVMsV0FBVyxhQUFhO0dBQ2pDLFdBQVc7RUFDYixDQUFDO0VBRUQsU0FBUyxxQkFEa0IsZUFBZSxrQkFBa0IsU0FBUyxvQkFBb0I7Q0FFM0Y7Q0FDQSxJQUFJLE1BQU0sWUFBWSxnQkFBZ0I7RUFDcEMsTUFBTSxTQUFTO0VBQ2YsTUFBTSxXQUFXLEtBQUs7RUFDdEIsU0FBUyxZQUFZLE1BQU0sTUFBTSxjQUFjO0VBQy9DLFNBQVMsWUFBWSxVQUFVLGFBQWEsT0FBTyxNQUFNLFFBQVEsY0FBYztFQUMvRSxlQUFlLElBQUk7R0FDakIsY0FBYztHQUNkLFFBQVE7R0FDUixTQUFTLFdBQVcsYUFBYTtHQUNqQyxXQUFXO0VBQ2IsQ0FBQztFQUNELE1BQU0sV0FBVyxLQUFLLFVBQVUsSUFBSSxJQUFJO0VBQ3hDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLG9CQUFvQixLQUMvQyxlQUFlLGFBQWEsZUFBZSxxQkFBcUIsZUFBZSxhQUFhLFNBQVM7RUFFdkcsZUFBZSxJQUFJO0dBQ2pCLGNBQWM7R0FDZCxRQUFRO0dBQ1IsV0FBVztFQUNiLENBQUM7Q0FDSDtDQUNBLFFBQVEsYUFBYTtFQUVuQixNQUFNLGNBRFcsS0FBSztFQUV0QixNQUFNLGtCQUFrQixZQUFZLGFBQWEsbUJBQW1CLFlBQVksYUFBYSxZQUFZO0VBQ3pHLElBQUksaUJBQWlCLGdCQUFnQjtFQUNyQyxJQUFJLFlBQVksV0FBVyxpQkFBaUI7R0FDMUMsWUFBWSxhQUFhLG1CQUFtQjtHQUM1QyxZQUFZLFFBQVEsZUFBZSxjQUFjLG9CQUFvQixjQUFjO0dBQ25GO0dBQ0EsWUFBWSxVQUFVLFFBQVEsQ0FBQztFQUNqQyxPQUFPLElBQUksWUFBWSxXQUFXLGVBQWU7R0FDL0MsSUFBSSxZQUFZLFNBQ2QsWUFBWSxRQUFRLGVBQWUsY0FBYyxxQkFBcUIsY0FBYztRQUVwRixZQUFZLFFBQVEsZUFBZSxjQUFjLGFBQWEsY0FBYztHQUU5RSxZQUFZLFVBQVUsUUFBUSxFQUFFO0VBQ2xDLE9BQU8sSUFBSSxZQUFZLFdBQVcsZ0JBQWdCO0dBQ2hELFlBQVksVUFBVSxRQUFRLENBQUM7R0FDL0IsSUFBSSxtQkFBbUIsR0FDckIsWUFBWSxRQUFRLGVBQWUsY0FBYyx1QkFBdUIsY0FBYztRQUNqRjtJQUNMLFlBQVksYUFBYSxNQUFNLE1BQU0sTUFBTSxPQUFPO0lBQ2xELFlBQVksUUFBUSxlQUFlLGNBQWMsVUFBVSxjQUFjO0dBQzNFO0dBQ0E7RUFDRixPQUFPLElBQUksWUFBWSxXQUFXLGNBQWM7R0FDOUMsSUFBSSxZQUFZLFNBQ2QsWUFBWSxRQUFRLGVBQWUsY0FBYyxxQkFBcUIsY0FBYztRQUVwRixZQUFZLFFBQVEsZUFBZSxjQUFjLGFBQWEsY0FBYztHQUU5RSxZQUFZLFVBQVUsUUFBUSxFQUFFO0VBQ2xDO0VBQ0EsZ0JBQWdCLGlCQUFpQjtDQUNuQztDQUNBLFVBQVU7RUFDUixLQUFLLFlBQVk7RUFDakIsS0FBSyxZQUFZO0NBQ25CO0FBQ0Y7QUFDQSxnQkFBZ0IsWUFBWTtDQUMxQixNQUFNLENBQ0osY0FBYyxZQUNkLGNBQWMsV0FDaEI7Q0FDQSxNQUFNO0FBQ1I7OztBQ2xIQSxJQUFNLG1CQUFOLE1BQXVCO0NBQ3JCLFlBQVksVUFBVTtFQUNwQixLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxtQkFBbUIsQ0FDbkI7Q0FDQSxvQkFBb0IsQ0FDcEI7Q0FDQSxxQkFBcUI7RUFDbkIsT0FBTztDQUNUO0NBQ0EsY0FBYyxXQUFXLGdCQUFnQjtFQUN2QyxLQUFLLFVBQVUsWUFBWSxNQUFNLE1BQU0sY0FBYztFQUNyRCxlQUFlLElBQUksU0FBUztDQUM5QjtDQUNBLFFBQVEsV0FBVztFQUNqQixJQUFJLENBQUMsVUFBVSxjQUFjO0VBQzdCLFVBQVUsT0FBTyxLQUFLLFNBQVM7Q0FDakM7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxZQUFZO0NBQ25CO0FBQ0Y7QUFDQSxpQkFBaUIsWUFBWTtDQUMzQixNQUFNO0VBQ0osY0FBYztFQUNkLGNBQWM7RUFDZCxjQUFjO0NBQ2hCO0NBQ0EsTUFBTTtBQUNSOzs7QUNoQ0EsU0FBUyxvQkFBb0IsYUFBYSxVQUFVO0NBQ2xELE1BQU0saUJBQWlCLFlBQVk7Q0FDbkMsTUFBTSxlQUFlLGVBQWU7Q0FDcEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGVBQWUsaUJBQWlCLEtBQUs7RUFDdkQsTUFBTSxjQUFjLGFBQWE7RUFDakMsU0FBUyxZQUFZLGFBQWEsQ0FBQyxRQUFRLFdBQVc7Q0FDeEQ7QUFDRjs7O0FDREEsSUFBTSxrQkFBTixNQUFzQjtDQUNwQixZQUFZLFVBQVU7RUFDcEIsS0FBSyxZQUFZO0NBQ25CO0NBQ0EsZUFBZSxhQUFhLGdCQUFnQjtFQUMxQyxJQUFJLFlBQVksbUJBQ2QsS0FBSyw2QkFBNkIsYUFBYSxjQUFjO09BRTdELEtBQUsscUJBQXFCLGFBQWEsY0FBYztDQUV6RDtDQUNBLFFBQVEsYUFBYTtFQUNuQixJQUFJLENBQUMsWUFBWSxjQUFjO0VBQy9CLElBQUksWUFBWSxtQkFDZCxLQUFLLHVCQUF1QixXQUFXO09BRXZDLEtBQUssZUFBZSxXQUFXO0NBRW5DO0NBQ0EsVUFBVTtFQUNSLEtBQUssWUFBWTtDQUNuQjtDQUNBLHFCQUFxQixhQUFhLGdCQUFnQjtFQUNoRCxLQUFLLFVBQVUsWUFBWSxNQUFNLE1BQU0sY0FBYztFQUNyRCxJQUFJLFlBQVksdUJBQXVCO0dBQ3JDLFFBQVEsT0FBTyxZQUFZLHFCQUFxQjtHQUNoRCxZQUFZLHdCQUF3QjtFQUN0QztFQUNBLGVBQWUsSUFBSSxXQUFXO0NBQ2hDO0NBQ0EsNkJBQTZCLGFBQWEsZ0JBQWdCO0VBQ3hELE1BQU0sdUJBQXVCLFlBQVksMEJBQTBCLFlBQVksd0JBQXdCLFFBQVEsSUFBSSxlQUFlO0VBQ2xJLHFCQUFxQixhQUFhLFlBQVk7RUFDOUMscUJBQXFCLFlBQVksWUFBWSxLQUFLO0VBQ2xELHFCQUFxQixVQUFVLFlBQVk7RUFDM0MscUJBQXFCLFNBQVMsWUFBWTtFQUMxQyxlQUFlLElBQUksV0FBVztFQUM5QixLQUFLLFVBQVUsWUFBWSxVQUFVLGNBQWMsYUFBYSxZQUFZLEtBQUssZ0JBQWdCLGNBQWM7RUFDL0csS0FBSyxVQUFVLFlBQVksTUFBTSxXQUFXLHNCQUFzQixjQUFjO0VBQ2hGLEtBQUssVUFBVSxZQUFZLFVBQVUsYUFBYSxjQUFjO0NBQ2xFO0NBQ0EsdUJBQXVCLGFBQWE7RUFDbEMsSUFBSSxZQUFZLG9CQUFvQjtHQUNsQyxZQUFZLHFCQUFxQjtHQUNqQyxNQUFNLHVCQUF1QixJQUFJLE9BQU8sQ0FBQyxDQUFDLFVBQ3hDLENBQUMsWUFBWSxlQUFlLEdBQzVCLENBQUMsWUFBWSxlQUFlLENBQzlCO0dBQ0EsS0FBSyxVQUFVLGFBQWEsS0FBSztJQUMvQixRQUFRLFlBQVk7SUFDcEIsT0FBTztJQUNQLE9BQU8sWUFBWSxRQUFRO0dBQzdCLENBQUM7R0FDRCxLQUFLLFVBQVUsZUFBZSxLQUFLO0lBQ2pDO0lBQ0EsWUFBWTtJQUNaLFFBQVE7S0FBRSxHQUFHO0tBQUcsR0FBRztJQUFFO0dBQ3ZCLENBQUM7R0FDRCxvQkFBb0IsYUFBYSxLQUFLLFVBQVUsV0FBVztHQUMzRCxLQUFLLFVBQVUsYUFBYSxpQkFBaUI7R0FDN0MsS0FBSyxVQUFVLGFBQWEsSUFBSTtHQUNoQyxLQUFLLFVBQVUsZUFBZSxJQUFJO0VBQ3BDO0VBQ0EsWUFBWSxzQkFBc0IsU0FBUyxjQUFjLFlBQVkscUJBQXFCO0VBQzFGLFlBQVksc0JBQXNCLFNBQVMsU0FBUyxRQUFRLEVBQUUsQ0FBQyxPQUFPO0NBQ3hFO0NBQ0EsZUFBZSxhQUFhO0VBQzFCLEtBQUssVUFBVSxlQUFlLEtBQUs7R0FDakMsc0JBQXNCLFlBQVk7R0FDbEMsWUFBWSxZQUFZO0VBQzFCLENBQUM7RUFDRCxvQkFBb0IsYUFBYSxLQUFLLFVBQVUsV0FBVztFQUMzRCxLQUFLLFVBQVUsZUFBZSxJQUFJO0NBQ3BDO0FBQ0Y7QUFDQSxnQkFBZ0IsWUFBWTtDQUMxQixNQUFNO0VBQ0osY0FBYztFQUNkLGNBQWM7RUFDZCxjQUFjO0NBQ2hCO0NBQ0EsTUFBTTtBQUNSOzs7QUNyRkEsSUFBTSxhQUFOLE1BQWlCO0NBQ2YsWUFBWSxVQUFVO0VBQ3BCLEtBQUssWUFBWTtDQUNuQjtDQUNBLGNBQWMsUUFBUSxnQkFBZ0I7RUFDcEMsTUFBTSxZQUFZLEtBQUssY0FBYyxNQUFNO0VBQzNDLElBQUksT0FBTyxlQUFlLEtBQUssdUJBQXVCLFFBQVEsU0FBUztFQUN2RSxLQUFLLFVBQVUsWUFBWSxNQUFNLFdBQVcsV0FBVyxjQUFjO0NBQ3ZFO0NBQ0EsaUJBQWlCLFFBQVE7RUFDdkIsTUFBTSxZQUFZLEtBQUssY0FBYyxNQUFNO0VBQzNDLElBQUksT0FBTyxlQUFlLEtBQUssdUJBQXVCLFFBQVEsU0FBUztFQUN2RSxVQUFVLFNBQVMsY0FBYyxTQUFTO0NBQzVDO0NBQ0EsbUJBQW1CLFFBQVE7RUFDekIsTUFBTSxZQUFZLEtBQUssY0FBYyxNQUFNO0VBQzNDLE9BQU8sQ0FBQyxVQUFVLFNBQVMsc0JBQ3pCLFdBQ0EsT0FBTyxRQUNUO0NBQ0Y7Q0FDQSx1QkFBdUIsUUFBUSxpQkFBaUI7RUFDOUMsZ0JBQWdCLFNBQVMsT0FBTztFQUNoQyxnQkFBZ0IsVUFBVSxPQUFPO0NBQ25DO0NBQ0EsY0FBYyxRQUFRO0VBQ3BCLE9BQU8sT0FBTyxTQUFTLEtBQUssVUFBVSxRQUFRLEtBQUssZUFBZSxNQUFNO0NBQzFFO0NBQ0EsZUFBZSxRQUFRO0VBQ3JCLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0VBQzVDLGdCQUFnQixhQUFhO0VBQzdCLGdCQUFnQixZQUFZLE9BQU87RUFDbkMsZ0JBQWdCLFVBQVUsT0FBTztFQUNqQyxnQkFBZ0IsU0FBUyxPQUFPO0VBQ2hDLGdCQUFnQixjQUFjLEtBQUssVUFBVSxlQUFlLE9BQU87RUFDbkUsT0FBTyxTQUFTLEtBQUssVUFBVSxPQUFPO0VBQ3RDLE9BQU87Q0FDVDtDQUNBLFVBQVU7RUFDUixLQUFLLFlBQVk7Q0FDbkI7QUFDRjs7QUFFQSxXQUFXLFlBQVk7Q0FDckIsTUFBTTtFQUNKLGNBQWM7RUFDZCxjQUFjO0VBQ2QsY0FBYztDQUNoQjtDQUNBLE1BQU07QUFDUjs7O0FDaERBLElBQU0scUJBQXFCLENBQUM7QUFDNUIsV0FBVyxPQUFPLGNBQWMsWUFBWSxVQUFVO0NBQ3BELElBQUksQ0FBQyxNQUFNLE1BQ1QsTUFBTSxJQUFJLE1BQU0sK0NBQStDO0NBRWpFLG1CQUFtQixNQUFNLFFBQVEsTUFBTTtBQUN6QyxJQUFJLFVBQVU7Q0FDWixPQUFPLG1CQUFtQixNQUFNO0FBQ2xDLENBQUM7QUFDRCxJQUFNLGdCQUFOLE1BQW9CO0NBQ2xCLFlBQVksVUFBVTtFQUNwQixLQUFLLGtCQUFrQixDQUFDO0VBQ3hCLEtBQUssY0FBYztFQUNuQixLQUFLLGNBQThCLHVCQUFPLE9BQU8sSUFBSTtFQUNyRCxLQUFLLFlBQVk7RUFDakIsS0FBSyxVQUFVLFFBQVEsVUFBVSxJQUFJLElBQUk7Q0FDM0M7Q0FDQSxZQUFZO0VBQ1YsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxjQUFjO0NBQ3JCOzs7Ozs7O0NBT0EsY0FBYyxZQUFZLFdBQVcsZ0JBQWdCO0VBQ25ELEtBQUssZ0JBQWdCLEtBQUssU0FBUztFQUNuQyxLQUFLLGFBQWEsWUFBWSxXQUFXLGNBQWM7Q0FDekQ7Ozs7O0NBS0EsYUFBYSxnQkFBZ0I7RUFDM0IsS0FBSyxnQkFBZ0IsSUFBSTtFQUN6QixNQUFNLFlBQVksS0FBSyxnQkFBZ0IsS0FBSyxpQkFBaUIsU0FBUyxNQUFNO0VBQzVFLEtBQUssYUFBYSxNQUFNLFdBQVcsY0FBYztDQUNuRDs7Ozs7Ozs7O0NBU0EsYUFBYSxZQUFZLFdBQVcsZ0JBQWdCO0VBQ2xELE1BQU0sZ0JBQWdCLHNCQUFzQjtFQUM1QyxJQUFJLEtBQUsscUJBQXFCLFdBQVc7R0FDdkMsSUFBSSxLQUFLLGVBQWUsY0FBYyxDQUFDLGVBQ3JDLEtBQUssaUJBQWlCLEtBQUssVUFBVTtHQUV2QztFQUNGO0VBQ0EsSUFBSSxLQUFLLGFBQWEsS0FBSyxzQkFBc0IsY0FBYztFQUMvRCxLQUFLLG1CQUFtQjtFQUN4QixJQUFJLENBQUMsWUFBWTtFQUNqQixLQUFLLGNBQWMsQ0FBQyxDQUFDLG1CQUFtQjtFQUN4QyxJQUFJLEtBQUssYUFBYSxLQUFLLHdCQUF3QixZQUFZLGNBQWM7Q0FDL0U7Q0FDQSx3QkFBd0IsWUFBWSxnQkFBZ0I7RUFDbEQsS0FBSyxVQUFVLFlBQVksTUFBTSxNQUFNLGNBQWM7RUFDckQsTUFBTSxZQUFZLEtBQUs7RUFDdkIsSUFBSSxDQUFDLG1CQUFtQixZQUFZO0dBQ2xDLEtBQUssZ0NBQWdDLFVBQVUsa0VBQWtFO0dBQ2pIO0VBQ0Y7RUFDQSxNQUFNLGVBQWUsS0FBSyxvQkFBb0IsU0FBUztFQUN2RCxNQUFNLGdCQUFnQixzQkFBc0I7RUFDNUMsTUFBTSxjQUFjO0dBQ2xCLGNBQWM7R0FDZCxRQUFRO0dBQ1I7R0FDQSxhQUFhLGdCQUFnQixPQUFPLENBQUMsVUFBVTtHQUMvQyxXQUFXLGdCQUFnQixXQUFXLE9BQU87R0FDN0MsV0FBVztFQUNiO0VBQ0EsS0FBSyxrQkFBa0IsWUFBWTtFQUNuQyxlQUFlLElBQUksV0FBVztDQUNoQztDQUNBLG9CQUFvQixXQUFXO0VBQzdCLElBQUksZUFBZSxLQUFLLFlBQVk7RUFDcEMsSUFBSSxDQUFDLGNBQWM7R0FDakIsZUFBZSxLQUFLLFlBQVksYUFBYSxJQUFJLGFBQWE7R0FDOUQsYUFBYSxVQUFVLENBQUMsSUFBSSxtQkFBbUIsV0FBVyxDQUFDO0VBQzdEO0VBQ0EsT0FBTztDQUNUO0NBQ0Esc0JBQXNCLGdCQUFnQjtFQUNwQyxLQUFLLGNBQWM7RUFDbkIsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxVQUFVLFlBQVksTUFBTSxNQUFNLGNBQWM7RUFDckQsZUFBZSxJQUFJO0dBQ2pCLGNBQWM7R0FDZCxRQUFRO0dBQ1IsV0FBVztFQUNiLENBQUM7Q0FDSDs7Ozs7Q0FLQSxhQUFhO0VBQ1gsS0FBSyxjQUFjO0NBQ3JCOzs7Ozs7O0NBT0EsU0FBUyxnQkFBZ0I7RUFDdkIsSUFBSSxDQUFDLEtBQUssYUFBYTtFQUN2QixLQUFLLHNCQUFzQixjQUFjO0NBQzNDOztDQUVBLFVBQVU7RUFDUixLQUFLLFlBQVk7RUFDakIsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxNQUFNLEtBQUssS0FBSyxhQUNuQixLQUFLLFlBQVksRUFBRSxDQUFDLFFBQVE7RUFFOUIsS0FBSyxjQUFjO0NBQ3JCO0FBQ0Y7O0FBRUEsY0FBYyxZQUFZO0NBQ3hCLE1BQU07RUFDSixjQUFjO0VBQ2QsY0FBYztFQUNkLGNBQWM7Q0FDaEI7Q0FDQSxNQUFNO0FBQ1I7OztBQzVJQSxTQUFTLFVBQVUsTUFBTSxPQUFPO0NBQzlCLFVBQVUsUUFBUTtDQUNsQixLQUFLLElBQUksSUFBSSxPQUFPLElBQUksS0FBSyxRQUFRLEtBQ25DLElBQUksS0FBSyxJQUNQLEtBQUssS0FBSztNQUVWO0FBR047OztBQ0xBLElBQU0sZ0JBQWdCLElBQUksVUFBVTtBQUNwQyxJQUFNLDZCQUFBO0FBQ04sU0FBUyw0QkFBNEIsYUFBYSwwQkFBMEIsT0FBTztDQUNqRiwyQkFBMkIsV0FBVztDQUN0QyxNQUFNLG1CQUFtQixZQUFZO0NBQ3JDLE1BQU0sYUFBYSxZQUFZO0NBQy9CLEtBQUssTUFBTSxLQUFLLGtCQUFrQjtFQUNoQyxNQUFNLG1CQUFtQixPQUFPLENBQUM7RUFDakMsTUFBTSxrQkFBa0IsaUJBQWlCO0VBQ3pDLE1BQU0sT0FBTyxnQkFBZ0I7RUFDN0IsTUFBTSxRQUFRLGdCQUFnQjtFQUM5QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLO0dBQzlCLE1BQU0sUUFBUSxLQUFLO0dBQ25CLElBQUksTUFBTSxzQkFBc0IsZUFBZSxNQUFNLDZCQUE2QixrQkFDaEYsMkJBQTJCLE9BQU8sWUFBWSxDQUFDO0VBRW5EO0VBQ0EsVUFBVSxNQUFNLEtBQUs7RUFDckIsZ0JBQWdCLFFBQVE7Q0FDMUI7Q0FDQSxJQUFJLHlCQUNGLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxZQUFZLG9CQUFvQixRQUFRLEtBQzFELDRCQUE0QixZQUFZLG9CQUFvQixJQUFJLHVCQUF1QjtBQUc3RjtBQUNBLFNBQVMsMkJBQTJCLGFBQWE7Q0FDL0MsTUFBTSxPQUFPLFlBQVk7Q0FDekIsSUFBSTtDQUNKLElBQUksWUFBWSxtQkFBbUI7RUFDakMsTUFBTSxvQkFBb0IsWUFBWTtFQUN0QyxZQUFZLGVBQWUsV0FDekIsS0FBSyx3QkFDTCxrQkFBa0IsY0FDcEI7RUFDQSxZQUFZLGFBQWEsZUFDdkIsS0FBSyxZQUNMLGtCQUFrQixVQUNwQjtFQUNBLGFBQWEsS0FBSyxhQUFhLGtCQUFrQjtDQUNuRCxPQUFPO0VBQ0wsWUFBWSxlQUFlLFNBQVMsS0FBSyxjQUFjO0VBQ3ZELFlBQVksYUFBYSxLQUFLO0VBQzlCLGFBQWEsS0FBSztDQUNwQjtDQUNBLGFBQWEsYUFBYSxJQUFJLElBQUksYUFBYSxJQUFJLElBQUk7Q0FDdkQsWUFBWSxhQUFhO0NBQ3pCLFlBQVksa0JBQWtCLFlBQVksZUFBZSxhQUFhLE1BQU0sTUFBTTtBQUNwRjtBQUNBLFNBQVMsMkJBQTJCLFdBQVcsWUFBWSxhQUFhO0NBQ3RFLElBQUksZUFBZSxVQUFVLFlBQVk7Q0FDekMsVUFBVSxhQUFhO0NBQ3ZCLFVBQVUsWUFBWTtDQUN0QixNQUFNLGlCQUFpQixVQUFVO0NBQ2pDLFVBQVUscUJBQXFCO0NBQy9CLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLElBQUksVUFBVSxDQUFDLE9BQU8sYUFBYTtFQUNqQyxlQUFlLFVBQVU7RUFDekIsVUFBVSx1QkFBdUIsV0FDL0IsZ0JBQ0EsT0FBTyxzQkFDVDtFQUNBLElBQUksY0FBYyw0QkFDaEIsMkJBQTJCLFdBQVcsUUFBUSxXQUFXO0NBRTdELE9BQU87RUFDTCxjQUFjLFVBQVU7RUFDeEIsVUFBVSx1QkFBdUIsU0FBUyxjQUFjO0VBQ3hELElBQUksY0FBYyw0QkFDaEIsMkJBQTJCLFdBQVcsZUFBZSxXQUFXO0NBRXBFO0NBQ0EsSUFBSSxDQUFDLFVBQVUsYUFBYTtFQUMxQixNQUFNLFdBQVcsVUFBVTtFQUMzQixNQUFNLFNBQVMsU0FBUztFQUN4QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUMxQiwyQkFBMkIsU0FBUyxJQUFJLFlBQVksV0FBVztFQUVqRSxNQUFNLGNBQWMsVUFBVTtFQUM5QixNQUFNLGFBQWE7RUFDbkIsSUFBSSxXQUFXLGdCQUFnQixDQUFDLFlBQVksb0JBQzFDLFlBQVksaUJBQWlCLFVBQVU7Q0FFM0M7QUFDRjtBQUNBLFNBQVMsMkJBQTJCLFdBQVcsUUFBUSxhQUFhO0NBQ2xFLElBQUksY0FBQSxHQUE0QjtFQUM5QixVQUFVLGFBQWEsZUFDckIsVUFBVSxZQUNWLE9BQU8sVUFDVDtFQUNBLElBQUksYUFBYSxVQUFVLGFBQWEsT0FBTztFQUMvQyxhQUFhLGFBQWEsSUFBSSxJQUFJLGFBQWEsSUFBSSxJQUFJO0VBQ3ZELFVBQVUsYUFBYTtFQUN2QixVQUFVLGtCQUFrQixVQUFVLGVBQWUsYUFBYSxNQUFNLE1BQU07Q0FDaEY7Q0FDQSxJQUFJLGNBQUEsR0FDRixVQUFVLGlCQUFpQixVQUFVLG1CQUFtQixZQUFZLE9BQU8saUJBQWlCLFVBQVU7Q0FFeEcsSUFBSSxjQUFBLEdBQ0YsVUFBVSxzQkFBc0IsVUFBVSxxQkFBcUIsT0FBTztDQUV4RSxVQUFVLGVBQWU7QUFDM0I7OztBQzNHQSxTQUFTLG9CQUFvQixhQUFhLGFBQWE7Q0FDckQsTUFBTSxFQUFFLFNBQVMsWUFBWTtDQUM3QixJQUFJLGtCQUFrQjtDQUN0QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSw0QkFBNEIsT0FBTyxLQUFLO0VBQ3RFLE1BQU0sWUFBWSxLQUFLO0VBR3ZCLGtCQURhLFlBQVlDLFVBQVcsYUFDZCxDQUFDLG1CQUFtQixTQUFTO0VBQ25ELElBQUksaUJBQ0Y7Q0FFSjtDQUNBLFlBQVkscUJBQXFCO0NBQ2pDLE9BQU87QUFDVDs7O0FDTEEsSUFBTSxhQUFhLElBQUksT0FBTztBQUM5QixJQUFNLG9CQUFOLE1BQXdCO0NBQ3RCLFlBQVksVUFBVTtFQUNwQixLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxPQUFPLEVBQUUsV0FBVyxhQUFhO0VBQy9CLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLE1BQU0sb0JBQW9CLFVBQVUsWUFBWTtFQUNoRCxVQUFVLFNBQVM7RUFDbkIsVUFBVSxZQUFZLG9CQUFvQjtFQUMxQyxNQUFNLFdBQVcsS0FBSztFQUN0QixNQUFNLHlCQUF5QjtFQUMvQixJQUFJLFdBQVc7R0FDYix1QkFBdUIsU0FBUyxVQUFVLFlBQVksY0FBYztHQUNwRSxVQUFVLFlBQVksZUFBZSxTQUFTLFNBQVM7RUFDekQ7RUFDQSxNQUFNLGNBQWMsU0FBUztFQUM3QixLQUFLLDBCQUEwQixVQUFVLGFBQWEsSUFBSTtFQUMxRCxLQUFLLG9CQUFvQixVQUFVLFdBQVc7RUFDOUMsU0FBUyxlQUFlLE1BQU07R0FDNUIsc0JBQXNCLFlBQVksVUFBVSxZQUFZLGlCQUFpQixVQUFVLFlBQVk7R0FDL0YsWUFBWSxVQUFVLFlBQVk7RUFDcEMsQ0FBQztFQUNELG9CQUFvQixVQUFVLGFBQWEsV0FBVztFQUN0RCxJQUFJLFlBQVksY0FDZCxZQUFZLGFBQWEsVUFBVTtFQUVyQyxJQUFJLFdBQ0YsVUFBVSxZQUFZLGVBQWUsU0FBUyxzQkFBc0I7RUFFdEUsVUFBVSxTQUFTO0VBQ25CLFVBQVUsWUFBWSxvQkFBb0I7Q0FDNUM7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxZQUFZO0NBQ25CO0NBQ0EsMEJBQTBCLGFBQWEsdUJBQXVCO0VBQzVELFlBQVksbUNBQW1DO0VBQy9DLElBQUksWUFBWSxtQkFBbUI7R0FDakMsSUFBSSxDQUFDLFlBQVksb0JBQW9CO0dBQ3JDLHdCQUF3QjtFQUMxQjtFQUNBLEtBQUssSUFBSSxJQUFJLFlBQVksb0JBQW9CLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FDL0QsS0FBSywwQkFBMEIsWUFBWSxvQkFBb0IsSUFBSSxxQkFBcUI7RUFFMUYsWUFBWSxtQkFBbUI7RUFDL0IsSUFBSSxZQUFZLG1CQUNWO09BQUEsWUFBWSxvQkFBb0I7SUFDbEMsTUFBTSxTQUFTLFlBQVksS0FBSyxlQUFlO0lBQy9DLE1BQU0sV0FBVyxLQUFLO0lBQ3RCLE1BQU0sYUFBYSxZQUFZLGVBQWUsY0FBYyxTQUFTLEtBQUs7SUFDMUUsTUFBTSxZQUFZLFlBQVksZUFBZSxhQUFhLFNBQVMsS0FBSztJQUN4RSxNQUFNLFlBQVksWUFBWSxlQUFlLGFBQWE7SUFDMUQsTUFBTSxjQUFjLFlBQVk7SUFDaEMsT0FBTyxLQUFLO0lBQ1osSUFBSSxZQUFZLFNBQ2QsWUFBWSxjQUFjLFlBQVksT0FBTztJQVMvQyxZQUFZLFVBUEksWUFBWSxrQkFBa0I7S0FDNUMsT0FBTyxPQUFPO0tBQ2QsUUFBUSxPQUFPO0tBQ2Y7S0FDQTtLQUNBO0lBQ0YsQ0FDNEI7SUFDNUIsWUFBWSxtQkFBbUIsWUFBWSxpQkFBaUIsSUFBSSxPQUFPO0lBQ3ZFLFlBQVksZUFBZSxTQUFTLE1BQU07SUFDMUMsSUFBSSxnQkFBZ0IsWUFBWSxTQUMxQjtTQUFBLFlBQVksbUJBQ2QsWUFBWSxrQkFBa0IscUJBQXFCO0lBQUE7R0FHekQ7U0FDSyxJQUFJLFlBQVksU0FBUztHQUM5QixZQUFZLGNBQWMsWUFBWSxPQUFPO0dBQzdDLFlBQVksVUFBVTtFQUN4QjtDQUNGO0NBQ0Esb0JBQW9CLGFBQWE7RUFDL0IsTUFBTSxXQUFXLEtBQUs7RUFDdEIsTUFBTSxjQUFjLFNBQVM7RUFDN0IsWUFBWSxZQUFZLFFBQVE7RUFDaEMsWUFBWSxlQUFlLGNBQWM7RUFDekMsSUFBSSxDQUFDLFlBQVksb0JBQ2Ysb0JBQW9CLGFBQWEsV0FBVztPQUU1QyxVQUFVLFlBQVksNEJBQTRCLE1BQU0sQ0FBQztFQUUzRCw0QkFBNEIsV0FBVztFQUN2QyxJQUFJLFlBQVksb0JBQW9CO0dBQ2xDLFlBQVkscUJBQXFCO0dBQ2pDLEtBQUssbUJBQW1CLGFBQWEsUUFBUTtFQUMvQyxPQUNFLEtBQUssbUJBQW1CLFdBQVc7RUFFckMsWUFBWSw0QkFBNEIsUUFBUTtFQUNoRCxTQUFTLFlBQVksTUFBTSxPQUFPLFlBQVksY0FBYztFQUM1RCxJQUFJLFlBQVkscUJBQXFCLENBQUMsWUFBWSxvQkFBb0I7RUFDdEUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFlBQVksb0JBQW9CLFFBQVEsS0FDMUQsS0FBSyxvQkFBb0IsWUFBWSxvQkFBb0IsRUFBRTtDQUUvRDtDQUNBLG1CQUFtQixhQUFhO0VBQzlCLE1BQU0sRUFBRSxNQUFNLFVBQVUsWUFBWTtFQUNwQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxLQUFLO0dBQzlCLE1BQU0sWUFBWSxLQUFLO0dBQ3ZCLElBQUksVUFBVSxlQUNaLFlBQVksaUJBQWlCLFNBQVM7RUFFMUM7RUFDQSxVQUFVLE1BQU0sS0FBSztDQUN2QjtDQUNBLG1CQUFtQixhQUFhLGlCQUFpQjtFQUMvQyxNQUFNLE9BQU8sWUFBWTtFQUN6QixNQUFNLGlCQUFpQixZQUFZO0VBQ25DLGVBQWUsTUFBTTtFQUNyQixNQUFNLFdBQVcsZ0JBQWdCLGNBQWMsa0JBQWtCLGdCQUFnQixNQUFNO0VBQ3ZGLE1BQU0sY0FBYyxTQUFTO0VBQzdCLFlBQVksTUFBTSxXQUFXLGNBQWM7RUFDM0MsWUFBWSxVQUFVLFdBQVc7RUFDakMsWUFBWSxVQUFVLFdBQVc7RUFDakMsSUFBSSxLQUFLLGtCQUNQLEtBQUssYUFBYTtFQUVwQixLQUFLLDhCQUE4QixnQkFBZ0IsVUFBVSxJQUFJO0VBQ2pFLFlBQVksTUFBTSxTQUFTLGNBQWM7RUFDekMsWUFBWSxVQUFVLFNBQVMsY0FBYztDQUMvQztBQUNGOztBQUVBLGtCQUFrQixZQUFZO0NBQzVCLE1BQU07RUFDSixjQUFjO0VBQ2QsY0FBYztFQUNkLGNBQWM7Q0FDaEI7Q0FDQSxNQUFNO0FBQ1I7OztBQy9JQSxJQUFNLG9CQUFvQixNQUFNLGtCQUFrQjtDQUNoRCxjQUFjO0VBQ1osS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxtQkFBbUIsSUFBSSxNQUFNLENBQUM7RUFDbkMsS0FBSyxRQUFRLEtBQUs7RUFDbEIsS0FBSyxRQUFRO0NBQ2Y7Ozs7O0NBS0EsS0FBSyxTQUFTO0VBQ1osVUFBVTtHQUFFLEdBQUcsa0JBQWtCO0dBQWdCLEdBQUc7RUFBUTtFQUM1RCxLQUFLLG9CQUFvQixRQUFRO0VBQ2pDLEtBQUssUUFBUSxRQUFRLGNBQWMsUUFBUSxtQkFBbUIsS0FBSztFQUNuRSxLQUFLLFFBQVEsUUFBUTtFQUNyQixLQUFLLGlCQUFpQixTQUFTLFFBQVEsZUFBZTtDQUN4RDs7Q0FFQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksTUFBTSxPQUFPO0VBRWYsSUFEaUIsTUFBTSxPQUFPLFNBQVMsS0FDNUIsQ0FBQyxDQUFDLFFBQVEsS0FBSyxLQUFLLGlCQUFpQixVQUFVLEdBQ3hELEtBQ0UsOElBQ0Y7RUFFRixLQUFLLGlCQUFpQixTQUFTLEtBQUs7Q0FDdEM7O0NBRUEsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLGlCQUFpQjtDQUMvQjtDQUNBLElBQUksTUFBTSxPQUFPO0VBQ2YsS0FBSyxpQkFBaUIsU0FBUyxLQUFLO0NBQ3RDOztDQUVBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSyxpQkFBaUIsUUFBUTtDQUN2Qzs7Ozs7Q0FLQSxVQUFVLENBQ1Y7QUFDRjs7QUFFQSxrQkFBa0IsWUFBWTtDQUM1QixNQUFNO0VBQ0osY0FBYztFQUNkLGNBQWM7RUFDZCxjQUFjO0NBQ2hCO0NBQ0EsTUFBTTtDQUNOLFVBQVU7QUFDWjs7QUFFQSxrQkFBa0IsaUJBQWlCOzs7OztDQUtqQyxpQkFBaUI7Ozs7O0NBS2pCLGlCQUFpQjs7Ozs7Q0FLakIsbUJBQW1CO0FBQ3JCO0FBQ0EsSUFBSSxtQkFBbUI7OztBQzVFdkIsSUFBTSxhQUFhO0NBQ2pCLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsTUFBTTtBQUNSO0FBQ0EsSUFBTSxpQkFBaUIsTUFBTSxlQUFlOztDQUUxQyxZQUFZLFVBQVU7RUFDcEIsS0FBSyxZQUFZO0NBQ25CO0NBQ0Esa0JBQWtCLFNBQVMsV0FBVyxDQUFDLEdBQUc7RUFDeEMsSUFBSSxtQkFBbUIsYUFBYSxtQkFBbUIsU0FDckQsT0FBTztHQUNMLFFBQVE7R0FDUixHQUFHO0VBQ0w7RUFFRixPQUFPO0dBQ0wsR0FBRztHQUNILEdBQUc7RUFDTDtDQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQ0EsTUFBTSxNQUFNLFNBQVM7RUFDbkIsTUFBTSxRQUFRLFdBQVcsSUFBSSxDQUFDLENBQUMsWUFBWTtFQUMzQyxNQUFNLE1BQU0sTUFBTSxLQUFLLE9BQU8sT0FBTztFQUNyQyxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWlDQSxNQUFNLE9BQU8sU0FBUztFQUNwQixVQUFVLEtBQUssa0JBQ2IsU0FDQSxlQUFlLG1CQUNqQjtFQUNBLE1BQU0sRUFBRSxRQUFRLFlBQVk7RUFDNUIsTUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPO0VBQ2xDLElBQUksT0FBTyxXQUFXLEtBQUssR0FDekIsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0dBQ3RDLE9BQU8sUUFBUSxTQUFTO0lBQ3RCLElBQUksQ0FBQyxNQUFNO0tBQ1QsdUJBQU8sSUFBSSxNQUFNLHdCQUF3QixDQUFDO0tBQzFDO0lBQ0Y7SUFDQSxNQUFNLFNBQVMsSUFBSSxXQUFXO0lBQzlCLE9BQU8sZUFBZSxRQUFRLE9BQU8sTUFBTTtJQUMzQyxPQUFPLFVBQVU7SUFDakIsT0FBTyxjQUFjLElBQUk7R0FDM0IsR0FBRyxXQUFXLFNBQVMsT0FBTztFQUNoQyxDQUFDO0VBRUgsSUFBSSxPQUFPLGNBQWMsS0FBSyxHQUM1QixPQUFPLE9BQU8sVUFBVSxXQUFXLFNBQVMsT0FBTztFQUVyRCxJQUFJLE9BQU8sa0JBQWtCLEtBQUssR0FBRztHQUNuQyxNQUFNLE9BQU8sTUFBTSxPQUFPLGNBQWM7SUFBRSxNQUFNLFdBQVc7SUFBUztHQUFRLENBQUM7R0FDN0UsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0lBQ3RDLE1BQU0sU0FBUyxJQUFJLFdBQVc7SUFDOUIsT0FBTyxlQUFlLFFBQVEsT0FBTyxNQUFNO0lBQzNDLE9BQU8sVUFBVTtJQUNqQixPQUFPLGNBQWMsSUFBSTtHQUMzQixDQUFDO0VBQ0g7RUFDQSxNQUFNLElBQUksTUFBTSx5R0FBeUc7Q0FDM0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBeUNBLE9BQU8sU0FBUztFQUNkLFVBQVUsS0FBSyxrQkFBa0IsT0FBTztFQUN4QyxNQUFNLFNBQVMsUUFBUTtFQUN2QixNQUFNLFdBQVcsS0FBSztFQUN0QixJQUFJLGtCQUFrQixTQUNwQixPQUFPLFNBQVMsUUFBUSxlQUFlLE1BQU07RUFFL0MsTUFBTSxVQUFVLFNBQVMsaUJBQWlCLGdCQUFnQixPQUFPO0VBQ2pFLE1BQU0sU0FBUyxTQUFTLFFBQVEsZUFBZSxPQUFPO0VBQ3RELFFBQVEsUUFBUSxJQUFJO0VBQ3BCLE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQStCQSxPQUFPLFNBQVM7RUFDZCxVQUFVLEtBQUssa0JBQWtCLE9BQU87RUFDeEMsTUFBTSxTQUFTLFFBQVE7RUFDdkIsTUFBTSxXQUFXLEtBQUs7RUFDdEIsTUFBTSxVQUFVLGtCQUFrQixVQUFVLFNBQVMsU0FBUyxpQkFBaUIsZ0JBQWdCLE9BQU87RUFDdEcsTUFBTSxZQUFZLFNBQVMsUUFBUSxVQUFVLE9BQU87RUFDcEQsSUFBSSxrQkFBa0IsV0FDcEIsUUFBUSxRQUFRLElBQUk7RUFFdEIsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTRDQSxRQUFRLFNBQVM7RUFDZixVQUFVLEtBQUssa0JBQWtCLE9BQU87RUFDeEMsSUFBSSxRQUFRLGtCQUFrQixTQUFTLE9BQU8sUUFBUTtFQUN0RCxPQUFPLEtBQUssVUFBVSxpQkFBaUIsZ0JBQWdCLE9BQU87Q0FDaEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTZDQSxTQUFTLFNBQVM7RUFDaEIsVUFBVSxLQUFLLGtCQUFrQixPQUFPO0VBQ3hDLE1BQU0sU0FBUyxLQUFLLE9BQU8sT0FBTztFQUNsQyxNQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7RUFDdkMsS0FBSyxXQUFXLFFBQVEsWUFBWTtFQUNwQyxLQUFLLE9BQU8sT0FBTyxVQUFVLFdBQVc7RUFDeEMsU0FBUyxLQUFLLFlBQVksSUFBSTtFQUM5QixLQUFLLE1BQU07RUFDWCxTQUFTLEtBQUssWUFBWSxJQUFJO0NBQ2hDOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxJQUFJLFNBQVM7RUFDWCxNQUFNLFFBQVEsUUFBUSxTQUFTO0VBQy9CLFVBQVUsS0FBSyxrQkFBa0IsT0FBTztFQUN4QyxNQUFNLFNBQVMsS0FBSyxPQUFPLE9BQU87RUFDbEMsTUFBTSxTQUFTLE9BQU8sVUFBVTtFQUNoQyxRQUFRLElBQUksa0JBQWtCLE9BQU8sTUFBTSxLQUFLLE9BQU8sT0FBTyxHQUFHO0VBQ2pFLE1BQU0sUUFBUTtHQUNaO0dBQ0EsWUFBWSxNQUFNO0dBQ2xCLG1CQUFtQixPQUFPO0dBQzFCO0VBQ0YsQ0FBQyxDQUFDLEtBQUssR0FBRztFQUNWLFFBQVEsSUFBSSxPQUFPLEtBQUs7Q0FDMUI7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxZQUFZO0NBQ25CO0FBQ0Y7O0FBRUEsZUFBZSxZQUFZO0NBQ3pCLE1BQU07RUFDSixjQUFjO0VBQ2QsY0FBYztFQUNkLGNBQWM7Q0FDaEI7Q0FDQSxNQUFNO0FBQ1I7Ozs7Ozs7Ozs7Ozs7QUFhQSxlQUFlLHNCQUFzQjtDQUNuQyxRQUFRO0NBQ1IsU0FBUztBQUNYO0FBQ0EsSUFBSSxnQkFBZ0I7OztBQzlYcEIsSUFBTSxnQkFBTixNQUFNLHNCQUFzQixRQUFROzs7Ozs7Ozs7O0NBVWxDLE9BQU8sT0FBTyxTQUFTO0VBQ3JCLE1BQU0sRUFBRSxTQUFTLGdCQUFnQixHQUFHLFNBQVM7RUFDN0MsT0FBTyxJQUFJLGNBQWM7R0FDdkIsR0FBRztHQUNILFFBQVEsSUFBSSxjQUFjLElBQUk7R0FDOUIsU0FBUyxXQUFXO0VBQ3RCLENBQUM7Q0FDSDs7Ozs7Ozs7Q0FRQSxPQUFPLE9BQU8sUUFBUSxZQUFZO0VBQ2hDLEtBQUssT0FBTyxPQUFPLE9BQU8sUUFBUSxVQUFVO0VBQzVDLE9BQU87Q0FDVDtBQUNGOzs7QUN2QkEsSUFBTSxXQUFXLElBQUksVUFBVTtBQUMvQixJQUFNLGFBQWEsSUFBSSxPQUFPO0FBQzlCLElBQU0sVUFBVTtDQUFDO0NBQUc7Q0FBRztDQUFHO0FBQUM7QUFDM0IsSUFBTSx3QkFBTixNQUE0QjtDQUMxQixZQUFZLFVBQVU7RUFDcEIsS0FBSyxZQUFZO0NBQ25COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBcUNBLGdCQUFnQixTQUFTO0VBQ3ZCLElBQUksbUJBQW1CLFdBQ3JCLFVBQVU7R0FDUixRQUFRO0dBQ1IsT0FBTyxLQUFLO0dBQ1osc0JBQXNCLENBQUM7R0FDdkIsWUFBWSxLQUFLO0VBQ25CO0VBRUYsTUFBTSxhQUFhLFFBQVEsY0FBYyxLQUFLLFVBQVU7RUFDeEQsTUFBTSxZQUFZLFFBQVEsYUFBYSxLQUFLLFVBQVUsS0FBSztFQUMzRCxNQUFNLFlBQVksUUFBUTtFQUMxQixJQUFJLGFBQWEsUUFBUTtFQUN6QixJQUFJLFlBRUYsYUFEb0IsTUFBTSxRQUFRLFVBQVUsS0FBSyxXQUFXLFdBQVcsSUFDNUMsYUFBYSxNQUFNLE9BQU8sU0FBUyxVQUFVLENBQUMsQ0FBQyxRQUFRO09BRWxGLGFBQWE7RUFFZixNQUFNLFNBQVMsUUFBUSxPQUFPLE9BQU8sUUFBUSxLQUFLLGVBQWUsV0FBVyxVQUFVLENBQUMsQ0FBQztFQUN4RixNQUFNLGlCQUFpQixRQUFRLGlCQUFpQixFQUM5QyxlQUFlLFFBQVEsY0FDekI7RUFDQSxPQUFPLFFBQVEsS0FBSyxJQUFJLE9BQU8sT0FBTyxJQUFJLFVBQVUsSUFBSTtFQUN4RCxPQUFPLFNBQVMsS0FBSyxJQUFJLE9BQU8sUUFBUSxJQUFJLFVBQVUsSUFBSTtFQUMxRCxNQUFNLFNBQVMsY0FBYyxPQUFPO0dBQ2xDLEdBQUcsUUFBUTtHQUNYLE9BQU8sT0FBTztHQUNkLFFBQVEsT0FBTztHQUNmO0dBQ0E7R0FDQTtFQUNGLENBQUM7RUFDRCxNQUFNLFlBQVksT0FBTyxPQUFPLFVBQVUsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxPQUFPLENBQUM7RUFDOUQsS0FBSyxVQUFVLE9BQU87R0FDcEI7R0FDQTtHQUNBO0dBQ0E7RUFDRixDQUFDO0VBQ0QsT0FBTyxPQUFPLGNBQWM7RUFDNUIsT0FBTztDQUNUO0NBQ0EsVUFBVTtFQUNSLEtBQUssWUFBWTtDQUNuQjtBQUNGOztBQUVBLHNCQUFzQixZQUFZO0NBQ2hDLE1BQU07RUFDSixjQUFjO0VBQ2QsY0FBYztFQUNkLGNBQWM7Q0FDaEI7Q0FDQSxNQUFNO0FBQ1I7OztBQzNHQSxTQUFTLFVBQVUsTUFBTTtDQUN2QixJQUFJLFFBQVE7Q0FDWixLQUFLLE1BQU0sS0FBSyxNQUNkLElBQUksS0FBSyxNQUFNLEtBQUssR0FBRztFQUNyQixRQUFRO0VBQ1I7Q0FDRjtDQUVGLElBQUksQ0FBQyxPQUFPLE9BQU87Q0FDbkIsTUFBTSxhQUE2Qix1QkFBTyxPQUFPLElBQUk7Q0FDckQsS0FBSyxNQUFNLEtBQUssTUFBTTtFQUNwQixNQUFNLFFBQVEsS0FBSztFQUNuQixJQUFJLE9BQ0YsV0FBVyxLQUFLO0NBRXBCO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxXQUFXLEtBQUs7Q0FDdkIsSUFBSSxTQUFTO0NBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUM5QixJQUFJLElBQUksTUFBTSxLQUFLLEdBQ2pCO01BRUEsSUFBSSxJQUFJLFVBQVUsSUFBSTtDQUcxQixJQUFJLFVBQVU7Q0FDZCxPQUFPO0FBQ1Q7OztBQzFCQSxJQUFNLFlBQVksTUFBTSxVQUFVOzs7OztDQUtoQyxZQUFZLFVBQVU7O0VBRXBCLEtBQUssb0JBQW9CLENBQUM7RUFDMUIsS0FBSyx5QkFBeUIsQ0FBQztFQUMvQixLQUFLLHNCQUFzQixDQUFDO0VBQzVCLEtBQUssU0FBUztFQUNkLEtBQUssV0FBVztFQUNoQixLQUFLLFlBQVk7Q0FDbkI7Ozs7O0NBS0EsS0FBSyxTQUFTO0VBQ1osVUFBVTtHQUFFLEdBQUcsVUFBVTtHQUFnQixHQUFHO0VBQVE7RUFDcEQsS0FBSyxnQkFBZ0IsUUFBUTtFQUM3QixLQUFLLGFBQWEsUUFBUTtFQUMxQixLQUFLLFVBQVUsUUFBUTtFQUN2QixLQUFLLE1BQU0sWUFBWSxJQUFJO0NBQzdCOzs7OztDQUtBLElBQUksVUFBVTtFQUNaLE9BQU8sQ0FBQyxDQUFDLEtBQUs7Q0FDaEI7Ozs7OztDQU1BLElBQUksUUFBUSxPQUFPO0VBQ2pCLElBQUksS0FBSyxZQUFZLE9BQU87RUFDNUIsSUFBSSxPQUFPO0dBQ1QsS0FBSyxXQUFXLEtBQUssVUFBVSxVQUFVLGFBQ2pDO0lBQ0osS0FBSyxTQUFTO0dBQ2hCLEdBQ0EsS0FBSyxZQUNMLEtBQ0Y7R0FDQSxLQUFLLHNCQUFzQixLQUFLLFVBQVUsVUFBVSxhQUM1QztJQUNKLEtBQUssTUFBTSxRQUFRLEtBQUsscUJBQXFCO0tBQzNDLE1BQU0sRUFBRSxTQUFTLFlBQVksU0FBUztLQUN0QyxJQUFJLFNBQVMsUUFDWCxRQUFRLGNBQWMsVUFBVSxRQUFRLFdBQVc7VUFFbkQsUUFBUSxjQUFjLFdBQVcsUUFBUSxXQUFXO0lBRXhEO0dBQ0YsR0FDQSxLQUFLLFVBQ1A7RUFDRixPQUFPO0dBQ0wsS0FBSyxVQUFVLFVBQVUsT0FBTyxLQUFLLFFBQVE7R0FDN0MsS0FBSyxVQUFVLFVBQVUsT0FBTyxLQUFLLG1CQUFtQjtHQUN4RCxLQUFLLFdBQVc7R0FDaEIsS0FBSyxzQkFBc0I7RUFDN0I7Q0FDRjs7Ozs7O0NBTUEsVUFBVSxFQUFFLGFBQWE7RUFDdkIsS0FBSyxNQUFNLFlBQVksSUFBSTtFQUMzQixVQUFVLFlBQVksU0FBUyxLQUFLLFVBQVU7RUFDOUMsS0FBSyx5QkFBeUIsVUFBVSxhQUFhLFVBQVUsWUFBWSxNQUFNO0NBQ25GOztDQUVBLGFBQWE7RUFDWCxJQUFJLENBQUMsS0FBSyxVQUFVLENBQUMsS0FBSyxTQUFTO0VBQ25DLEtBQUssSUFBSTtFQUNULEtBQUssU0FBUztDQUNoQjs7Ozs7O0NBTUEseUJBQXlCLGFBQWEsUUFBUTtFQUM1QyxZQUFZLGVBQWUsU0FBUztFQUNwQyxZQUFZLFNBQVM7RUFDckIsS0FBSyxNQUFNLFNBQVMsWUFBWSxxQkFDOUIsS0FBSyx5QkFBeUIsT0FBTyxNQUFNO0NBRS9DOzs7Ozs7O0NBT0EsY0FBYyxTQUFTLFlBQVksTUFBTTtFQUN2QyxLQUFLLG9CQUFvQixLQUFLO0dBQzVCO0dBQ0E7R0FDQTtFQUNGLENBQUM7Q0FDSDs7Ozs7O0NBTUEsWUFBWSxVQUFVLE1BQU07RUFDMUIsSUFBSSxTQUFTLGdCQUFnQixJQUFJO0dBQy9CLFNBQVMsY0FBYyxLQUFLO0dBQzVCLFNBQVMsV0FBVyxLQUFLLEdBQUc7R0FDNUI7RUFDRjtFQUVBLFNBQVMsVUFBVTtHQUNqQixPQUZZLEtBQUssa0JBQWtCO0dBR25DO0VBQ0Y7RUFDQSxTQUFTLGNBQWMsS0FBSztFQUM1QixTQUFTLFdBQVcsS0FBSyxHQUFHO0VBQzVCLFNBQVMsS0FBSyxVQUFVLEtBQUssZ0JBQWdCLElBQUk7RUFDakQsS0FBSyxrQkFBa0IsS0FBSyxRQUFRO0NBQ3RDOzs7Ozs7Q0FNQSxlQUFlLFVBQVU7RUFDdkIsTUFBTSxTQUFTLFNBQVM7RUFDeEIsSUFBSSxDQUFDLFFBQVE7RUFDYixNQUFNLFFBQVEsT0FBTztFQUNyQixNQUFNLE9BQU8sS0FBSyxrQkFBa0IsU0FBUztFQUM3QyxJQUFJLEtBQUssVUFDUCxLQUFLLGtCQUFrQixTQUFTO09BQzNCO0dBQ0wsSUFBSSxVQUFVLE1BQU07SUFDbEIsTUFBTSxlQUFlLEtBQUssa0JBQWtCO0lBQzVDLEtBQUssa0JBQWtCLFNBQVM7SUFDaEMsYUFBYSxRQUFRLFFBQVE7R0FDL0I7R0FDQSxLQUFLLGtCQUFrQjtFQUN6QjtFQUNBLFNBQVMsVUFBVTtFQUNuQixTQUFTLGNBQWM7Q0FDekI7Ozs7Ozs7OztDQVNBLGdCQUFnQixTQUFTLE1BQU0sTUFBTSxXQUFXLEdBQUc7RUFDakQsS0FBSyx1QkFBdUIsS0FBSztHQUMvQjtHQUNBO0dBQ0E7R0FDQTtFQUNGLENBQUM7RUFDRCxLQUFLLHVCQUF1QixNQUFNLEdBQUcsTUFBTSxFQUFFLFdBQVcsRUFBRSxRQUFRO0NBQ3BFOzs7OztDQUtBLE1BQU07RUFDSixJQUFJLEtBQUssVUFBVTtFQUNuQixNQUFNLE1BQU0sWUFBWSxJQUFJO0VBQzVCLE1BQU0sd0JBQXdCLEtBQUs7RUFDbkMsTUFBTSxtQkFBbUIsS0FBSztFQUM5QixLQUFLLFdBQVc7RUFDaEIsSUFBSTtHQUNGLEtBQUssTUFBTSxhQUFhLHVCQUN0QixLQUFLLFVBQVUsV0FBVyxHQUFHO0dBRS9CLE1BQU0sU0FBUyxpQkFBaUI7R0FDaEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FBSztJQUMvQixNQUFNLFdBQVcsaUJBQWlCO0lBQ2xDLElBQUksVUFBVSxLQUFLLGNBQWMsVUFBVSxHQUFHO0dBQ2hEO0VBQ0YsVUFBVTtHQUNSLElBQUksYUFBYTtHQUNqQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksaUJBQWlCLFFBQVEsS0FBSztJQUNoRCxNQUFNLFdBQVcsaUJBQWlCO0lBQ2xDLElBQUksQ0FBQyxVQUFVO0lBQ2YsSUFBSSxlQUFlLEdBQUc7S0FDcEIsaUJBQWlCLGNBQWM7S0FDL0IsU0FBUyxRQUFRLFFBQVE7SUFDM0I7SUFDQTtHQUNGO0dBQ0EsaUJBQWlCLFNBQVM7R0FDMUIsS0FBSyxXQUFXO0VBQ2xCO0NBQ0Y7Q0FDQSx1QkFBdUIsWUFBWSxLQUFLO0VBQ3RDLE1BQU0sY0FBYyxXQUFXLGVBQWUsV0FBVztFQUN6RCxNQUFNLGNBQWMsYUFBYSxnQkFBZ0IsVUFBVTtFQUMzRCxLQUFLLGFBQWEsVUFBVSxPQUFPLGFBQWE7R0FDOUMsV0FBVyxjQUFjO0dBQ3pCLFdBQVcsV0FBVyxHQUFHO0VBQzNCO0NBQ0Y7Q0FDQSxjQUFjLFVBQVUsS0FBSztFQUMzQixJQUFJLFNBQVMsUUFBUSxTQUFTLGNBQzVCLEtBQUssdUJBQXVCLFVBQVUsR0FBRztFQUczQyxJQUR1QixNQUFNLFNBQVMsY0FBYyxLQUFLLGlCQUNuQyxDQUFDLFNBQVMsb0JBQW9CO0VBQ3BELFNBQVMsSUFBSSxVQUFVLEtBQUssZ0JBQWdCLElBQUk7RUFDaEQsU0FBUyxPQUFPO0VBQ2hCLEtBQUssZUFBZSxRQUFRO0NBQzlCOzs7Ozs7O0NBT0EsaUJBQWlCLFdBQVcsU0FBUztFQUNuQyxNQUFNLFlBQTRCLHVCQUFPLE9BQU8sSUFBSTtFQUNwRCxLQUFLLE1BQU0sS0FBSyxXQUFXO0dBQ3pCLElBQUksTUFBTSxTQUFTO0dBQ25CLElBQUksVUFBVSxPQUFPLE1BQU0sVUFBVSxLQUFLLFVBQVU7RUFDdEQ7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxVQUFVLFdBQVcsS0FBSztFQUN4QixNQUFNLEVBQUUsU0FBUyxNQUFNLFNBQVM7RUFDaEMsTUFBTSxZQUFZLFFBQVE7RUFDMUIsSUFBSSxZQUFZO0VBQ2hCLElBQUksWUFBWTtFQUNoQixLQUFLLE1BQU0sT0FBTyxXQUFXO0dBQzNCLE1BQU0sV0FBVyxVQUFVO0dBQzNCLElBQUksYUFBYSxNQUFNO0lBQ3JCO0lBQ0EsSUFBSSxjQUFjLE9BQU8sQ0FBQyxXQUN4QixZQUFZLEtBQUssaUJBQWlCLFdBQVcsR0FBRztJQUVsRDtHQUNGO0dBQ0EsSUFBSSxTQUFTLGdCQUFnQixJQUFJO0lBQy9CLFNBQVMsY0FBYztJQUN2QixTQUFTLFdBQVcsR0FBRztJQUN2QixJQUFJLFdBQVcsVUFBVSxPQUFPO0lBQ2hDO0dBQ0Y7R0FDQSxJQUFJLFNBQVMsY0FDWCxLQUFLLHVCQUF1QixVQUFVLEdBQUc7R0FHM0MsSUFBSSxFQURtQixNQUFNLFNBQVMsY0FBYyxLQUFLLGtCQUNsQyxTQUFTLG9CQUFvQjtJQUNsRCxJQUFJLFNBQVMsY0FBYztLQUN6QixNQUFNLE1BQU07S0FDWixNQUFNLGNBQWMsSUFBSSxlQUFlLElBQUk7S0FDM0MsSUFBSSxhQUFhLFlBQVkscUJBQXFCO0lBQ3BEO0lBQ0EsU0FBUyxPQUFPO0lBQ2hCLFNBQVMsVUFBVTtJQUNuQixTQUFTLGNBQWM7SUFDdkIsSUFBSSxDQUFDLFdBQVc7S0FDZCxJQUFJLFlBQVksTUFBTSxLQUFLO01BQ3pCLFVBQVUsT0FBTztNQUNqQjtLQUNGLE9BQ0UsWUFBWSxLQUFLLGlCQUFpQixXQUFXLEdBQUc7SUFFcEQ7R0FDRixPQUFPLElBQUksV0FDVCxVQUFVLE9BQU87RUFFckI7RUFDQSxJQUFJLFdBQ0YsUUFBUSxRQUFRO0NBRXBCOztDQUVBLFVBQVU7RUFDUixLQUFLLFVBQVU7RUFDZixLQUFLLGtCQUFrQixTQUFTLGFBQWE7R0FDM0MsVUFBVSxJQUFJLFVBQVUsS0FBSyxnQkFBZ0IsSUFBSTtFQUNuRCxDQUFDO0VBQ0QsS0FBSyxrQkFBa0IsU0FBUztFQUNoQyxLQUFLLHVCQUF1QixTQUFTO0VBQ3JDLEtBQUssb0JBQW9CLFNBQVM7RUFDbEMsS0FBSyxZQUFZO0NBQ25CO0FBQ0Y7O0FBRUEsVUFBVSxZQUFZO0NBQ3BCLE1BQU07RUFDSixjQUFjO0VBQ2QsY0FBYztFQUNkLGNBQWM7Q0FDaEI7Q0FDQSxNQUFNO0NBQ04sVUFBVTtBQUNaOztBQUVBLFVBQVUsaUJBQWlCOztDQUV6QixVQUFVOztDQUVWLGlCQUFpQjs7Q0FFakIsYUFBYTtBQUNmO0FBQ0EsSUFBSSxXQUFXOzs7QUN0VGYsSUFBTSxzQkFBTixNQUEwQjtDQUN4QixZQUFZLFVBQVU7RUFDcEIsS0FBSyxjQUFjO0VBQ25CLEtBQUssMEJBQTBCLENBQUM7RUFDaEMsS0FBSyxnQkFBZ0IsQ0FBQztFQUN0QixLQUFLLGtCQUFrQixDQUFDO0VBQ3hCLEtBQUssaUJBQWlCLENBQUM7RUFDdkIsS0FBSyxvQkFBb0IsQ0FBQztFQUMxQixLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxRQUFRO0VBQ04sS0FBSyxjQUFjO0VBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLGdCQUFnQixRQUFRLEtBQy9DLEtBQUssY0FBYyxLQUFLLEtBQUssZ0JBQWdCLEVBQUU7RUFFakQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssa0JBQWtCLFFBQVEsS0FDakQsS0FBSyxlQUFlLEtBQUssS0FBSyxrQkFBa0IsRUFBRTtFQUVwRCxLQUFLLGdCQUFnQixTQUFTO0VBQzlCLEtBQUssa0JBQWtCLFNBQVM7Q0FDbEM7Q0FDQSxNQUFNLFNBQVM7RUFDYixLQUFLLE1BQU07RUFDWCxLQUFLLEtBQUssT0FBTztDQUNuQjtDQUNBLEtBQUssRUFDSCxNQUNBLGtCQUNBLHNCQUNBLFlBQ0EsVUFDQztFQUNELE1BQU0sZUFBZSxLQUFLLFVBQVUsYUFBYTtFQUNqRCxNQUFNLDJCQUEyQixLQUFLLGNBQWMsS0FBSyx3QkFBd0IsS0FBSyxjQUFjLEtBQUs7R0FDdkcsZ0JBQWdCO0dBQ2hCLHNCQUFzQixJQUFJLE9BQU87R0FDakMsWUFBWTtHQUNaLFFBQVEsSUFBSSxNQUFNO0VBQ3BCO0VBQ0EsTUFBTSxvQkFBb0I7R0FDeEIsa0JBQWtCLG9CQUFvQixLQUFLLFVBQVUsYUFBYTtHQUNsRSxZQUFZLFFBQVEsYUFBYTtHQUNqQyxzQkFBc0Isd0JBQXdCLHlCQUF5QjtHQUN2RSxZQUFZLGNBQWMseUJBQXlCO0dBQ25ELFFBQVEsVUFBVSx5QkFBeUI7R0FDM0MsV0FBVztFQUNiO0VBQ0EsTUFBTSxlQUFlLEtBQUssY0FBYyxJQUFJLEtBQUssS0FBSyxnQkFBZ0I7RUFDdEUsS0FBSyxnQkFBZ0IsS0FBSyxZQUFZO0VBQ3RDLE1BQU0sV0FBVyxhQUFhO0VBQzlCLFNBQVMsb0JBQW9CLGtCQUFrQjtFQUMvQyxTQUFTLGNBQWMsa0JBQWtCO0VBQ3pDLFNBQVMsc0JBQXNCLFNBQVMsa0JBQWtCLG9CQUFvQjtFQUM5RSxTQUFTLHNCQUFzQixNQUFNLGtCQUFrQixPQUFPO0VBQzlELFNBQVMsc0JBQXNCLE1BQU0sa0JBQWtCLE9BQU87RUFDOUQsb0JBQ0Usa0JBQWtCLFlBQ2xCLFNBQVMsa0JBQ1QsQ0FDRjtFQUNBLGFBQWEsT0FBTztFQUNwQixJQUFJO0VBQ0osSUFBSSxLQUFLLFVBQVUsWUFBWSxjQUM3QixZQUFZLEtBQUssVUFBVSxZQUFZLGFBQWEsb0JBQW9CLGNBQWMsS0FBSztPQUN0RjtHQUNMLFlBQVksS0FBSyxlQUFlLElBQUksS0FBSyxJQUFJLFVBQVU7R0FDdkQsS0FBSyxrQkFBa0IsS0FBSyxTQUFTO0dBQ3JDLFVBQVUsWUFBWSxjQUFjLENBQUM7RUFDdkM7RUFDQSxrQkFBa0IsWUFBWTtFQUM5QixLQUFLLDRCQUE0QjtDQUNuQztDQUNBLEtBQUssU0FBUztFQUNaLEtBQUssS0FBSyxPQUFPO0VBQ2pCLEtBQUssd0JBQXdCLEtBQUssaUJBQWlCLEtBQUs7Q0FDMUQ7Q0FDQSxNQUFNO0VBQ0osS0FBSyw0QkFBNEIsS0FBSyx3QkFBd0IsRUFBRSxLQUFLLGNBQWM7RUFDbkYsSUFBSSxLQUFLLFVBQVUsU0FBUyxhQUFhLE9BQ3ZDLEtBQUssMEJBQTBCLFVBQVUsVUFBVSxFQUFFLENBQUMsT0FBTztDQUVqRTtDQUNBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSywwQkFBMEI7Q0FDeEM7Q0FDQSxJQUFJLG9CQUFvQjtFQUN0QixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksZUFBZTtFQUNqQixPQUFPLEtBQUssMEJBQTBCLFVBQVUsVUFBVTtDQUM1RDtDQUNBLGtCQUFrQjtFQVVoQixPQUFPLElBVG9CLGFBQWE7R0FDdEMsbUJBQW1CO0lBQUUsT0FBTyxJQUFJLE9BQU87SUFBRyxNQUFNO0dBQWM7R0FDOUQsdUJBQXVCO0lBQUUsT0FBTyxJQUFJLE9BQU87SUFBRyxNQUFNO0dBQWM7R0FFbEUsa0JBQWtCO0lBQUUsdUJBQU8sSUFBSSxhQUFhLENBQUM7SUFBRyxNQUFNO0dBQVk7R0FDbEUsYUFBYTtJQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUM7SUFBRyxNQUFNO0dBQVk7RUFDbEQsR0FBRyxFQUNELFVBQVUsS0FDWixDQUNvQjtDQUN0QjtDQUNBLFVBQVU7RUFDUixLQUFLLFlBQVk7RUFDakIsS0FBSyx3QkFBd0IsU0FBUztFQUN0QyxLQUFLLGNBQWMsU0FBUztFQUM1QixLQUFLLGdCQUFnQixTQUFTO0VBQzlCLEtBQUssZUFBZSxTQUFTO0VBQzdCLEtBQUssa0JBQWtCLFNBQVM7RUFDaEMsS0FBSyw0QkFBNEI7Q0FDbkM7QUFDRjs7QUFFQSxvQkFBb0IsWUFBWTtDQUM5QixNQUFNO0VBQ0osY0FBYztFQUNkLGNBQWM7RUFDZCxjQUFjO0NBQ2hCO0NBQ0EsTUFBTTtBQUNSOzs7QUM5SEEsSUFBSSxNQUFNO0FBQ1YsSUFBTSxrQkFBTixNQUFzQjtDQUNwQixjQUFjO0VBQ1osS0FBSyxTQUFTLENBQUM7O0VBRWYsS0FBSyxVQUFVO0NBQ2pCOztDQUVBLE9BQU87RUFDTCxPQUFPLE9BQU8sSUFBSSxLQUFLLFNBQVMsSUFBSTtDQUN0Qzs7Ozs7Ozs7Q0FRQSxPQUFPLE1BQU0sVUFBVSxZQUFZLE1BQU07RUFDdkMsTUFBTSxLQUFLO0VBQ1gsSUFBSSxTQUFTO0VBQ2IsSUFBSSxXQUFXO0dBQ2IsS0FBSyxXQUFXO0dBQ2hCLFNBQVMsS0FBSztFQUNoQjtFQUNBLEtBQUssT0FBTyxLQUFLO0dBQ2Y7R0FDQTtHQUNBLE9BQU8sWUFBWSxJQUFJO0dBQ3ZCO0dBQ0EsTUFBTSxZQUFZLElBQUk7R0FDdEIsUUFBUTtHQUNSO0VBQ0YsQ0FBQztFQUNELE9BQU87Q0FDVDs7Ozs7Q0FLQSxPQUFPLElBQUk7RUFDVCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxPQUFPLFFBQVEsS0FDdEMsSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDLE9BQU8sSUFBSTtHQUM1QixLQUFLLE9BQU8sT0FBTyxHQUFHLENBQUM7R0FDdkI7RUFDRjtDQUVKOzs7OztDQUtBLFVBQVU7RUFDUixNQUFNLE1BQU0sWUFBWSxJQUFJO0VBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLE9BQU8sUUFBUSxLQUFLO0dBQzNDLE1BQU0sT0FBTyxLQUFLLE9BQU87R0FDekIsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLFFBQVEsS0FBSyxVQUFVO0lBQ2xELE1BQU0sVUFBVSxNQUFNLEtBQUs7SUFDM0IsS0FBSyxLQUFLLE9BQU87SUFDakIsS0FBSyxPQUFPO0dBQ2Q7RUFDRjtDQUNGOzs7OztDQUtBLFVBQVU7RUFDUixPQUFPLE9BQU8sT0FBTyxLQUFLLFNBQVMsSUFBSTtFQUN2QyxLQUFLLE9BQU8sU0FBUztDQUN2QjtBQUNGOztBQUVBLGdCQUFnQixZQUFZO0NBQzFCLE1BQU07RUFDSixjQUFjO0VBQ2QsY0FBYztFQUNkLGNBQWM7Q0FDaEI7Q0FDQSxNQUFNO0NBQ04sVUFBVTtBQUNaOzs7QUNqRkEsSUFBSSxZQUFZO0FBQ2hCLFNBQVMsU0FBUyxNQUFNO0NBQ3RCLElBQUksV0FDRjtDQUVGLElBQUksV0FBVyxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLFlBQVksQ0FBQyxDQUFDLFFBQVEsUUFBUSxJQUFJLElBQUk7RUFDbEYsTUFBTSxPQUFPO0dBQ1gsaUNBQWlDLFFBQVEsSUFBSSxLQUFLOzs7R0FHbEQ7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxXQUFXLFFBQVEsSUFBSSxHQUFHLElBQUk7Q0FDaEMsT0FBTyxJQUFJLFdBQVcsU0FDcEIsV0FBVyxRQUFRLElBQUksVUFBVSxRQUFRLEtBQUssS0FBSywwQkFBMEI7Q0FFL0UsWUFBWTtBQUNkOzs7QUNyQkEsSUFBTSxjQUFOLE1BQWtCO0NBQ2hCLFlBQVksVUFBVTtFQUNwQixLQUFLLFlBQVk7Q0FDbkI7Ozs7O0NBS0EsS0FBSyxTQUFTO0VBQ1osSUFBSSxRQUFRLE9BQU87R0FDakIsSUFBSSxPQUFPLEtBQUssVUFBVTtHQUMxQixJQUFJLEtBQUssVUFBVSxTQUFTLGFBQWEsT0FDdkMsUUFBUSxJQUFJLEtBQUssVUFBVSxRQUFRO0dBRXJDLFNBQVMsSUFBSTtFQUNmO0NBQ0Y7QUFDRjs7QUFFQSxZQUFZLFlBQVk7Q0FDdEIsTUFBTTtFQUNKLGNBQWM7RUFDZCxjQUFjO0VBQ2QsY0FBYztDQUNoQjtDQUNBLE1BQU07Q0FDTixVQUFVO0FBQ1o7O0FBRUEsWUFBWSxpQkFBaUI7O0FBRTNCLE9BQU8sTUFDVDs7O0FDakNBLElBQU0sc0JBQXNCLE1BQU0sb0JBQW9COzs7OztDQUtwRCxZQUFZLFVBQVU7RUFDcEIsS0FBSyxZQUFZO0NBQ25COzs7OztDQUtBLEtBQUssU0FBUztFQUNaLFVBQVU7R0FBRSxHQUFHLG9CQUFvQjtHQUFnQixHQUFHO0VBQVE7RUFDOUQsS0FBSyxnQkFBZ0IsUUFBUTtDQUMvQjs7Ozs7Q0FLQSxJQUFJLFVBQVU7RUFDWixZQUFZLFVBQVUsb0ZBQW9GO0VBQzFHLE9BQU8sS0FBSyxVQUFVLEdBQUc7Q0FDM0I7Ozs7OztDQU1BLElBQUksUUFBUSxPQUFPO0VBQ2pCLFlBQVksVUFBVSxvRkFBb0Y7RUFDMUcsS0FBSyxVQUFVLEdBQUcsVUFBVTtDQUM5Qjs7Ozs7O0NBTUEsZUFBZSxTQUFTLE1BQU07RUFDNUIsWUFBWSxVQUFVLGlHQUFpRztFQUN2SCxLQUFLLFVBQVUsR0FBRyxjQUFjLFNBQVMsTUFBTSxNQUFNO0NBQ3ZEOzs7Ozs7Q0FNQSxnQkFBZ0IsU0FBUyxNQUFNO0VBQzdCLFlBQVksVUFBVSxrR0FBa0c7RUFDeEgsS0FBSyxVQUFVLEdBQUcsY0FBYyxTQUFTLE1BQU0sT0FBTztDQUN4RDs7Ozs7O0NBTUEsY0FBYyxhQUFhO0VBQ3pCLFlBQVksVUFBVSxrRkFBa0Y7RUFDeEcsS0FBSyxVQUFVLEdBQUcsWUFBWSxhQUFhLFlBQVk7Q0FDekQ7Ozs7O0NBS0EsTUFBTTtFQUNKLFlBQVksVUFBVSx3RUFBd0U7RUFDOUYsS0FBSyxVQUFVLEdBQUcsSUFBSTtDQUN4Qjs7Q0FFQSxVQUFVO0VBQ1IsS0FBSyxZQUFZO0NBQ25CO0FBQ0Y7Ozs7O0FBS0Esb0JBQW9CLFlBQVk7Q0FDOUIsTUFBTTtFQUNKLGNBQWM7RUFDZCxjQUFjO0VBQ2QsY0FBYztDQUNoQjtDQUNBLE1BQU07Q0FDTixVQUFVO0FBQ1o7Ozs7OztBQU1BLG9CQUFvQixpQkFBaUI7O0NBRW5DLG9CQUFvQjs7Q0FFcEIsMkJBQTJCOztDQUUzQix1QkFBdUI7QUFDekI7QUFDQSxJQUFJLHFCQUFxQjs7O0FDbkd6QixJQUFNLG1CQUFtQixNQUFNLGlCQUFpQjs7Ozs7O0NBTTlDLElBQUksUUFBUTtFQUNWLE9BQU8sS0FBSyxVQUFVO0NBQ3hCOzs7Ozs7Q0FNQSxJQUFJLGFBQWE7RUFDZixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksV0FBVyxPQUFPO0VBQ3BCLFlBQVksVUFBVSxxRUFBcUU7RUFDM0YsS0FBSyxjQUFjO0NBQ3JCOzs7Ozs7Q0FNQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUssVUFBVSxHQUFHLGdCQUFnQixNQUFNO0NBQ2pEO0NBQ0EsSUFBSSxRQUFRLE9BQU87RUFDakIsWUFBWSxVQUFVLHFFQUFxRTtFQUMzRixLQUFLLFVBQVUsR0FBRyxnQkFBZ0IsUUFBUSxLQUFLO0NBQ2pEOzs7Ozs7Q0FPQSxJQUFJLGdCQUFnQjtFQUNsQixPQUFPLEtBQUssTUFBTSxLQUFLLFVBQVUsR0FBRyxnQkFBZ0IsR0FBRztDQUN6RDtDQUNBLElBQUksY0FBYyxRQUFRO0VBQ3hCLFlBQVksVUFBVSxxRUFBcUU7Q0FDN0Y7Ozs7OztDQU1BLElBQUksU0FBUztFQUNYLE9BQU8sS0FBSyxVQUFVLEdBQUc7Q0FDM0I7Q0FDQSxJQUFJLE9BQU8sT0FBTztFQUNoQixZQUFZLFVBQVUscUVBQXFFO0VBQzNGLEtBQUssVUFBVSxHQUFHLFVBQVU7Q0FDOUI7O0NBRUEsWUFBWSxVQUFVO0VBQ3BCLEtBQUssWUFBWTtFQUNqQixLQUFLLGNBQWM7Q0FDckI7Q0FDQSxLQUFLLFNBQVM7RUFDWixJQUFJLFFBQVEsb0JBQW9CLGlCQUFpQixlQUFlLGlCQUM5RCxLQUFLLFNBQVMsUUFBUTtFQUV4QixJQUFJLFFBQVEscUJBQXFCLGlCQUFpQixlQUFlLGtCQUMvRCxLQUFLLFVBQVUsUUFBUTtFQUV6QixJQUFJLFFBQVEsMkJBQTJCLGlCQUFpQixlQUFlLHdCQUNyRSxLQUFLLGdCQUFnQixRQUFRO0NBRWpDOzs7Ozs7Q0FNQSxNQUFNO0VBQ0osWUFBWSxVQUFVLHFFQUFxRTtFQUMzRixLQUFLLFVBQVUsR0FBRyxJQUFJO0NBQ3hCO0NBQ0EsVUFBVTtFQUNSLEtBQUssWUFBWTtDQUNuQjtBQUNGOztBQUVBLGlCQUFpQixZQUFZO0NBQzNCLE1BQU0sQ0FDSixjQUFjLGFBQ2QsY0FBYyxZQUNoQjtDQUNBLE1BQU07QUFDUjs7Ozs7QUFLQSxpQkFBaUIsaUJBQWlCOzs7OztDQUtoQyxpQkFBaUI7Ozs7O0NBS2pCLG1CQUFtQjs7Ozs7Q0FLbkIsa0JBQWtCOzs7OztDQUtsQix3QkFBd0I7QUFDMUI7QUFDQSxJQUFJLGtCQUFrQjs7O0FDdEh0QixJQUFNLGdCQUFnQixNQUFNLHNCQUFzQkMsc0JBQWE7Ozs7Q0FJN0QsWUFBWSxVQUFVLENBQUMsR0FBRztFQUN4QixNQUFNOztFQUVOLEtBQUssTUFBTUMsTUFBSSxjQUFjOzs7OztFQUs3QixLQUFLLG1CQUFtQixDQUFDO0VBQ3pCLEtBQUssVUFBVTtFQUNmLEtBQUssU0FBUztFQUNkLEtBQUssd0JBQVEsSUFBSSxhQUFhLENBQUM7O0VBRS9CLEtBQUssd0JBQXdCOztFQUU3QixLQUFLLFNBQVM7O0VBRWQsS0FBSyxXQUFXO0VBQ2hCLEtBQUssaUJBQWlCO0VBQ3RCLE1BQU0sYUFBYSxzQkFBc0IsVUFBVSxVQUFVLEtBQUssa0JBQWtCLE9BQU87RUFDM0YsS0FBSyxTQUFTLFdBQVcsVUFBVTtFQUNuQyxLQUFLLFFBQVEsV0FBVztFQUN4QixLQUFLLG1CQUFtQixXQUFXO0VBQ25DLEtBQUsseUJBQXlCLFdBQVc7RUFDekMsSUFBSSxLQUFLLHdCQUF3QjtHQUMvQixNQUFNLFNBQVMsS0FBSyx1QkFBdUIsUUFBUTtHQUNuRCxLQUFLLFdBQVcsS0FBSyxTQUFTLE9BQU8sU0FBUyxPQUFPO0dBQ3JELEtBQUssYUFBYSxLQUFLLFdBQVcsT0FBTyxTQUFTLFNBQVM7RUFDN0Q7RUFDQSxJQUFJLEtBQUssaUJBQWlCLFdBQVcsS0FBSyxDQUFDLEtBQUssd0JBQzlDLE1BQU0sSUFBSSxNQUFNLDJKQUEySjtFQUU3SyxJQUFJLEtBQUssaUJBQWlCLFNBQVMsR0FBRztHQUNwQyxNQUFNLGNBQWMsS0FBSztHQUN6QixLQUFLLE9BQU8sWUFBWSxPQUFPLFlBQVksUUFBUSxZQUFZLFdBQVc7RUFDNUU7RUFDQSxJQUFJLEtBQUssWUFDUCxLQUFLLFdBQVcsR0FBRyxVQUFVLEtBQUssZ0JBQWdCLElBQUk7Q0FFMUQ7Q0FDQSxrQkFBa0IsU0FBUztFQUN6QixNQUFNLE9BQU87R0FBRSxHQUFHLGNBQWM7R0FBZ0IsR0FBRztFQUFRO0VBQzNELE1BQU0sbUJBQW1CLENBQUM7RUFDMUIsSUFBSTtFQUNKLElBQUksT0FBTyxLQUFLLGtCQUFrQixVQUM1QjtPQUFBLEtBQUssZ0JBQWdCLEdBQUc7SUFDMUIsS0FBSyx3QkFBd0I7SUFDN0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssZUFBZSxLQUN0QyxpQkFBaUIsS0FBSztLQUNwQixTQUFTLElBQUksY0FBYztNQUN6QixPQUFPLEtBQUs7TUFDWixRQUFRLEtBQUs7TUFDYixZQUFZLEtBQUs7TUFDakIsV0FBVyxLQUFLO0tBQ2xCLENBQUM7S0FDRCxRQUFRO0tBQ1IsU0FBUztJQUNYLENBQUM7R0FFTDtTQUVBLEtBQUssY0FBYyxTQUFTLFlBQVk7R0FDdEMsaUJBQWlCLEtBQUs7SUFDcEIsU0FBUyxRQUFRO0lBQ2pCLFFBQVE7SUFDUixTQUFTO0dBQ1gsQ0FBQztFQUNILENBQUM7RUFFSCxNQUFNLDJCQUEyQixLQUFLLHdCQUF3QjtFQUM5RCxLQUFLLFNBQVMsQ0FBQyxFQUFFLEtBQUssU0FBUztFQUMvQixLQUFLLFdBQVcsQ0FBQyxFQUFFLEtBQUssV0FBVztFQUNuQyxJQUFJLEtBQUssK0JBQStCLFdBQVcsS0FBSywrQkFBK0IsZUFBZTtHQUNwRyxJQUFJLEtBQUssUUFDUCxNQUFNLElBQUksTUFBTSx5SkFBOEo7R0FFaEwseUJBQXlCLEVBQ3ZCLFNBQVMsS0FBSyxvQkFBb0IsT0FDcEM7RUFDRixPQUFPLElBQUksNEJBQTRCLENBQUMsS0FBSyxXQUFXLEtBQUssV0FBVyxLQUFLLFVBQVUsaUJBQWlCLFdBQVcsR0FDakgseUJBQXlCLEtBQUssMkJBQTJCLEtBQUssT0FBTyxLQUFLLFFBQVEsS0FBSyxVQUFVO0VBRW5HLE9BQU87R0FDTDtHQUNBO0dBQ0EsUUFBUSxLQUFLO0dBQ2IsT0FBTyxLQUFLO0VBQ2Q7Q0FDRjtDQUNBLElBQUksT0FBTztFQUNULE1BQU0sUUFBUSxLQUFLO0VBQ25CLE1BQU0sS0FBSyxLQUFLO0VBQ2hCLE1BQU0sS0FBSyxLQUFLO0VBQ2hCLE9BQU87Q0FDVDtDQUNBLElBQUksUUFBUTtFQUNWLE9BQU8sS0FBSyxXQUFXO0NBQ3pCO0NBQ0EsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLLFdBQVc7Q0FDekI7Q0FDQSxJQUFJLGFBQWE7RUFDZixPQUFPLEtBQUssV0FBVztDQUN6QjtDQUNBLElBQUksY0FBYztFQUNoQixPQUFPLEtBQUssV0FBVztDQUN6QjtDQUNBLElBQUksYUFBYTtFQUNmLE9BQU8sS0FBSyxXQUFXO0NBQ3pCOzs7Ozs7Q0FNQSxJQUFJLGdCQUFnQjtFQUNsQixLQUFLLG1CQUFtQixLQUFLLGlCQUFpQixLQUFLLGlCQUFpQixLQUFLLE1BQU0sRUFBRSxPQUFPO0VBQ3hGLE9BQU8sS0FBSztDQUNkOztDQUVBLElBQUksc0JBQXNCO0VBQ3hCLE9BQU8sS0FBSyx3QkFBd0IsV0FBVztDQUNqRDs7Q0FFQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUs7Q0FDZDs7Q0FFQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksZUFBZTtFQUNqQixPQUFPLEtBQUssaUJBQWlCLEVBQUUsRUFBRTtDQUNuQzs7Ozs7O0NBTUEsSUFBSSxhQUFhO0VBQ2YsT0FBTyxLQUFLLGlCQUFpQixFQUFFLEVBQUUsV0FBVyxLQUFLLHdCQUF3QjtDQUMzRTtDQUNBLGVBQWUsUUFBUTtFQUNyQixLQUFLLE9BQU8sT0FBTyxPQUFPLE9BQU8sUUFBUSxPQUFPLGFBQWEsSUFBSTtDQUNuRTs7Ozs7O0NBTUEsNEJBQTRCO0VBQzFCLEtBQUssMkJBQTJCLEtBQUssV0FBVyxPQUFPLEtBQUssV0FBVyxRQUFRLEtBQUssV0FBVyxXQUFXO0VBQzFHLEtBQUssU0FBUztFQUNkLEtBQUssV0FBVztDQUNsQjtDQUNBLE9BQU8sT0FBTyxRQUFRLGFBQWEsS0FBSyxZQUFZLG1CQUFtQixPQUFPO0VBQzVFLEtBQUs7RUFDTCxLQUFLLGlCQUFpQixTQUFTLGlCQUFpQixNQUFNO0dBQ3BELElBQUksb0JBQW9CLE1BQU0sR0FBRztHQUNqQyxnQkFBZ0IsUUFBUSxPQUFPLE9BQU8sUUFBUSxVQUFVO0VBQzFELENBQUM7RUFDRCxJQUFJLEtBQUssd0JBQXdCO0dBQy9CLElBQUksb0JBQW9CLEtBQUssaUJBQWlCLFdBQVcsR0FBRztHQUM1RCxLQUFLLHVCQUF1QixRQUFRLE9BQU8sT0FBTyxRQUFRLFVBQVU7RUFDdEU7Q0FDRjtDQUNBLFVBQVU7RUFDUixJQUFJLENBQUMsS0FBSyxvQkFBb0IsQ0FBQyxLQUFLLHdCQUF3QjtFQUM1RCxLQUFLLEtBQUssV0FBVyxJQUFJO0VBQ3pCLEtBQUssV0FBVyxJQUFJLFVBQVUsS0FBSyxnQkFBZ0IsSUFBSTtFQUN2RCxJQUFJLEtBQUssdUJBQ1AsS0FBSyxpQkFBaUIsU0FBUyxlQUFlO0dBQzVDLFdBQVcsUUFBUSxRQUFRO0VBQzdCLENBQUM7RUFFSCxJQUFJLEtBQUssd0JBQXdCO0dBQy9CLEtBQUssdUJBQXVCLFFBQVEsUUFBUTtHQUM1QyxPQUFPLEtBQUs7RUFDZDtFQUNBLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssbUJBQW1CO0NBQzFCOzs7Ozs7O0NBT0EsMkJBQTJCLE9BQU8sUUFBUSxZQUFZO0VBQ3BELEtBQUssMkJBQTJCLEtBQUsseUJBQXlCLEVBQzVELFNBQVMsSUFBSSxjQUFjO0dBQ3pCO0dBQ0E7R0FDQTtHQUNBLFFBQVE7R0FDUixxQkFBcUI7R0FDckIsV0FBVztHQUNYLGVBQWU7RUFFakIsQ0FBQyxFQUNIO0VBQ0EsT0FBTyxLQUFLO0NBQ2Q7QUFDRjs7Ozs7OztBQU9BLGNBQWMsaUJBQWlCOztDQUU3QixPQUFPOztDQUVQLFFBQVE7O0NBRVIsWUFBWTs7Q0FFWixlQUFlOztDQUVmLFNBQVM7O0NBRVQsT0FBTzs7Q0FFUCxXQUFXOztDQUdYLFFBQVE7QUFDVjtBQUNBLElBQUksZUFBZTs7O0FDM09uQixJQUFNLDhCQUE4QixJQUFJLElBQUk7QUFDNUMsdUJBQXVCLFNBQVMsV0FBVztBQUMzQyxTQUFTLGlCQUFpQixRQUFRLFNBQVM7Q0FDekMsSUFBSSxDQUFDLFlBQVksSUFBSSxNQUFNLEdBQUc7RUFDNUIsTUFBTSxVQUFVLElBQUksUUFBUSxFQUMxQixRQUFRLElBQUksYUFBYTtHQUN2QixVQUFVO0dBQ1YsR0FBRztFQUNMLENBQUMsRUFDSCxDQUFDO0VBQ0QsTUFBTSxrQkFBa0I7R0FDdEIsSUFBSSxZQUFZLElBQUksTUFBTSxNQUFNLFNBQzlCLFlBQVksT0FBTyxNQUFNO0VBRTdCO0VBQ0EsUUFBUSxLQUFLLFdBQVcsU0FBUztFQUNqQyxRQUFRLE9BQU8sS0FBSyxXQUFXLFNBQVM7RUFDeEMsWUFBWSxJQUFJLFFBQVEsT0FBTztDQUNqQztDQUNBLE9BQU8sWUFBWSxJQUFJLE1BQU07QUFDL0I7QUFDQSxTQUFTLHVCQUF1QixRQUFRO0NBQ3RDLE9BQU8sWUFBWSxJQUFJLE1BQU07QUFDL0I7OztBQ2xCQSxJQUFNLGNBQWMsTUFBTSxZQUFZOzs7Ozs7Q0FNcEMsSUFBSSxjQUFjO0VBQ2hCLE9BQU8sS0FBSyxRQUFRLE9BQU87Q0FDN0I7Q0FDQSxJQUFJLFlBQVksT0FBTztFQUNyQixLQUFLLFFBQVEsT0FBTyxjQUFjO0NBQ3BDOztDQUVBLElBQUksYUFBYTtFQUNmLE9BQU8sS0FBSyxRQUFRLE9BQU87Q0FDN0I7Q0FDQSxJQUFJLFdBQVcsT0FBTztFQUNwQixLQUFLLFFBQVEsT0FBTyxPQUNsQixLQUFLLFFBQVEsT0FBTyxPQUNwQixLQUFLLFFBQVEsT0FBTyxRQUNwQixLQUNGO0NBQ0Y7Q0FDQSxZQUFZLFVBQVU7RUFDcEIsS0FBSyxZQUFZO0NBQ25COzs7OztDQUtBLEtBQUssU0FBUztFQUNaLFVBQVU7R0FDUixHQUFHLFlBQVk7R0FDZixHQUFHO0VBQ0w7RUFDQSxJQUFJLFFBQVEsTUFBTTtHQUNoQixZQUFZLFFBQVEsdURBQXVEO0dBQzNFLFFBQVEsU0FBUyxRQUFRO0VBQzNCO0VBQ0EsS0FBSyxTQUFTLElBQUksVUFBVSxHQUFHLEdBQUcsUUFBUSxPQUFPLFFBQVEsTUFBTTtFQUMvRCxLQUFLLFNBQVMsUUFBUSxVQUFVLFdBQVcsSUFBSSxDQUFDLENBQUMsYUFBYTtFQUM5RCxLQUFLLFlBQVksQ0FBQyxDQUFDLFFBQVE7RUFDM0IsTUFBTSxFQUFFLE9BQU8sR0FBRyxrQkFBa0I7RUFDcEMsS0FBSyxVQUFVLGlCQUFpQixLQUFLLFFBQVEsYUFBYTtFQUMxRCxLQUFLLGVBQWUsSUFBSSxhQUFhO0dBQ25DLGVBQWUsQ0FBQyxLQUFLLE9BQU87R0FDNUIsT0FBTyxDQUFDLENBQUM7R0FDVCxRQUFRO0VBQ1YsQ0FBQztFQUNELEtBQUssUUFBUSxPQUFPLGNBQWMsUUFBUSxrQkFBa0I7RUFDNUQsS0FBSyxRQUFRLE9BQU8sR0FBRyxVQUFVLEtBQUssbUJBQW1CLElBQUk7RUFDN0QsS0FBSyxhQUFhLFFBQVE7RUFDMUIsS0FBSyxrQkFBa0I7Q0FDekI7Ozs7Ozs7Q0FPQSxPQUFPLG9CQUFvQixxQkFBcUIsWUFBWTtFQUMxRCxLQUFLLFFBQVEsT0FBTyxPQUFPLG9CQUFvQixxQkFBcUIsVUFBVTtFQUM5RSxLQUFLLE9BQU8sUUFBUSxLQUFLLFFBQVEsTUFBTTtFQUN2QyxLQUFLLE9BQU8sU0FBUyxLQUFLLFFBQVEsTUFBTTtDQUMxQzs7Ozs7Ozs7O0NBU0EsUUFBUSxVQUFVLE9BQU87RUFFdkIsS0FEbUIsT0FBTyxZQUFZLFlBQVksVUFBVSxDQUFDLENBQUMsU0FBUyxlQUNyRCxLQUFLLE9BQU8sWUFDNUIsS0FBSyxPQUFPLFdBQVcsWUFBWSxLQUFLLE1BQU07RUFFaEQsS0FBSyxRQUFRLE9BQU8sSUFBSSxVQUFVLEtBQUssbUJBQW1CLElBQUk7RUFDOUQsWUFBWSxhQUFhLEtBQUssVUFBVSxHQUFHO0VBQzNDLFdBQVcsYUFBYSxLQUFLLFVBQVUsR0FBRztFQUMxQyxLQUFLLFFBQVEsUUFBUTtDQUN2Qjs7Ozs7Q0FLQSxvQkFBb0I7RUFDbEIsTUFBTSxFQUFFLFlBQVksZ0JBQWdCLEtBQUssUUFBUTtFQUNqRCxNQUFNLE1BQU0sS0FBSyxVQUFVO0VBQzNCLFlBQVksY0FBYyxLQUFLLFlBQVksV0FBVztFQUN0RCxXQUFXLGNBQWMsS0FBSyxZQUFZLFdBQVc7Q0FDdkQ7QUFDRjs7QUFFQSxZQUFZLFlBQVk7Q0FDdEIsTUFBTTtFQUNKLGNBQWM7RUFDZCxjQUFjO0VBQ2QsY0FBYztDQUNoQjtDQUNBLE1BQU07Q0FDTixVQUFVO0FBQ1o7O0FBRUEsWUFBWSxpQkFBaUI7Ozs7O0NBSzNCLE9BQU87Ozs7O0NBS1AsUUFBUTs7Ozs7Q0FLUixhQUFhOzs7OztDQUtiLFdBQVc7QUFDYjtBQUNBLElBQUksYUFBYTs7O0FDbkhqQixJQUFNLGdCQUFnQjtDQUNwQjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRjtBQUNBLElBQU0sb0JBQW9CO0NBQ3hCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRjs7O0FDNUNBLFNBQVMsb0JBQW9CLElBQUksR0FBRyxHQUFHLE9BQU8sUUFBUSxPQUFPO0NBQzNELE1BQU0sT0FBTyxRQUFRLElBQUk7Q0FDekIsR0FBRyxTQUFTO0NBQ1osR0FBRyxJQUFJLElBQUksUUFBUTtDQUNuQixHQUFHLElBQUksUUFBUSxJQUFJLFNBQVM7Q0FDNUIsR0FBRyxLQUFLLEtBQUssSUFBSSxHQUFHO0NBQ3BCLEdBQUcsS0FBSyxDQUFDLE9BQU8sSUFBSSxHQUFHO0NBQ3ZCLE9BQU87QUFDVDs7O0FDUkEsU0FBUyxvQkFBb0IsY0FBYztDQUN6QyxJQUFJLGFBQWEsaUJBQWlCLFdBQVcsR0FBRyxPQUFPO0NBQ3ZELE1BQU0sV0FBVyxhQUFhLGFBQWE7Q0FDM0MsT0FBTyxXQUFXLHFCQUFxQixvQkFBb0IscUJBQXFCLFNBQVMsS0FBSyxTQUFTLFFBQVE7QUFDakg7OztBQ1dBLElBQU0scUJBQU4sTUFBeUI7Q0FDdkIsWUFBWSxVQUFVOztFQUVwQixLQUFLLGVBQWUsSUFBSSxVQUFVOztFQUVsQyxLQUFLLFdBQVcsSUFBSSxVQUFVOzs7OztFQUs5QixLQUFLLHVCQUF1QixJQUFJLGFBQWEsc0JBQXNCOztFQUVuRSxLQUFLLG1CQUFtQixJQUFJLE9BQU87O0VBRW5DLEtBQUssb0JBQW9CO0dBQUM7R0FBRztHQUFHO0dBQUc7RUFBQzs7Ozs7RUFLcEMsS0FBSyxtREFBbUQsSUFBSSxJQUFJOztFQUVoRSxLQUFLLHVCQUF1Qyx1QkFBTyxPQUFPLElBQUk7O0VBRTlELEtBQUsscUJBQXFCLENBQUM7Ozs7OztFQU0zQixLQUFLLGFBQWE7R0FDaEIsUUFBUTtHQUNSLE9BQU8sS0FBSztHQUNaLFVBQVU7R0FDVixPQUFPO0dBQ1AsT0FBTztFQUNUOztFQUVBLEtBQUssYUFBYSxJQUFJLFVBQVU7RUFDaEMsS0FBSyxZQUFZO0VBQ2pCLFNBQVMsR0FBRyxjQUFjLE1BQU0sd0JBQXdCLE1BQU07Q0FDaEU7O0NBRUEsSUFBSSxnQkFBZ0I7RUFDbEIsT0FBTyxLQUFLLFdBQVc7Q0FDekI7O0NBRUEsSUFBSSxXQUFXO0VBQ2IsT0FBTyxLQUFLLFdBQVc7Q0FDekI7O0NBRUEsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLFdBQVc7Q0FDekI7O0NBRUEsbUJBQW1CO0VBQ2pCLEtBQUssUUFBUSxpQkFBaUIsS0FBSyxZQUFZO0NBQ2pEOzs7Ozs7Q0FNQSxZQUFZLFNBQVM7RUFDbkIsS0FBSyxtQkFBbUIsU0FBUztFQUNqQyxLQUFLLEtBQUssT0FBTztFQUNqQixLQUFLLGFBQWEsU0FBUyxLQUFLLFFBQVE7RUFDeEMsS0FBSyxtQkFBbUIsS0FBSztFQUM3QixLQUFLLG9CQUFvQixvQkFBb0IsS0FBSyxnQkFBZ0I7RUFDbEUsS0FBSyxRQUFRLFlBQVksS0FBSyxnQkFBZ0I7Q0FDaEQ7Q0FDQSxhQUFhO0VBQ1gsS0FBSyxRQUFRLGFBQWEsS0FBSyxnQkFBZ0I7Q0FDakQ7Q0FDQSxLQUFLLGtCQUFrQixRQUFRLE1BQU0sWUFBWSxPQUFPLFdBQVcsR0FBRyxRQUFRLEdBQUcsT0FBTztFQUN0RixJQUFJO0VBQ0osSUFBSSxZQUFZLGtCQUNkLFVBQVU7T0FDTDtHQUNMLFlBQVksVUFBVSx3S0FBd0s7R0FDOUwsVUFBVTtJQUFFLFFBQVE7SUFBa0I7SUFBTztJQUFZO0lBQU87SUFBVTtJQUFPO0dBQU07RUFDekY7RUFDQSxNQUFNLGdCQUFnQixRQUFRO0VBQzlCLFFBQVEsUUFBUSxTQUFTO0VBQ3pCLGFBQWEsUUFBUTtFQUNyQixZQUFZLFFBQVEsWUFBWSxLQUFLO0VBQ3JDLFNBQVMsUUFBUSxTQUFTLEtBQUs7RUFDL0IsUUFBUSxRQUFRO0VBQ2hCLFFBQVEsUUFBUTtFQUNoQixNQUFNLGVBQWUsS0FBSyxnQkFBZ0IsYUFBYTtFQUN2RCxNQUFNLFlBQVksS0FBSyxpQkFBaUIsZ0JBQWdCLENBQUMsQ0FBQyxhQUFhLFVBQVUsQ0FBQyxDQUFDO0VBQ25GLEtBQUssZUFBZTtFQUNwQixNQUFNLGtCQUFrQixLQUFLLG1CQUFtQixZQUFZO0VBQzVELElBQUksYUFBYSxlQUFlLGdCQUFnQixTQUFTLGFBQWEsZ0JBQWdCLGdCQUFnQixRQUFRO0dBQzVHLEtBQUssUUFBUSxzQkFBc0IsWUFBWTtHQUMvQyxnQkFBZ0IsUUFBUSxhQUFhO0dBQ3JDLGdCQUFnQixTQUFTLGFBQWE7RUFDeEM7RUFDQSxNQUFNLFNBQVMsYUFBYSxpQkFBaUIsRUFBRSxFQUFFLFdBQVcsYUFBYSx3QkFBd0I7RUFDakcsTUFBTSxXQUFXLEtBQUs7RUFDdEIsTUFBTSxhQUFhLE9BQU8sY0FBYyxPQUFPLEtBQUssSUFBSSxPQUFPLFNBQVMsVUFBVSxDQUFDLElBQUksT0FBTztFQUM5RixJQUFJLFFBQVEsS0FBSyxTQUFTLFlBQ3hCLE1BQU0sSUFBSSxNQUFNLDhCQUE4QixNQUFNLGlDQUFpQyxXQUFXLEdBQUc7RUFFckcsTUFBTSxZQUFZLEtBQUs7RUFDdkIsVUFBVSxTQUFTO0VBQ25CLFVBQVUsUUFBUSxRQUFRLEtBQUssV0FBVyxTQUFTLEtBQUssSUFBSSxLQUFLO0VBQ2pFLFVBQVUsV0FBVztFQUNyQixVQUFVLFFBQVE7RUFDbEIsVUFBVSxRQUFRO0VBQ2xCLE1BQU0sYUFBYSxLQUFLLElBQUksT0FBTyxjQUFjLFVBQVUsQ0FBQztFQUM1RCxNQUFNLGNBQWMsS0FBSyxJQUFJLE9BQU8sZUFBZSxVQUFVLENBQUM7RUFDOUQsSUFBSSxDQUFDLFNBQVMseUJBQXlCLFNBQ3JDLFFBQVEsY0FBYztFQUV4QixJQUFJLE9BQU87R0FDVCxNQUFNLGFBQWEsT0FBTztHQUMxQixNQUFNLFFBQVEsS0FBSyxLQUFLLElBQUksVUFBVSxDQUFDO0dBQ3ZDLE1BQU0sUUFBUSxNQUFNLElBQUksYUFBYSxLQUFNO0dBQzNDLE1BQU0sUUFBUSxNQUFNLElBQUksYUFBYSxLQUFNO0dBQzNDLE1BQU0sUUFBUSxNQUFNLFFBQVEsYUFBYSxLQUFNO0dBQy9DLE1BQU0sUUFBUSxNQUFNLFNBQVMsYUFBYSxLQUFNO0dBQ2hELElBQUksSUFBSSxLQUFLLE1BQU0sUUFBUSxLQUFLO0dBQ2hDLElBQUksSUFBSSxLQUFLLE1BQU0sUUFBUSxLQUFLO0dBQ2hDLElBQUksSUFBSSxLQUFLLEtBQUssUUFBUSxLQUFLO0dBQy9CLElBQUksSUFBSSxLQUFLLEtBQUssUUFBUSxLQUFLO0dBQy9CLElBQUksSUFBSSxHQUFHO0lBQ1QsS0FBSztJQUNMLElBQUk7R0FDTjtHQUNBLElBQUksSUFBSSxHQUFHO0lBQ1QsS0FBSztJQUNMLElBQUk7R0FDTjtHQUNBLElBQUksS0FBSyxJQUFJLEdBQUcsYUFBYSxDQUFDO0dBQzlCLElBQUksS0FBSyxJQUFJLEdBQUcsY0FBYyxDQUFDO0dBQy9CLElBQUksS0FBSyxJQUFJLEdBQUcsYUFBYSxDQUFDO0dBQzlCLElBQUksS0FBSyxJQUFJLEdBQUcsY0FBYyxDQUFDO0dBQy9CLElBQUksS0FBSyxJQUFJLEdBQUcsQ0FBQztHQUNqQixJQUFJLEtBQUssSUFBSSxHQUFHLENBQUM7R0FDakIsU0FBUyxJQUFJO0dBQ2IsU0FBUyxJQUFJO0dBQ2IsU0FBUyxRQUFRO0dBQ2pCLFNBQVMsU0FBUztFQUNwQixPQUFPO0dBQ0wsU0FBUyxJQUFJO0dBQ2IsU0FBUyxJQUFJO0dBQ2IsU0FBUyxRQUFRO0dBQ2pCLFNBQVMsU0FBUztFQUNwQjtFQUNBLGFBQWEsUUFBUTtFQUNyQixvQkFDRSxLQUFLLGtCQUNMLEdBQ0EsR0FDQSxTQUFTLFFBQVEsT0FBTyxZQUN4QixTQUFTLFNBQVMsT0FBTyxZQUN6QixDQUFDLGFBQWEsV0FBVyxDQUFDLENBQUMsYUFBYSxLQUMxQztFQUNBLEtBQUssUUFBUSxnQkFBZ0IsY0FBYyxPQUFPLFlBQVksVUFBVSxVQUFVLEtBQUs7RUFDdkYsSUFBSSxXQUNGLEtBQUsscUJBQXFCLEtBQUssWUFBWTtFQUU3QyxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXdCQSxhQUFhLEtBQUs7RUFDaEIsSUFBSSxDQUFDLEtBQUssY0FDUixNQUFNLElBQUksTUFBTSxpRkFBaUY7RUFFbkcsTUFBTSxZQUFZLEtBQUs7RUFDdkIsUUFBUSxNQUFNLENBQUM7RUFDZixJQUFJLFNBQVMsVUFBVTtFQUN2QixJQUFJLFFBQVEsTUFBTTtFQUNsQixJQUFJLGFBQWEsS0FBSztFQUN0QixJQUFJLENBQUMsVUFBVSxPQUNiLElBQUksUUFBUSxLQUFLO09BQ1osSUFBSSxJQUFJLE9BQ2IsSUFBSSxNQUFNLFNBQVMsVUFBVSxLQUFLO09BRWxDLElBQUksUUFBUSxVQUFVLE1BQU0sTUFBTTtFQUVwQyxJQUFJLFdBQVcsVUFBVTtFQUN6QixJQUFJLFFBQVEsVUFBVTtFQUN0QixJQUFJLFFBQVEsQ0FBQyxDQUFDLFVBQVU7RUFDeEIsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3QkEsb0JBQW9CLGNBQWMsT0FBTztFQUN2QyxJQUFJLENBQUMsY0FBYztHQUNqQixlQUFlLEtBQUs7R0FDcEIsSUFBSSxDQUFDLGNBQWMsT0FBTztHQUMxQixRQUFRLGFBQWE7RUFDdkI7RUFDQSxPQUFPLENBQUMsQ0FBQyxXQUFXLEtBQUssVUFBVSxTQUFTLGFBQWEsU0FBUyxDQUFDLGFBQWE7Q0FDbEY7Ozs7OztDQU1BLElBQUksb0JBQW9CO0VBQ3RCLFlBQVksU0FBUyx1RkFBdUY7RUFDNUcsT0FBTyxLQUFLLG9CQUFvQjtDQUNsQztDQUNBLE1BQU0sUUFBUSxRQUFRLE1BQU0sS0FBSyxZQUFZLFdBQVcsS0FBSyxVQUFVLFFBQVEsS0FBSyxPQUFPO0VBQ3pGLElBQUksQ0FBQyxPQUFPO0VBQ1osSUFBSSxRQUNGLFNBQVMsS0FBSyxnQkFBZ0IsTUFBTTtFQUV0QyxLQUFLLFFBQVEsTUFDWCxVQUFVLEtBQUssY0FDZixPQUNBLFlBQ0EsS0FBSyxVQUNMLFVBQ0EsS0FDRjtDQUNGO0NBQ0EsZ0JBQWdCO0VBQ2QsS0FBSyx1QkFBdUMsdUJBQU8sT0FBTyxJQUFJO0NBQ2hFO0NBQ0EsS0FBSyxrQkFBa0IsUUFBUSxNQUFNLEtBQUssWUFBWSxPQUFPLFdBQVcsR0FBRyxRQUFRLEdBQUcsT0FBTztFQUMzRixJQUFJO0VBQ0osSUFBSSxZQUFZLGtCQUNkLFVBQVU7T0FDTDtHQUNMLFlBQVksVUFBVSx3S0FBd0s7R0FDOUwsVUFBVTtJQUFFLFFBQVE7SUFBa0I7SUFBTztJQUFZO0lBQU87SUFBVTtJQUFPO0dBQU07RUFDekY7RUFDQSxNQUFNLGVBQWUsS0FBSyxLQUFLLE9BQU87RUFDdEMsS0FBSyxtQkFBbUIsS0FBSztHQUMzQixRQUFRLFFBQVE7R0FDaEIsT0FBTztHQUNQLFlBQVksS0FBSztHQUNqQixPQUFPLFFBQVEsUUFBUSxRQUFRLE1BQU0sTUFBTSxJQUFJLEtBQUs7R0FDcEQsVUFBVSxRQUFRO0dBQ2xCLE9BQU8sUUFBUTtHQUNmLE9BQU8sUUFBUTtFQUNqQixDQUFDO0VBQ0QsT0FBTztDQUNUOzs7OztDQUtBLE1BQU07RUFDSixLQUFLLG1CQUFtQixJQUFJO0VBQzVCLE1BQU0sV0FBVyxLQUFLLG1CQUFtQixLQUFLLG1CQUFtQixTQUFTO0VBQzFFLElBQUksQ0FBQyxVQUNILE1BQU0sSUFBSSxNQUFNLDJFQUEyRTtFQUU3RixPQUFPLEtBQUssS0FBSyxRQUFRO0NBQzNCOzs7Ozs7OztDQVFBLGdCQUFnQixlQUFlO0VBQzdCLElBQUksY0FBYyxXQUNoQixnQkFBZ0IsY0FBYztFQUVoQyxPQUFPLEtBQUssaUNBQWlDLElBQUksYUFBYSxLQUFLLEtBQUssa0JBQWtCLGFBQWE7Q0FDekc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3Q0EsY0FBYyxxQkFBcUIsb0JBQW9CLFdBQVcsTUFBTSxZQUFZO0VBQ2xGLE1BQU0scUJBQXFCLEtBQUssZ0JBQWdCLG1CQUFtQjtFQUNuRSxJQUFJLFVBQVUsSUFBSSxHQUFHO0dBQ25CLEtBQUssU0FBUyxVQUFVO0dBQ3hCLFdBQVcsS0FBSyxVQUFVO0dBQzFCLFVBQVUsSUFBSTtFQUNoQjtFQUNBLElBQUksVUFBVSxJQUFJLEdBQUc7R0FDbkIsS0FBSyxVQUFVLFVBQVU7R0FDekIsV0FBVyxLQUFLLFVBQVU7R0FDMUIsVUFBVSxJQUFJO0VBQ2hCO0VBQ0EsTUFBTSxFQUFFLFlBQVksZ0JBQWdCO0VBQ3BDLEtBQUssUUFBUSxLQUFLLElBQUksS0FBSyxPQUFPLGFBQWEsVUFBVSxDQUFDO0VBQzFELEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxRQUFRLGNBQWMsVUFBVSxDQUFDO0VBQzdELE9BQU8sS0FBSyxRQUFRLGNBQ2xCLG9CQUNBLG9CQUNBLFdBQ0EsTUFDQSxVQUNGO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQ0EsaUJBQWlCLFFBQVEsYUFBYSxXQUFXLE1BQU0sYUFBYTtFQUFFLEdBQUc7RUFBRyxHQUFHO0NBQUUsR0FBRztFQUNsRixNQUFNLHFCQUFxQixLQUFLLGdCQUFnQixNQUFNO0VBQ3RELElBQUksQ0FBQyxtQkFBbUIsd0JBQXdCO0dBQzlDLEtBQUssc0dBQXNHO0dBQzNHO0VBQ0Y7RUFDQSxNQUFNLGFBQWEsWUFBWTtFQUMvQixJQUFJLENBQUMsV0FBVyxPQUFPLFNBQVMsT0FBTyxLQUFLLENBQUMsV0FBVyxPQUFPLFNBQVMsU0FBUyxHQUFHO0dBQ2xGLEtBQUsseUdBQXlHLFdBQVcsT0FBTyxHQUFHO0dBQ25JO0VBQ0Y7RUFDQSxJQUFJLE9BQU8sVUFBVTtFQUNyQixJQUFJLE9BQU8sVUFBVTtFQUNyQixJQUFJLFFBQVEsV0FBVztFQUN2QixJQUFJLFFBQVEsV0FBVztFQUN2QixJQUFJLFFBQVEsS0FBSztFQUNqQixJQUFJLFNBQVMsS0FBSztFQUNsQixJQUFJLE9BQU8sR0FBRztHQUNaLFNBQVM7R0FDVCxTQUFTO0dBQ1QsT0FBTztFQUNUO0VBQ0EsSUFBSSxPQUFPLEdBQUc7R0FDWixVQUFVO0dBQ1YsU0FBUztHQUNULE9BQU87RUFDVDtFQUNBLFFBQVEsS0FBSyxJQUFJLE9BQU8sbUJBQW1CLGFBQWEsSUFBSTtFQUM1RCxTQUFTLEtBQUssSUFBSSxRQUFRLG1CQUFtQixjQUFjLElBQUk7RUFDL0QsUUFBUSxLQUFLLElBQUksT0FBTyxXQUFXLGFBQWEsS0FBSztFQUNyRCxTQUFTLEtBQUssSUFBSSxRQUFRLFdBQVcsY0FBYyxLQUFLO0VBQ3hELElBQUksU0FBUyxLQUFLLFVBQVUsR0FBRztFQUMvQixLQUFLLFFBQVEsaUJBQ1gsb0JBQ0EsYUFDQTtHQUFFLEdBQUc7R0FBTSxHQUFHO0VBQUssR0FDbkI7R0FBRTtHQUFPO0VBQU8sR0FDaEI7R0FBRSxHQUFHO0dBQU8sR0FBRztFQUFNLENBQ3ZCO0NBQ0Y7Ozs7O0NBS0EscUJBQXFCO0VBQ25CLElBQUksQ0FBQyxLQUFLLGFBQWEsU0FBUztHQUM5QixJQUFJLEtBQUssYUFBYSxxQkFBcUI7SUFDekMsS0FBSywwR0FBMEcsS0FBSyxhQUFhLG9CQUFvQixPQUFPLG9HQUFvRztJQUNoUTtHQUNGO0dBQ0EsS0FBSyxhQUFhLFNBQVM7R0FDM0IsS0FBSyxhQUFhLFdBQVc7R0FDN0IsS0FBSyxRQUFRLGdCQUFnQixLQUFLLGNBQWMsT0FBTyxNQUFNLEtBQUssVUFBVSxHQUFHLEtBQUssS0FBSztFQUMzRjtDQUNGOztDQUVBLFVBQVU7RUFDUixLQUFLLFlBQVk7RUFDakIsS0FBSyxpQ0FBaUMsU0FBUyxjQUFjLFFBQVE7R0FDbkUsSUFBSSxpQkFBaUIsS0FDbkIsS0FBSyxxQkFBcUIsS0FBSyxZQUFZO1FBRTNDLGFBQWEsSUFBSSxXQUFXLEtBQUssd0JBQXdCLElBQUk7RUFFakUsQ0FBQztFQUNELEtBQUssaUNBQWlDLE1BQU07RUFDNUMsS0FBSyxNQUFNLG1CQUFtQixPQUFPLE9BQU8sS0FBSyxvQkFBb0IsR0FDbkUsSUFBSSxpQkFBaUIsS0FBSyxRQUFRLHVCQUF1QixlQUFlO0VBRTFFLEtBQUssdUJBQXVDLHVCQUFPLE9BQU8sSUFBSTtDQUNoRTtDQUNBLGtCQUFrQixlQUFlO0VBQy9CLElBQUksZUFBZTtFQUNuQixJQUFJLGFBQWEsS0FBSyxhQUFhLEdBQ2pDLGdCQUFnQixpQkFBaUIsYUFBYSxDQUFDLENBQUM7RUFFbEQsSUFBSSx5QkFBeUIsY0FBYztHQUN6QyxlQUFlO0dBQ2YsY0FBYyxLQUFLLFdBQVcsS0FBSyx3QkFBd0IsSUFBSTtFQUNqRSxPQUFPLElBQUkseUJBQXlCLGVBQWU7R0FDakQsTUFBTSxTQUFTLGNBQWM7R0FFN0IsZUFEdUIsT0FBTyxTQUFTLE9BQU8sS0FBSyxPQUFPLFNBQVMsU0FBUyxJQUM1QyxJQUFJLGFBQWE7SUFBRSxlQUFlO0lBQUcscUJBQXFCO0dBQWMsQ0FBQyxJQUFJLElBQUksYUFBYSxFQUFFLGVBQWUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztHQUNoSyxJQUFJLGNBQWMsa0JBQWtCLGNBQ2xDLGFBQWEsU0FBUztHQUV4QixjQUFjLEtBQUssV0FBVyxLQUFLLHlCQUF5QixJQUFJO0VBQ2xFO0VBQ0EsS0FBSyxpQ0FBaUMsSUFBSSxlQUFlLFlBQVk7RUFDckUsT0FBTztDQUNUO0NBQ0Esd0JBQXdCLGVBQWU7RUFDckMsTUFBTSxlQUFlLEtBQUssaUNBQWlDLElBQUksYUFBYTtFQUM1RSxJQUFJLGNBQWMsS0FBSyxxQkFBcUIsZUFBZSxZQUFZO0NBQ3pFOzs7Ozs7Q0FNQSx1QkFBdUIsY0FBYztFQUNuQyxLQUFLLGlDQUFpQyxPQUFPLFlBQVk7RUFDekQsS0FBSyx3QkFBd0IsWUFBWTtDQUMzQzs7Ozs7Ozs7Q0FRQSxxQkFBcUIsZUFBZSxjQUFjO0VBQ2hELGFBQWEsUUFBUTtFQUNyQixLQUFLLGlDQUFpQyxPQUFPLGFBQWE7RUFDMUQsY0FBYyxJQUFJLFdBQVcsS0FBSyx5QkFBeUIsSUFBSTtFQUMvRCxLQUFLLHdCQUF3QixZQUFZO0NBQzNDOzs7OztDQUtBLHdCQUF3QixjQUFjO0VBQ3BDLE1BQU0sa0JBQWtCLEtBQUsscUJBQXFCLGFBQWE7RUFDL0QsSUFBSSxpQkFBaUI7R0FDbkIsS0FBSyxxQkFBcUIsYUFBYSxPQUFPO0dBQzlDLEtBQUssUUFBUSx1QkFBdUIsZUFBZTtFQUNyRDtDQUNGO0NBQ0EsbUJBQW1CLGNBQWM7RUFDL0IsT0FBTyxLQUFLLHFCQUFxQixhQUFhLFNBQVMsS0FBSyxxQkFBcUIsYUFBYSxPQUFPLEtBQUssUUFBUSxvQkFBb0IsWUFBWTtDQUNwSjtDQUNBLGFBQWE7RUFDWCxLQUFLLGVBQWU7RUFDcEIsS0FBSyxXQUFXLFNBQVM7Q0FDM0I7QUFDRiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzLDM0LDM1LDM2LDM3LDM4LDM5LDQwLDQxLDQyLDQzLDQ0XX0=
import { G as Texture, H as warn, J as TextureSource, N as DOMAdapter, W as Bounds, _t as ExtensionType, d as BindGroup, dt as Matrix, f as UniformGroup, g as GpuProgram, lt as Rectangle, q as BufferImageSource, r as Geometry, t as CanvasPool, u as RendererType, vt as extensions, w as GlProgram } from "/node_modules/.vite/deps/CanvasPool-BcIVNj8Y.js?v=7ab6e4ce";
import { M as matrixPool, O as getGlobalBounds, _ as TexturePool, c as Sprite, i as Ticker, j as boundsPool, s as CanvasSource, t as Filter, u as Container, w as getLocalBounds } from "/node_modules/.vite/deps/Filter-BpcfXGWT.js?v=7ab6e4ce";
import { r as ImageSource, t as canvasUtils } from "/node_modules/.vite/deps/canvasUtils-BdSlPf1K.js?v=7ab6e4ce";
import { n as convertToList, t as Cache } from "/node_modules/.vite/deps/Cache-JEGFrDRF.js?v=7ab6e4ce";
//#region node_modules/pixi.js/lib/rendering/mask/utils/addMaskBounds.mjs
var tempBounds$1 = new Bounds();
function addMaskBounds(mask, bounds, skipUpdateTransform) {
	const boundsToMask = tempBounds$1;
	mask.measurable = true;
	getGlobalBounds(mask, skipUpdateTransform, boundsToMask);
	bounds.addBoundsMask(boundsToMask);
	mask.measurable = false;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/utils/addMaskLocalBounds.mjs
function addMaskLocalBounds(mask, bounds, localRoot) {
	const boundsToMask = boundsPool.get();
	mask.measurable = true;
	const tempMatrix = matrixPool.get().identity();
	const relativeMask = getMatrixRelativeToParent(mask, localRoot, tempMatrix);
	getLocalBounds(mask, boundsToMask, relativeMask);
	mask.measurable = false;
	bounds.addBoundsMask(boundsToMask);
	matrixPool.return(tempMatrix);
	boundsPool.return(boundsToMask);
}
function getMatrixRelativeToParent(target, root, matrix) {
	if (!target) {
		warn("Mask bounds, renderable is not inside the root container");
		return matrix;
	}
	if (target !== root) {
		getMatrixRelativeToParent(target.parent, root, matrix);
		target.updateLocalTransform();
		matrix.append(target.localTransform);
	}
	return matrix;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/alpha/AlphaMask.mjs
var AlphaMask = class {
	constructor(options) {
		this.priority = 0;
		this.inverse = false;
		this.channel = "red";
		this.pipe = "alphaMask";
		if (options?.mask) this.init(options.mask);
	}
	init(mask) {
		this.mask = mask;
		this.renderMaskToTexture = !(mask instanceof Sprite);
		this.mask.renderable = this.renderMaskToTexture;
		this.mask.includeInBuild = !this.renderMaskToTexture;
		this.mask.measurable = false;
	}
	reset() {
		if (this.mask === null) return;
		this.mask.measurable = true;
		this.mask = null;
	}
	addBounds(bounds, skipUpdateTransform) {
		if (!this.inverse) addMaskBounds(this.mask, bounds, skipUpdateTransform);
	}
	addLocalBounds(bounds, localRoot) {
		addMaskLocalBounds(this.mask, bounds, localRoot);
	}
	containsPoint(point, hitTestFn) {
		const mask = this.mask;
		return hitTestFn(mask, point);
	}
	destroy() {
		this.reset();
	}
	static test(mask) {
		return mask instanceof Sprite;
	}
};
AlphaMask.extension = ExtensionType.MaskEffect;
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/color/ColorMask.mjs
var ColorMask = class {
	constructor(options) {
		this.priority = 0;
		this.pipe = "colorMask";
		if (options?.mask) this.init(options.mask);
	}
	init(mask) {
		this.mask = mask;
	}
	destroy() {}
	static test(mask) {
		return typeof mask === "number";
	}
};
ColorMask.extension = ExtensionType.MaskEffect;
//#endregion
//#region node_modules/pixi.js/lib/rendering/mask/stencil/StencilMask.mjs
var StencilMask = class {
	constructor(options) {
		this.priority = 0;
		this.pipe = "stencilMask";
		if (options?.mask) this.init(options.mask);
	}
	init(mask) {
		this.mask = mask;
		this.mask.includeInBuild = false;
		this.mask.measurable = false;
	}
	reset() {
		if (this.mask === null) return;
		this.mask.measurable = true;
		this.mask.includeInBuild = true;
		this.mask = null;
	}
	addBounds(bounds, skipUpdateTransform) {
		addMaskBounds(this.mask, bounds, skipUpdateTransform);
	}
	addLocalBounds(bounds, localRoot) {
		addMaskLocalBounds(this.mask, bounds, localRoot);
	}
	containsPoint(point, hitTestFn) {
		const mask = this.mask;
		return hitTestFn(mask, point);
	}
	destroy() {
		this.reset();
	}
	static test(mask) {
		return mask instanceof Container;
	}
};
StencilMask.extension = ExtensionType.MaskEffect;
//#endregion
//#region node_modules/pixi.js/lib/utils/browser/detectVideoAlphaMode.mjs
var promise;
async function detectVideoAlphaMode() {
	promise ?? (promise = (async () => {
		const gl = DOMAdapter.get().createCanvas(1, 1).getContext("webgl");
		if (!gl) return "premultiply-alpha-on-upload";
		const video = await new Promise((resolve) => {
			const video2 = document.createElement("video");
			video2.onloadeddata = () => resolve(video2);
			video2.onerror = () => resolve(null);
			video2.autoplay = false;
			video2.crossOrigin = "anonymous";
			video2.preload = "auto";
			video2.src = "data:video/webm;base64,GkXfo59ChoEBQveBAULygQRC84EIQoKEd2VibUKHgQJChYECGFOAZwEAAAAAAAHTEU2bdLpNu4tTq4QVSalmU6yBoU27i1OrhBZUrmtTrIHGTbuMU6uEElTDZ1OsggEXTbuMU6uEHFO7a1OsggG97AEAAAAAAABZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVSalmoCrXsYMPQkBNgIRMYXZmV0GETGF2ZkSJiEBEAAAAAAAAFlSua8yuAQAAAAAAAEPXgQFzxYgAAAAAAAAAAZyBACK1nIN1bmSIgQCGhVZfVlA5g4EBI+ODhAJiWgDglLCBArqBApqBAlPAgQFVsIRVuYEBElTDZ9Vzc9JjwItjxYgAAAAAAAAAAWfInEWjh0VOQ09ERVJEh49MYXZjIGxpYnZweC12cDlnyKJFo4hEVVJBVElPTkSHlDAwOjAwOjAwLjA0MDAwMDAwMAAAH0O2dcfngQCgwqGggQAAAIJJg0IAABAAFgA4JBwYSgAAICAAEb///4r+AAB1oZ2mm+6BAaWWgkmDQgAAEAAWADgkHBhKAAAgIABIQBxTu2uRu4+zgQC3iveBAfGCAXHwgQM=";
			video2.load();
		});
		if (!video) return "premultiply-alpha-on-upload";
		const texture = gl.createTexture();
		gl.bindTexture(gl.TEXTURE_2D, texture);
		const framebuffer = gl.createFramebuffer();
		gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
		gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
		gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
		gl.pixelStorei(gl.UNPACK_COLORSPACE_CONVERSION_WEBGL, gl.NONE);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, video);
		const pixel = /* @__PURE__ */ new Uint8Array(4);
		gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, pixel);
		gl.deleteFramebuffer(framebuffer);
		gl.deleteTexture(texture);
		gl.getExtension("WEBGL_lose_context")?.loseContext();
		return pixel[0] <= pixel[3] ? "premultiplied-alpha" : "premultiply-alpha-on-upload";
	})());
	return promise;
}
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/sources/VideoSource.mjs
var _VideoSource = class _VideoSource extends TextureSource {
	constructor(options) {
		super(options);
		/** Whether or not the video is ready to play. */
		this.isReady = false;
		/** The upload method for this texture. */
		this.uploadMethodId = "video";
		options = {
			..._VideoSource.defaultOptions,
			...options
		};
		this._autoUpdate = true;
		this._isConnectedToTicker = false;
		this._updateFPS = options.updateFPS || 0;
		this._msToNextUpdate = 0;
		this.autoPlay = options.autoPlay !== false;
		this.alphaMode = options.alphaMode ?? "premultiply-alpha-on-upload";
		this._videoFrameRequestCallback = this._videoFrameRequestCallback.bind(this);
		this._videoFrameRequestCallbackHandle = null;
		this._load = null;
		this._resolve = null;
		this._reject = null;
		this._onCanPlay = this._onCanPlay.bind(this);
		this._onCanPlayThrough = this._onCanPlayThrough.bind(this);
		this._onError = this._onError.bind(this);
		this._onPlayStart = this._onPlayStart.bind(this);
		this._onPlayStop = this._onPlayStop.bind(this);
		this._onSeeked = this._onSeeked.bind(this);
		this._onLoadedMetadata = this._onLoadedMetadata.bind(this);
		if (options.autoLoad !== false) this.load();
	}
	/** Update the video frame if the source is not destroyed and meets certain conditions. */
	updateFrame() {
		if (this.destroyed) return;
		if (this._updateFPS) {
			const elapsedMS = Ticker.shared.elapsedMS * this.resource.playbackRate;
			this._msToNextUpdate = Math.floor(this._msToNextUpdate - elapsedMS);
		}
		if (!this._updateFPS || this._msToNextUpdate <= 0) this._msToNextUpdate = this._updateFPS ? Math.floor(1e3 / this._updateFPS) : 0;
		if (this.isValid) this.update();
	}
	/** Callback to update the video frame and potentially request the next frame update. */
	_videoFrameRequestCallback() {
		this.updateFrame();
		if (this.destroyed) this._videoFrameRequestCallbackHandle = null;
		else this._videoFrameRequestCallbackHandle = this.resource.requestVideoFrameCallback(this._videoFrameRequestCallback);
	}
	/**
	* Checks if the resource has valid dimensions.
	* @returns {boolean} True if width and height are set, otherwise false.
	*/
	get isValid() {
		return !!this.resource.videoWidth && !!this.resource.videoHeight;
	}
	/**
	* Start preloading the video resource.
	* @returns {Promise<this>} Handle the validate event
	*/
	async load() {
		if (this._load) return this._load;
		const source = this.resource;
		const options = this.options;
		if ((source.readyState === source.HAVE_ENOUGH_DATA || source.readyState === source.HAVE_FUTURE_DATA) && source.width && source.height) source.complete = true;
		source.addEventListener("play", this._onPlayStart);
		source.addEventListener("pause", this._onPlayStop);
		source.addEventListener("seeked", this._onSeeked);
		if (!this._isSourceReady()) {
			if (!options.preload) source.addEventListener("canplay", this._onCanPlay);
			source.addEventListener("canplaythrough", this._onCanPlayThrough);
			source.addEventListener("error", this._onError, true);
		} else this._mediaReady();
		if (!this.isValid) source.addEventListener("loadedmetadata", this._onLoadedMetadata);
		this.alphaMode = await detectVideoAlphaMode();
		this._load = new Promise((resolve, reject) => {
			if (this.isValid) resolve(this);
			else {
				this._resolve = resolve;
				this._reject = reject;
				if (options.preloadTimeoutMs !== void 0) this._preloadTimeout = setTimeout(() => {
					this._onError(new ErrorEvent(`Preload exceeded timeout of ${options.preloadTimeoutMs}ms`));
				});
				source.load();
			}
		});
		return this._load;
	}
	/**
	* Handle video error events.
	* @param event - The error event
	*/
	_onError(event) {
		this.resource.removeEventListener("error", this._onError, true);
		this.emit("error", event);
		if (this._reject) {
			this._reject(event);
			this._reject = null;
			this._resolve = null;
		}
	}
	/**
	* Checks if the underlying source is playing.
	* @returns True if playing.
	*/
	_isSourcePlaying() {
		const source = this.resource;
		return !source.paused && !source.ended;
	}
	/**
	* Checks if the underlying source is ready for playing.
	* @returns True if ready.
	*/
	_isSourceReady() {
		return this.resource.readyState > 2;
	}
	/** Runs the update loop when the video is ready to play. */
	_onPlayStart() {
		this._configureAutoUpdate();
	}
	/** Stops the update loop when a pause event is triggered. */
	_onPlayStop() {
		this._configureAutoUpdate();
	}
	/** Handles behavior when the video completes seeking to the current playback position. */
	_onSeeked() {
		if (this._autoUpdate && !this._isSourcePlaying()) {
			this._msToNextUpdate = 0;
			this.updateFrame();
			this._msToNextUpdate = 0;
		}
	}
	/** When intrinsic size becomes known after play / canplay (common with MediaStream). */
	_onLoadedMetadata() {
		if (!this.isValid) return;
		this._mediaReady();
	}
	_onCanPlay() {
		this.resource.removeEventListener("canplay", this._onCanPlay);
		this._mediaReady();
	}
	_onCanPlayThrough() {
		this.resource.removeEventListener("canplaythrough", this._onCanPlayThrough);
		if (this._preloadTimeout) {
			clearTimeout(this._preloadTimeout);
			this._preloadTimeout = void 0;
		}
		this._mediaReady();
	}
	/** Fired when the video is loaded and ready to play. */
	_mediaReady() {
		const source = this.resource;
		if (this.isValid) {
			this.isReady = true;
			this.resize(source.videoWidth, source.videoHeight);
		}
		this._msToNextUpdate = 0;
		this.updateFrame();
		this._msToNextUpdate = 0;
		if (this._resolve && this.isValid) {
			this._resolve(this);
			this._resolve = null;
			this._reject = null;
		}
		if (this._isSourcePlaying()) this._onPlayStart();
		else if (this.autoPlay) this.resource.play();
	}
	/** Cleans up resources and event listeners associated with this texture. */
	destroy() {
		this._configureAutoUpdate();
		const source = this.resource;
		if (source) {
			source.removeEventListener("play", this._onPlayStart);
			source.removeEventListener("pause", this._onPlayStop);
			source.removeEventListener("seeked", this._onSeeked);
			source.removeEventListener("canplay", this._onCanPlay);
			source.removeEventListener("canplaythrough", this._onCanPlayThrough);
			source.removeEventListener("loadedmetadata", this._onLoadedMetadata);
			source.removeEventListener("error", this._onError, true);
			source.pause();
			source.src = "";
			source.load();
		}
		super.destroy();
	}
	/** Should the base texture automatically update itself, set to true by default. */
	get autoUpdate() {
		return this._autoUpdate;
	}
	set autoUpdate(value) {
		if (value !== this._autoUpdate) {
			this._autoUpdate = value;
			this._configureAutoUpdate();
		}
	}
	/**
	* How many times a second to update the texture from the video.
	* Leave at 0 to update at every render.
	* A lower fps can help performance, as updating the texture at 60fps on a 30ps video may not be efficient.
	*/
	get updateFPS() {
		return this._updateFPS;
	}
	set updateFPS(value) {
		if (value !== this._updateFPS) {
			this._updateFPS = value;
			this._configureAutoUpdate();
		}
	}
	/**
	* Configures the updating mechanism based on the current state and settings.
	*
	* This method decides between using the browser's native video frame callback or a custom ticker
	* for updating the video frame. It ensures optimal performance and responsiveness
	* based on the video's state, playback status, and the desired frames-per-second setting.
	*
	* - If `_autoUpdate` is enabled and the video source is playing:
	*   - It will prefer the native video frame callback if available and no specific FPS is set.
	*   - Otherwise, it will use a custom ticker for manual updates.
	* - If `_autoUpdate` is disabled or the video isn't playing, any active update mechanisms are halted.
	*/
	_configureAutoUpdate() {
		if (this._autoUpdate && this._isSourcePlaying()) {
			if (!this._updateFPS && this.resource.requestVideoFrameCallback) {
				if (this._isConnectedToTicker) {
					Ticker.shared.remove(this.updateFrame, this);
					this._isConnectedToTicker = false;
					this._msToNextUpdate = 0;
				}
				if (this._videoFrameRequestCallbackHandle === null) this._videoFrameRequestCallbackHandle = this.resource.requestVideoFrameCallback(this._videoFrameRequestCallback);
			} else {
				if (this._videoFrameRequestCallbackHandle !== null) {
					this.resource.cancelVideoFrameCallback(this._videoFrameRequestCallbackHandle);
					this._videoFrameRequestCallbackHandle = null;
				}
				if (!this._isConnectedToTicker) {
					Ticker.shared.add(this.updateFrame, this);
					this._isConnectedToTicker = true;
					this._msToNextUpdate = 0;
				}
			}
		} else {
			if (this._videoFrameRequestCallbackHandle !== null) {
				this.resource.cancelVideoFrameCallback(this._videoFrameRequestCallbackHandle);
				this._videoFrameRequestCallbackHandle = null;
			}
			if (this._isConnectedToTicker) {
				Ticker.shared.remove(this.updateFrame, this);
				this._isConnectedToTicker = false;
				this._msToNextUpdate = 0;
			}
		}
	}
	static test(resource) {
		return globalThis.HTMLVideoElement && resource instanceof HTMLVideoElement;
	}
};
_VideoSource.extension = ExtensionType.TextureSource;
/** The default options for video sources. */
_VideoSource.defaultOptions = {
	...TextureSource.defaultOptions,
	/** If true, the video will start loading immediately. */
	autoLoad: true,
	/** If true, the video will start playing as soon as it is loaded. */
	autoPlay: true,
	/** The number of times a second to update the texture from the video. Leave at 0 to update at every render. */
	updateFPS: 0,
	/** If true, the video will be loaded with the `crossorigin` attribute. */
	crossorigin: true,
	/** If true, the video will loop when it ends. */
	loop: false,
	/** If true, the video will be muted. */
	muted: true,
	/** If true, the video will play inline. */
	playsinline: true,
	/** If true, the video will be preloaded. */
	preload: false
};
/**
* Map of video MIME types that can't be directly derived from file extensions.
* @readonly
*/
_VideoSource.MIME_TYPES = {
	ogv: "video/ogg",
	mov: "video/quicktime",
	m4v: "video/mp4"
};
var VideoSource = _VideoSource;
//#endregion
//#region node_modules/pixi.js/lib/rendering/renderers/shared/texture/utils/textureFrom.mjs
var sources = [];
extensions.handleByList(ExtensionType.TextureSource, sources);
function autoDetectSource(options = {}) {
	return textureSourceFrom(options);
}
function textureSourceFrom(options = {}) {
	const hasResource = options && options.resource;
	const res = hasResource ? options.resource : options;
	const opts = hasResource ? options : { resource: options };
	for (let i = 0; i < sources.length; i++) {
		const Source = sources[i];
		if (Source.test(res)) return new Source(opts);
	}
	throw new Error(`Could not find a source type for resource: ${opts.resource}`);
}
function resourceToTexture(options = {}, skipCache = false) {
	const hasResource = options && options.resource;
	const resource = hasResource ? options.resource : options;
	const opts = hasResource ? options : { resource: options };
	if (!skipCache && Cache.has(resource)) return Cache.get(resource);
	const texture = new Texture({ source: textureSourceFrom(opts) });
	texture.on("destroy", () => {
		if (Cache.has(resource)) Cache.remove(resource);
	});
	if (!skipCache) Cache.set(resource, texture);
	return texture;
}
function textureFrom(id, skipCache = false) {
	if (typeof id === "string") return Cache.get(id);
	else if (id instanceof TextureSource) return new Texture({ source: id });
	return resourceToTexture(id, skipCache);
}
Texture.from = textureFrom;
TextureSource.from = textureSourceFrom;
//#endregion
//#region node_modules/pixi.js/lib/rendering/init.mjs
extensions.add(AlphaMask, ColorMask, StencilMask, VideoSource, ImageSource, CanvasSource, BufferImageSource);
//#endregion
//#region node_modules/pixi.js/lib/assets/loader/parsers/LoaderParser.mjs
var LoaderParserPriority = /* @__PURE__ */ ((LoaderParserPriority2) => {
	LoaderParserPriority2[LoaderParserPriority2["Low"] = 0] = "Low";
	LoaderParserPriority2[LoaderParserPriority2["Normal"] = 1] = "Normal";
	LoaderParserPriority2[LoaderParserPriority2["High"] = 2] = "High";
	return LoaderParserPriority2;
})(LoaderParserPriority || {});
//#endregion
//#region node_modules/pixi.js/lib/utils/path.mjs
function assertPath(path2) {
	if (typeof path2 !== "string") throw new TypeError(`Path must be a string. Received ${JSON.stringify(path2)}`);
}
function removeUrlParams(url) {
	return url.split("?")[0].split("#")[0];
}
function escapeRegExp(string) {
	return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function replaceAll(str, find, replace) {
	return str.replace(new RegExp(escapeRegExp(find), "g"), replace);
}
function normalizeStringPosix(path2, allowAboveRoot) {
	let res = "";
	let lastSegmentLength = 0;
	let lastSlash = -1;
	let dots = 0;
	let code = -1;
	for (let i = 0; i <= path2.length; ++i) {
		if (i < path2.length) code = path2.charCodeAt(i);
		else if (code === 47) break;
		else code = 47;
		if (code === 47) {
			if (lastSlash === i - 1 || dots === 1) {} else if (lastSlash !== i - 1 && dots === 2) {
				if (res.length < 2 || lastSegmentLength !== 2 || res.charCodeAt(res.length - 1) !== 46 || res.charCodeAt(res.length - 2) !== 46) {
					if (res.length > 2) {
						const lastSlashIndex = res.lastIndexOf("/");
						if (lastSlashIndex !== res.length - 1) {
							if (lastSlashIndex === -1) {
								res = "";
								lastSegmentLength = 0;
							} else {
								res = res.slice(0, lastSlashIndex);
								lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
							}
							lastSlash = i;
							dots = 0;
							continue;
						}
					} else if (res.length === 2 || res.length === 1) {
						res = "";
						lastSegmentLength = 0;
						lastSlash = i;
						dots = 0;
						continue;
					}
				}
				if (allowAboveRoot) {
					if (res.length > 0) res += "/..";
					else res = "..";
					lastSegmentLength = 2;
				}
			} else {
				if (res.length > 0) res += `/${path2.slice(lastSlash + 1, i)}`;
				else res = path2.slice(lastSlash + 1, i);
				lastSegmentLength = i - lastSlash - 1;
			}
			lastSlash = i;
			dots = 0;
		} else if (code === 46 && dots !== -1) ++dots;
		else dots = -1;
	}
	return res;
}
var path = {
	/**
	* Converts a path to posix format.
	* @param path - The path to convert to posix
	* @example
	* ```ts
	* // Convert a Windows path to POSIX format
	* path.toPosix('C:\\Users\\User\\Documents\\file.txt');
	* // -> 'C:/Users/User/Documents/file.txt'
	* ```
	*/
	toPosix(path2) {
		return replaceAll(path2, "\\", "/");
	},
	/**
	* Checks if the path is a URL e.g. http://, https://
	* @param path - The path to check
	* @example
	* ```ts
	* // Check if a path is a URL
	* path.isUrl('http://www.example.com');
	* // -> true
	* path.isUrl('C:/Users/User/Documents/file.txt');
	* // -> false
	* ```
	*/
	isUrl(path2) {
		return /^https?:/.test(this.toPosix(path2));
	},
	/**
	* Checks if the path is a data URL
	* @param path - The path to check
	* @example
	* ```ts
	* // Check if a path is a data URL
	* path.isDataUrl('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUA...');
	* // -> true
	* ```
	*/
	isDataUrl(path2) {
		return /^data:([a-z]+\/[a-z0-9-+.]+(;[a-z0-9-.!#$%*+.{}|~`]+=[a-z0-9-.!#$%*+.{}()_|~`]+)*)?(;base64)?,([a-z0-9!$&',()*+;=\-._~:@\/?%\s<>]*?)$/i.test(path2);
	},
	/**
	* Checks if the path is a blob URL
	* @param path - The path to check
	* @example
	* ```ts
	* // Check if a path is a blob URL
	* path.isBlobUrl('blob:http://www.example.com/12345678-1234-1234-1234-123456789012');
	* // -> true
	* ```
	*/
	isBlobUrl(path2) {
		return path2.startsWith("blob:");
	},
	/**
	* Checks if the path has a protocol e.g. http://, https://, file:///, data:, blob:, C:/
	* This will return true for windows file paths
	* @param path - The path to check
	* @example
	* ```ts
	* // Check if a path has a protocol
	* path.hasProtocol('http://www.example.com');
	* // -> true
	* path.hasProtocol('C:/Users/User/Documents/file.txt');
	* // -> true
	* ```
	*/
	hasProtocol(path2) {
		return /^[^/:]+:/.test(this.toPosix(path2));
	},
	/**
	* Returns the protocol of the path e.g. http://, https://, file:///, data:, blob:, C:/
	* @param path - The path to get the protocol from
	* @example
	* ```ts
	* // Get the protocol from a URL
	* path.getProtocol('http://www.example.com/path/to/resource');
	* // -> 'http://'
	* // Get the protocol from a file path
	* path.getProtocol('C:/Users/User/Documents/file.txt');
	* // -> 'C:/'
	* ```
	*/
	getProtocol(path2) {
		assertPath(path2);
		path2 = this.toPosix(path2);
		const matchFile = /^file:\/\/\//.exec(path2);
		if (matchFile) return matchFile[0];
		const matchProtocol = /^[^/:]+:\/{0,2}/.exec(path2);
		if (matchProtocol) return matchProtocol[0];
		return "";
	},
	/**
	* Converts URL to an absolute path.
	* When loading from a Web Worker, we must use absolute paths.
	* If the URL is already absolute we return it as is
	* If it's not, we convert it
	* @param url - The URL to test
	* @param customBaseUrl - The base URL to use
	* @param customRootUrl - The root URL to use
	* @example
	* ```ts
	* // Convert a relative URL to an absolute path
	* path.toAbsolute('images/texture.png', 'http://example.com/assets/');
	* // -> 'http://example.com/assets/images/texture.png'
	* ```
	*/
	toAbsolute(url, customBaseUrl, customRootUrl) {
		assertPath(url);
		if (this.isDataUrl(url) || this.isBlobUrl(url)) return url;
		const baseUrl = removeUrlParams(this.toPosix(customBaseUrl ?? DOMAdapter.get().getBaseUrl()));
		const rootUrl = removeUrlParams(this.toPosix(customRootUrl ?? this.rootname(baseUrl)));
		url = this.toPosix(url);
		if (url.startsWith("/")) return path.join(rootUrl, url.slice(1));
		return this.isAbsolute(url) ? url : this.join(baseUrl, url);
	},
	/**
	* Normalizes the given path, resolving '..' and '.' segments
	* @param path - The path to normalize
	* @example
	* ```ts
	* // Normalize a path with relative segments
	* path.normalize('http://www.example.com/foo/bar/../baz');
	* // -> 'http://www.example.com/foo/baz'
	* // Normalize a file path with relative segments
	* path.normalize('C:\\Users\\User\\Documents\\..\\file.txt');
	* // -> 'C:/Users/User/file.txt'
	* ```
	*/
	normalize(path2) {
		assertPath(path2);
		if (path2.length === 0) return ".";
		if (this.isDataUrl(path2) || this.isBlobUrl(path2)) return path2;
		path2 = this.toPosix(path2);
		let protocol = "";
		const isAbsolute = path2.startsWith("/");
		if (this.hasProtocol(path2)) {
			protocol = this.rootname(path2);
			path2 = path2.slice(protocol.length);
		}
		const trailingSeparator = path2.endsWith("/");
		path2 = normalizeStringPosix(path2, false);
		if (path2.length > 0 && trailingSeparator) path2 += "/";
		if (isAbsolute) return `/${path2}`;
		return protocol + path2;
	},
	/**
	* Determines if path is an absolute path.
	* Absolute paths can be urls, data urls, or paths on disk
	* @param path - The path to test
	* @example
	* ```ts
	* // Check if a path is absolute
	* path.isAbsolute('http://www.example.com/foo/bar');
	* // -> true
	* path.isAbsolute('C:/Users/User/Documents/file.txt');
	* // -> true
	* ```
	*/
	isAbsolute(path2) {
		assertPath(path2);
		path2 = this.toPosix(path2);
		if (this.hasProtocol(path2)) return true;
		return path2.startsWith("/");
	},
	/**
	* Joins all given path segments together using the platform-specific separator as a delimiter,
	* then normalizes the resulting path
	* @param segments - The segments of the path to join
	* @example
	* ```ts
	* // Join multiple path segments
	* path.join('assets', 'images', 'sprite.png');
	* // -> 'assets/images/sprite.png'
	* // Join with relative segments
	* path.join('assets', 'images', '../textures', 'sprite.png');
	* // -> 'assets/textures/sprite.png'
	* ```
	*/
	join(...segments) {
		if (segments.length === 0) return ".";
		let joined;
		for (let i = 0; i < segments.length; ++i) {
			const arg = segments[i];
			assertPath(arg);
			if (arg.length > 0) {
				if (joined === void 0) joined = arg;
				else {
					const prevArg = segments[i - 1] ?? "";
					if (this.joinExtensions.includes(this.extname(prevArg).toLowerCase())) joined += `/../${arg}`;
					else joined += `/${arg}`;
				}
			}
		}
		if (joined === void 0) return ".";
		return this.normalize(joined);
	},
	/**
	* Returns the directory name of a path
	* @param path - The path to parse
	* @example
	* ```ts
	* // Get the directory name of a path
	* path.dirname('http://www.example.com/foo/bar/baz.png');
	* // -> 'http://www.example.com/foo/bar'
	* // Get the directory name of a file path
	* path.dirname('C:/Users/User/Documents/file.txt');
	* // -> 'C:/Users/User/Documents'
	* ```
	*/
	dirname(path2) {
		assertPath(path2);
		if (path2.length === 0) return ".";
		path2 = this.toPosix(path2);
		let code = path2.charCodeAt(0);
		const hasRoot = code === 47;
		let end = -1;
		let matchedSlash = true;
		const proto = this.getProtocol(path2);
		const origpath = path2;
		path2 = path2.slice(proto.length);
		for (let i = path2.length - 1; i >= 1; --i) {
			code = path2.charCodeAt(i);
			if (code === 47) {
				if (!matchedSlash) {
					end = i;
					break;
				}
			} else matchedSlash = false;
		}
		if (end === -1) return hasRoot ? "/" : this.isUrl(origpath) ? proto + path2 : proto;
		if (hasRoot && end === 1) return "//";
		return proto + path2.slice(0, end);
	},
	/**
	* Returns the root of the path e.g. /, C:/, file:///, http://domain.com/
	* @param path - The path to parse
	* @example
	* ```ts
	* // Get the root of a URL
	* path.rootname('http://www.example.com/foo/bar/baz.png');
	* // -> 'http://www.example.com/'
	* // Get the root of a file path
	* path.rootname('C:/Users/User/Documents/file.txt');
	* // -> 'C:/'
	* ```
	*/
	rootname(path2) {
		assertPath(path2);
		path2 = this.toPosix(path2);
		let root = "";
		if (path2.startsWith("/")) root = "/";
		else root = this.getProtocol(path2);
		if (this.isUrl(path2)) {
			const index = path2.indexOf("/", root.length);
			if (index !== -1) root = path2.slice(0, index);
			else root = path2;
			if (!root.endsWith("/")) root += "/";
		}
		return root;
	},
	/**
	* Returns the last portion of a path
	* @param path - The path to test
	* @param ext - Optional extension to remove
	* @example
	* ```ts
	* // Get the basename of a URL
	* path.basename('http://www.example.com/foo/bar/baz.png');
	* // -> 'baz.png'
	* // Get the basename of a file path
	* path.basename('C:/Users/User/Documents/file.txt');
	* // -> 'file.txt'
	* ```
	*/
	basename(path2, ext) {
		assertPath(path2);
		if (ext) assertPath(ext);
		path2 = removeUrlParams(this.toPosix(path2));
		let start = 0;
		let end = -1;
		let matchedSlash = true;
		let i;
		if (ext !== void 0 && ext.length > 0 && ext.length <= path2.length) {
			if (ext.length === path2.length && ext === path2) return "";
			let extIdx = ext.length - 1;
			let firstNonSlashEnd = -1;
			for (i = path2.length - 1; i >= 0; --i) {
				const code = path2.charCodeAt(i);
				if (code === 47) {
					if (!matchedSlash) {
						start = i + 1;
						break;
					}
				} else {
					if (firstNonSlashEnd === -1) {
						matchedSlash = false;
						firstNonSlashEnd = i + 1;
					}
					if (extIdx >= 0) {
						if (code === ext.charCodeAt(extIdx)) {
							if (--extIdx === -1) end = i;
						} else {
							extIdx = -1;
							end = firstNonSlashEnd;
						}
					}
				}
			}
			if (start === end) end = firstNonSlashEnd;
			else if (end === -1) end = path2.length;
			return path2.slice(start, end);
		}
		for (i = path2.length - 1; i >= 0; --i) if (path2.charCodeAt(i) === 47) {
			if (!matchedSlash) {
				start = i + 1;
				break;
			}
		} else if (end === -1) {
			matchedSlash = false;
			end = i + 1;
		}
		if (end === -1) return "";
		return path2.slice(start, end);
	},
	/**
	* Returns the extension of the path, from the last occurrence of the . (period) character to end of string in the last
	* portion of the path. If there is no . in the last portion of the path, or if there are no . characters other than
	* the first character of the basename of path, an empty string is returned.
	* @param path - The path to parse
	* @example
	* ```ts
	* // Get the extension of a URL
	* path.extname('http://www.example.com/foo/bar/baz.png');
	* // -> '.png'
	* // Get the extension of a file path
	* path.extname('C:/Users/User/Documents/file.txt');
	* // -> '.txt'
	* ```
	*/
	extname(path2) {
		assertPath(path2);
		path2 = removeUrlParams(this.toPosix(path2));
		let startDot = -1;
		let startPart = 0;
		let end = -1;
		let matchedSlash = true;
		let preDotState = 0;
		for (let i = path2.length - 1; i >= 0; --i) {
			const code = path2.charCodeAt(i);
			if (code === 47) {
				if (!matchedSlash) {
					startPart = i + 1;
					break;
				}
				continue;
			}
			if (end === -1) {
				matchedSlash = false;
				end = i + 1;
			}
			if (code === 46) {
				if (startDot === -1) startDot = i;
				else if (preDotState !== 1) preDotState = 1;
			} else if (startDot !== -1) preDotState = -1;
		}
		if (startDot === -1 || end === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) return "";
		return path2.slice(startDot, end);
	},
	/**
	* Parses a path into an object containing the 'root', `dir`, `base`, `ext`, and `name` properties.
	* @param path - The path to parse
	* @example
	* ```ts
	* // Parse a URL
	* const parsed = path.parse('http://www.example.com/foo/bar/baz.png');
	* // -> {
	* //   root: 'http://www.example.com/',
	* //   dir: 'http://www.example.com/foo/bar',
	* //   base: 'baz.png',
	* //   ext: '.png',
	* //   name: 'baz'
	* // }
	* // Parse a file path
	* const parsedFile = path.parse('C:/Users/User/Documents/file.txt');
	* // -> {
	* //   root: 'C:/',
	* //   dir: 'C:/Users/User/Documents',
	* //   base: 'file.txt',
	* //   ext: '.txt',
	* //   name: 'file'
	* // }
	* ```
	*/
	parse(path2) {
		assertPath(path2);
		const ret = {
			root: "",
			dir: "",
			base: "",
			ext: "",
			name: ""
		};
		if (path2.length === 0) return ret;
		path2 = removeUrlParams(this.toPosix(path2));
		let code = path2.charCodeAt(0);
		const isAbsolute = this.isAbsolute(path2);
		let start;
		ret.root = this.rootname(path2);
		if (isAbsolute || this.hasProtocol(path2)) start = 1;
		else start = 0;
		let startDot = -1;
		let startPart = 0;
		let end = -1;
		let matchedSlash = true;
		let i = path2.length - 1;
		let preDotState = 0;
		for (; i >= start; --i) {
			code = path2.charCodeAt(i);
			if (code === 47) {
				if (!matchedSlash) {
					startPart = i + 1;
					break;
				}
				continue;
			}
			if (end === -1) {
				matchedSlash = false;
				end = i + 1;
			}
			if (code === 46) {
				if (startDot === -1) startDot = i;
				else if (preDotState !== 1) preDotState = 1;
			} else if (startDot !== -1) preDotState = -1;
		}
		if (startDot === -1 || end === -1 || preDotState === 0 || preDotState === 1 && startDot === end - 1 && startDot === startPart + 1) {
			if (end !== -1) {
				if (startPart === 0 && isAbsolute) ret.base = ret.name = path2.slice(1, end);
				else ret.base = ret.name = path2.slice(startPart, end);
			}
		} else {
			if (startPart === 0 && isAbsolute) {
				ret.name = path2.slice(1, startDot);
				ret.base = path2.slice(1, end);
			} else {
				ret.name = path2.slice(startPart, startDot);
				ret.base = path2.slice(startPart, end);
			}
			ret.ext = path2.slice(startDot, end);
		}
		ret.dir = this.dirname(path2);
		return ret;
	},
	sep: "/",
	delimiter: ":",
	joinExtensions: [".html"]
};
//#endregion
//#region node_modules/pixi.js/lib/assets/utils/createStringVariations.mjs
function processX(base, ids, depth, result, tags) {
	const id = ids[depth];
	for (let i = 0; i < id.length; i++) {
		const value = id[i];
		if (depth < ids.length - 1) processX(base.replace(result[depth], value), ids, depth + 1, result, tags);
		else tags.push(base.replace(result[depth], value));
	}
}
function createStringVariations(string) {
	const result = string.match(/\{(.*?)\}/g);
	const tags = [];
	if (result) {
		const ids = [];
		result.forEach((vars) => {
			const split = vars.substring(1, vars.length - 1).split(",");
			ids.push(split);
		});
		processX(string, ids, 0, result, tags);
	} else tags.push(string);
	return tags;
}
//#endregion
//#region node_modules/pixi.js/lib/assets/utils/isSingleItem.mjs
var isSingleItem = (item) => !Array.isArray(item);
//#endregion
//#region node_modules/pixi.js/lib/assets/resolver/Resolver.mjs
var Resolver = class {
	constructor() {
		this._defaultBundleIdentifierOptions = {
			connector: "-",
			createBundleAssetId: (bundleId, assetId) => `${bundleId}${this._bundleIdConnector}${assetId}`,
			extractAssetIdFromBundle: (bundleId, assetBundleId) => assetBundleId.replace(`${bundleId}${this._bundleIdConnector}`, "")
		};
		/** The character that is used to connect the bundleId and the assetId when generating a bundle asset id key */
		this._bundleIdConnector = this._defaultBundleIdentifierOptions.connector;
		/**
		* A function that generates a bundle asset id key from a bundleId and an assetId
		* @param bundleId - the bundleId
		* @param assetId  - the assetId
		* @returns the bundle asset id key
		*/
		this._createBundleAssetId = this._defaultBundleIdentifierOptions.createBundleAssetId;
		/**
		* A function that generates an assetId from a bundle asset id key. This is the reverse of generateBundleAssetId
		* @param bundleId - the bundleId
		* @param assetBundleId - the bundle asset id key
		* @returns the assetId
		*/
		this._extractAssetIdFromBundle = this._defaultBundleIdentifierOptions.extractAssetIdFromBundle;
		this._assetMap = {};
		this._preferredOrder = [];
		this._parsers = [];
		this._resolverHash = {};
		this._bundles = {};
	}
	/**
	* Override how the resolver deals with generating bundle ids.
	* must be called before any bundles are added
	* @param bundleIdentifier - the bundle identifier options
	*/
	setBundleIdentifier(bundleIdentifier) {
		this._bundleIdConnector = bundleIdentifier.connector ?? this._bundleIdConnector;
		this._createBundleAssetId = bundleIdentifier.createBundleAssetId ?? this._createBundleAssetId;
		this._extractAssetIdFromBundle = bundleIdentifier.extractAssetIdFromBundle ?? this._extractAssetIdFromBundle;
		if (this._extractAssetIdFromBundle("foo", this._createBundleAssetId("foo", "bar")) !== "bar") throw new Error("[Resolver] GenerateBundleAssetId are not working correctly");
	}
	/**
	* Let the resolver know which assets you prefer to use when resolving assets.
	* Multiple prefer user defined rules can be added.
	* @example
	* resolver.prefer({
	*     // first look for something with the correct format, and then then correct resolution
	*     priority: ['format', 'resolution'],
	*     params:{
	*         format:'webp', // prefer webp images
	*         resolution: 2, // prefer a resolution of 2
	*     }
	* })
	* resolver.add('foo', ['bar@2x.webp', 'bar@2x.png', 'bar.webp', 'bar.png']);
	* resolver.resolveUrl('foo') // => 'bar@2x.webp'
	* @param preferOrders - the prefer options
	*/
	prefer(...preferOrders) {
		preferOrders.forEach((prefer) => {
			this._preferredOrder.push(prefer);
			if (!prefer.priority) prefer.priority = Object.keys(prefer.params);
		});
		this._resolverHash = {};
	}
	/**
	* Set the base path to prepend to all urls when resolving
	* @example
	* resolver.basePath = 'https://home.com/';
	* resolver.add('foo', 'bar.ong');
	* resolver.resolveUrl('foo', 'bar.png'); // => 'https://home.com/bar.png'
	* @param basePath - the base path to use
	*/
	set basePath(basePath) {
		this._basePath = basePath;
	}
	get basePath() {
		return this._basePath;
	}
	/**
	* Set the root path for root-relative URLs. By default the `basePath`'s root is used. If no `basePath` is set, then the
	* default value for browsers is `window.location.origin`
	* @example
	* // Application hosted on https://home.com/some-path/index.html
	* resolver.basePath = 'https://home.com/some-path/';
	* resolver.rootPath = 'https://home.com/';
	* resolver.add('foo', '/bar.png');
	* resolver.resolveUrl('foo', '/bar.png'); // => 'https://home.com/bar.png'
	* @param rootPath - the root path to use
	*/
	set rootPath(rootPath) {
		this._rootPath = rootPath;
	}
	get rootPath() {
		return this._rootPath;
	}
	/**
	* All the active URL parsers that help the parser to extract information and create
	* an asset object-based on parsing the URL itself.
	*
	* Can be added using the extensions API
	* @example
	* resolver.add('foo', [
	*     {
	*         resolution: 2,
	*         format: 'png',
	*         src: 'image@2x.png',
	*     },
	*     {
	*         resolution:1,
	*         format:'png',
	*         src: 'image.png',
	*     },
	* ]);
	*
	* // With a url parser the information such as resolution and file format could extracted from the url itself:
	* extensions.add({
	*     extension: ExtensionType.ResolveParser,
	*     test: loadTextures.test, // test if url ends in an image
	*     parse: (value: string) =>
	*     ({
	*         resolution: parseFloat(Resolver.RETINA_PREFIX.exec(value)?.[1] ?? '1'),
	*         format: value.split('.').pop(),
	*         src: value,
	*     }),
	* });
	*
	* // Now resolution and format can be extracted from the url
	* resolver.add('foo', [
	*     'image@2x.png',
	*     'image.png',
	* ]);
	*/
	get parsers() {
		return this._parsers;
	}
	/** Used for testing, this resets the resolver to its initial state */
	reset() {
		this.setBundleIdentifier(this._defaultBundleIdentifierOptions);
		this._assetMap = {};
		this._preferredOrder = [];
		this._resolverHash = {};
		this._rootPath = null;
		this._basePath = null;
		this._manifest = null;
		this._bundles = {};
		this._defaultSearchParams = null;
	}
	/**
	* Sets the default URL search parameters for the URL resolver. The urls can be specified as a string or an object.
	* @param searchParams - the default url parameters to append when resolving urls
	*/
	setDefaultSearchParams(searchParams) {
		if (typeof searchParams === "string") this._defaultSearchParams = searchParams;
		else {
			const queryValues = searchParams;
			this._defaultSearchParams = Object.keys(queryValues).map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(queryValues[key])}`).join("&");
		}
	}
	/**
	* Returns the aliases for a given asset
	* @param asset - the asset to get the aliases for
	*/
	getAlias(asset) {
		const { alias, src } = asset;
		return convertToList(alias || src, (value) => {
			if (typeof value === "string") return value;
			if (Array.isArray(value)) return value.map((v) => v?.src ?? v);
			if (value?.src) return value.src;
			return value;
		}, true);
	}
	/**
	* Removes the specified alias for an asset.
	*
	* This only removes the alias mapping. It does **not** remove, unload, or destroy the
	* underlying asset. If the asset is already cached, it stays in memory until you call
	* `Assets.unload`.
	*
	* If `asset` is provided, the alias is only removed when the resolver's current mapping for
	* that alias matches the given `ResolvedAsset`. This lets you avoid accidentally removing an
	* alias that has been reassigned.
	*
	* Silently returns if the alias does not exist or the asset does not match.
	* @param alias - the alias to remove
	* @param asset - only remove the alias if it is currently assigned to this asset
	* @example
	* ```ts
	* resolver.add({ alias: 'hero', src: 'hero.png' });
	*
	* // Simple removal
	* resolver.removeAlias('hero');
	*
	* // Conditional removal — only if alias currently maps to a specific asset
	* const resolved = resolver.resolve('hero');
	* resolver.removeAlias('hero', resolved);
	* ```
	*/
	removeAlias(alias, asset) {
		if (!this._assetMap[alias]) return;
		if (asset && asset !== this._resolverHash[alias]) return;
		delete this._resolverHash[alias];
		delete this._assetMap[alias];
	}
	/**
	* Add a manifest to the asset resolver. This is a nice way to add all the asset information in one go.
	* generally a manifest would be built using a tool.
	* @param manifest - the manifest to add to the resolver
	*/
	addManifest(manifest) {
		if (this._manifest) warn("[Resolver] Manifest already exists, this will be overwritten");
		this._manifest = manifest;
		manifest.bundles.forEach((bundle) => {
			this.addBundle(bundle.name, bundle.assets);
		});
	}
	/**
	* This adds a bundle of assets in one go so that you can resolve them as a group.
	* For example you could add a bundle for each screen in you pixi app
	* @example
	* resolver.addBundle('animals', [
	*  { alias: 'bunny', src: 'bunny.png' },
	*  { alias: 'chicken', src: 'chicken.png' },
	*  { alias: 'thumper', src: 'thumper.png' },
	* ]);
	* // or
	* resolver.addBundle('animals', {
	*     bunny: 'bunny.png',
	*     chicken: 'chicken.png',
	*     thumper: 'thumper.png',
	* });
	*
	* const resolvedAssets = await resolver.resolveBundle('animals');
	* @param bundleId - The id of the bundle to add
	* @param assets - A record of the asset or assets that will be chosen from when loading via the specified key
	*/
	addBundle(bundleId, assets) {
		const assetNames = [];
		let convertedAssets = assets;
		if (!Array.isArray(assets)) convertedAssets = Object.entries(assets).map(([alias, src]) => {
			if (typeof src === "string" || Array.isArray(src)) return {
				alias,
				src
			};
			return {
				alias,
				...src
			};
		});
		convertedAssets.forEach((asset) => {
			const srcs = asset.src;
			const aliases = asset.alias;
			let ids;
			if (typeof aliases === "string") {
				const bundleAssetId = this._createBundleAssetId(bundleId, aliases);
				assetNames.push(bundleAssetId);
				ids = [aliases, bundleAssetId];
			} else {
				const bundleIds = aliases.map((name) => this._createBundleAssetId(bundleId, name));
				assetNames.push(...bundleIds);
				ids = [...aliases, ...bundleIds];
			}
			this.add({
				...asset,
				alias: ids,
				src: srcs
			});
		});
		this._bundles[bundleId] = assetNames;
	}
	/**
	* Tells the resolver what keys are associated with witch asset.
	* The most important thing the resolver does
	* @example
	* // Single key, single asset:
	* resolver.add({alias: 'foo', src: 'bar.png');
	* resolver.resolveUrl('foo') // => 'bar.png'
	*
	* // Multiple keys, single asset:
	* resolver.add({alias: ['foo', 'boo'], src: 'bar.png'});
	* resolver.resolveUrl('foo') // => 'bar.png'
	* resolver.resolveUrl('boo') // => 'bar.png'
	*
	* // Multiple keys, multiple assets:
	* resolver.add({alias: ['foo', 'boo'], src: ['bar.png', 'bar.webp']});
	* resolver.resolveUrl('foo') // => 'bar.png'
	*
	* // Add custom data attached to the resolver
	* Resolver.add({
	*     alias: 'bunnyBooBooSmooth',
	*     src: 'bunny{png,webp}',
	*     data: { scaleMode:SCALE_MODES.NEAREST }, // Base texture options
	* });
	*
	* resolver.resolve('bunnyBooBooSmooth') // => { src: 'bunny.png', data: { scaleMode: SCALE_MODES.NEAREST } }
	* @param aliases - the UnresolvedAsset or array of UnresolvedAssets to add to the resolver
	*/
	add(aliases) {
		const assets = [];
		if (Array.isArray(aliases)) assets.push(...aliases);
		else assets.push(aliases);
		let keyCheck = (key) => {
			if (this.hasKey(key)) warn(`[Resolver] already has key: ${key} overwriting`);
		};
		convertToList(assets).forEach((asset) => {
			const { src } = asset;
			let { data, format, loadParser: userDefinedLoadParser, parser: userDefinedParser } = asset;
			const srcsToUse = convertToList(src).map((src2) => {
				if (typeof src2 === "string") return createStringVariations(src2);
				return Array.isArray(src2) ? src2 : [src2];
			});
			const aliasesToUse = this.getAlias(asset);
			Array.isArray(aliasesToUse) ? aliasesToUse.forEach(keyCheck) : keyCheck(aliasesToUse);
			const resolvedAssets = [];
			const parseUrl = (url) => {
				return {
					src: url,
					...this._parsers.find((p) => p.test(url))?.parse(url)
				};
			};
			srcsToUse.forEach((srcs) => {
				srcs.forEach((src2) => {
					let formattedAsset = {};
					if (typeof src2 !== "object") formattedAsset = parseUrl(src2);
					else {
						data = src2.data ?? data;
						format = src2.format ?? format;
						if (src2.loadParser || src2.parser) {
							userDefinedLoadParser = src2.loadParser ?? userDefinedLoadParser;
							userDefinedParser = src2.parser ?? userDefinedParser;
						}
						formattedAsset = {
							...parseUrl(src2.src),
							...src2
						};
					}
					if (!aliasesToUse) throw new Error(`[Resolver] alias is undefined for this asset: ${formattedAsset.src}`);
					formattedAsset = this._buildResolvedAsset(formattedAsset, {
						aliases: aliasesToUse,
						data,
						format,
						loadParser: userDefinedLoadParser,
						parser: userDefinedParser,
						progressSize: asset.progressSize
					});
					resolvedAssets.push(formattedAsset);
				});
			});
			aliasesToUse.forEach((alias) => {
				this._assetMap[alias] = resolvedAssets;
			});
		});
	}
	/**
	* If the resolver has had a manifest set via setManifest, this will return the assets urls for
	* a given bundleId or bundleIds.
	* @example
	* // Manifest Example
	* const manifest = {
	*     bundles: [
	*         {
	*             name: 'load-screen',
	*             assets: [
	*                 {
	*                     alias: 'background',
	*                     src: 'sunset.png',
	*                 },
	*                 {
	*                     alias: 'bar',
	*                     src: 'load-bar.{png,webp}',
	*                 },
	*             ],
	*         },
	*         {
	*             name: 'game-screen',
	*             assets: [
	*                 {
	*                     alias: 'character',
	*                     src: 'robot.png',
	*                 },
	*                 {
	*                     alias: 'enemy',
	*                     src: 'bad-guy.png',
	*                 },
	*             ],
	*         },
	*     ]
	* };
	*
	* resolver.setManifest(manifest);
	* const resolved = resolver.resolveBundle('load-screen');
	* @param bundleIds - The bundle ids to resolve
	* @returns All the bundles assets or a hash of assets for each bundle specified
	*/
	resolveBundle(bundleIds) {
		const singleAsset = isSingleItem(bundleIds);
		bundleIds = convertToList(bundleIds);
		const out = {};
		bundleIds.forEach((bundleId) => {
			const assetNames = this._bundles[bundleId];
			if (assetNames) {
				const results = this.resolve(assetNames);
				const assets = {};
				for (const key in results) {
					const asset = results[key];
					assets[this._extractAssetIdFromBundle(bundleId, key)] = asset;
				}
				out[bundleId] = assets;
			}
		});
		return singleAsset ? out[bundleIds[0]] : out;
	}
	/**
	* Does exactly what resolve does, but returns just the URL rather than the whole asset object
	* @param key - The key or keys to resolve
	* @returns - The URLs associated with the key(s)
	*/
	resolveUrl(key) {
		const result = this.resolve(key);
		if (typeof key !== "string") {
			const out = {};
			for (const i in result) out[i] = result[i].src;
			return out;
		}
		return result.src;
	}
	resolve(keys) {
		const singleAsset = isSingleItem(keys);
		keys = convertToList(keys);
		const result = {};
		keys.forEach((key) => {
			if (!this._resolverHash[key]) {
				if (this._assetMap[key]) {
					let assets = this._assetMap[key];
					const preferredOrder = this._getPreferredOrder(assets);
					preferredOrder?.priority.forEach((priorityKey) => {
						preferredOrder.params[priorityKey].forEach((value) => {
							const filteredAssets = assets.filter((asset) => {
								if (asset[priorityKey]) return asset[priorityKey] === value;
								return false;
							});
							if (filteredAssets.length) assets = filteredAssets;
						});
					});
					this._resolverHash[key] = assets[0];
				} else this._resolverHash[key] = this._buildResolvedAsset({
					alias: [key],
					src: key
				}, {});
			}
			result[key] = this._resolverHash[key];
		});
		return singleAsset ? result[keys[0]] : result;
	}
	/**
	* Checks if an asset with a given key exists in the resolver
	* @param key - The key of the asset
	*/
	hasKey(key) {
		return !!this._assetMap[key];
	}
	/**
	* Checks if a bundle with the given key exists in the resolver
	* @param key - The key of the bundle
	*/
	hasBundle(key) {
		return !!this._bundles[key];
	}
	/**
	* Internal function for figuring out what prefer criteria an asset should use.
	* @param assets
	*/
	_getPreferredOrder(assets) {
		for (let i = 0; i < assets.length; i++) {
			const asset = assets[i];
			const preferred = this._preferredOrder.find((preference) => preference.params.format.includes(asset.format));
			if (preferred) return preferred;
		}
		return this._preferredOrder[0];
	}
	/**
	* Appends the default url parameters to the url
	* @param url - The url to append the default parameters to
	* @returns - The url with the default parameters appended
	*/
	_appendDefaultSearchParams(url) {
		if (!this._defaultSearchParams) return url;
		return `${url}${/\?/.test(url) ? "&" : "?"}${this._defaultSearchParams}`;
	}
	_buildResolvedAsset(formattedAsset, data) {
		const { aliases, data: assetData, loadParser, parser, format, progressSize } = data;
		if (this._basePath || this._rootPath) formattedAsset.src = path.toAbsolute(formattedAsset.src, this._basePath, this._rootPath);
		formattedAsset.alias = aliases ?? formattedAsset.alias ?? [formattedAsset.src];
		formattedAsset.src = this._appendDefaultSearchParams(formattedAsset.src);
		formattedAsset.data = {
			...assetData || {},
			...formattedAsset.data
		};
		formattedAsset.loadParser = loadParser ?? formattedAsset.loadParser;
		formattedAsset.parser = parser ?? formattedAsset.parser;
		formattedAsset.format = format ?? formattedAsset.format ?? getUrlExtension(formattedAsset.src);
		if (progressSize !== void 0) formattedAsset.progressSize = progressSize;
		return formattedAsset;
	}
};
/**
* The prefix that denotes a URL is for a retina asset.
* @default /@([0-9\.]+)x/
* @example `@2x`
*/
Resolver.RETINA_PREFIX = /@([0-9\.]+)x/;
function getUrlExtension(url) {
	return url.split(".").pop().split("?").shift().split("#").shift();
}
//#endregion
//#region node_modules/pixi.js/lib/assets/utils/copySearchParams.mjs
var copySearchParams = (targetUrl, sourceUrl) => {
	const searchParams = sourceUrl.split("?")[1];
	if (searchParams) targetUrl += `?${searchParams}`;
	return targetUrl;
};
//#endregion
//#region node_modules/pixi.js/lib/spritesheet/Spritesheet.mjs
var _Spritesheet = class _Spritesheet {
	constructor(optionsOrTexture, arg1) {
		/** For multi-packed spritesheets, this contains a reference to all the other spritesheets it depends on. */
		this.linkedSheets = [];
		let options = optionsOrTexture;
		if (optionsOrTexture?.source instanceof TextureSource) options = {
			texture: optionsOrTexture,
			data: arg1
		};
		const { texture, data, cachePrefix = "" } = options;
		this.cachePrefix = cachePrefix;
		this._texture = texture instanceof Texture ? texture : null;
		this.textureSource = texture.source;
		this.textures = {};
		this.animations = {};
		this.data = data;
		const metaResolution = parseFloat(data.meta.scale);
		if (metaResolution) {
			this.resolution = metaResolution;
			texture.source.resolution = this.resolution;
		} else this.resolution = texture.source._resolution;
		this._frames = this.data.frames;
		this._frameKeys = Object.keys(this._frames);
		this._batchIndex = 0;
		this._callback = null;
	}
	/**
	* Parse spritesheet from loaded data. This is done asynchronously
	* to prevent creating too many Texture within a single process.
	*/
	parse() {
		return new Promise((resolve) => {
			this._callback = resolve;
			this._batchIndex = 0;
			if (this._frameKeys.length <= _Spritesheet.BATCH_SIZE) {
				this._processFrames(0);
				this._processAnimations();
				this._parseComplete();
			} else this._nextBatch();
		});
	}
	/**
	* Parse spritesheet from loaded data. This is done synchronously
	* and is only suitable for smaller spritesheets (less than ~1000 frames)
	* or may cause too many Texture within a single process. However, synchronous parsing may be
	* more convenient since the called does not need to be asynchronous and is safe for
	* small-to-medium sized spritesheets.
	*
	* Other than being synchronous, `parseSync` is otherwise identical to `.parse()`.
	*/
	parseSync() {
		this._processFrames(0, true);
		this._processAnimations();
		return this.textures;
	}
	/**
	* Process a batch of frames
	* @param initialFrameIndex - The index of frame to start.
	* @param processAll - if true will process all frames in a single batch, ignoring BATCH_SIZE - this
	* is used for synchronous parsing.
	*/
	_processFrames(initialFrameIndex, processAll = false) {
		let frameIndex = initialFrameIndex;
		const maxFrames = processAll ? Infinity : _Spritesheet.BATCH_SIZE;
		while (frameIndex - initialFrameIndex < maxFrames && frameIndex < this._frameKeys.length) {
			const i = this._frameKeys[frameIndex];
			const data = this._frames[i];
			const rect = data.frame;
			if (rect) {
				let frame = null;
				let trim = null;
				const sourceSize = data.trimmed !== false && data.sourceSize ? data.sourceSize : data.frame;
				const orig = new Rectangle(0, 0, Math.floor(sourceSize.w) / this.resolution, Math.floor(sourceSize.h) / this.resolution);
				if (data.rotated) frame = new Rectangle(Math.floor(rect.x) / this.resolution, Math.floor(rect.y) / this.resolution, Math.floor(rect.h) / this.resolution, Math.floor(rect.w) / this.resolution);
				else frame = new Rectangle(Math.floor(rect.x) / this.resolution, Math.floor(rect.y) / this.resolution, Math.floor(rect.w) / this.resolution, Math.floor(rect.h) / this.resolution);
				if (data.trimmed !== false && data.spriteSourceSize) trim = new Rectangle(Math.floor(data.spriteSourceSize.x) / this.resolution, Math.floor(data.spriteSourceSize.y) / this.resolution, Math.floor(rect.w) / this.resolution, Math.floor(rect.h) / this.resolution);
				this.textures[i] = new Texture({
					source: this.textureSource,
					frame,
					orig,
					trim,
					rotate: data.rotated ? 2 : 0,
					defaultAnchor: data.anchor,
					defaultBorders: data.borders,
					label: i.toString()
				});
			}
			frameIndex++;
		}
	}
	/** Parse animations config. */
	_processAnimations() {
		const animations = this.data.animations || {};
		for (const animName in animations) {
			this.animations[animName] = [];
			for (let i = 0; i < animations[animName].length; i++) {
				const frameName = animations[animName][i];
				this.animations[animName].push(this.textures[frameName]);
			}
		}
	}
	/** The parse has completed. */
	_parseComplete() {
		const callback = this._callback;
		this._callback = null;
		this._batchIndex = 0;
		callback.call(this, this.textures);
	}
	/** Begin the next batch of textures. */
	_nextBatch() {
		this._processFrames(this._batchIndex * _Spritesheet.BATCH_SIZE);
		this._batchIndex++;
		setTimeout(() => {
			if (this._batchIndex * _Spritesheet.BATCH_SIZE < this._frameKeys.length) this._nextBatch();
			else {
				this._processAnimations();
				this._parseComplete();
			}
		}, 0);
	}
	/**
	* Destroy Spritesheet and don't use after this.
	* @param {boolean} [destroyBase=false] - Whether to destroy the base texture as well
	*/
	destroy(destroyBase = false) {
		for (const i in this.textures) this.textures[i].destroy();
		this._frames = null;
		this._frameKeys = null;
		this.data = null;
		this.textures = null;
		if (destroyBase) {
			this._texture?.destroy();
			this.textureSource.destroy();
		}
		this._texture = null;
		this.textureSource = null;
		this.linkedSheets = [];
	}
};
/**
* The maximum number of Textures to build per process.
* @advanced
*/
_Spritesheet.BATCH_SIZE = 1e3;
var Spritesheet = _Spritesheet;
//#endregion
//#region node_modules/pixi.js/lib/spritesheet/spritesheetAsset.mjs
var validImages = [
	"jpg",
	"png",
	"jpeg",
	"avif",
	"webp",
	"basis",
	"etc2",
	"bc7",
	"bc6h",
	"bc5",
	"bc4",
	"bc3",
	"bc2",
	"bc1",
	"eac",
	"astc"
];
function getCacheableAssets(keys, asset, ignoreMultiPack) {
	const out = {};
	keys.forEach((key) => {
		out[key] = asset;
	});
	Object.keys(asset.textures).forEach((key) => {
		out[`${asset.cachePrefix}${key}`] = asset.textures[key];
	});
	if (!ignoreMultiPack) {
		const basePath = path.dirname(keys[0]);
		asset.linkedSheets.forEach((item, i) => {
			const out2 = getCacheableAssets([`${basePath}/${asset.data.meta.related_multi_packs[i]}`], item, true);
			Object.assign(out, out2);
		});
	}
	return out;
}
var spritesheetAsset = {
	extension: ExtensionType.Asset,
	/** Handle the caching of the related Spritesheet Textures */
	cache: {
		test: (asset) => asset instanceof Spritesheet,
		getCacheableAssets: (keys, asset) => getCacheableAssets(keys, asset, false)
	},
	/** Resolve the resolution of the asset. */
	resolver: {
		extension: {
			type: ExtensionType.ResolveParser,
			name: "resolveSpritesheet"
		},
		test: (value) => {
			const split = value.split("?")[0].split(".");
			const extension = split.pop();
			const format = split.pop();
			return extension === "json" && validImages.includes(format);
		},
		parse: (value) => {
			const split = value.split(".");
			return {
				resolution: parseFloat(Resolver.RETINA_PREFIX.exec(value)?.[1] ?? "1"),
				format: split[split.length - 2],
				src: value
			};
		}
	},
	/**
	* Loader plugin that parses sprite sheets!
	* once the JSON has been loaded this checks to see if the JSON is spritesheet data.
	* If it is, we load the spritesheets image and parse the data into Spritesheet
	* All textures in the sprite sheet are then added to the cache
	*/
	loader: {
		/** used for deprecation purposes */
		name: "spritesheetLoader",
		id: "spritesheet",
		extension: {
			type: ExtensionType.LoadParser,
			priority: LoaderParserPriority.Normal,
			name: "spritesheetLoader"
		},
		async testParse(asset, options) {
			return path.extname(options.src).toLowerCase() === ".json" && !!asset.frames;
		},
		async parse(asset, options, loader) {
			const { texture: imageTexture, imageFilename, textureOptions, cachePrefix } = options?.data ?? {};
			let basePath = path.dirname(options.src);
			if (basePath && basePath.lastIndexOf("/") !== basePath.length - 1) basePath += "/";
			let texture;
			if (imageTexture instanceof Texture) texture = imageTexture;
			else {
				const imagePath = copySearchParams(basePath + (imageFilename ?? asset.meta.image), options.src);
				texture = (await loader.load([{
					src: imagePath,
					data: textureOptions
				}]))[imagePath];
			}
			const spritesheet = new Spritesheet({
				texture: texture.source,
				data: asset,
				cachePrefix
			});
			await spritesheet.parse();
			const multiPacks = asset?.meta?.related_multi_packs;
			if (Array.isArray(multiPacks)) {
				const promises = [];
				for (const item of multiPacks) {
					if (typeof item !== "string") continue;
					let itemUrl = basePath + item;
					if (options.data?.ignoreMultiPack) continue;
					itemUrl = copySearchParams(itemUrl, options.src);
					promises.push(loader.load({
						src: itemUrl,
						data: {
							textureOptions,
							ignoreMultiPack: true
						}
					}));
				}
				const res = await Promise.all(promises);
				spritesheet.linkedSheets = res;
				res.forEach((item) => {
					item.linkedSheets = [spritesheet].concat(spritesheet.linkedSheets.filter((sp) => sp !== item));
				});
			}
			return spritesheet;
		},
		async unload(spritesheet, _resolvedAsset, loader) {
			await loader.unload(spritesheet.textureSource._sourceOrigin);
			spritesheet.destroy(false);
		}
	}
};
//#endregion
//#region node_modules/pixi.js/lib/spritesheet/init.mjs
extensions.add(spritesheetAsset);
//#endregion
//#region node_modules/pixi.js/lib/scene/container/bounds/getRenderableBounds.mjs
var tempProjectionMatrix = new Matrix();
function getGlobalRenderableBounds(renderables, bounds) {
	bounds.clear();
	const actualMatrix = bounds.matrix;
	for (let i = 0; i < renderables.length; i++) {
		const renderable = renderables[i];
		if (renderable.globalDisplayStatus < 7) continue;
		const renderGroup = renderable.renderGroup ?? renderable.parentRenderGroup;
		if (renderGroup?.isCachedAsTexture) bounds.matrix = tempProjectionMatrix.copyFrom(renderGroup.textureOffsetInverseTransform).append(renderable.worldTransform);
		else if (renderGroup?._parentCacheAsTextureRenderGroup) bounds.matrix = tempProjectionMatrix.copyFrom(renderGroup._parentCacheAsTextureRenderGroup.inverseWorldTransform).append(renderable.groupTransform);
		else bounds.matrix = renderable.worldTransform;
		bounds.addBounds(renderable.bounds);
	}
	bounds.matrix = actualMatrix;
	return bounds;
}
//#endregion
//#region node_modules/pixi.js/lib/scene/text/utils/getPo2TextureFromSource.mjs
var tempBounds = new Bounds();
function getPo2TextureFromSource(image, width, height, resolution, autoGenerateMipmaps = false, scaleMode) {
	const bounds = tempBounds;
	bounds.minX = 0;
	bounds.minY = 0;
	bounds.maxX = image.width / resolution | 0;
	bounds.maxY = image.height / resolution | 0;
	const texture = TexturePool.getOptimalTexture({
		width: bounds.width,
		height: bounds.height,
		resolution,
		autoGenerateMipmaps,
		scaleMode
	});
	texture.source.uploadMethodId = "image";
	texture.source.resource = image;
	texture.source.alphaMode = "premultiply-alpha-on-upload";
	texture.frame.width = width / resolution;
	texture.frame.height = height / resolution;
	texture.source.emit("update", texture.source);
	texture.updateUvs();
	return texture;
}
//#endregion
//#region node_modules/pixi.js/lib/filters/CanvasFilterSystem.mjs
function isCanvasFilterCapable(filter) {
	return typeof filter.getCanvasFilterString === "function";
}
var CanvasFilterFrame = class {
	constructor() {
		this.skip = false;
		this.useClip = false;
		this.filters = null;
		this.container = null;
		this.bounds = new Bounds();
		this.cssFilterString = "";
	}
};
var CanvasFilterSystem = class {
	/**
	* @param renderer - The Canvas renderer
	* @param renderer.canvasContext
	* @param renderer.canvasContext.activeContext
	* @param renderer.canvasContext.activeResolution
	*/
	constructor(renderer) {
		this._filterStack = [];
		this._filterStackIndex = 0;
		this._savedStates = [];
		this._alphaMultiplier = 1;
		this._warnedFilterTypes = /* @__PURE__ */ new Set();
		this.renderer = renderer;
	}
	/**
	* Push a filter instruction onto the stack.
	* Called when entering a filtered container.
	* @param instruction - The filter instruction from FilterPipe
	*/
	push(instruction) {
		const filterFrame = this._pushFilterFrame();
		const filters = instruction.filterEffect.filters;
		filterFrame.skip = false;
		filterFrame.useClip = false;
		filterFrame.filters = filters;
		filterFrame.container = instruction.container;
		filterFrame.cssFilterString = "";
		if (filters.every((filter) => !filter.enabled)) {
			filterFrame.skip = true;
			return;
		}
		const cssFilters = [];
		for (const filter of filters) {
			if (!filter.enabled) continue;
			if (!isCanvasFilterCapable(filter)) {
				this._warnUnsupportedFilter(filter);
				continue;
			}
			const cssString = filter.getCanvasFilterString();
			if (cssString === null) {
				this._warnUnsupportedFilter(filter);
				continue;
			}
			if (cssString) cssFilters.push(cssString);
		}
		if (cssFilters.length === 0 && true) {
			filterFrame.skip = true;
			return;
		}
		filterFrame.cssFilterString = cssFilters.join(" ");
		this._calculateFilterArea(instruction, filterFrame.bounds);
		filterFrame.useClip = !!instruction.filterEffect.filterArea;
		const context = this.renderer.canvasContext.activeContext;
		const previousFilter = context.filter || "none";
		this._savedStates.push({
			filter: previousFilter,
			alphaMultiplier: this._alphaMultiplier
		});
		if (filterFrame.useClip && Number.isFinite(filterFrame.bounds.width) && Number.isFinite(filterFrame.bounds.height) && filterFrame.bounds.width > 0 && filterFrame.bounds.height > 0) {
			const resolution = this.renderer.canvasContext.activeResolution || 1;
			context.save();
			context.setTransform(1, 0, 0, 1, 0, 0);
			context.beginPath();
			context.rect(filterFrame.bounds.x * resolution, filterFrame.bounds.y * resolution, filterFrame.bounds.width * resolution, filterFrame.bounds.height * resolution);
			context.clip();
		} else filterFrame.useClip = false;
		if (filterFrame.cssFilterString) context.filter = previousFilter !== "none" ? `${previousFilter} ${filterFrame.cssFilterString}` : filterFrame.cssFilterString;
	}
	/** Pop a filter from the stack. Called when exiting a filtered container. */
	pop() {
		const filterFrame = this._popFilterFrame();
		if (filterFrame.skip) return;
		const savedState = this._savedStates.pop();
		if (!savedState) return;
		const context = this.renderer.canvasContext.activeContext;
		if (filterFrame.useClip) context.restore();
		else context.filter = savedState.filter;
		this._alphaMultiplier = savedState.alphaMultiplier;
	}
	/**
	* Applies supported filters to a texture and returns a new texture.
	* Unsupported filters are skipped with a warn-once message.
	* @param params - The parameters for applying filters.
	* @param params.texture
	* @param params.filters
	* @returns The resulting texture after filters are applied.
	*/
	generateFilteredTexture({ texture, filters }) {
		if (!filters?.length || filters.every((filter) => !filter.enabled)) return texture;
		const cssFilters = [];
		for (const filter of filters) {
			if (!filter.enabled) continue;
			if (!isCanvasFilterCapable(filter)) {
				this._warnUnsupportedFilter(filter);
				continue;
			}
			const cssString = filter.getCanvasFilterString();
			if (cssString === null) {
				this._warnUnsupportedFilter(filter);
				continue;
			}
			if (cssString) cssFilters.push(cssString);
		}
		if (cssFilters.length === 0 && true) return texture;
		const source = canvasUtils.getCanvasSource(texture);
		if (!source) return texture;
		const frame = texture.frame;
		const resolution = texture.source._resolution ?? texture.source.resolution ?? 1;
		const width = frame.width;
		const height = frame.height;
		const { canvas, context } = CanvasPool.getOptimalCanvasAndContext(width, height, resolution);
		context.setTransform(1, 0, 0, 1, 0, 0);
		context.clearRect(0, 0, canvas.width, canvas.height);
		if (cssFilters.length) context.filter = cssFilters.join(" ");
		const sx = frame.x * resolution;
		const sy = frame.y * resolution;
		const sw = width * resolution;
		const sh = height * resolution;
		context.drawImage(source, sx, sy, sw, sh, 0, 0, sw, sh);
		context.filter = "none";
		context.globalAlpha = 1;
		return getPo2TextureFromSource(canvas, width, height, resolution);
	}
	/**
	* Calculate the filter area bounds.
	* @param instruction - Filter instruction
	* @param bounds - Bounds object to populate
	*/
	_calculateFilterArea(instruction, bounds) {
		if (instruction.renderables) getGlobalRenderableBounds(instruction.renderables, bounds);
		else if (instruction.filterEffect.filterArea) {
			bounds.clear();
			bounds.addRect(instruction.filterEffect.filterArea);
			bounds.applyMatrix(instruction.container.worldTransform);
		} else instruction.container.getFastGlobalBounds(true, bounds);
		if (instruction.container) {
			const filterFrameTransform = (instruction.container.renderGroup || instruction.container.parentRenderGroup)?.cacheToLocalTransform;
			if (filterFrameTransform) bounds.applyMatrix(filterFrameTransform);
		}
	}
	_warnUnsupportedFilter(filter) {
		const filterName = filter?.constructor?.name || "Filter";
		if (this._warnedFilterTypes.has(filterName)) return;
		this._warnedFilterTypes.add(filterName);
		console.warn(`CanvasRenderer: filter "${filterName}" is not supported in Canvas2D and will be skipped.`);
	}
	get alphaMultiplier() {
		return this._alphaMultiplier;
	}
	_pushFilterFrame() {
		let filterFrame = this._filterStack[this._filterStackIndex];
		if (!filterFrame) filterFrame = this._filterStack[this._filterStackIndex] = new CanvasFilterFrame();
		this._filterStackIndex++;
		return filterFrame;
	}
	_popFilterFrame() {
		if (this._filterStackIndex <= 0) return this._filterStack[0];
		this._filterStackIndex--;
		return this._filterStack[this._filterStackIndex];
	}
	/** Destroys the system */
	destroy() {
		this._filterStack = null;
		this._savedStates = null;
		this._warnedFilterTypes = null;
		this._alphaMultiplier = 1;
	}
};
/** @ignore */
CanvasFilterSystem.extension = {
	type: [ExtensionType.CanvasSystem],
	name: "filter"
};
//#endregion
//#region node_modules/pixi.js/lib/filters/defaults/defaultFilter.vert.mjs
var vertex = "in vec2 aPosition;\nout vec2 vTextureCoord;\n\nuniform vec4 uInputSize;\nuniform vec4 uOutputFrame;\nuniform vec4 uOutputTexture;\n\nvec4 filterVertexPosition( void )\n{\n    vec2 position = aPosition * uOutputFrame.zw + uOutputFrame.xy;\n    \n    position.x = position.x * (2.0 / uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0*uOutputTexture.z / uOutputTexture.y) - uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nvec2 filterTextureCoord( void )\n{\n    return aPosition * (uOutputFrame.zw * uInputSize.zw);\n}\n\nvoid main(void)\n{\n    gl_Position = filterVertexPosition();\n    vTextureCoord = filterTextureCoord();\n}\n";
//#endregion
//#region node_modules/pixi.js/lib/filters/defaults/passthrough/passthrough.frag.mjs
var fragment = "in vec2 vTextureCoord;\nout vec4 finalColor;\nuniform sampler2D uTexture;\nvoid main() {\n    finalColor = texture(uTexture, vTextureCoord);\n}\n";
//#endregion
//#region node_modules/pixi.js/lib/filters/defaults/passthrough/passthrough.wgsl.mjs
var source = "struct GlobalFilterUniforms {\n  uInputSize: vec4<f32>,\n  uInputPixel: vec4<f32>,\n  uInputClamp: vec4<f32>,\n  uOutputFrame: vec4<f32>,\n  uGlobalFrame: vec4<f32>,\n  uOutputTexture: vec4<f32>,\n};\n\n@group(0) @binding(0) var <uniform> gfu: GlobalFilterUniforms;\n@group(0) @binding(1) var uTexture: texture_2d<f32>;\n@group(0) @binding(2) var uSampler: sampler;\n\nstruct VSOutput {\n  @builtin(position) position: vec4<f32>,\n  @location(0) uv: vec2<f32>\n};\n\nfn filterVertexPosition(aPosition: vec2<f32>) -> vec4<f32>\n{\n    var position = aPosition * gfu.uOutputFrame.zw + gfu.uOutputFrame.xy;\n\n    position.x = position.x * (2.0 / gfu.uOutputTexture.x) - 1.0;\n    position.y = position.y * (2.0 * gfu.uOutputTexture.z / gfu.uOutputTexture.y) - gfu.uOutputTexture.z;\n\n    return vec4(position, 0.0, 1.0);\n}\n\nfn filterTextureCoord(aPosition: vec2<f32>) -> vec2<f32>\n{\n    return aPosition * (gfu.uOutputFrame.zw * gfu.uInputSize.zw);\n}\n\n@vertex\nfn mainVertex(\n  @location(0) aPosition: vec2<f32>,\n) -> VSOutput {\n  return VSOutput(\n   filterVertexPosition(aPosition),\n   filterTextureCoord(aPosition)\n  );\n}\n\n@fragment\nfn mainFragment(\n  @location(0) uv: vec2<f32>,\n) -> @location(0) vec4<f32> {\n    return textureSample(uTexture, uSampler, uv);\n}\n";
//#endregion
//#region node_modules/pixi.js/lib/filters/defaults/passthrough/PassthroughFilter.mjs
var PassthroughFilter = class extends Filter {
	constructor() {
		const gpuProgram = GpuProgram.from({
			vertex: {
				source,
				entryPoint: "mainVertex"
			},
			fragment: {
				source,
				entryPoint: "mainFragment"
			},
			name: "passthrough-filter"
		});
		const glProgram = GlProgram.from({
			vertex,
			fragment,
			name: "passthrough-filter"
		});
		super({
			gpuProgram,
			glProgram
		});
	}
};
//#endregion
//#region node_modules/pixi.js/lib/filters/FilterPipe.mjs
var FilterPipe = class {
	constructor(renderer) {
		this._renderer = renderer;
	}
	push(filterEffect, container, instructionSet) {
		this._renderer.renderPipes.batch.break(instructionSet);
		instructionSet.add({
			renderPipeId: "filter",
			canBundle: false,
			action: "pushFilter",
			container,
			filterEffect
		});
	}
	pop(_filterEffect, _container, instructionSet) {
		this._renderer.renderPipes.batch.break(instructionSet);
		instructionSet.add({
			renderPipeId: "filter",
			action: "popFilter",
			canBundle: false
		});
	}
	execute(instruction) {
		if (instruction.action === "pushFilter") this._renderer.filter.push(instruction);
		else if (instruction.action === "popFilter") this._renderer.filter.pop();
	}
	destroy() {
		this._renderer = null;
	}
};
FilterPipe.extension = {
	type: [
		ExtensionType.WebGLPipes,
		ExtensionType.WebGPUPipes,
		ExtensionType.CanvasPipes
	],
	name: "filter"
};
//#endregion
//#region node_modules/pixi.js/lib/filters/FilterSystem.mjs
var quadGeometry = new Geometry({
	attributes: { aPosition: {
		buffer: new Float32Array([
			0,
			0,
			1,
			0,
			1,
			1,
			0,
			1
		]),
		format: "float32x2",
		stride: 8,
		offset: 0
	} },
	indexBuffer: new Uint32Array([
		0,
		1,
		2,
		0,
		2,
		3
	])
});
var FilterData = class {
	constructor() {
		/**
		* Indicates whether the filter should be skipped.
		* @type {boolean}
		*/
		this.skip = false;
		/**
		* The texture to which the filter is applied.
		* @type {Texture}
		*/
		this.inputTexture = null;
		/**
		* The back texture used for blending, if required.
		* @type {Texture | null}
		*/
		this.backTexture = null;
		/**
		* The list of filters to be applied.
		* @type {Filter[]}
		*/
		this.filters = null;
		/**
		* The bounds of the filter area.
		* @type {Bounds}
		*/
		this.bounds = new Bounds();
		/**
		* The container to which the filter is applied.
		* @type {Container}
		*/
		this.container = null;
		/**
		* Indicates whether blending is required for the filter.
		* @type {boolean}
		*/
		this.blendRequired = false;
		/**
		* The render surface where the output of the filter is rendered.
		* @type {RenderSurface}
		*/
		this.outputRenderSurface = null;
		/** The first enabled filter index in the current filter list. */
		this.firstEnabledIndex = -1;
		/** The last enabled filter index in the current filter list. */
		this.lastEnabledIndex = -1;
	}
};
var FilterSystem = class {
	constructor(renderer) {
		this._filterStackIndex = 0;
		this._filterStack = [];
		this._filterGlobalUniforms = new UniformGroup({
			uInputSize: {
				value: /* @__PURE__ */ new Float32Array(4),
				type: "vec4<f32>"
			},
			uInputPixel: {
				value: /* @__PURE__ */ new Float32Array(4),
				type: "vec4<f32>"
			},
			uInputClamp: {
				value: /* @__PURE__ */ new Float32Array(4),
				type: "vec4<f32>"
			},
			uOutputFrame: {
				value: /* @__PURE__ */ new Float32Array(4),
				type: "vec4<f32>"
			},
			uGlobalFrame: {
				value: /* @__PURE__ */ new Float32Array(4),
				type: "vec4<f32>"
			},
			uOutputTexture: {
				value: /* @__PURE__ */ new Float32Array(4),
				type: "vec4<f32>"
			}
		});
		this._globalFilterBindGroup = new BindGroup({});
		this.renderer = renderer;
	}
	/**
	* The back texture of the currently active filter. Requires the filter to have `blendRequired` set to true.
	* @readonly
	*/
	get activeBackTexture() {
		return this._activeFilterData?.backTexture;
	}
	/**
	* Pushes a filter instruction onto the filter stack.
	* @param instruction - The instruction containing the filter effect and container.
	* @internal
	*/
	push(instruction) {
		const renderer = this.renderer;
		const filters = instruction.filterEffect.filters;
		const filterData = this._pushFilterData();
		filterData.skip = false;
		filterData.filters = filters;
		filterData.container = instruction.container;
		filterData.outputRenderSurface = renderer.renderTarget.renderSurface;
		const colorTextureSource = renderer.renderTarget.renderTarget.colorTexture.source;
		const rootResolution = colorTextureSource.resolution;
		const rootAntialias = colorTextureSource.antialias;
		if (filters.every((filter) => !filter.enabled)) {
			filterData.skip = true;
			return;
		}
		const bounds = filterData.bounds;
		this._calculateFilterArea(instruction, bounds);
		this._calculateFilterBounds(filterData, renderer.renderTarget.rootViewPort, rootAntialias, rootResolution, 1);
		if (filterData.skip) return;
		const previousFilterData = this._getPreviousFilterData();
		this._setupFilterTextures(filterData, bounds, renderer, previousFilterData);
	}
	/**
	* Applies filters to a texture.
	*
	* This method takes a texture and a list of filters, applies the filters to the texture,
	* and returns the resulting texture.
	* @param {object} params - The parameters for applying filters.
	* @param {Texture} params.texture - The texture to apply filters to.
	* @param {Filter[]} params.filters - The filters to apply.
	* @returns {Texture} The resulting texture after all filters have been applied.
	* @example
	*
	* ```ts
	* // Create a texture and a list of filters
	* const texture = new Texture(...);
	* const filters = [new BlurFilter(), new ColorMatrixFilter()];
	*
	* // Apply the filters to the texture
	* const resultTexture = renderer.filter.generateFilteredTexture({ texture, filters });
	*
	* // Use the resulting texture
	* sprite.texture = resultTexture;
	* ```
	*
	* Key Points:
	* 1. padding is not currently supported here - so clipping may occur with filters that use padding.
	* 2. If all filters are disabled or skipped, the original texture is returned.
	*/
	generateFilteredTexture({ texture, filters }) {
		if (filters.every((filter) => !filter.enabled)) return texture;
		const filterData = this._pushFilterData();
		this._activeFilterData = filterData;
		filterData.skip = false;
		filterData.filters = filters;
		const colorTextureSource = texture.source;
		const rootResolution = colorTextureSource.resolution;
		const rootAntialias = colorTextureSource.antialias;
		const bounds = filterData.bounds;
		bounds.clear();
		bounds.addRect(texture.frame);
		this._calculateFilterBounds(filterData, bounds.rectangle, rootAntialias, rootResolution, 0);
		if (filterData.skip) {
			this._popFilterData();
			return texture;
		}
		filterData.outputRenderSurface = TexturePool.getOptimalTexture({
			width: bounds.width,
			height: bounds.height,
			resolution: filterData.resolution,
			antialias: filterData.antialias
		});
		filterData.backTexture = Texture.EMPTY;
		filterData.inputTexture = texture;
		this.renderer.renderTarget.finishRenderPass();
		this._applyFiltersToTexture(filterData, true);
		const outputTexture = filterData.outputRenderSurface;
		outputTexture.source.alphaMode = "premultiplied-alpha";
		this._popFilterData();
		return outputTexture;
	}
	/** @internal */
	pop() {
		const renderer = this.renderer;
		const filterData = this._popFilterData();
		if (filterData.skip) return;
		renderer.globalUniforms.pop();
		renderer.renderTarget.finishRenderPass();
		this._activeFilterData = filterData;
		this._applyFiltersToTexture(filterData, false);
		if (filterData.blendRequired) TexturePool.returnTexture(filterData.backTexture);
		TexturePool.returnTexture(filterData.inputTexture);
	}
	/**
	* Copies the last render surface to a texture.
	* @param lastRenderSurface - The last render surface to copy from.
	* @param bounds - The bounds of the area to copy.
	* @param previousBounds - The previous bounds to use for offsetting the copy.
	*/
	getBackTexture(lastRenderSurface, bounds, previousBounds) {
		const backgroundResolution = lastRenderSurface.colorTexture.source._resolution;
		const backTexture = TexturePool.getOptimalTexture({
			width: bounds.width,
			height: bounds.height,
			resolution: backgroundResolution
		});
		let x = bounds.minX;
		let y = bounds.minY;
		if (previousBounds) {
			x -= previousBounds.minX;
			y -= previousBounds.minY;
		}
		x = Math.floor(x * backgroundResolution);
		y = Math.floor(y * backgroundResolution);
		const width = Math.ceil(bounds.width * backgroundResolution);
		const height = Math.ceil(bounds.height * backgroundResolution);
		this.renderer.renderTarget.copyToTexture(lastRenderSurface, backTexture, {
			x,
			y
		}, {
			width,
			height
		}, {
			x: 0,
			y: 0
		});
		return backTexture;
	}
	/**
	* Applies a filter to a texture.
	* @param filter - The filter to apply.
	* @param input - The input texture.
	* @param output - The output render surface.
	* @param clear - Whether to clear the output surface before applying the filter.
	*/
	applyFilter(filter, input, output, clear) {
		const renderer = this.renderer;
		const filterData = this._activeFilterData;
		const isFinalTarget = filterData.outputRenderSurface === output;
		const closestFilterData = this._findClosestFilterData();
		const resolution = closestFilterData ? closestFilterData.inputTexture.source._resolution : renderer.renderTarget.rootRenderTarget.colorTexture.source._resolution;
		let offsetX = 0;
		let offsetY = 0;
		if (isFinalTarget && closestFilterData) {
			offsetX = closestFilterData.bounds.minX;
			offsetY = closestFilterData.bounds.minY;
		}
		this._updateFilterUniforms(input, output, filterData, offsetX, offsetY, resolution, isFinalTarget, clear);
		const filterToApply = filter.enabled ? filter : this._getPassthroughFilter();
		this._setupBindGroupsAndRender(filterToApply, input, renderer);
	}
	/**
	* Multiply _input normalized coordinates_ to this matrix to get _sprite texture normalized coordinates_.
	*
	* Use `outputMatrix * vTextureCoord` in the shader.
	* @param outputMatrix - The matrix to output to.
	* @param {Sprite} sprite - The sprite to map to.
	* @returns The mapped matrix.
	*/
	calculateSpriteMatrix(outputMatrix, sprite) {
		const data = this._activeFilterData;
		const mappedMatrix = outputMatrix.set(data.inputTexture._source.width, 0, 0, data.inputTexture._source.height, data.bounds.minX, data.bounds.minY);
		const worldTransform = sprite.worldTransform.copyTo(Matrix.shared);
		const renderGroup = sprite.renderGroup || sprite.parentRenderGroup;
		if (renderGroup && renderGroup.cacheToLocalTransform) worldTransform.prepend(renderGroup.cacheToLocalTransform);
		worldTransform.invert();
		mappedMatrix.prepend(worldTransform);
		mappedMatrix.scale(1 / sprite.texture.orig.width, 1 / sprite.texture.orig.height);
		mappedMatrix.translate(sprite.anchor.x, sprite.anchor.y);
		return mappedMatrix;
	}
	destroy() {
		this._passthroughFilter?.destroy(true);
		this._passthroughFilter = null;
	}
	_getPassthroughFilter() {
		this._passthroughFilter ?? (this._passthroughFilter = new PassthroughFilter());
		return this._passthroughFilter;
	}
	/**
	* Sets up the bind groups and renders the filter.
	* @param filter - The filter to apply
	* @param input - The input texture
	* @param renderer - The renderer instance
	*/
	_setupBindGroupsAndRender(filter, input, renderer) {
		if (renderer.renderPipes.uniformBatch) {
			const batchUniforms = renderer.renderPipes.uniformBatch.getUboResource(this._filterGlobalUniforms);
			this._globalFilterBindGroup.setResource(batchUniforms, 0);
		} else this._globalFilterBindGroup.setResource(this._filterGlobalUniforms, 0);
		this._globalFilterBindGroup.setResource(input.source, 1);
		this._globalFilterBindGroup.setResource(input.source.style, 2);
		filter.groups[0] = this._globalFilterBindGroup;
		renderer.encoder.draw({
			geometry: quadGeometry,
			shader: filter,
			state: filter._state,
			topology: "triangle-list"
		});
		if (renderer.type === RendererType.WEBGL) renderer.renderTarget.finishRenderPass();
	}
	/**
	* Sets up the filter textures including input texture and back texture if needed.
	* @param filterData - The filter data to update
	* @param bounds - The bounds for the texture
	* @param renderer - The renderer instance
	* @param previousFilterData - The previous filter data for back texture calculation
	*/
	_setupFilterTextures(filterData, bounds, renderer, previousFilterData) {
		filterData.backTexture = Texture.EMPTY;
		filterData.inputTexture = TexturePool.getOptimalTexture({
			width: bounds.width,
			height: bounds.height,
			resolution: filterData.resolution,
			antialias: filterData.antialias
		});
		if (filterData.blendRequired) {
			renderer.renderTarget.finishRenderPass();
			const renderTarget = renderer.renderTarget.getRenderTarget(filterData.outputRenderSurface);
			filterData.backTexture = this.getBackTexture(renderTarget, bounds, previousFilterData?.bounds);
		}
		renderer.renderTarget.bind({
			target: filterData.inputTexture,
			clear: true
		});
		renderer.globalUniforms.push({ offset: bounds });
	}
	/**
	* Updates the filter uniforms with the current filter state.
	* @param input - The input texture
	* @param output - The output render surface
	* @param filterData - The current filter data
	* @param offsetX - The X offset for positioning
	* @param offsetY - The Y offset for positioning
	* @param resolution - The current resolution
	* @param isFinalTarget - Whether this is the final render target
	* @param clear - Whether to clear the output surface
	*/
	_updateFilterUniforms(input, output, filterData, offsetX, offsetY, resolution, isFinalTarget, clear) {
		const uniforms = this._filterGlobalUniforms.uniforms;
		const outputFrame = uniforms.uOutputFrame;
		const inputSize = uniforms.uInputSize;
		const inputPixel = uniforms.uInputPixel;
		const inputClamp = uniforms.uInputClamp;
		const globalFrame = uniforms.uGlobalFrame;
		const outputTexture = uniforms.uOutputTexture;
		if (isFinalTarget) {
			outputFrame[0] = filterData.bounds.minX - offsetX;
			outputFrame[1] = filterData.bounds.minY - offsetY;
		} else {
			outputFrame[0] = 0;
			outputFrame[1] = 0;
		}
		outputFrame[2] = input.frame.width;
		outputFrame[3] = input.frame.height;
		inputSize[0] = input.source.width;
		inputSize[1] = input.source.height;
		inputSize[2] = 1 / inputSize[0];
		inputSize[3] = 1 / inputSize[1];
		inputPixel[0] = input.source.pixelWidth;
		inputPixel[1] = input.source.pixelHeight;
		inputPixel[2] = 1 / inputPixel[0];
		inputPixel[3] = 1 / inputPixel[1];
		inputClamp[0] = .5 * inputPixel[2];
		inputClamp[1] = .5 * inputPixel[3];
		inputClamp[2] = input.frame.width * inputSize[2] - .5 * inputPixel[2];
		inputClamp[3] = input.frame.height * inputSize[3] - .5 * inputPixel[3];
		const rootTexture = this.renderer.renderTarget.rootRenderTarget.colorTexture;
		globalFrame[0] = offsetX * resolution;
		globalFrame[1] = offsetY * resolution;
		globalFrame[2] = rootTexture.source.width * resolution;
		globalFrame[3] = rootTexture.source.height * resolution;
		if (output instanceof Texture) output.source.resource = null;
		const renderTarget = this.renderer.renderTarget.getRenderTarget(output);
		this.renderer.renderTarget.bind({
			target: output,
			clear: !!clear
		});
		if (output instanceof Texture) {
			outputTexture[0] = output.frame.width;
			outputTexture[1] = output.frame.height;
		} else {
			outputTexture[0] = renderTarget.width;
			outputTexture[1] = renderTarget.height;
		}
		outputTexture[2] = renderTarget.isRoot ? -1 : 1;
		this._filterGlobalUniforms.update();
	}
	/**
	* Finds the non-skipped entry closest to the top of the filter stack.
	*
	* `pop()` removes its entry before it applies the filters, so the result is the enclosing filter's entry.
	* `generateFilteredTexture()` applies the filters while its entry is still on the stack, so the result is that entry.
	* @returns The entry, or null if there is none
	*/
	_findClosestFilterData() {
		for (let i = this._filterStackIndex - 1; i >= 0; i--) {
			const filterData = this._filterStack[i];
			if (!filterData.skip) return filterData;
		}
		return null;
	}
	/**
	* Calculates the filter area bounds based on the instruction type.
	* @param instruction - The filter instruction
	* @param bounds - The bounds object to populate
	*/
	_calculateFilterArea(instruction, bounds) {
		if (instruction.renderables) getGlobalRenderableBounds(instruction.renderables, bounds);
		else if (instruction.filterEffect.filterArea) {
			bounds.clear();
			bounds.addRect(instruction.filterEffect.filterArea);
			bounds.applyMatrix(instruction.container.worldTransform);
		} else instruction.container.getFastGlobalBounds(true, bounds);
		if (instruction.container) {
			const filterFrameTransform = (instruction.container.renderGroup || instruction.container.parentRenderGroup).cacheToLocalTransform;
			if (filterFrameTransform) bounds.applyMatrix(filterFrameTransform);
		}
	}
	_applyFiltersToTexture(filterData, clear) {
		const inputTexture = filterData.inputTexture;
		const bounds = filterData.bounds;
		const filters = filterData.filters;
		const firstEnabled = filterData.firstEnabledIndex;
		const lastEnabled = filterData.lastEnabledIndex;
		this._globalFilterBindGroup.setResource(inputTexture.source.style, 2);
		this._globalFilterBindGroup.setResource(filterData.backTexture.source, 3);
		if (firstEnabled === lastEnabled) filters[firstEnabled].apply(this, inputTexture, filterData.outputRenderSurface, clear);
		else {
			let flip = filterData.inputTexture;
			const tempTexture = TexturePool.getOptimalTexture({
				width: bounds.width,
				height: bounds.height,
				resolution: flip.source._resolution
			});
			let flop = tempTexture;
			for (let i = firstEnabled; i < lastEnabled; i++) {
				const filter = filters[i];
				if (!filter.enabled) continue;
				filter.apply(this, flip, flop, true);
				const t = flip;
				flip = flop;
				flop = t;
			}
			filters[lastEnabled].apply(this, flip, filterData.outputRenderSurface, clear);
			TexturePool.returnTexture(tempTexture);
		}
	}
	_calculateFilterBounds(filterData, viewPort, rootAntialias, rootResolution, paddingMultiplier) {
		const renderer = this.renderer;
		const bounds = filterData.bounds;
		const filters = filterData.filters;
		let resolution = Infinity;
		let padding = 0;
		let antialias = true;
		let blendRequired = false;
		let enabled = false;
		let clipToViewport = true;
		let firstEnabledIndex = -1;
		let lastEnabledIndex = -1;
		for (let i = 0; i < filters.length; i++) {
			const filter = filters[i];
			if (!filter.enabled) continue;
			if (firstEnabledIndex === -1) firstEnabledIndex = i;
			lastEnabledIndex = i;
			resolution = Math.min(resolution, filter.resolution === "inherit" ? rootResolution : filter.resolution);
			padding += filter.padding;
			if (filter.antialias === "off") antialias = false;
			else if (filter.antialias === "inherit") antialias && (antialias = rootAntialias);
			if (!filter.clipToViewport) clipToViewport = false;
			if (!!!(filter.compatibleRenderers & renderer.type)) {
				enabled = false;
				break;
			}
			if (filter.blendRequired && !(renderer.backBuffer?.useBackBuffer ?? true)) {
				warn("Blend filter requires backBuffer on WebGL renderer to be enabled. Set `useBackBuffer: true` in the renderer options.");
				enabled = false;
				break;
			}
			enabled = true;
			blendRequired || (blendRequired = filter.blendRequired);
		}
		if (!enabled) {
			filterData.skip = true;
			return;
		}
		if (clipToViewport) bounds.fitBounds(0, viewPort.width / rootResolution, 0, viewPort.height / rootResolution);
		bounds.scale(resolution).ceil().scale(1 / resolution).pad((padding | 0) * paddingMultiplier);
		if (!bounds.isPositive) {
			filterData.skip = true;
			return;
		}
		filterData.antialias = antialias;
		filterData.resolution = resolution;
		filterData.blendRequired = blendRequired;
		filterData.firstEnabledIndex = firstEnabledIndex;
		filterData.lastEnabledIndex = lastEnabledIndex;
	}
	_popFilterData() {
		this._filterStackIndex--;
		return this._filterStack[this._filterStackIndex];
	}
	/**
	* Finds the closest non-skipped entry that encloses the filter being pushed.
	*
	* `push()` has already added that filter's own entry, so the search starts one entry below it.
	* @returns The entry, or null if there is none
	*/
	_getPreviousFilterData() {
		for (let i = this._filterStackIndex - 2; i >= 0; i--) {
			const filterData = this._filterStack[i];
			if (!filterData.skip) return filterData;
		}
		return null;
	}
	_pushFilterData() {
		let filterData = this._filterStack[this._filterStackIndex];
		if (!filterData) filterData = this._filterStack[this._filterStackIndex] = new FilterData();
		this._filterStackIndex++;
		return filterData;
	}
};
/** @ignore */
FilterSystem.extension = {
	type: [ExtensionType.WebGLSystem, ExtensionType.WebGPUSystem],
	name: "filter"
};
//#endregion
export { VideoSource as C, AlphaMask as D, ColorMask as E, addMaskLocalBounds as O, textureFrom as S, StencilMask as T, createStringVariations as _, fragment as a, autoDetectSource as b, isCanvasFilterCapable as c, spritesheetAsset as d, Spritesheet as f, isSingleItem as g, getUrlExtension as h, source as i, addMaskBounds as k, getPo2TextureFromSource as l, Resolver as m, FilterPipe as n, vertex as o, copySearchParams as p, PassthroughFilter as r, CanvasFilterSystem as s, FilterSystem as t, getGlobalRenderableBounds as u, path as v, detectVideoAlphaMode as w, resourceToTexture as x, LoaderParserPriority as y };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRmlsdGVyU3lzdGVtLUJma3JQVkltLmpzIiwibmFtZXMiOlsidGVtcEJvdW5kcyJdLCJzb3VyY2VzIjpbIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9tYXNrL3V0aWxzL2FkZE1hc2tCb3VuZHMubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL21hc2svdXRpbHMvYWRkTWFza0xvY2FsQm91bmRzLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9tYXNrL2FscGhhL0FscGhhTWFzay5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvbWFzay9jb2xvci9Db2xvck1hc2subWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvcmVuZGVyaW5nL21hc2svc3RlbmNpbC9TdGVuY2lsTWFzay5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi91dGlscy9icm93c2VyL2RldGVjdFZpZGVvQWxwaGFNb2RlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvc291cmNlcy9WaWRlb1NvdXJjZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL3V0aWxzL3RleHR1cmVGcm9tLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3JlbmRlcmluZy9pbml0Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2Fzc2V0cy9sb2FkZXIvcGFyc2Vycy9Mb2FkZXJQYXJzZXIubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvdXRpbHMvcGF0aC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9hc3NldHMvdXRpbHMvY3JlYXRlU3RyaW5nVmFyaWF0aW9ucy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9hc3NldHMvdXRpbHMvaXNTaW5nbGVJdGVtLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2Fzc2V0cy9yZXNvbHZlci9SZXNvbHZlci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9hc3NldHMvdXRpbHMvY29weVNlYXJjaFBhcmFtcy5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zcHJpdGVzaGVldC9TcHJpdGVzaGVldC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9zcHJpdGVzaGVldC9zcHJpdGVzaGVldEFzc2V0Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3Nwcml0ZXNoZWV0L2luaXQubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvc2NlbmUvY29udGFpbmVyL2JvdW5kcy9nZXRSZW5kZXJhYmxlQm91bmRzLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL3NjZW5lL3RleHQvdXRpbHMvZ2V0UG8yVGV4dHVyZUZyb21Tb3VyY2UubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvZmlsdGVycy9DYW52YXNGaWx0ZXJTeXN0ZW0ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvZmlsdGVycy9kZWZhdWx0cy9kZWZhdWx0RmlsdGVyLnZlcnQubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvZmlsdGVycy9kZWZhdWx0cy9wYXNzdGhyb3VnaC9wYXNzdGhyb3VnaC5mcmFnLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2ZpbHRlcnMvZGVmYXVsdHMvcGFzc3Rocm91Z2gvcGFzc3Rocm91Z2gud2dzbC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9maWx0ZXJzL2RlZmF1bHRzL3Bhc3N0aHJvdWdoL1Bhc3N0aHJvdWdoRmlsdGVyLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2ZpbHRlcnMvRmlsdGVyUGlwZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9maWx0ZXJzL0ZpbHRlclN5c3RlbS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm91bmRzIH0gZnJvbSAnLi4vLi4vLi4vc2NlbmUvY29udGFpbmVyL2JvdW5kcy9Cb3VuZHMubWpzJztcbmltcG9ydCB7IGdldEdsb2JhbEJvdW5kcyB9IGZyb20gJy4uLy4uLy4uL3NjZW5lL2NvbnRhaW5lci9ib3VuZHMvZ2V0R2xvYmFsQm91bmRzLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgdGVtcEJvdW5kcyA9IG5ldyBCb3VuZHMoKTtcbmZ1bmN0aW9uIGFkZE1hc2tCb3VuZHMobWFzaywgYm91bmRzLCBza2lwVXBkYXRlVHJhbnNmb3JtKSB7XG4gIGNvbnN0IGJvdW5kc1RvTWFzayA9IHRlbXBCb3VuZHM7XG4gIG1hc2subWVhc3VyYWJsZSA9IHRydWU7XG4gIGdldEdsb2JhbEJvdW5kcyhtYXNrLCBza2lwVXBkYXRlVHJhbnNmb3JtLCBib3VuZHNUb01hc2spO1xuICBib3VuZHMuYWRkQm91bmRzTWFzayhib3VuZHNUb01hc2spO1xuICBtYXNrLm1lYXN1cmFibGUgPSBmYWxzZTtcbn1cblxuZXhwb3J0IHsgYWRkTWFza0JvdW5kcyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YWRkTWFza0JvdW5kcy5tanMubWFwXG4iLCJpbXBvcnQgeyBnZXRMb2NhbEJvdW5kcyB9IGZyb20gJy4uLy4uLy4uL3NjZW5lL2NvbnRhaW5lci9ib3VuZHMvZ2V0TG9jYWxCb3VuZHMubWpzJztcbmltcG9ydCB7IGJvdW5kc1Bvb2wsIG1hdHJpeFBvb2wgfSBmcm9tICcuLi8uLi8uLi9zY2VuZS9jb250YWluZXIvYm91bmRzL3V0aWxzL21hdHJpeEFuZEJvdW5kc1Bvb2wubWpzJztcbmltcG9ydCB7IHdhcm4gfSBmcm9tICcuLi8uLi8uLi91dGlscy9sb2dnaW5nL3dhcm4ubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBhZGRNYXNrTG9jYWxCb3VuZHMobWFzaywgYm91bmRzLCBsb2NhbFJvb3QpIHtcbiAgY29uc3QgYm91bmRzVG9NYXNrID0gYm91bmRzUG9vbC5nZXQoKTtcbiAgbWFzay5tZWFzdXJhYmxlID0gdHJ1ZTtcbiAgY29uc3QgdGVtcE1hdHJpeCA9IG1hdHJpeFBvb2wuZ2V0KCkuaWRlbnRpdHkoKTtcbiAgY29uc3QgcmVsYXRpdmVNYXNrID0gZ2V0TWF0cml4UmVsYXRpdmVUb1BhcmVudChtYXNrLCBsb2NhbFJvb3QsIHRlbXBNYXRyaXgpO1xuICBnZXRMb2NhbEJvdW5kcyhtYXNrLCBib3VuZHNUb01hc2ssIHJlbGF0aXZlTWFzayk7XG4gIG1hc2subWVhc3VyYWJsZSA9IGZhbHNlO1xuICBib3VuZHMuYWRkQm91bmRzTWFzayhib3VuZHNUb01hc2spO1xuICBtYXRyaXhQb29sLnJldHVybih0ZW1wTWF0cml4KTtcbiAgYm91bmRzUG9vbC5yZXR1cm4oYm91bmRzVG9NYXNrKTtcbn1cbmZ1bmN0aW9uIGdldE1hdHJpeFJlbGF0aXZlVG9QYXJlbnQodGFyZ2V0LCByb290LCBtYXRyaXgpIHtcbiAgaWYgKCF0YXJnZXQpIHtcbiAgICB3YXJuKFwiTWFzayBib3VuZHMsIHJlbmRlcmFibGUgaXMgbm90IGluc2lkZSB0aGUgcm9vdCBjb250YWluZXJcIik7XG4gICAgcmV0dXJuIG1hdHJpeDtcbiAgfVxuICBpZiAodGFyZ2V0ICE9PSByb290KSB7XG4gICAgZ2V0TWF0cml4UmVsYXRpdmVUb1BhcmVudCh0YXJnZXQucGFyZW50LCByb290LCBtYXRyaXgpO1xuICAgIHRhcmdldC51cGRhdGVMb2NhbFRyYW5zZm9ybSgpO1xuICAgIG1hdHJpeC5hcHBlbmQodGFyZ2V0LmxvY2FsVHJhbnNmb3JtKTtcbiAgfVxuICByZXR1cm4gbWF0cml4O1xufVxuXG5leHBvcnQgeyBhZGRNYXNrTG9jYWxCb3VuZHMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFkZE1hc2tMb2NhbEJvdW5kcy5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBTcHJpdGUgfSBmcm9tICcuLi8uLi8uLi9zY2VuZS9zcHJpdGUvU3ByaXRlLm1qcyc7XG5pbXBvcnQgeyBhZGRNYXNrQm91bmRzIH0gZnJvbSAnLi4vdXRpbHMvYWRkTWFza0JvdW5kcy5tanMnO1xuaW1wb3J0IHsgYWRkTWFza0xvY2FsQm91bmRzIH0gZnJvbSAnLi4vdXRpbHMvYWRkTWFza0xvY2FsQm91bmRzLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgQWxwaGFNYXNrIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIHRoaXMucHJpb3JpdHkgPSAwO1xuICAgIHRoaXMuaW52ZXJzZSA9IGZhbHNlO1xuICAgIHRoaXMuY2hhbm5lbCA9IFwicmVkXCI7XG4gICAgdGhpcy5waXBlID0gXCJhbHBoYU1hc2tcIjtcbiAgICBpZiAob3B0aW9ucz8ubWFzaykge1xuICAgICAgdGhpcy5pbml0KG9wdGlvbnMubWFzayk7XG4gICAgfVxuICB9XG4gIGluaXQobWFzaykge1xuICAgIHRoaXMubWFzayA9IG1hc2s7XG4gICAgdGhpcy5yZW5kZXJNYXNrVG9UZXh0dXJlID0gIShtYXNrIGluc3RhbmNlb2YgU3ByaXRlKTtcbiAgICB0aGlzLm1hc2sucmVuZGVyYWJsZSA9IHRoaXMucmVuZGVyTWFza1RvVGV4dHVyZTtcbiAgICB0aGlzLm1hc2suaW5jbHVkZUluQnVpbGQgPSAhdGhpcy5yZW5kZXJNYXNrVG9UZXh0dXJlO1xuICAgIHRoaXMubWFzay5tZWFzdXJhYmxlID0gZmFsc2U7XG4gIH1cbiAgcmVzZXQoKSB7XG4gICAgaWYgKHRoaXMubWFzayA9PT0gbnVsbCkgcmV0dXJuO1xuICAgIHRoaXMubWFzay5tZWFzdXJhYmxlID0gdHJ1ZTtcbiAgICB0aGlzLm1hc2sgPSBudWxsO1xuICB9XG4gIGFkZEJvdW5kcyhib3VuZHMsIHNraXBVcGRhdGVUcmFuc2Zvcm0pIHtcbiAgICBpZiAoIXRoaXMuaW52ZXJzZSkge1xuICAgICAgYWRkTWFza0JvdW5kcyh0aGlzLm1hc2ssIGJvdW5kcywgc2tpcFVwZGF0ZVRyYW5zZm9ybSk7XG4gICAgfVxuICB9XG4gIGFkZExvY2FsQm91bmRzKGJvdW5kcywgbG9jYWxSb290KSB7XG4gICAgYWRkTWFza0xvY2FsQm91bmRzKHRoaXMubWFzaywgYm91bmRzLCBsb2NhbFJvb3QpO1xuICB9XG4gIGNvbnRhaW5zUG9pbnQocG9pbnQsIGhpdFRlc3RGbikge1xuICAgIGNvbnN0IG1hc2sgPSB0aGlzLm1hc2s7XG4gICAgcmV0dXJuIGhpdFRlc3RGbihtYXNrLCBwb2ludCk7XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLnJlc2V0KCk7XG4gIH1cbiAgc3RhdGljIHRlc3QobWFzaykge1xuICAgIHJldHVybiBtYXNrIGluc3RhbmNlb2YgU3ByaXRlO1xuICB9XG59XG5BbHBoYU1hc2suZXh0ZW5zaW9uID0gRXh0ZW5zaW9uVHlwZS5NYXNrRWZmZWN0O1xuXG5leHBvcnQgeyBBbHBoYU1hc2sgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUFscGhhTWFzay5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vLi4vLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgQ29sb3JNYXNrIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIHRoaXMucHJpb3JpdHkgPSAwO1xuICAgIHRoaXMucGlwZSA9IFwiY29sb3JNYXNrXCI7XG4gICAgaWYgKG9wdGlvbnM/Lm1hc2spIHtcbiAgICAgIHRoaXMuaW5pdChvcHRpb25zLm1hc2spO1xuICAgIH1cbiAgfVxuICBpbml0KG1hc2spIHtcbiAgICB0aGlzLm1hc2sgPSBtYXNrO1xuICB9XG4gIGRlc3Ryb3koKSB7XG4gIH1cbiAgc3RhdGljIHRlc3QobWFzaykge1xuICAgIHJldHVybiB0eXBlb2YgbWFzayA9PT0gXCJudW1iZXJcIjtcbiAgfVxufVxuQ29sb3JNYXNrLmV4dGVuc2lvbiA9IEV4dGVuc2lvblR5cGUuTWFza0VmZmVjdDtcblxuZXhwb3J0IHsgQ29sb3JNYXNrIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1Db2xvck1hc2subWpzLm1hcFxuIiwiaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgQ29udGFpbmVyIH0gZnJvbSAnLi4vLi4vLi4vc2NlbmUvY29udGFpbmVyL0NvbnRhaW5lci5tanMnO1xuaW1wb3J0IHsgYWRkTWFza0JvdW5kcyB9IGZyb20gJy4uL3V0aWxzL2FkZE1hc2tCb3VuZHMubWpzJztcbmltcG9ydCB7IGFkZE1hc2tMb2NhbEJvdW5kcyB9IGZyb20gJy4uL3V0aWxzL2FkZE1hc2tMb2NhbEJvdW5kcy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIFN0ZW5jaWxNYXNrIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIHRoaXMucHJpb3JpdHkgPSAwO1xuICAgIHRoaXMucGlwZSA9IFwic3RlbmNpbE1hc2tcIjtcbiAgICBpZiAob3B0aW9ucz8ubWFzaykge1xuICAgICAgdGhpcy5pbml0KG9wdGlvbnMubWFzayk7XG4gICAgfVxuICB9XG4gIGluaXQobWFzaykge1xuICAgIHRoaXMubWFzayA9IG1hc2s7XG4gICAgdGhpcy5tYXNrLmluY2x1ZGVJbkJ1aWxkID0gZmFsc2U7XG4gICAgdGhpcy5tYXNrLm1lYXN1cmFibGUgPSBmYWxzZTtcbiAgfVxuICByZXNldCgpIHtcbiAgICBpZiAodGhpcy5tYXNrID09PSBudWxsKSByZXR1cm47XG4gICAgdGhpcy5tYXNrLm1lYXN1cmFibGUgPSB0cnVlO1xuICAgIHRoaXMubWFzay5pbmNsdWRlSW5CdWlsZCA9IHRydWU7XG4gICAgdGhpcy5tYXNrID0gbnVsbDtcbiAgfVxuICBhZGRCb3VuZHMoYm91bmRzLCBza2lwVXBkYXRlVHJhbnNmb3JtKSB7XG4gICAgYWRkTWFza0JvdW5kcyh0aGlzLm1hc2ssIGJvdW5kcywgc2tpcFVwZGF0ZVRyYW5zZm9ybSk7XG4gIH1cbiAgYWRkTG9jYWxCb3VuZHMoYm91bmRzLCBsb2NhbFJvb3QpIHtcbiAgICBhZGRNYXNrTG9jYWxCb3VuZHModGhpcy5tYXNrLCBib3VuZHMsIGxvY2FsUm9vdCk7XG4gIH1cbiAgY29udGFpbnNQb2ludChwb2ludCwgaGl0VGVzdEZuKSB7XG4gICAgY29uc3QgbWFzayA9IHRoaXMubWFzaztcbiAgICByZXR1cm4gaGl0VGVzdEZuKG1hc2ssIHBvaW50KTtcbiAgfVxuICBkZXN0cm95KCkge1xuICAgIHRoaXMucmVzZXQoKTtcbiAgfVxuICBzdGF0aWMgdGVzdChtYXNrKSB7XG4gICAgcmV0dXJuIG1hc2sgaW5zdGFuY2VvZiBDb250YWluZXI7XG4gIH1cbn1cblN0ZW5jaWxNYXNrLmV4dGVuc2lvbiA9IEV4dGVuc2lvblR5cGUuTWFza0VmZmVjdDtcblxuZXhwb3J0IHsgU3RlbmNpbE1hc2sgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVN0ZW5jaWxNYXNrLm1qcy5tYXBcbiIsImltcG9ydCB7IERPTUFkYXB0ZXIgfSBmcm9tICcuLi8uLi9lbnZpcm9ubWVudC9hZGFwdGVyLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xubGV0IHByb21pc2U7XG5hc3luYyBmdW5jdGlvbiBkZXRlY3RWaWRlb0FscGhhTW9kZSgpIHtcbiAgcHJvbWlzZSA/PyAocHJvbWlzZSA9IChhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gRE9NQWRhcHRlci5nZXQoKS5jcmVhdGVDYW52YXMoMSwgMSk7XG4gICAgY29uc3QgZ2wgPSBjYW52YXMuZ2V0Q29udGV4dChcIndlYmdsXCIpO1xuICAgIGlmICghZ2wpIHtcbiAgICAgIHJldHVybiBcInByZW11bHRpcGx5LWFscGhhLW9uLXVwbG9hZFwiO1xuICAgIH1cbiAgICBjb25zdCB2aWRlbyA9IGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBjb25zdCB2aWRlbzIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwidmlkZW9cIik7XG4gICAgICB2aWRlbzIub25sb2FkZWRkYXRhID0gKCkgPT4gcmVzb2x2ZSh2aWRlbzIpO1xuICAgICAgdmlkZW8yLm9uZXJyb3IgPSAoKSA9PiByZXNvbHZlKG51bGwpO1xuICAgICAgdmlkZW8yLmF1dG9wbGF5ID0gZmFsc2U7XG4gICAgICB2aWRlbzIuY3Jvc3NPcmlnaW4gPSBcImFub255bW91c1wiO1xuICAgICAgdmlkZW8yLnByZWxvYWQgPSBcImF1dG9cIjtcbiAgICAgIHZpZGVvMi5zcmMgPSBcImRhdGE6dmlkZW8vd2VibTtiYXNlNjQsR2tYZm81OUNob0VCUXZlQkFVTHlnUVJDODRFSVFvS0VkMlZpYlVLSGdRSkNoWUVDR0ZPQVp3RUFBQUFBQUFIVEVVMmJkTHBOdTR0VHE0UVZTYWxtVTZ5Qm9VMjdpMU9yaEJaVXJtdFRySUhHVGJ1TVU2dUVFbFREWjFPc2dnRVhUYnVNVTZ1RUhGTzdhMU9zZ2dHOTdBRUFBQUFBQUFCWkFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBVlNhbG1vQ3JYc1lNUFFrQk5nSVJNWVhabVYwR0VUR0YyWmtTSmlFQkVBQUFBQUFBQUZsU3VhOHl1QVFBQUFBQUFBRVBYZ1FGenhZZ0FBQUFBQUFBQUFaeUJBQ0sxbklOMWJtU0lnUUNHaFZaZlZsQTVnNEVCSStPRGhBSmlXZ0RnbExDQkFycUJBcHFCQWxQQWdRRlZzSVJWdVlFQkVsVERaOVZ6YzlKandJdGp4WWdBQUFBQUFBQUFBV2ZJbkVXamgwVk9RMDlFUlZKRWg0OU1ZWFpqSUd4cFluWndlQzEyY0RsbnlLSkZvNGhFVlZKQlZFbFBUa1NIbERBd09qQXdPakF3TGpBME1EQXdNREF3TUFBQUgwTzJkY2ZuZ1FDZ3dxR2dnUUFBQUlKSmcwSUFBQkFBRmdBNEpCd1lTZ0FBSUNBQUViLy8vNHIrQUFCMW9aMm1tKzZCQWFXV2drbURRZ0FBRUFBV0FEZ2tIQmhLQUFBZ0lBQklRQnhUdTJ1UnU0K3pnUUMzaXZlQkFmR0NBWEh3Z1FNPVwiO1xuICAgICAgdmlkZW8yLmxvYWQoKTtcbiAgICB9KTtcbiAgICBpZiAoIXZpZGVvKSB7XG4gICAgICByZXR1cm4gXCJwcmVtdWx0aXBseS1hbHBoYS1vbi11cGxvYWRcIjtcbiAgICB9XG4gICAgY29uc3QgdGV4dHVyZSA9IGdsLmNyZWF0ZVRleHR1cmUoKTtcbiAgICBnbC5iaW5kVGV4dHVyZShnbC5URVhUVVJFXzJELCB0ZXh0dXJlKTtcbiAgICBjb25zdCBmcmFtZWJ1ZmZlciA9IGdsLmNyZWF0ZUZyYW1lYnVmZmVyKCk7XG4gICAgZ2wuYmluZEZyYW1lYnVmZmVyKGdsLkZSQU1FQlVGRkVSLCBmcmFtZWJ1ZmZlcik7XG4gICAgZ2wuZnJhbWVidWZmZXJUZXh0dXJlMkQoXG4gICAgICBnbC5GUkFNRUJVRkZFUixcbiAgICAgIGdsLkNPTE9SX0FUVEFDSE1FTlQwLFxuICAgICAgZ2wuVEVYVFVSRV8yRCxcbiAgICAgIHRleHR1cmUsXG4gICAgICAwXG4gICAgKTtcbiAgICBnbC5waXhlbFN0b3JlaShnbC5VTlBBQ0tfUFJFTVVMVElQTFlfQUxQSEFfV0VCR0wsIGZhbHNlKTtcbiAgICBnbC5waXhlbFN0b3JlaShnbC5VTlBBQ0tfQ09MT1JTUEFDRV9DT05WRVJTSU9OX1dFQkdMLCBnbC5OT05FKTtcbiAgICBnbC50ZXhJbWFnZTJEKGdsLlRFWFRVUkVfMkQsIDAsIGdsLlJHQkEsIGdsLlJHQkEsIGdsLlVOU0lHTkVEX0JZVEUsIHZpZGVvKTtcbiAgICBjb25zdCBwaXhlbCA9IG5ldyBVaW50OEFycmF5KDQpO1xuICAgIGdsLnJlYWRQaXhlbHMoMCwgMCwgMSwgMSwgZ2wuUkdCQSwgZ2wuVU5TSUdORURfQllURSwgcGl4ZWwpO1xuICAgIGdsLmRlbGV0ZUZyYW1lYnVmZmVyKGZyYW1lYnVmZmVyKTtcbiAgICBnbC5kZWxldGVUZXh0dXJlKHRleHR1cmUpO1xuICAgIGdsLmdldEV4dGVuc2lvbihcIldFQkdMX2xvc2VfY29udGV4dFwiKT8ubG9zZUNvbnRleHQoKTtcbiAgICByZXR1cm4gcGl4ZWxbMF0gPD0gcGl4ZWxbM10gPyBcInByZW11bHRpcGxpZWQtYWxwaGFcIiA6IFwicHJlbXVsdGlwbHktYWxwaGEtb24tdXBsb2FkXCI7XG4gIH0pKCkpO1xuICByZXR1cm4gcHJvbWlzZTtcbn1cblxuZXhwb3J0IHsgZGV0ZWN0VmlkZW9BbHBoYU1vZGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRldGVjdFZpZGVvQWxwaGFNb2RlLm1qcy5tYXBcbiIsImltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi8uLi8uLi8uLi8uLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IFRpY2tlciB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3RpY2tlci9UaWNrZXIubWpzJztcbmltcG9ydCB7IGRldGVjdFZpZGVvQWxwaGFNb2RlIH0gZnJvbSAnLi4vLi4vLi4vLi4vLi4vdXRpbHMvYnJvd3Nlci9kZXRlY3RWaWRlb0FscGhhTW9kZS5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVNvdXJjZSB9IGZyb20gJy4vVGV4dHVyZVNvdXJjZS5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IF9WaWRlb1NvdXJjZSA9IGNsYXNzIF9WaWRlb1NvdXJjZSBleHRlbmRzIFRleHR1cmVTb3VyY2Uge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgc3VwZXIob3B0aW9ucyk7XG4gICAgLy8gUHVibGljXG4gICAgLyoqIFdoZXRoZXIgb3Igbm90IHRoZSB2aWRlbyBpcyByZWFkeSB0byBwbGF5LiAqL1xuICAgIHRoaXMuaXNSZWFkeSA9IGZhbHNlO1xuICAgIC8qKiBUaGUgdXBsb2FkIG1ldGhvZCBmb3IgdGhpcyB0ZXh0dXJlLiAqL1xuICAgIHRoaXMudXBsb2FkTWV0aG9kSWQgPSBcInZpZGVvXCI7XG4gICAgb3B0aW9ucyA9IHtcbiAgICAgIC4uLl9WaWRlb1NvdXJjZS5kZWZhdWx0T3B0aW9ucyxcbiAgICAgIC4uLm9wdGlvbnNcbiAgICB9O1xuICAgIHRoaXMuX2F1dG9VcGRhdGUgPSB0cnVlO1xuICAgIHRoaXMuX2lzQ29ubmVjdGVkVG9UaWNrZXIgPSBmYWxzZTtcbiAgICB0aGlzLl91cGRhdGVGUFMgPSBvcHRpb25zLnVwZGF0ZUZQUyB8fCAwO1xuICAgIHRoaXMuX21zVG9OZXh0VXBkYXRlID0gMDtcbiAgICB0aGlzLmF1dG9QbGF5ID0gb3B0aW9ucy5hdXRvUGxheSAhPT0gZmFsc2U7XG4gICAgdGhpcy5hbHBoYU1vZGUgPSBvcHRpb25zLmFscGhhTW9kZSA/PyBcInByZW11bHRpcGx5LWFscGhhLW9uLXVwbG9hZFwiO1xuICAgIHRoaXMuX3ZpZGVvRnJhbWVSZXF1ZXN0Q2FsbGJhY2sgPSB0aGlzLl92aWRlb0ZyYW1lUmVxdWVzdENhbGxiYWNrLmJpbmQodGhpcyk7XG4gICAgdGhpcy5fdmlkZW9GcmFtZVJlcXVlc3RDYWxsYmFja0hhbmRsZSA9IG51bGw7XG4gICAgdGhpcy5fbG9hZCA9IG51bGw7XG4gICAgdGhpcy5fcmVzb2x2ZSA9IG51bGw7XG4gICAgdGhpcy5fcmVqZWN0ID0gbnVsbDtcbiAgICB0aGlzLl9vbkNhblBsYXkgPSB0aGlzLl9vbkNhblBsYXkuYmluZCh0aGlzKTtcbiAgICB0aGlzLl9vbkNhblBsYXlUaHJvdWdoID0gdGhpcy5fb25DYW5QbGF5VGhyb3VnaC5iaW5kKHRoaXMpO1xuICAgIHRoaXMuX29uRXJyb3IgPSB0aGlzLl9vbkVycm9yLmJpbmQodGhpcyk7XG4gICAgdGhpcy5fb25QbGF5U3RhcnQgPSB0aGlzLl9vblBsYXlTdGFydC5iaW5kKHRoaXMpO1xuICAgIHRoaXMuX29uUGxheVN0b3AgPSB0aGlzLl9vblBsYXlTdG9wLmJpbmQodGhpcyk7XG4gICAgdGhpcy5fb25TZWVrZWQgPSB0aGlzLl9vblNlZWtlZC5iaW5kKHRoaXMpO1xuICAgIHRoaXMuX29uTG9hZGVkTWV0YWRhdGEgPSB0aGlzLl9vbkxvYWRlZE1ldGFkYXRhLmJpbmQodGhpcyk7XG4gICAgaWYgKG9wdGlvbnMuYXV0b0xvYWQgIT09IGZhbHNlKSB7XG4gICAgICB2b2lkIHRoaXMubG9hZCgpO1xuICAgIH1cbiAgfVxuICAvKiogVXBkYXRlIHRoZSB2aWRlbyBmcmFtZSBpZiB0aGUgc291cmNlIGlzIG5vdCBkZXN0cm95ZWQgYW5kIG1lZXRzIGNlcnRhaW4gY29uZGl0aW9ucy4gKi9cbiAgdXBkYXRlRnJhbWUoKSB7XG4gICAgaWYgKHRoaXMuZGVzdHJveWVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0aGlzLl91cGRhdGVGUFMpIHtcbiAgICAgIGNvbnN0IGVsYXBzZWRNUyA9IFRpY2tlci5zaGFyZWQuZWxhcHNlZE1TICogdGhpcy5yZXNvdXJjZS5wbGF5YmFja1JhdGU7XG4gICAgICB0aGlzLl9tc1RvTmV4dFVwZGF0ZSA9IE1hdGguZmxvb3IodGhpcy5fbXNUb05leHRVcGRhdGUgLSBlbGFwc2VkTVMpO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuX3VwZGF0ZUZQUyB8fCB0aGlzLl9tc1RvTmV4dFVwZGF0ZSA8PSAwKSB7XG4gICAgICB0aGlzLl9tc1RvTmV4dFVwZGF0ZSA9IHRoaXMuX3VwZGF0ZUZQUyA/IE1hdGguZmxvb3IoMWUzIC8gdGhpcy5fdXBkYXRlRlBTKSA6IDA7XG4gICAgfVxuICAgIGlmICh0aGlzLmlzVmFsaWQpIHtcbiAgICAgIHRoaXMudXBkYXRlKCk7XG4gICAgfVxuICB9XG4gIC8qKiBDYWxsYmFjayB0byB1cGRhdGUgdGhlIHZpZGVvIGZyYW1lIGFuZCBwb3RlbnRpYWxseSByZXF1ZXN0IHRoZSBuZXh0IGZyYW1lIHVwZGF0ZS4gKi9cbiAgX3ZpZGVvRnJhbWVSZXF1ZXN0Q2FsbGJhY2soKSB7XG4gICAgdGhpcy51cGRhdGVGcmFtZSgpO1xuICAgIGlmICh0aGlzLmRlc3Ryb3llZCkge1xuICAgICAgdGhpcy5fdmlkZW9GcmFtZVJlcXVlc3RDYWxsYmFja0hhbmRsZSA9IG51bGw7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX3ZpZGVvRnJhbWVSZXF1ZXN0Q2FsbGJhY2tIYW5kbGUgPSB0aGlzLnJlc291cmNlLnJlcXVlc3RWaWRlb0ZyYW1lQ2FsbGJhY2soXG4gICAgICAgIHRoaXMuX3ZpZGVvRnJhbWVSZXF1ZXN0Q2FsbGJhY2tcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBDaGVja3MgaWYgdGhlIHJlc291cmNlIGhhcyB2YWxpZCBkaW1lbnNpb25zLlxuICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB3aWR0aCBhbmQgaGVpZ2h0IGFyZSBzZXQsIG90aGVyd2lzZSBmYWxzZS5cbiAgICovXG4gIGdldCBpc1ZhbGlkKCkge1xuICAgIHJldHVybiAhIXRoaXMucmVzb3VyY2UudmlkZW9XaWR0aCAmJiAhIXRoaXMucmVzb3VyY2UudmlkZW9IZWlnaHQ7XG4gIH1cbiAgLyoqXG4gICAqIFN0YXJ0IHByZWxvYWRpbmcgdGhlIHZpZGVvIHJlc291cmNlLlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTx0aGlzPn0gSGFuZGxlIHRoZSB2YWxpZGF0ZSBldmVudFxuICAgKi9cbiAgYXN5bmMgbG9hZCgpIHtcbiAgICBpZiAodGhpcy5fbG9hZCkge1xuICAgICAgcmV0dXJuIHRoaXMuX2xvYWQ7XG4gICAgfVxuICAgIGNvbnN0IHNvdXJjZSA9IHRoaXMucmVzb3VyY2U7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMub3B0aW9ucztcbiAgICBpZiAoKHNvdXJjZS5yZWFkeVN0YXRlID09PSBzb3VyY2UuSEFWRV9FTk9VR0hfREFUQSB8fCBzb3VyY2UucmVhZHlTdGF0ZSA9PT0gc291cmNlLkhBVkVfRlVUVVJFX0RBVEEpICYmIHNvdXJjZS53aWR0aCAmJiBzb3VyY2UuaGVpZ2h0KSB7XG4gICAgICBzb3VyY2UuY29tcGxldGUgPSB0cnVlO1xuICAgIH1cbiAgICBzb3VyY2UuYWRkRXZlbnRMaXN0ZW5lcihcInBsYXlcIiwgdGhpcy5fb25QbGF5U3RhcnQpO1xuICAgIHNvdXJjZS5hZGRFdmVudExpc3RlbmVyKFwicGF1c2VcIiwgdGhpcy5fb25QbGF5U3RvcCk7XG4gICAgc291cmNlLmFkZEV2ZW50TGlzdGVuZXIoXCJzZWVrZWRcIiwgdGhpcy5fb25TZWVrZWQpO1xuICAgIGlmICghdGhpcy5faXNTb3VyY2VSZWFkeSgpKSB7XG4gICAgICBpZiAoIW9wdGlvbnMucHJlbG9hZCkge1xuICAgICAgICBzb3VyY2UuYWRkRXZlbnRMaXN0ZW5lcihcImNhbnBsYXlcIiwgdGhpcy5fb25DYW5QbGF5KTtcbiAgICAgIH1cbiAgICAgIHNvdXJjZS5hZGRFdmVudExpc3RlbmVyKFwiY2FucGxheXRocm91Z2hcIiwgdGhpcy5fb25DYW5QbGF5VGhyb3VnaCk7XG4gICAgICBzb3VyY2UuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIHRoaXMuX29uRXJyb3IsIHRydWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9tZWRpYVJlYWR5KCk7XG4gICAgfVxuICAgIGlmICghdGhpcy5pc1ZhbGlkKSB7XG4gICAgICBzb3VyY2UuYWRkRXZlbnRMaXN0ZW5lcihcImxvYWRlZG1ldGFkYXRhXCIsIHRoaXMuX29uTG9hZGVkTWV0YWRhdGEpO1xuICAgIH1cbiAgICB0aGlzLmFscGhhTW9kZSA9IGF3YWl0IGRldGVjdFZpZGVvQWxwaGFNb2RlKCk7XG4gICAgdGhpcy5fbG9hZCA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGlmICh0aGlzLmlzVmFsaWQpIHtcbiAgICAgICAgcmVzb2x2ZSh0aGlzKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX3Jlc29sdmUgPSByZXNvbHZlO1xuICAgICAgICB0aGlzLl9yZWplY3QgPSByZWplY3Q7XG4gICAgICAgIGlmIChvcHRpb25zLnByZWxvYWRUaW1lb3V0TXMgIT09IHZvaWQgMCkge1xuICAgICAgICAgIHRoaXMuX3ByZWxvYWRUaW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLl9vbkVycm9yKG5ldyBFcnJvckV2ZW50KGBQcmVsb2FkIGV4Y2VlZGVkIHRpbWVvdXQgb2YgJHtvcHRpb25zLnByZWxvYWRUaW1lb3V0TXN9bXNgKSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgc291cmNlLmxvYWQoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gdGhpcy5fbG9hZDtcbiAgfVxuICAvKipcbiAgICogSGFuZGxlIHZpZGVvIGVycm9yIGV2ZW50cy5cbiAgICogQHBhcmFtIGV2ZW50IC0gVGhlIGVycm9yIGV2ZW50XG4gICAqL1xuICBfb25FcnJvcihldmVudCkge1xuICAgIHRoaXMucmVzb3VyY2UucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIHRoaXMuX29uRXJyb3IsIHRydWUpO1xuICAgIHRoaXMuZW1pdChcImVycm9yXCIsIGV2ZW50KTtcbiAgICBpZiAodGhpcy5fcmVqZWN0KSB7XG4gICAgICB0aGlzLl9yZWplY3QoZXZlbnQpO1xuICAgICAgdGhpcy5fcmVqZWN0ID0gbnVsbDtcbiAgICAgIHRoaXMuX3Jlc29sdmUgPSBudWxsO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogQ2hlY2tzIGlmIHRoZSB1bmRlcmx5aW5nIHNvdXJjZSBpcyBwbGF5aW5nLlxuICAgKiBAcmV0dXJucyBUcnVlIGlmIHBsYXlpbmcuXG4gICAqL1xuICBfaXNTb3VyY2VQbGF5aW5nKCkge1xuICAgIGNvbnN0IHNvdXJjZSA9IHRoaXMucmVzb3VyY2U7XG4gICAgcmV0dXJuICFzb3VyY2UucGF1c2VkICYmICFzb3VyY2UuZW5kZWQ7XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyBpZiB0aGUgdW5kZXJseWluZyBzb3VyY2UgaXMgcmVhZHkgZm9yIHBsYXlpbmcuXG4gICAqIEByZXR1cm5zIFRydWUgaWYgcmVhZHkuXG4gICAqL1xuICBfaXNTb3VyY2VSZWFkeSgpIHtcbiAgICBjb25zdCBzb3VyY2UgPSB0aGlzLnJlc291cmNlO1xuICAgIHJldHVybiBzb3VyY2UucmVhZHlTdGF0ZSA+IDI7XG4gIH1cbiAgLyoqIFJ1bnMgdGhlIHVwZGF0ZSBsb29wIHdoZW4gdGhlIHZpZGVvIGlzIHJlYWR5IHRvIHBsYXkuICovXG4gIF9vblBsYXlTdGFydCgpIHtcbiAgICB0aGlzLl9jb25maWd1cmVBdXRvVXBkYXRlKCk7XG4gIH1cbiAgLyoqIFN0b3BzIHRoZSB1cGRhdGUgbG9vcCB3aGVuIGEgcGF1c2UgZXZlbnQgaXMgdHJpZ2dlcmVkLiAqL1xuICBfb25QbGF5U3RvcCgpIHtcbiAgICB0aGlzLl9jb25maWd1cmVBdXRvVXBkYXRlKCk7XG4gIH1cbiAgLyoqIEhhbmRsZXMgYmVoYXZpb3Igd2hlbiB0aGUgdmlkZW8gY29tcGxldGVzIHNlZWtpbmcgdG8gdGhlIGN1cnJlbnQgcGxheWJhY2sgcG9zaXRpb24uICovXG4gIF9vblNlZWtlZCgpIHtcbiAgICBpZiAodGhpcy5fYXV0b1VwZGF0ZSAmJiAhdGhpcy5faXNTb3VyY2VQbGF5aW5nKCkpIHtcbiAgICAgIHRoaXMuX21zVG9OZXh0VXBkYXRlID0gMDtcbiAgICAgIHRoaXMudXBkYXRlRnJhbWUoKTtcbiAgICAgIHRoaXMuX21zVG9OZXh0VXBkYXRlID0gMDtcbiAgICB9XG4gIH1cbiAgLyoqIFdoZW4gaW50cmluc2ljIHNpemUgYmVjb21lcyBrbm93biBhZnRlciBwbGF5IC8gY2FucGxheSAoY29tbW9uIHdpdGggTWVkaWFTdHJlYW0pLiAqL1xuICBfb25Mb2FkZWRNZXRhZGF0YSgpIHtcbiAgICBpZiAoIXRoaXMuaXNWYWxpZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLl9tZWRpYVJlYWR5KCk7XG4gIH1cbiAgX29uQ2FuUGxheSgpIHtcbiAgICBjb25zdCBzb3VyY2UgPSB0aGlzLnJlc291cmNlO1xuICAgIHNvdXJjZS5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2FucGxheVwiLCB0aGlzLl9vbkNhblBsYXkpO1xuICAgIHRoaXMuX21lZGlhUmVhZHkoKTtcbiAgfVxuICBfb25DYW5QbGF5VGhyb3VnaCgpIHtcbiAgICBjb25zdCBzb3VyY2UgPSB0aGlzLnJlc291cmNlO1xuICAgIHNvdXJjZS5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2FucGxheXRocm91Z2hcIiwgdGhpcy5fb25DYW5QbGF5VGhyb3VnaCk7XG4gICAgaWYgKHRoaXMuX3ByZWxvYWRUaW1lb3V0KSB7XG4gICAgICBjbGVhclRpbWVvdXQodGhpcy5fcHJlbG9hZFRpbWVvdXQpO1xuICAgICAgdGhpcy5fcHJlbG9hZFRpbWVvdXQgPSB2b2lkIDA7XG4gICAgfVxuICAgIHRoaXMuX21lZGlhUmVhZHkoKTtcbiAgfVxuICAvKiogRmlyZWQgd2hlbiB0aGUgdmlkZW8gaXMgbG9hZGVkIGFuZCByZWFkeSB0byBwbGF5LiAqL1xuICBfbWVkaWFSZWFkeSgpIHtcbiAgICBjb25zdCBzb3VyY2UgPSB0aGlzLnJlc291cmNlO1xuICAgIGlmICh0aGlzLmlzVmFsaWQpIHtcbiAgICAgIHRoaXMuaXNSZWFkeSA9IHRydWU7XG4gICAgICB0aGlzLnJlc2l6ZShzb3VyY2UudmlkZW9XaWR0aCwgc291cmNlLnZpZGVvSGVpZ2h0KTtcbiAgICB9XG4gICAgdGhpcy5fbXNUb05leHRVcGRhdGUgPSAwO1xuICAgIHRoaXMudXBkYXRlRnJhbWUoKTtcbiAgICB0aGlzLl9tc1RvTmV4dFVwZGF0ZSA9IDA7XG4gICAgaWYgKHRoaXMuX3Jlc29sdmUgJiYgdGhpcy5pc1ZhbGlkKSB7XG4gICAgICB0aGlzLl9yZXNvbHZlKHRoaXMpO1xuICAgICAgdGhpcy5fcmVzb2x2ZSA9IG51bGw7XG4gICAgICB0aGlzLl9yZWplY3QgPSBudWxsO1xuICAgIH1cbiAgICBpZiAodGhpcy5faXNTb3VyY2VQbGF5aW5nKCkpIHtcbiAgICAgIHRoaXMuX29uUGxheVN0YXJ0KCk7XG4gICAgfSBlbHNlIGlmICh0aGlzLmF1dG9QbGF5KSB7XG4gICAgICB2b2lkIHRoaXMucmVzb3VyY2UucGxheSgpO1xuICAgIH1cbiAgfVxuICAvKiogQ2xlYW5zIHVwIHJlc291cmNlcyBhbmQgZXZlbnQgbGlzdGVuZXJzIGFzc29jaWF0ZWQgd2l0aCB0aGlzIHRleHR1cmUuICovXG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5fY29uZmlndXJlQXV0b1VwZGF0ZSgpO1xuICAgIGNvbnN0IHNvdXJjZSA9IHRoaXMucmVzb3VyY2U7XG4gICAgaWYgKHNvdXJjZSkge1xuICAgICAgc291cmNlLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwbGF5XCIsIHRoaXMuX29uUGxheVN0YXJ0KTtcbiAgICAgIHNvdXJjZS5yZW1vdmVFdmVudExpc3RlbmVyKFwicGF1c2VcIiwgdGhpcy5fb25QbGF5U3RvcCk7XG4gICAgICBzb3VyY2UucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNlZWtlZFwiLCB0aGlzLl9vblNlZWtlZCk7XG4gICAgICBzb3VyY2UucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNhbnBsYXlcIiwgdGhpcy5fb25DYW5QbGF5KTtcbiAgICAgIHNvdXJjZS5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2FucGxheXRocm91Z2hcIiwgdGhpcy5fb25DYW5QbGF5VGhyb3VnaCk7XG4gICAgICBzb3VyY2UucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImxvYWRlZG1ldGFkYXRhXCIsIHRoaXMuX29uTG9hZGVkTWV0YWRhdGEpO1xuICAgICAgc291cmNlLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJlcnJvclwiLCB0aGlzLl9vbkVycm9yLCB0cnVlKTtcbiAgICAgIHNvdXJjZS5wYXVzZSgpO1xuICAgICAgc291cmNlLnNyYyA9IFwiXCI7XG4gICAgICBzb3VyY2UubG9hZCgpO1xuICAgIH1cbiAgICBzdXBlci5kZXN0cm95KCk7XG4gIH1cbiAgLyoqIFNob3VsZCB0aGUgYmFzZSB0ZXh0dXJlIGF1dG9tYXRpY2FsbHkgdXBkYXRlIGl0c2VsZiwgc2V0IHRvIHRydWUgYnkgZGVmYXVsdC4gKi9cbiAgZ2V0IGF1dG9VcGRhdGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2F1dG9VcGRhdGU7XG4gIH1cbiAgc2V0IGF1dG9VcGRhdGUodmFsdWUpIHtcbiAgICBpZiAodmFsdWUgIT09IHRoaXMuX2F1dG9VcGRhdGUpIHtcbiAgICAgIHRoaXMuX2F1dG9VcGRhdGUgPSB2YWx1ZTtcbiAgICAgIHRoaXMuX2NvbmZpZ3VyZUF1dG9VcGRhdGUoKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIEhvdyBtYW55IHRpbWVzIGEgc2Vjb25kIHRvIHVwZGF0ZSB0aGUgdGV4dHVyZSBmcm9tIHRoZSB2aWRlby5cbiAgICogTGVhdmUgYXQgMCB0byB1cGRhdGUgYXQgZXZlcnkgcmVuZGVyLlxuICAgKiBBIGxvd2VyIGZwcyBjYW4gaGVscCBwZXJmb3JtYW5jZSwgYXMgdXBkYXRpbmcgdGhlIHRleHR1cmUgYXQgNjBmcHMgb24gYSAzMHBzIHZpZGVvIG1heSBub3QgYmUgZWZmaWNpZW50LlxuICAgKi9cbiAgZ2V0IHVwZGF0ZUZQUygpIHtcbiAgICByZXR1cm4gdGhpcy5fdXBkYXRlRlBTO1xuICB9XG4gIHNldCB1cGRhdGVGUFModmFsdWUpIHtcbiAgICBpZiAodmFsdWUgIT09IHRoaXMuX3VwZGF0ZUZQUykge1xuICAgICAgdGhpcy5fdXBkYXRlRlBTID0gdmFsdWU7XG4gICAgICB0aGlzLl9jb25maWd1cmVBdXRvVXBkYXRlKCk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBDb25maWd1cmVzIHRoZSB1cGRhdGluZyBtZWNoYW5pc20gYmFzZWQgb24gdGhlIGN1cnJlbnQgc3RhdGUgYW5kIHNldHRpbmdzLlxuICAgKlxuICAgKiBUaGlzIG1ldGhvZCBkZWNpZGVzIGJldHdlZW4gdXNpbmcgdGhlIGJyb3dzZXIncyBuYXRpdmUgdmlkZW8gZnJhbWUgY2FsbGJhY2sgb3IgYSBjdXN0b20gdGlja2VyXG4gICAqIGZvciB1cGRhdGluZyB0aGUgdmlkZW8gZnJhbWUuIEl0IGVuc3VyZXMgb3B0aW1hbCBwZXJmb3JtYW5jZSBhbmQgcmVzcG9uc2l2ZW5lc3NcbiAgICogYmFzZWQgb24gdGhlIHZpZGVvJ3Mgc3RhdGUsIHBsYXliYWNrIHN0YXR1cywgYW5kIHRoZSBkZXNpcmVkIGZyYW1lcy1wZXItc2Vjb25kIHNldHRpbmcuXG4gICAqXG4gICAqIC0gSWYgYF9hdXRvVXBkYXRlYCBpcyBlbmFibGVkIGFuZCB0aGUgdmlkZW8gc291cmNlIGlzIHBsYXlpbmc6XG4gICAqICAgLSBJdCB3aWxsIHByZWZlciB0aGUgbmF0aXZlIHZpZGVvIGZyYW1lIGNhbGxiYWNrIGlmIGF2YWlsYWJsZSBhbmQgbm8gc3BlY2lmaWMgRlBTIGlzIHNldC5cbiAgICogICAtIE90aGVyd2lzZSwgaXQgd2lsbCB1c2UgYSBjdXN0b20gdGlja2VyIGZvciBtYW51YWwgdXBkYXRlcy5cbiAgICogLSBJZiBgX2F1dG9VcGRhdGVgIGlzIGRpc2FibGVkIG9yIHRoZSB2aWRlbyBpc24ndCBwbGF5aW5nLCBhbnkgYWN0aXZlIHVwZGF0ZSBtZWNoYW5pc21zIGFyZSBoYWx0ZWQuXG4gICAqL1xuICBfY29uZmlndXJlQXV0b1VwZGF0ZSgpIHtcbiAgICBpZiAodGhpcy5fYXV0b1VwZGF0ZSAmJiB0aGlzLl9pc1NvdXJjZVBsYXlpbmcoKSkge1xuICAgICAgaWYgKCF0aGlzLl91cGRhdGVGUFMgJiYgdGhpcy5yZXNvdXJjZS5yZXF1ZXN0VmlkZW9GcmFtZUNhbGxiYWNrKSB7XG4gICAgICAgIGlmICh0aGlzLl9pc0Nvbm5lY3RlZFRvVGlja2VyKSB7XG4gICAgICAgICAgVGlja2VyLnNoYXJlZC5yZW1vdmUodGhpcy51cGRhdGVGcmFtZSwgdGhpcyk7XG4gICAgICAgICAgdGhpcy5faXNDb25uZWN0ZWRUb1RpY2tlciA9IGZhbHNlO1xuICAgICAgICAgIHRoaXMuX21zVG9OZXh0VXBkYXRlID0gMDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodGhpcy5fdmlkZW9GcmFtZVJlcXVlc3RDYWxsYmFja0hhbmRsZSA9PT0gbnVsbCkge1xuICAgICAgICAgIHRoaXMuX3ZpZGVvRnJhbWVSZXF1ZXN0Q2FsbGJhY2tIYW5kbGUgPSB0aGlzLnJlc291cmNlLnJlcXVlc3RWaWRlb0ZyYW1lQ2FsbGJhY2soXG4gICAgICAgICAgICB0aGlzLl92aWRlb0ZyYW1lUmVxdWVzdENhbGxiYWNrXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHRoaXMuX3ZpZGVvRnJhbWVSZXF1ZXN0Q2FsbGJhY2tIYW5kbGUgIT09IG51bGwpIHtcbiAgICAgICAgICB0aGlzLnJlc291cmNlLmNhbmNlbFZpZGVvRnJhbWVDYWxsYmFjayh0aGlzLl92aWRlb0ZyYW1lUmVxdWVzdENhbGxiYWNrSGFuZGxlKTtcbiAgICAgICAgICB0aGlzLl92aWRlb0ZyYW1lUmVxdWVzdENhbGxiYWNrSGFuZGxlID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMuX2lzQ29ubmVjdGVkVG9UaWNrZXIpIHtcbiAgICAgICAgICBUaWNrZXIuc2hhcmVkLmFkZCh0aGlzLnVwZGF0ZUZyYW1lLCB0aGlzKTtcbiAgICAgICAgICB0aGlzLl9pc0Nvbm5lY3RlZFRvVGlja2VyID0gdHJ1ZTtcbiAgICAgICAgICB0aGlzLl9tc1RvTmV4dFVwZGF0ZSA9IDA7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKHRoaXMuX3ZpZGVvRnJhbWVSZXF1ZXN0Q2FsbGJhY2tIYW5kbGUgIT09IG51bGwpIHtcbiAgICAgICAgdGhpcy5yZXNvdXJjZS5jYW5jZWxWaWRlb0ZyYW1lQ2FsbGJhY2sodGhpcy5fdmlkZW9GcmFtZVJlcXVlc3RDYWxsYmFja0hhbmRsZSk7XG4gICAgICAgIHRoaXMuX3ZpZGVvRnJhbWVSZXF1ZXN0Q2FsbGJhY2tIYW5kbGUgPSBudWxsO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMuX2lzQ29ubmVjdGVkVG9UaWNrZXIpIHtcbiAgICAgICAgVGlja2VyLnNoYXJlZC5yZW1vdmUodGhpcy51cGRhdGVGcmFtZSwgdGhpcyk7XG4gICAgICAgIHRoaXMuX2lzQ29ubmVjdGVkVG9UaWNrZXIgPSBmYWxzZTtcbiAgICAgICAgdGhpcy5fbXNUb05leHRVcGRhdGUgPSAwO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBzdGF0aWMgdGVzdChyZXNvdXJjZSkge1xuICAgIHJldHVybiBnbG9iYWxUaGlzLkhUTUxWaWRlb0VsZW1lbnQgJiYgcmVzb3VyY2UgaW5zdGFuY2VvZiBIVE1MVmlkZW9FbGVtZW50O1xuICB9XG59O1xuX1ZpZGVvU291cmNlLmV4dGVuc2lvbiA9IEV4dGVuc2lvblR5cGUuVGV4dHVyZVNvdXJjZTtcbi8qKiBUaGUgZGVmYXVsdCBvcHRpb25zIGZvciB2aWRlbyBzb3VyY2VzLiAqL1xuX1ZpZGVvU291cmNlLmRlZmF1bHRPcHRpb25zID0ge1xuICAuLi5UZXh0dXJlU291cmNlLmRlZmF1bHRPcHRpb25zLFxuICAvKiogSWYgdHJ1ZSwgdGhlIHZpZGVvIHdpbGwgc3RhcnQgbG9hZGluZyBpbW1lZGlhdGVseS4gKi9cbiAgYXV0b0xvYWQ6IHRydWUsXG4gIC8qKiBJZiB0cnVlLCB0aGUgdmlkZW8gd2lsbCBzdGFydCBwbGF5aW5nIGFzIHNvb24gYXMgaXQgaXMgbG9hZGVkLiAqL1xuICBhdXRvUGxheTogdHJ1ZSxcbiAgLyoqIFRoZSBudW1iZXIgb2YgdGltZXMgYSBzZWNvbmQgdG8gdXBkYXRlIHRoZSB0ZXh0dXJlIGZyb20gdGhlIHZpZGVvLiBMZWF2ZSBhdCAwIHRvIHVwZGF0ZSBhdCBldmVyeSByZW5kZXIuICovXG4gIHVwZGF0ZUZQUzogMCxcbiAgLyoqIElmIHRydWUsIHRoZSB2aWRlbyB3aWxsIGJlIGxvYWRlZCB3aXRoIHRoZSBgY3Jvc3NvcmlnaW5gIGF0dHJpYnV0ZS4gKi9cbiAgY3Jvc3NvcmlnaW46IHRydWUsXG4gIC8qKiBJZiB0cnVlLCB0aGUgdmlkZW8gd2lsbCBsb29wIHdoZW4gaXQgZW5kcy4gKi9cbiAgbG9vcDogZmFsc2UsXG4gIC8qKiBJZiB0cnVlLCB0aGUgdmlkZW8gd2lsbCBiZSBtdXRlZC4gKi9cbiAgbXV0ZWQ6IHRydWUsXG4gIC8qKiBJZiB0cnVlLCB0aGUgdmlkZW8gd2lsbCBwbGF5IGlubGluZS4gKi9cbiAgcGxheXNpbmxpbmU6IHRydWUsXG4gIC8qKiBJZiB0cnVlLCB0aGUgdmlkZW8gd2lsbCBiZSBwcmVsb2FkZWQuICovXG4gIHByZWxvYWQ6IGZhbHNlXG59O1xuLyoqXG4gKiBNYXAgb2YgdmlkZW8gTUlNRSB0eXBlcyB0aGF0IGNhbid0IGJlIGRpcmVjdGx5IGRlcml2ZWQgZnJvbSBmaWxlIGV4dGVuc2lvbnMuXG4gKiBAcmVhZG9ubHlcbiAqL1xuX1ZpZGVvU291cmNlLk1JTUVfVFlQRVMgPSB7XG4gIG9ndjogXCJ2aWRlby9vZ2dcIixcbiAgbW92OiBcInZpZGVvL3F1aWNrdGltZVwiLFxuICBtNHY6IFwidmlkZW8vbXA0XCJcbn07XG5sZXQgVmlkZW9Tb3VyY2UgPSBfVmlkZW9Tb3VyY2U7XG5cbmV4cG9ydCB7IFZpZGVvU291cmNlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1WaWRlb1NvdXJjZS5tanMubWFwXG4iLCJpbXBvcnQgeyBDYWNoZSB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2Fzc2V0cy9jYWNoZS9DYWNoZS5tanMnO1xuaW1wb3J0IHsgZXh0ZW5zaW9ucywgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVNvdXJjZSB9IGZyb20gJy4uL3NvdXJjZXMvVGV4dHVyZVNvdXJjZS5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4uL1RleHR1cmUubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBzb3VyY2VzID0gW107XG5leHRlbnNpb25zLmhhbmRsZUJ5TGlzdChFeHRlbnNpb25UeXBlLlRleHR1cmVTb3VyY2UsIHNvdXJjZXMpO1xuZnVuY3Rpb24gYXV0b0RldGVjdFNvdXJjZShvcHRpb25zID0ge30pIHtcbiAgcmV0dXJuIHRleHR1cmVTb3VyY2VGcm9tKG9wdGlvbnMpO1xufVxuZnVuY3Rpb24gdGV4dHVyZVNvdXJjZUZyb20ob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IGhhc1Jlc291cmNlID0gb3B0aW9ucyAmJiBvcHRpb25zLnJlc291cmNlO1xuICBjb25zdCByZXMgPSBoYXNSZXNvdXJjZSA/IG9wdGlvbnMucmVzb3VyY2UgOiBvcHRpb25zO1xuICBjb25zdCBvcHRzID0gaGFzUmVzb3VyY2UgPyBvcHRpb25zIDogeyByZXNvdXJjZTogb3B0aW9ucyB9O1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHNvdXJjZXMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBTb3VyY2UgPSBzb3VyY2VzW2ldO1xuICAgIGlmIChTb3VyY2UudGVzdChyZXMpKSB7XG4gICAgICByZXR1cm4gbmV3IFNvdXJjZShvcHRzKTtcbiAgICB9XG4gIH1cbiAgdGhyb3cgbmV3IEVycm9yKGBDb3VsZCBub3QgZmluZCBhIHNvdXJjZSB0eXBlIGZvciByZXNvdXJjZTogJHtvcHRzLnJlc291cmNlfWApO1xufVxuZnVuY3Rpb24gcmVzb3VyY2VUb1RleHR1cmUob3B0aW9ucyA9IHt9LCBza2lwQ2FjaGUgPSBmYWxzZSkge1xuICBjb25zdCBoYXNSZXNvdXJjZSA9IG9wdGlvbnMgJiYgb3B0aW9ucy5yZXNvdXJjZTtcbiAgY29uc3QgcmVzb3VyY2UgPSBoYXNSZXNvdXJjZSA/IG9wdGlvbnMucmVzb3VyY2UgOiBvcHRpb25zO1xuICBjb25zdCBvcHRzID0gaGFzUmVzb3VyY2UgPyBvcHRpb25zIDogeyByZXNvdXJjZTogb3B0aW9ucyB9O1xuICBpZiAoIXNraXBDYWNoZSAmJiBDYWNoZS5oYXMocmVzb3VyY2UpKSB7XG4gICAgcmV0dXJuIENhY2hlLmdldChyZXNvdXJjZSk7XG4gIH1cbiAgY29uc3QgdGV4dHVyZSA9IG5ldyBUZXh0dXJlKHsgc291cmNlOiB0ZXh0dXJlU291cmNlRnJvbShvcHRzKSB9KTtcbiAgdGV4dHVyZS5vbihcImRlc3Ryb3lcIiwgKCkgPT4ge1xuICAgIGlmIChDYWNoZS5oYXMocmVzb3VyY2UpKSB7XG4gICAgICBDYWNoZS5yZW1vdmUocmVzb3VyY2UpO1xuICAgIH1cbiAgfSk7XG4gIGlmICghc2tpcENhY2hlKSB7XG4gICAgQ2FjaGUuc2V0KHJlc291cmNlLCB0ZXh0dXJlKTtcbiAgfVxuICByZXR1cm4gdGV4dHVyZTtcbn1cbmZ1bmN0aW9uIHRleHR1cmVGcm9tKGlkLCBza2lwQ2FjaGUgPSBmYWxzZSkge1xuICBpZiAodHlwZW9mIGlkID09PSBcInN0cmluZ1wiKSB7XG4gICAgcmV0dXJuIENhY2hlLmdldChpZCk7XG4gIH0gZWxzZSBpZiAoaWQgaW5zdGFuY2VvZiBUZXh0dXJlU291cmNlKSB7XG4gICAgcmV0dXJuIG5ldyBUZXh0dXJlKHsgc291cmNlOiBpZCB9KTtcbiAgfVxuICByZXR1cm4gcmVzb3VyY2VUb1RleHR1cmUoaWQsIHNraXBDYWNoZSk7XG59XG5UZXh0dXJlLmZyb20gPSB0ZXh0dXJlRnJvbTtcblRleHR1cmVTb3VyY2UuZnJvbSA9IHRleHR1cmVTb3VyY2VGcm9tO1xuXG5leHBvcnQgeyBhdXRvRGV0ZWN0U291cmNlLCByZXNvdXJjZVRvVGV4dHVyZSwgdGV4dHVyZUZyb20gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXRleHR1cmVGcm9tLm1qcy5tYXBcbiIsImltcG9ydCB7IGV4dGVuc2lvbnMgfSBmcm9tICcuLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IEFscGhhTWFzayB9IGZyb20gJy4vbWFzay9hbHBoYS9BbHBoYU1hc2subWpzJztcbmltcG9ydCB7IENvbG9yTWFzayB9IGZyb20gJy4vbWFzay9jb2xvci9Db2xvck1hc2subWpzJztcbmltcG9ydCB7IFN0ZW5jaWxNYXNrIH0gZnJvbSAnLi9tYXNrL3N0ZW5jaWwvU3RlbmNpbE1hc2subWpzJztcbmltcG9ydCB7IEJ1ZmZlckltYWdlU291cmNlIH0gZnJvbSAnLi9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvc291cmNlcy9CdWZmZXJJbWFnZVNvdXJjZS5tanMnO1xuaW1wb3J0IHsgQ2FudmFzU291cmNlIH0gZnJvbSAnLi9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvc291cmNlcy9DYW52YXNTb3VyY2UubWpzJztcbmltcG9ydCB7IEltYWdlU291cmNlIH0gZnJvbSAnLi9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvc291cmNlcy9JbWFnZVNvdXJjZS5tanMnO1xuaW1wb3J0IHsgVmlkZW9Tb3VyY2UgfSBmcm9tICcuL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9zb3VyY2VzL1ZpZGVvU291cmNlLm1qcyc7XG5pbXBvcnQgJy4vcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL3V0aWxzL3RleHR1cmVGcm9tLm1qcyc7XG5pbXBvcnQgJy4vbWFzay9NYXNrRWZmZWN0TWFuYWdlci5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmV4dGVuc2lvbnMuYWRkKFxuICBBbHBoYU1hc2ssXG4gIENvbG9yTWFzayxcbiAgU3RlbmNpbE1hc2ssXG4gIFZpZGVvU291cmNlLFxuICBJbWFnZVNvdXJjZSxcbiAgQ2FudmFzU291cmNlLFxuICBCdWZmZXJJbWFnZVNvdXJjZVxuKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluaXQubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgTG9hZGVyUGFyc2VyUHJpb3JpdHkgPSAvKiBAX19QVVJFX18gKi8gKChMb2FkZXJQYXJzZXJQcmlvcml0eTIpID0+IHtcbiAgTG9hZGVyUGFyc2VyUHJpb3JpdHkyW0xvYWRlclBhcnNlclByaW9yaXR5MltcIkxvd1wiXSA9IDBdID0gXCJMb3dcIjtcbiAgTG9hZGVyUGFyc2VyUHJpb3JpdHkyW0xvYWRlclBhcnNlclByaW9yaXR5MltcIk5vcm1hbFwiXSA9IDFdID0gXCJOb3JtYWxcIjtcbiAgTG9hZGVyUGFyc2VyUHJpb3JpdHkyW0xvYWRlclBhcnNlclByaW9yaXR5MltcIkhpZ2hcIl0gPSAyXSA9IFwiSGlnaFwiO1xuICByZXR1cm4gTG9hZGVyUGFyc2VyUHJpb3JpdHkyO1xufSkoTG9hZGVyUGFyc2VyUHJpb3JpdHkgfHwge30pO1xuXG5leHBvcnQgeyBMb2FkZXJQYXJzZXJQcmlvcml0eSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9TG9hZGVyUGFyc2VyLm1qcy5tYXBcbiIsImltcG9ydCB7IERPTUFkYXB0ZXIgfSBmcm9tICcuLi9lbnZpcm9ubWVudC9hZGFwdGVyLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gYXNzZXJ0UGF0aChwYXRoMikge1xuICBpZiAodHlwZW9mIHBhdGgyICE9PSBcInN0cmluZ1wiKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgUGF0aCBtdXN0IGJlIGEgc3RyaW5nLiBSZWNlaXZlZCAke0pTT04uc3RyaW5naWZ5KHBhdGgyKX1gKTtcbiAgfVxufVxuZnVuY3Rpb24gcmVtb3ZlVXJsUGFyYW1zKHVybCkge1xuICBjb25zdCByZSA9IHVybC5zcGxpdChcIj9cIilbMF07XG4gIHJldHVybiByZS5zcGxpdChcIiNcIilbMF07XG59XG5mdW5jdGlvbiBlc2NhcGVSZWdFeHAoc3RyaW5nKSB7XG4gIHJldHVybiBzdHJpbmcucmVwbGFjZSgvWy4qKz9eJHt9KCl8W1xcXVxcXFxdL2csIFwiXFxcXCQmXCIpO1xufVxuZnVuY3Rpb24gcmVwbGFjZUFsbChzdHIsIGZpbmQsIHJlcGxhY2UpIHtcbiAgcmV0dXJuIHN0ci5yZXBsYWNlKG5ldyBSZWdFeHAoZXNjYXBlUmVnRXhwKGZpbmQpLCBcImdcIiksIHJlcGxhY2UpO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplU3RyaW5nUG9zaXgocGF0aDIsIGFsbG93QWJvdmVSb290KSB7XG4gIGxldCByZXMgPSBcIlwiO1xuICBsZXQgbGFzdFNlZ21lbnRMZW5ndGggPSAwO1xuICBsZXQgbGFzdFNsYXNoID0gLTE7XG4gIGxldCBkb3RzID0gMDtcbiAgbGV0IGNvZGUgPSAtMTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPD0gcGF0aDIubGVuZ3RoOyArK2kpIHtcbiAgICBpZiAoaSA8IHBhdGgyLmxlbmd0aCkge1xuICAgICAgY29kZSA9IHBhdGgyLmNoYXJDb2RlQXQoaSk7XG4gICAgfSBlbHNlIGlmIChjb2RlID09PSA0Nykge1xuICAgICAgYnJlYWs7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvZGUgPSA0NztcbiAgICB9XG4gICAgaWYgKGNvZGUgPT09IDQ3KSB7XG4gICAgICBpZiAobGFzdFNsYXNoID09PSBpIC0gMSB8fCBkb3RzID09PSAxKSB7XG4gICAgICB9IGVsc2UgaWYgKGxhc3RTbGFzaCAhPT0gaSAtIDEgJiYgZG90cyA9PT0gMikge1xuICAgICAgICBpZiAocmVzLmxlbmd0aCA8IDIgfHwgbGFzdFNlZ21lbnRMZW5ndGggIT09IDIgfHwgcmVzLmNoYXJDb2RlQXQocmVzLmxlbmd0aCAtIDEpICE9PSA0NiB8fCByZXMuY2hhckNvZGVBdChyZXMubGVuZ3RoIC0gMikgIT09IDQ2KSB7XG4gICAgICAgICAgaWYgKHJlcy5sZW5ndGggPiAyKSB7XG4gICAgICAgICAgICBjb25zdCBsYXN0U2xhc2hJbmRleCA9IHJlcy5sYXN0SW5kZXhPZihcIi9cIik7XG4gICAgICAgICAgICBpZiAobGFzdFNsYXNoSW5kZXggIT09IHJlcy5sZW5ndGggLSAxKSB7XG4gICAgICAgICAgICAgIGlmIChsYXN0U2xhc2hJbmRleCA9PT0gLTEpIHtcbiAgICAgICAgICAgICAgICByZXMgPSBcIlwiO1xuICAgICAgICAgICAgICAgIGxhc3RTZWdtZW50TGVuZ3RoID0gMDtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXMgPSByZXMuc2xpY2UoMCwgbGFzdFNsYXNoSW5kZXgpO1xuICAgICAgICAgICAgICAgIGxhc3RTZWdtZW50TGVuZ3RoID0gcmVzLmxlbmd0aCAtIDEgLSByZXMubGFzdEluZGV4T2YoXCIvXCIpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGxhc3RTbGFzaCA9IGk7XG4gICAgICAgICAgICAgIGRvdHMgPSAwO1xuICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2UgaWYgKHJlcy5sZW5ndGggPT09IDIgfHwgcmVzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgcmVzID0gXCJcIjtcbiAgICAgICAgICAgIGxhc3RTZWdtZW50TGVuZ3RoID0gMDtcbiAgICAgICAgICAgIGxhc3RTbGFzaCA9IGk7XG4gICAgICAgICAgICBkb3RzID0gMDtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoYWxsb3dBYm92ZVJvb3QpIHtcbiAgICAgICAgICBpZiAocmVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHJlcyArPSBcIi8uLlwiO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXMgPSBcIi4uXCI7XG4gICAgICAgICAgfVxuICAgICAgICAgIGxhc3RTZWdtZW50TGVuZ3RoID0gMjtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHJlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgcmVzICs9IGAvJHtwYXRoMi5zbGljZShsYXN0U2xhc2ggKyAxLCBpKX1gO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlcyA9IHBhdGgyLnNsaWNlKGxhc3RTbGFzaCArIDEsIGkpO1xuICAgICAgICB9XG4gICAgICAgIGxhc3RTZWdtZW50TGVuZ3RoID0gaSAtIGxhc3RTbGFzaCAtIDE7XG4gICAgICB9XG4gICAgICBsYXN0U2xhc2ggPSBpO1xuICAgICAgZG90cyA9IDA7XG4gICAgfSBlbHNlIGlmIChjb2RlID09PSA0NiAmJiBkb3RzICE9PSAtMSkge1xuICAgICAgKytkb3RzO1xuICAgIH0gZWxzZSB7XG4gICAgICBkb3RzID0gLTE7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXM7XG59XG5jb25zdCBwYXRoID0ge1xuICAvKipcbiAgICogQ29udmVydHMgYSBwYXRoIHRvIHBvc2l4IGZvcm1hdC5cbiAgICogQHBhcmFtIHBhdGggLSBUaGUgcGF0aCB0byBjb252ZXJ0IHRvIHBvc2l4XG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIENvbnZlcnQgYSBXaW5kb3dzIHBhdGggdG8gUE9TSVggZm9ybWF0XG4gICAqIHBhdGgudG9Qb3NpeCgnQzpcXFxcVXNlcnNcXFxcVXNlclxcXFxEb2N1bWVudHNcXFxcZmlsZS50eHQnKTtcbiAgICogLy8gLT4gJ0M6L1VzZXJzL1VzZXIvRG9jdW1lbnRzL2ZpbGUudHh0J1xuICAgKiBgYGBcbiAgICovXG4gIHRvUG9zaXgocGF0aDIpIHtcbiAgICByZXR1cm4gcmVwbGFjZUFsbChwYXRoMiwgXCJcXFxcXCIsIFwiL1wiKTtcbiAgfSxcbiAgLyoqXG4gICAqIENoZWNrcyBpZiB0aGUgcGF0aCBpcyBhIFVSTCBlLmcuIGh0dHA6Ly8sIGh0dHBzOi8vXG4gICAqIEBwYXJhbSBwYXRoIC0gVGhlIHBhdGggdG8gY2hlY2tcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQ2hlY2sgaWYgYSBwYXRoIGlzIGEgVVJMXG4gICAqIHBhdGguaXNVcmwoJ2h0dHA6Ly93d3cuZXhhbXBsZS5jb20nKTtcbiAgICogLy8gLT4gdHJ1ZVxuICAgKiBwYXRoLmlzVXJsKCdDOi9Vc2Vycy9Vc2VyL0RvY3VtZW50cy9maWxlLnR4dCcpO1xuICAgKiAvLyAtPiBmYWxzZVxuICAgKiBgYGBcbiAgICovXG4gIGlzVXJsKHBhdGgyKSB7XG4gICAgcmV0dXJuIC9eaHR0cHM/Oi8udGVzdCh0aGlzLnRvUG9zaXgocGF0aDIpKTtcbiAgfSxcbiAgLyoqXG4gICAqIENoZWNrcyBpZiB0aGUgcGF0aCBpcyBhIGRhdGEgVVJMXG4gICAqIEBwYXJhbSBwYXRoIC0gVGhlIHBhdGggdG8gY2hlY2tcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQ2hlY2sgaWYgYSBwYXRoIGlzIGEgZGF0YSBVUkxcbiAgICogcGF0aC5pc0RhdGFVcmwoJ2RhdGE6aW1hZ2UvcG5nO2Jhc2U2NCxpVkJPUncwS0dnb0FBQUFOU1VoRVVnQUFBQVVBLi4uJyk7XG4gICAqIC8vIC0+IHRydWVcbiAgICogYGBgXG4gICAqL1xuICBpc0RhdGFVcmwocGF0aDIpIHtcbiAgICByZXR1cm4gL15kYXRhOihbYS16XStcXC9bYS16MC05LSsuXSsoO1thLXowLTktLiEjJCUqKy57fXx+YF0rPVthLXowLTktLiEjJCUqKy57fSgpX3x+YF0rKSopPyg7YmFzZTY0KT8sKFthLXowLTkhJCYnLCgpKis7PVxcLS5ffjpAXFwvPyVcXHM8Pl0qPykkL2kudGVzdChwYXRoMik7XG4gIH0sXG4gIC8qKlxuICAgKiBDaGVja3MgaWYgdGhlIHBhdGggaXMgYSBibG9iIFVSTFxuICAgKiBAcGFyYW0gcGF0aCAtIFRoZSBwYXRoIHRvIGNoZWNrXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIENoZWNrIGlmIGEgcGF0aCBpcyBhIGJsb2IgVVJMXG4gICAqIHBhdGguaXNCbG9iVXJsKCdibG9iOmh0dHA6Ly93d3cuZXhhbXBsZS5jb20vMTIzNDU2NzgtMTIzNC0xMjM0LTEyMzQtMTIzNDU2Nzg5MDEyJyk7XG4gICAqIC8vIC0+IHRydWVcbiAgICogYGBgXG4gICAqL1xuICBpc0Jsb2JVcmwocGF0aDIpIHtcbiAgICByZXR1cm4gcGF0aDIuc3RhcnRzV2l0aChcImJsb2I6XCIpO1xuICB9LFxuICAvKipcbiAgICogQ2hlY2tzIGlmIHRoZSBwYXRoIGhhcyBhIHByb3RvY29sIGUuZy4gaHR0cDovLywgaHR0cHM6Ly8sIGZpbGU6Ly8vLCBkYXRhOiwgYmxvYjosIEM6L1xuICAgKiBUaGlzIHdpbGwgcmV0dXJuIHRydWUgZm9yIHdpbmRvd3MgZmlsZSBwYXRoc1xuICAgKiBAcGFyYW0gcGF0aCAtIFRoZSBwYXRoIHRvIGNoZWNrXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIENoZWNrIGlmIGEgcGF0aCBoYXMgYSBwcm90b2NvbFxuICAgKiBwYXRoLmhhc1Byb3RvY29sKCdodHRwOi8vd3d3LmV4YW1wbGUuY29tJyk7XG4gICAqIC8vIC0+IHRydWVcbiAgICogcGF0aC5oYXNQcm90b2NvbCgnQzovVXNlcnMvVXNlci9Eb2N1bWVudHMvZmlsZS50eHQnKTtcbiAgICogLy8gLT4gdHJ1ZVxuICAgKiBgYGBcbiAgICovXG4gIGhhc1Byb3RvY29sKHBhdGgyKSB7XG4gICAgcmV0dXJuIC9eW14vOl0rOi8udGVzdCh0aGlzLnRvUG9zaXgocGF0aDIpKTtcbiAgfSxcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHByb3RvY29sIG9mIHRoZSBwYXRoIGUuZy4gaHR0cDovLywgaHR0cHM6Ly8sIGZpbGU6Ly8vLCBkYXRhOiwgYmxvYjosIEM6L1xuICAgKiBAcGFyYW0gcGF0aCAtIFRoZSBwYXRoIHRvIGdldCB0aGUgcHJvdG9jb2wgZnJvbVxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBHZXQgdGhlIHByb3RvY29sIGZyb20gYSBVUkxcbiAgICogcGF0aC5nZXRQcm90b2NvbCgnaHR0cDovL3d3dy5leGFtcGxlLmNvbS9wYXRoL3RvL3Jlc291cmNlJyk7XG4gICAqIC8vIC0+ICdodHRwOi8vJ1xuICAgKiAvLyBHZXQgdGhlIHByb3RvY29sIGZyb20gYSBmaWxlIHBhdGhcbiAgICogcGF0aC5nZXRQcm90b2NvbCgnQzovVXNlcnMvVXNlci9Eb2N1bWVudHMvZmlsZS50eHQnKTtcbiAgICogLy8gLT4gJ0M6LydcbiAgICogYGBgXG4gICAqL1xuICBnZXRQcm90b2NvbChwYXRoMikge1xuICAgIGFzc2VydFBhdGgocGF0aDIpO1xuICAgIHBhdGgyID0gdGhpcy50b1Bvc2l4KHBhdGgyKTtcbiAgICBjb25zdCBtYXRjaEZpbGUgPSAvXmZpbGU6XFwvXFwvXFwvLy5leGVjKHBhdGgyKTtcbiAgICBpZiAobWF0Y2hGaWxlKSB7XG4gICAgICByZXR1cm4gbWF0Y2hGaWxlWzBdO1xuICAgIH1cbiAgICBjb25zdCBtYXRjaFByb3RvY29sID0gL15bXi86XSs6XFwvezAsMn0vLmV4ZWMocGF0aDIpO1xuICAgIGlmIChtYXRjaFByb3RvY29sKSB7XG4gICAgICByZXR1cm4gbWF0Y2hQcm90b2NvbFswXTtcbiAgICB9XG4gICAgcmV0dXJuIFwiXCI7XG4gIH0sXG4gIC8qKlxuICAgKiBDb252ZXJ0cyBVUkwgdG8gYW4gYWJzb2x1dGUgcGF0aC5cbiAgICogV2hlbiBsb2FkaW5nIGZyb20gYSBXZWIgV29ya2VyLCB3ZSBtdXN0IHVzZSBhYnNvbHV0ZSBwYXRocy5cbiAgICogSWYgdGhlIFVSTCBpcyBhbHJlYWR5IGFic29sdXRlIHdlIHJldHVybiBpdCBhcyBpc1xuICAgKiBJZiBpdCdzIG5vdCwgd2UgY29udmVydCBpdFxuICAgKiBAcGFyYW0gdXJsIC0gVGhlIFVSTCB0byB0ZXN0XG4gICAqIEBwYXJhbSBjdXN0b21CYXNlVXJsIC0gVGhlIGJhc2UgVVJMIHRvIHVzZVxuICAgKiBAcGFyYW0gY3VzdG9tUm9vdFVybCAtIFRoZSByb290IFVSTCB0byB1c2VcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQ29udmVydCBhIHJlbGF0aXZlIFVSTCB0byBhbiBhYnNvbHV0ZSBwYXRoXG4gICAqIHBhdGgudG9BYnNvbHV0ZSgnaW1hZ2VzL3RleHR1cmUucG5nJywgJ2h0dHA6Ly9leGFtcGxlLmNvbS9hc3NldHMvJyk7XG4gICAqIC8vIC0+ICdodHRwOi8vZXhhbXBsZS5jb20vYXNzZXRzL2ltYWdlcy90ZXh0dXJlLnBuZydcbiAgICogYGBgXG4gICAqL1xuICB0b0Fic29sdXRlKHVybCwgY3VzdG9tQmFzZVVybCwgY3VzdG9tUm9vdFVybCkge1xuICAgIGFzc2VydFBhdGgodXJsKTtcbiAgICBpZiAodGhpcy5pc0RhdGFVcmwodXJsKSB8fCB0aGlzLmlzQmxvYlVybCh1cmwpKSByZXR1cm4gdXJsO1xuICAgIGNvbnN0IGJhc2VVcmwgPSByZW1vdmVVcmxQYXJhbXModGhpcy50b1Bvc2l4KGN1c3RvbUJhc2VVcmwgPz8gRE9NQWRhcHRlci5nZXQoKS5nZXRCYXNlVXJsKCkpKTtcbiAgICBjb25zdCByb290VXJsID0gcmVtb3ZlVXJsUGFyYW1zKHRoaXMudG9Qb3NpeChjdXN0b21Sb290VXJsID8/IHRoaXMucm9vdG5hbWUoYmFzZVVybCkpKTtcbiAgICB1cmwgPSB0aGlzLnRvUG9zaXgodXJsKTtcbiAgICBpZiAodXJsLnN0YXJ0c1dpdGgoXCIvXCIpKSB7XG4gICAgICByZXR1cm4gcGF0aC5qb2luKHJvb3RVcmwsIHVybC5zbGljZSgxKSk7XG4gICAgfVxuICAgIGNvbnN0IGFic29sdXRlUGF0aCA9IHRoaXMuaXNBYnNvbHV0ZSh1cmwpID8gdXJsIDogdGhpcy5qb2luKGJhc2VVcmwsIHVybCk7XG4gICAgcmV0dXJuIGFic29sdXRlUGF0aDtcbiAgfSxcbiAgLyoqXG4gICAqIE5vcm1hbGl6ZXMgdGhlIGdpdmVuIHBhdGgsIHJlc29sdmluZyAnLi4nIGFuZCAnLicgc2VnbWVudHNcbiAgICogQHBhcmFtIHBhdGggLSBUaGUgcGF0aCB0byBub3JtYWxpemVcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gTm9ybWFsaXplIGEgcGF0aCB3aXRoIHJlbGF0aXZlIHNlZ21lbnRzXG4gICAqIHBhdGgubm9ybWFsaXplKCdodHRwOi8vd3d3LmV4YW1wbGUuY29tL2Zvby9iYXIvLi4vYmF6Jyk7XG4gICAqIC8vIC0+ICdodHRwOi8vd3d3LmV4YW1wbGUuY29tL2Zvby9iYXonXG4gICAqIC8vIE5vcm1hbGl6ZSBhIGZpbGUgcGF0aCB3aXRoIHJlbGF0aXZlIHNlZ21lbnRzXG4gICAqIHBhdGgubm9ybWFsaXplKCdDOlxcXFxVc2Vyc1xcXFxVc2VyXFxcXERvY3VtZW50c1xcXFwuLlxcXFxmaWxlLnR4dCcpO1xuICAgKiAvLyAtPiAnQzovVXNlcnMvVXNlci9maWxlLnR4dCdcbiAgICogYGBgXG4gICAqL1xuICBub3JtYWxpemUocGF0aDIpIHtcbiAgICBhc3NlcnRQYXRoKHBhdGgyKTtcbiAgICBpZiAocGF0aDIubGVuZ3RoID09PSAwKSByZXR1cm4gXCIuXCI7XG4gICAgaWYgKHRoaXMuaXNEYXRhVXJsKHBhdGgyKSB8fCB0aGlzLmlzQmxvYlVybChwYXRoMikpIHJldHVybiBwYXRoMjtcbiAgICBwYXRoMiA9IHRoaXMudG9Qb3NpeChwYXRoMik7XG4gICAgbGV0IHByb3RvY29sID0gXCJcIjtcbiAgICBjb25zdCBpc0Fic29sdXRlID0gcGF0aDIuc3RhcnRzV2l0aChcIi9cIik7XG4gICAgaWYgKHRoaXMuaGFzUHJvdG9jb2wocGF0aDIpKSB7XG4gICAgICBwcm90b2NvbCA9IHRoaXMucm9vdG5hbWUocGF0aDIpO1xuICAgICAgcGF0aDIgPSBwYXRoMi5zbGljZShwcm90b2NvbC5sZW5ndGgpO1xuICAgIH1cbiAgICBjb25zdCB0cmFpbGluZ1NlcGFyYXRvciA9IHBhdGgyLmVuZHNXaXRoKFwiL1wiKTtcbiAgICBwYXRoMiA9IG5vcm1hbGl6ZVN0cmluZ1Bvc2l4KHBhdGgyLCBmYWxzZSk7XG4gICAgaWYgKHBhdGgyLmxlbmd0aCA+IDAgJiYgdHJhaWxpbmdTZXBhcmF0b3IpIHBhdGgyICs9IFwiL1wiO1xuICAgIGlmIChpc0Fic29sdXRlKSByZXR1cm4gYC8ke3BhdGgyfWA7XG4gICAgcmV0dXJuIHByb3RvY29sICsgcGF0aDI7XG4gIH0sXG4gIC8qKlxuICAgKiBEZXRlcm1pbmVzIGlmIHBhdGggaXMgYW4gYWJzb2x1dGUgcGF0aC5cbiAgICogQWJzb2x1dGUgcGF0aHMgY2FuIGJlIHVybHMsIGRhdGEgdXJscywgb3IgcGF0aHMgb24gZGlza1xuICAgKiBAcGFyYW0gcGF0aCAtIFRoZSBwYXRoIHRvIHRlc3RcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQ2hlY2sgaWYgYSBwYXRoIGlzIGFic29sdXRlXG4gICAqIHBhdGguaXNBYnNvbHV0ZSgnaHR0cDovL3d3dy5leGFtcGxlLmNvbS9mb28vYmFyJyk7XG4gICAqIC8vIC0+IHRydWVcbiAgICogcGF0aC5pc0Fic29sdXRlKCdDOi9Vc2Vycy9Vc2VyL0RvY3VtZW50cy9maWxlLnR4dCcpO1xuICAgKiAvLyAtPiB0cnVlXG4gICAqIGBgYFxuICAgKi9cbiAgaXNBYnNvbHV0ZShwYXRoMikge1xuICAgIGFzc2VydFBhdGgocGF0aDIpO1xuICAgIHBhdGgyID0gdGhpcy50b1Bvc2l4KHBhdGgyKTtcbiAgICBpZiAodGhpcy5oYXNQcm90b2NvbChwYXRoMikpIHJldHVybiB0cnVlO1xuICAgIHJldHVybiBwYXRoMi5zdGFydHNXaXRoKFwiL1wiKTtcbiAgfSxcbiAgLyoqXG4gICAqIEpvaW5zIGFsbCBnaXZlbiBwYXRoIHNlZ21lbnRzIHRvZ2V0aGVyIHVzaW5nIHRoZSBwbGF0Zm9ybS1zcGVjaWZpYyBzZXBhcmF0b3IgYXMgYSBkZWxpbWl0ZXIsXG4gICAqIHRoZW4gbm9ybWFsaXplcyB0aGUgcmVzdWx0aW5nIHBhdGhcbiAgICogQHBhcmFtIHNlZ21lbnRzIC0gVGhlIHNlZ21lbnRzIG9mIHRoZSBwYXRoIHRvIGpvaW5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gSm9pbiBtdWx0aXBsZSBwYXRoIHNlZ21lbnRzXG4gICAqIHBhdGguam9pbignYXNzZXRzJywgJ2ltYWdlcycsICdzcHJpdGUucG5nJyk7XG4gICAqIC8vIC0+ICdhc3NldHMvaW1hZ2VzL3Nwcml0ZS5wbmcnXG4gICAqIC8vIEpvaW4gd2l0aCByZWxhdGl2ZSBzZWdtZW50c1xuICAgKiBwYXRoLmpvaW4oJ2Fzc2V0cycsICdpbWFnZXMnLCAnLi4vdGV4dHVyZXMnLCAnc3ByaXRlLnBuZycpO1xuICAgKiAvLyAtPiAnYXNzZXRzL3RleHR1cmVzL3Nwcml0ZS5wbmcnXG4gICAqIGBgYFxuICAgKi9cbiAgam9pbiguLi5zZWdtZW50cykge1xuICAgIGlmIChzZWdtZW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiBcIi5cIjtcbiAgICB9XG4gICAgbGV0IGpvaW5lZDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlZ21lbnRzLmxlbmd0aDsgKytpKSB7XG4gICAgICBjb25zdCBhcmcgPSBzZWdtZW50c1tpXTtcbiAgICAgIGFzc2VydFBhdGgoYXJnKTtcbiAgICAgIGlmIChhcmcubGVuZ3RoID4gMCkge1xuICAgICAgICBpZiAoam9pbmVkID09PSB2b2lkIDApIGpvaW5lZCA9IGFyZztcbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgY29uc3QgcHJldkFyZyA9IHNlZ21lbnRzW2kgLSAxXSA/PyBcIlwiO1xuICAgICAgICAgIGlmICh0aGlzLmpvaW5FeHRlbnNpb25zLmluY2x1ZGVzKHRoaXMuZXh0bmFtZShwcmV2QXJnKS50b0xvd2VyQ2FzZSgpKSkge1xuICAgICAgICAgICAgam9pbmVkICs9IGAvLi4vJHthcmd9YDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgam9pbmVkICs9IGAvJHthcmd9YDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGpvaW5lZCA9PT0gdm9pZCAwKSB7XG4gICAgICByZXR1cm4gXCIuXCI7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm5vcm1hbGl6ZShqb2luZWQpO1xuICB9LFxuICAvKipcbiAgICogUmV0dXJucyB0aGUgZGlyZWN0b3J5IG5hbWUgb2YgYSBwYXRoXG4gICAqIEBwYXJhbSBwYXRoIC0gVGhlIHBhdGggdG8gcGFyc2VcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gR2V0IHRoZSBkaXJlY3RvcnkgbmFtZSBvZiBhIHBhdGhcbiAgICogcGF0aC5kaXJuYW1lKCdodHRwOi8vd3d3LmV4YW1wbGUuY29tL2Zvby9iYXIvYmF6LnBuZycpO1xuICAgKiAvLyAtPiAnaHR0cDovL3d3dy5leGFtcGxlLmNvbS9mb28vYmFyJ1xuICAgKiAvLyBHZXQgdGhlIGRpcmVjdG9yeSBuYW1lIG9mIGEgZmlsZSBwYXRoXG4gICAqIHBhdGguZGlybmFtZSgnQzovVXNlcnMvVXNlci9Eb2N1bWVudHMvZmlsZS50eHQnKTtcbiAgICogLy8gLT4gJ0M6L1VzZXJzL1VzZXIvRG9jdW1lbnRzJ1xuICAgKiBgYGBcbiAgICovXG4gIGRpcm5hbWUocGF0aDIpIHtcbiAgICBhc3NlcnRQYXRoKHBhdGgyKTtcbiAgICBpZiAocGF0aDIubGVuZ3RoID09PSAwKSByZXR1cm4gXCIuXCI7XG4gICAgcGF0aDIgPSB0aGlzLnRvUG9zaXgocGF0aDIpO1xuICAgIGxldCBjb2RlID0gcGF0aDIuY2hhckNvZGVBdCgwKTtcbiAgICBjb25zdCBoYXNSb290ID0gY29kZSA9PT0gNDc7XG4gICAgbGV0IGVuZCA9IC0xO1xuICAgIGxldCBtYXRjaGVkU2xhc2ggPSB0cnVlO1xuICAgIGNvbnN0IHByb3RvID0gdGhpcy5nZXRQcm90b2NvbChwYXRoMik7XG4gICAgY29uc3Qgb3JpZ3BhdGggPSBwYXRoMjtcbiAgICBwYXRoMiA9IHBhdGgyLnNsaWNlKHByb3RvLmxlbmd0aCk7XG4gICAgZm9yIChsZXQgaSA9IHBhdGgyLmxlbmd0aCAtIDE7IGkgPj0gMTsgLS1pKSB7XG4gICAgICBjb2RlID0gcGF0aDIuY2hhckNvZGVBdChpKTtcbiAgICAgIGlmIChjb2RlID09PSA0Nykge1xuICAgICAgICBpZiAoIW1hdGNoZWRTbGFzaCkge1xuICAgICAgICAgIGVuZCA9IGk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG1hdGNoZWRTbGFzaCA9IGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoZW5kID09PSAtMSkgcmV0dXJuIGhhc1Jvb3QgPyBcIi9cIiA6IHRoaXMuaXNVcmwob3JpZ3BhdGgpID8gcHJvdG8gKyBwYXRoMiA6IHByb3RvO1xuICAgIGlmIChoYXNSb290ICYmIGVuZCA9PT0gMSkgcmV0dXJuIFwiLy9cIjtcbiAgICByZXR1cm4gcHJvdG8gKyBwYXRoMi5zbGljZSgwLCBlbmQpO1xuICB9LFxuICAvKipcbiAgICogUmV0dXJucyB0aGUgcm9vdCBvZiB0aGUgcGF0aCBlLmcuIC8sIEM6LywgZmlsZTovLy8sIGh0dHA6Ly9kb21haW4uY29tL1xuICAgKiBAcGFyYW0gcGF0aCAtIFRoZSBwYXRoIHRvIHBhcnNlXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEdldCB0aGUgcm9vdCBvZiBhIFVSTFxuICAgKiBwYXRoLnJvb3RuYW1lKCdodHRwOi8vd3d3LmV4YW1wbGUuY29tL2Zvby9iYXIvYmF6LnBuZycpO1xuICAgKiAvLyAtPiAnaHR0cDovL3d3dy5leGFtcGxlLmNvbS8nXG4gICAqIC8vIEdldCB0aGUgcm9vdCBvZiBhIGZpbGUgcGF0aFxuICAgKiBwYXRoLnJvb3RuYW1lKCdDOi9Vc2Vycy9Vc2VyL0RvY3VtZW50cy9maWxlLnR4dCcpO1xuICAgKiAvLyAtPiAnQzovJ1xuICAgKiBgYGBcbiAgICovXG4gIHJvb3RuYW1lKHBhdGgyKSB7XG4gICAgYXNzZXJ0UGF0aChwYXRoMik7XG4gICAgcGF0aDIgPSB0aGlzLnRvUG9zaXgocGF0aDIpO1xuICAgIGxldCByb290ID0gXCJcIjtcbiAgICBpZiAocGF0aDIuc3RhcnRzV2l0aChcIi9cIikpIHJvb3QgPSBcIi9cIjtcbiAgICBlbHNlIHtcbiAgICAgIHJvb3QgPSB0aGlzLmdldFByb3RvY29sKHBhdGgyKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuaXNVcmwocGF0aDIpKSB7XG4gICAgICBjb25zdCBpbmRleCA9IHBhdGgyLmluZGV4T2YoXCIvXCIsIHJvb3QubGVuZ3RoKTtcbiAgICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgICAgcm9vdCA9IHBhdGgyLnNsaWNlKDAsIGluZGV4KTtcbiAgICAgIH0gZWxzZSByb290ID0gcGF0aDI7XG4gICAgICBpZiAoIXJvb3QuZW5kc1dpdGgoXCIvXCIpKSByb290ICs9IFwiL1wiO1xuICAgIH1cbiAgICByZXR1cm4gcm9vdDtcbiAgfSxcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGxhc3QgcG9ydGlvbiBvZiBhIHBhdGhcbiAgICogQHBhcmFtIHBhdGggLSBUaGUgcGF0aCB0byB0ZXN0XG4gICAqIEBwYXJhbSBleHQgLSBPcHRpb25hbCBleHRlbnNpb24gdG8gcmVtb3ZlXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIC8vIEdldCB0aGUgYmFzZW5hbWUgb2YgYSBVUkxcbiAgICogcGF0aC5iYXNlbmFtZSgnaHR0cDovL3d3dy5leGFtcGxlLmNvbS9mb28vYmFyL2Jhei5wbmcnKTtcbiAgICogLy8gLT4gJ2Jhei5wbmcnXG4gICAqIC8vIEdldCB0aGUgYmFzZW5hbWUgb2YgYSBmaWxlIHBhdGhcbiAgICogcGF0aC5iYXNlbmFtZSgnQzovVXNlcnMvVXNlci9Eb2N1bWVudHMvZmlsZS50eHQnKTtcbiAgICogLy8gLT4gJ2ZpbGUudHh0J1xuICAgKiBgYGBcbiAgICovXG4gIGJhc2VuYW1lKHBhdGgyLCBleHQpIHtcbiAgICBhc3NlcnRQYXRoKHBhdGgyKTtcbiAgICBpZiAoZXh0KSBhc3NlcnRQYXRoKGV4dCk7XG4gICAgcGF0aDIgPSByZW1vdmVVcmxQYXJhbXModGhpcy50b1Bvc2l4KHBhdGgyKSk7XG4gICAgbGV0IHN0YXJ0ID0gMDtcbiAgICBsZXQgZW5kID0gLTE7XG4gICAgbGV0IG1hdGNoZWRTbGFzaCA9IHRydWU7XG4gICAgbGV0IGk7XG4gICAgaWYgKGV4dCAhPT0gdm9pZCAwICYmIGV4dC5sZW5ndGggPiAwICYmIGV4dC5sZW5ndGggPD0gcGF0aDIubGVuZ3RoKSB7XG4gICAgICBpZiAoZXh0Lmxlbmd0aCA9PT0gcGF0aDIubGVuZ3RoICYmIGV4dCA9PT0gcGF0aDIpIHJldHVybiBcIlwiO1xuICAgICAgbGV0IGV4dElkeCA9IGV4dC5sZW5ndGggLSAxO1xuICAgICAgbGV0IGZpcnN0Tm9uU2xhc2hFbmQgPSAtMTtcbiAgICAgIGZvciAoaSA9IHBhdGgyLmxlbmd0aCAtIDE7IGkgPj0gMDsgLS1pKSB7XG4gICAgICAgIGNvbnN0IGNvZGUgPSBwYXRoMi5jaGFyQ29kZUF0KGkpO1xuICAgICAgICBpZiAoY29kZSA9PT0gNDcpIHtcbiAgICAgICAgICBpZiAoIW1hdGNoZWRTbGFzaCkge1xuICAgICAgICAgICAgc3RhcnQgPSBpICsgMTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoZmlyc3ROb25TbGFzaEVuZCA9PT0gLTEpIHtcbiAgICAgICAgICAgIG1hdGNoZWRTbGFzaCA9IGZhbHNlO1xuICAgICAgICAgICAgZmlyc3ROb25TbGFzaEVuZCA9IGkgKyAxO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoZXh0SWR4ID49IDApIHtcbiAgICAgICAgICAgIGlmIChjb2RlID09PSBleHQuY2hhckNvZGVBdChleHRJZHgpKSB7XG4gICAgICAgICAgICAgIGlmICgtLWV4dElkeCA9PT0gLTEpIHtcbiAgICAgICAgICAgICAgICBlbmQgPSBpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBleHRJZHggPSAtMTtcbiAgICAgICAgICAgICAgZW5kID0gZmlyc3ROb25TbGFzaEVuZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChzdGFydCA9PT0gZW5kKSBlbmQgPSBmaXJzdE5vblNsYXNoRW5kO1xuICAgICAgZWxzZSBpZiAoZW5kID09PSAtMSkgZW5kID0gcGF0aDIubGVuZ3RoO1xuICAgICAgcmV0dXJuIHBhdGgyLnNsaWNlKHN0YXJ0LCBlbmQpO1xuICAgIH1cbiAgICBmb3IgKGkgPSBwYXRoMi5sZW5ndGggLSAxOyBpID49IDA7IC0taSkge1xuICAgICAgaWYgKHBhdGgyLmNoYXJDb2RlQXQoaSkgPT09IDQ3KSB7XG4gICAgICAgIGlmICghbWF0Y2hlZFNsYXNoKSB7XG4gICAgICAgICAgc3RhcnQgPSBpICsgMTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChlbmQgPT09IC0xKSB7XG4gICAgICAgIG1hdGNoZWRTbGFzaCA9IGZhbHNlO1xuICAgICAgICBlbmQgPSBpICsgMTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGVuZCA9PT0gLTEpIHJldHVybiBcIlwiO1xuICAgIHJldHVybiBwYXRoMi5zbGljZShzdGFydCwgZW5kKTtcbiAgfSxcbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIGV4dGVuc2lvbiBvZiB0aGUgcGF0aCwgZnJvbSB0aGUgbGFzdCBvY2N1cnJlbmNlIG9mIHRoZSAuIChwZXJpb2QpIGNoYXJhY3RlciB0byBlbmQgb2Ygc3RyaW5nIGluIHRoZSBsYXN0XG4gICAqIHBvcnRpb24gb2YgdGhlIHBhdGguIElmIHRoZXJlIGlzIG5vIC4gaW4gdGhlIGxhc3QgcG9ydGlvbiBvZiB0aGUgcGF0aCwgb3IgaWYgdGhlcmUgYXJlIG5vIC4gY2hhcmFjdGVycyBvdGhlciB0aGFuXG4gICAqIHRoZSBmaXJzdCBjaGFyYWN0ZXIgb2YgdGhlIGJhc2VuYW1lIG9mIHBhdGgsIGFuIGVtcHR5IHN0cmluZyBpcyByZXR1cm5lZC5cbiAgICogQHBhcmFtIHBhdGggLSBUaGUgcGF0aCB0byBwYXJzZVxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBHZXQgdGhlIGV4dGVuc2lvbiBvZiBhIFVSTFxuICAgKiBwYXRoLmV4dG5hbWUoJ2h0dHA6Ly93d3cuZXhhbXBsZS5jb20vZm9vL2Jhci9iYXoucG5nJyk7XG4gICAqIC8vIC0+ICcucG5nJ1xuICAgKiAvLyBHZXQgdGhlIGV4dGVuc2lvbiBvZiBhIGZpbGUgcGF0aFxuICAgKiBwYXRoLmV4dG5hbWUoJ0M6L1VzZXJzL1VzZXIvRG9jdW1lbnRzL2ZpbGUudHh0Jyk7XG4gICAqIC8vIC0+ICcudHh0J1xuICAgKiBgYGBcbiAgICovXG4gIGV4dG5hbWUocGF0aDIpIHtcbiAgICBhc3NlcnRQYXRoKHBhdGgyKTtcbiAgICBwYXRoMiA9IHJlbW92ZVVybFBhcmFtcyh0aGlzLnRvUG9zaXgocGF0aDIpKTtcbiAgICBsZXQgc3RhcnREb3QgPSAtMTtcbiAgICBsZXQgc3RhcnRQYXJ0ID0gMDtcbiAgICBsZXQgZW5kID0gLTE7XG4gICAgbGV0IG1hdGNoZWRTbGFzaCA9IHRydWU7XG4gICAgbGV0IHByZURvdFN0YXRlID0gMDtcbiAgICBmb3IgKGxldCBpID0gcGF0aDIubGVuZ3RoIC0gMTsgaSA+PSAwOyAtLWkpIHtcbiAgICAgIGNvbnN0IGNvZGUgPSBwYXRoMi5jaGFyQ29kZUF0KGkpO1xuICAgICAgaWYgKGNvZGUgPT09IDQ3KSB7XG4gICAgICAgIGlmICghbWF0Y2hlZFNsYXNoKSB7XG4gICAgICAgICAgc3RhcnRQYXJ0ID0gaSArIDE7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAoZW5kID09PSAtMSkge1xuICAgICAgICBtYXRjaGVkU2xhc2ggPSBmYWxzZTtcbiAgICAgICAgZW5kID0gaSArIDE7XG4gICAgICB9XG4gICAgICBpZiAoY29kZSA9PT0gNDYpIHtcbiAgICAgICAgaWYgKHN0YXJ0RG90ID09PSAtMSkgc3RhcnREb3QgPSBpO1xuICAgICAgICBlbHNlIGlmIChwcmVEb3RTdGF0ZSAhPT0gMSkgcHJlRG90U3RhdGUgPSAxO1xuICAgICAgfSBlbHNlIGlmIChzdGFydERvdCAhPT0gLTEpIHtcbiAgICAgICAgcHJlRG90U3RhdGUgPSAtMTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHN0YXJ0RG90ID09PSAtMSB8fCBlbmQgPT09IC0xIHx8IHByZURvdFN0YXRlID09PSAwIHx8IHByZURvdFN0YXRlID09PSAxICYmIHN0YXJ0RG90ID09PSBlbmQgLSAxICYmIHN0YXJ0RG90ID09PSBzdGFydFBhcnQgKyAxKSB7XG4gICAgICByZXR1cm4gXCJcIjtcbiAgICB9XG4gICAgcmV0dXJuIHBhdGgyLnNsaWNlKHN0YXJ0RG90LCBlbmQpO1xuICB9LFxuICAvKipcbiAgICogUGFyc2VzIGEgcGF0aCBpbnRvIGFuIG9iamVjdCBjb250YWluaW5nIHRoZSAncm9vdCcsIGBkaXJgLCBgYmFzZWAsIGBleHRgLCBhbmQgYG5hbWVgIHByb3BlcnRpZXMuXG4gICAqIEBwYXJhbSBwYXRoIC0gVGhlIHBhdGggdG8gcGFyc2VcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gUGFyc2UgYSBVUkxcbiAgICogY29uc3QgcGFyc2VkID0gcGF0aC5wYXJzZSgnaHR0cDovL3d3dy5leGFtcGxlLmNvbS9mb28vYmFyL2Jhei5wbmcnKTtcbiAgICogLy8gLT4ge1xuICAgKiAvLyAgIHJvb3Q6ICdodHRwOi8vd3d3LmV4YW1wbGUuY29tLycsXG4gICAqIC8vICAgZGlyOiAnaHR0cDovL3d3dy5leGFtcGxlLmNvbS9mb28vYmFyJyxcbiAgICogLy8gICBiYXNlOiAnYmF6LnBuZycsXG4gICAqIC8vICAgZXh0OiAnLnBuZycsXG4gICAqIC8vICAgbmFtZTogJ2JheidcbiAgICogLy8gfVxuICAgKiAvLyBQYXJzZSBhIGZpbGUgcGF0aFxuICAgKiBjb25zdCBwYXJzZWRGaWxlID0gcGF0aC5wYXJzZSgnQzovVXNlcnMvVXNlci9Eb2N1bWVudHMvZmlsZS50eHQnKTtcbiAgICogLy8gLT4ge1xuICAgKiAvLyAgIHJvb3Q6ICdDOi8nLFxuICAgKiAvLyAgIGRpcjogJ0M6L1VzZXJzL1VzZXIvRG9jdW1lbnRzJyxcbiAgICogLy8gICBiYXNlOiAnZmlsZS50eHQnLFxuICAgKiAvLyAgIGV4dDogJy50eHQnLFxuICAgKiAvLyAgIG5hbWU6ICdmaWxlJ1xuICAgKiAvLyB9XG4gICAqIGBgYFxuICAgKi9cbiAgcGFyc2UocGF0aDIpIHtcbiAgICBhc3NlcnRQYXRoKHBhdGgyKTtcbiAgICBjb25zdCByZXQgPSB7IHJvb3Q6IFwiXCIsIGRpcjogXCJcIiwgYmFzZTogXCJcIiwgZXh0OiBcIlwiLCBuYW1lOiBcIlwiIH07XG4gICAgaWYgKHBhdGgyLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHJldDtcbiAgICBwYXRoMiA9IHJlbW92ZVVybFBhcmFtcyh0aGlzLnRvUG9zaXgocGF0aDIpKTtcbiAgICBsZXQgY29kZSA9IHBhdGgyLmNoYXJDb2RlQXQoMCk7XG4gICAgY29uc3QgaXNBYnNvbHV0ZSA9IHRoaXMuaXNBYnNvbHV0ZShwYXRoMik7XG4gICAgbGV0IHN0YXJ0O1xuICAgIGNvbnN0IHByb3RvY29sID0gXCJcIjtcbiAgICByZXQucm9vdCA9IHRoaXMucm9vdG5hbWUocGF0aDIpO1xuICAgIGlmIChpc0Fic29sdXRlIHx8IHRoaXMuaGFzUHJvdG9jb2wocGF0aDIpKSB7XG4gICAgICBzdGFydCA9IDE7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN0YXJ0ID0gMDtcbiAgICB9XG4gICAgbGV0IHN0YXJ0RG90ID0gLTE7XG4gICAgbGV0IHN0YXJ0UGFydCA9IDA7XG4gICAgbGV0IGVuZCA9IC0xO1xuICAgIGxldCBtYXRjaGVkU2xhc2ggPSB0cnVlO1xuICAgIGxldCBpID0gcGF0aDIubGVuZ3RoIC0gMTtcbiAgICBsZXQgcHJlRG90U3RhdGUgPSAwO1xuICAgIGZvciAoOyBpID49IHN0YXJ0OyAtLWkpIHtcbiAgICAgIGNvZGUgPSBwYXRoMi5jaGFyQ29kZUF0KGkpO1xuICAgICAgaWYgKGNvZGUgPT09IDQ3KSB7XG4gICAgICAgIGlmICghbWF0Y2hlZFNsYXNoKSB7XG4gICAgICAgICAgc3RhcnRQYXJ0ID0gaSArIDE7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAoZW5kID09PSAtMSkge1xuICAgICAgICBtYXRjaGVkU2xhc2ggPSBmYWxzZTtcbiAgICAgICAgZW5kID0gaSArIDE7XG4gICAgICB9XG4gICAgICBpZiAoY29kZSA9PT0gNDYpIHtcbiAgICAgICAgaWYgKHN0YXJ0RG90ID09PSAtMSkgc3RhcnREb3QgPSBpO1xuICAgICAgICBlbHNlIGlmIChwcmVEb3RTdGF0ZSAhPT0gMSkgcHJlRG90U3RhdGUgPSAxO1xuICAgICAgfSBlbHNlIGlmIChzdGFydERvdCAhPT0gLTEpIHtcbiAgICAgICAgcHJlRG90U3RhdGUgPSAtMTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHN0YXJ0RG90ID09PSAtMSB8fCBlbmQgPT09IC0xIHx8IHByZURvdFN0YXRlID09PSAwIHx8IHByZURvdFN0YXRlID09PSAxICYmIHN0YXJ0RG90ID09PSBlbmQgLSAxICYmIHN0YXJ0RG90ID09PSBzdGFydFBhcnQgKyAxKSB7XG4gICAgICBpZiAoZW5kICE9PSAtMSkge1xuICAgICAgICBpZiAoc3RhcnRQYXJ0ID09PSAwICYmIGlzQWJzb2x1dGUpIHJldC5iYXNlID0gcmV0Lm5hbWUgPSBwYXRoMi5zbGljZSgxLCBlbmQpO1xuICAgICAgICBlbHNlIHJldC5iYXNlID0gcmV0Lm5hbWUgPSBwYXRoMi5zbGljZShzdGFydFBhcnQsIGVuZCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChzdGFydFBhcnQgPT09IDAgJiYgaXNBYnNvbHV0ZSkge1xuICAgICAgICByZXQubmFtZSA9IHBhdGgyLnNsaWNlKDEsIHN0YXJ0RG90KTtcbiAgICAgICAgcmV0LmJhc2UgPSBwYXRoMi5zbGljZSgxLCBlbmQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0Lm5hbWUgPSBwYXRoMi5zbGljZShzdGFydFBhcnQsIHN0YXJ0RG90KTtcbiAgICAgICAgcmV0LmJhc2UgPSBwYXRoMi5zbGljZShzdGFydFBhcnQsIGVuZCk7XG4gICAgICB9XG4gICAgICByZXQuZXh0ID0gcGF0aDIuc2xpY2Uoc3RhcnREb3QsIGVuZCk7XG4gICAgfVxuICAgIHJldC5kaXIgPSB0aGlzLmRpcm5hbWUocGF0aDIpO1xuICAgIGlmIChwcm90b2NvbCkgcmV0LmRpciA9IHByb3RvY29sICsgcmV0LmRpcjtcbiAgICByZXR1cm4gcmV0O1xuICB9LFxuICBzZXA6IFwiL1wiLFxuICBkZWxpbWl0ZXI6IFwiOlwiLFxuICBqb2luRXh0ZW5zaW9uczogW1wiLmh0bWxcIl1cbn07XG5cbmV4cG9ydCB7IHBhdGggfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhdGgubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5mdW5jdGlvbiBwcm9jZXNzWChiYXNlLCBpZHMsIGRlcHRoLCByZXN1bHQsIHRhZ3MpIHtcbiAgY29uc3QgaWQgPSBpZHNbZGVwdGhdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGlkLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgdmFsdWUgPSBpZFtpXTtcbiAgICBpZiAoZGVwdGggPCBpZHMubGVuZ3RoIC0gMSkge1xuICAgICAgcHJvY2Vzc1goYmFzZS5yZXBsYWNlKHJlc3VsdFtkZXB0aF0sIHZhbHVlKSwgaWRzLCBkZXB0aCArIDEsIHJlc3VsdCwgdGFncyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRhZ3MucHVzaChiYXNlLnJlcGxhY2UocmVzdWx0W2RlcHRoXSwgdmFsdWUpKTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGNyZWF0ZVN0cmluZ1ZhcmlhdGlvbnMoc3RyaW5nKSB7XG4gIGNvbnN0IHJlZ2V4ID0gL1xceyguKj8pXFx9L2c7XG4gIGNvbnN0IHJlc3VsdCA9IHN0cmluZy5tYXRjaChyZWdleCk7XG4gIGNvbnN0IHRhZ3MgPSBbXTtcbiAgaWYgKHJlc3VsdCkge1xuICAgIGNvbnN0IGlkcyA9IFtdO1xuICAgIHJlc3VsdC5mb3JFYWNoKCh2YXJzKSA9PiB7XG4gICAgICBjb25zdCBzcGxpdCA9IHZhcnMuc3Vic3RyaW5nKDEsIHZhcnMubGVuZ3RoIC0gMSkuc3BsaXQoXCIsXCIpO1xuICAgICAgaWRzLnB1c2goc3BsaXQpO1xuICAgIH0pO1xuICAgIHByb2Nlc3NYKHN0cmluZywgaWRzLCAwLCByZXN1bHQsIHRhZ3MpO1xuICB9IGVsc2Uge1xuICAgIHRhZ3MucHVzaChzdHJpbmcpO1xuICB9XG4gIHJldHVybiB0YWdzO1xufVxuXG5leHBvcnQgeyBjcmVhdGVTdHJpbmdWYXJpYXRpb25zIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jcmVhdGVTdHJpbmdWYXJpYXRpb25zLm1qcy5tYXBcbiIsIlwidXNlIHN0cmljdFwiO1xuY29uc3QgaXNTaW5nbGVJdGVtID0gKGl0ZW0pID0+ICFBcnJheS5pc0FycmF5KGl0ZW0pO1xuXG5leHBvcnQgeyBpc1NpbmdsZUl0ZW0gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWlzU2luZ2xlSXRlbS5tanMubWFwXG4iLCJpbXBvcnQgeyB3YXJuIH0gZnJvbSAnLi4vLi4vdXRpbHMvbG9nZ2luZy93YXJuLm1qcyc7XG5pbXBvcnQgeyBwYXRoIH0gZnJvbSAnLi4vLi4vdXRpbHMvcGF0aC5tanMnO1xuaW1wb3J0IHsgY29udmVydFRvTGlzdCB9IGZyb20gJy4uL3V0aWxzL2NvbnZlcnRUb0xpc3QubWpzJztcbmltcG9ydCB7IGNyZWF0ZVN0cmluZ1ZhcmlhdGlvbnMgfSBmcm9tICcuLi91dGlscy9jcmVhdGVTdHJpbmdWYXJpYXRpb25zLm1qcyc7XG5pbXBvcnQgeyBpc1NpbmdsZUl0ZW0gfSBmcm9tICcuLi91dGlscy9pc1NpbmdsZUl0ZW0ubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBSZXNvbHZlciB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuX2RlZmF1bHRCdW5kbGVJZGVudGlmaWVyT3B0aW9ucyA9IHtcbiAgICAgIGNvbm5lY3RvcjogXCItXCIsXG4gICAgICBjcmVhdGVCdW5kbGVBc3NldElkOiAoYnVuZGxlSWQsIGFzc2V0SWQpID0+IGAke2J1bmRsZUlkfSR7dGhpcy5fYnVuZGxlSWRDb25uZWN0b3J9JHthc3NldElkfWAsXG4gICAgICBleHRyYWN0QXNzZXRJZEZyb21CdW5kbGU6IChidW5kbGVJZCwgYXNzZXRCdW5kbGVJZCkgPT4gYXNzZXRCdW5kbGVJZC5yZXBsYWNlKGAke2J1bmRsZUlkfSR7dGhpcy5fYnVuZGxlSWRDb25uZWN0b3J9YCwgXCJcIilcbiAgICB9O1xuICAgIC8qKiBUaGUgY2hhcmFjdGVyIHRoYXQgaXMgdXNlZCB0byBjb25uZWN0IHRoZSBidW5kbGVJZCBhbmQgdGhlIGFzc2V0SWQgd2hlbiBnZW5lcmF0aW5nIGEgYnVuZGxlIGFzc2V0IGlkIGtleSAqL1xuICAgIHRoaXMuX2J1bmRsZUlkQ29ubmVjdG9yID0gdGhpcy5fZGVmYXVsdEJ1bmRsZUlkZW50aWZpZXJPcHRpb25zLmNvbm5lY3RvcjtcbiAgICAvKipcbiAgICAgKiBBIGZ1bmN0aW9uIHRoYXQgZ2VuZXJhdGVzIGEgYnVuZGxlIGFzc2V0IGlkIGtleSBmcm9tIGEgYnVuZGxlSWQgYW5kIGFuIGFzc2V0SWRcbiAgICAgKiBAcGFyYW0gYnVuZGxlSWQgLSB0aGUgYnVuZGxlSWRcbiAgICAgKiBAcGFyYW0gYXNzZXRJZCAgLSB0aGUgYXNzZXRJZFxuICAgICAqIEByZXR1cm5zIHRoZSBidW5kbGUgYXNzZXQgaWQga2V5XG4gICAgICovXG4gICAgdGhpcy5fY3JlYXRlQnVuZGxlQXNzZXRJZCA9IHRoaXMuX2RlZmF1bHRCdW5kbGVJZGVudGlmaWVyT3B0aW9ucy5jcmVhdGVCdW5kbGVBc3NldElkO1xuICAgIC8qKlxuICAgICAqIEEgZnVuY3Rpb24gdGhhdCBnZW5lcmF0ZXMgYW4gYXNzZXRJZCBmcm9tIGEgYnVuZGxlIGFzc2V0IGlkIGtleS4gVGhpcyBpcyB0aGUgcmV2ZXJzZSBvZiBnZW5lcmF0ZUJ1bmRsZUFzc2V0SWRcbiAgICAgKiBAcGFyYW0gYnVuZGxlSWQgLSB0aGUgYnVuZGxlSWRcbiAgICAgKiBAcGFyYW0gYXNzZXRCdW5kbGVJZCAtIHRoZSBidW5kbGUgYXNzZXQgaWQga2V5XG4gICAgICogQHJldHVybnMgdGhlIGFzc2V0SWRcbiAgICAgKi9cbiAgICB0aGlzLl9leHRyYWN0QXNzZXRJZEZyb21CdW5kbGUgPSB0aGlzLl9kZWZhdWx0QnVuZGxlSWRlbnRpZmllck9wdGlvbnMuZXh0cmFjdEFzc2V0SWRGcm9tQnVuZGxlO1xuICAgIHRoaXMuX2Fzc2V0TWFwID0ge307XG4gICAgdGhpcy5fcHJlZmVycmVkT3JkZXIgPSBbXTtcbiAgICB0aGlzLl9wYXJzZXJzID0gW107XG4gICAgdGhpcy5fcmVzb2x2ZXJIYXNoID0ge307XG4gICAgdGhpcy5fYnVuZGxlcyA9IHt9O1xuICB9XG4gIC8qKlxuICAgKiBPdmVycmlkZSBob3cgdGhlIHJlc29sdmVyIGRlYWxzIHdpdGggZ2VuZXJhdGluZyBidW5kbGUgaWRzLlxuICAgKiBtdXN0IGJlIGNhbGxlZCBiZWZvcmUgYW55IGJ1bmRsZXMgYXJlIGFkZGVkXG4gICAqIEBwYXJhbSBidW5kbGVJZGVudGlmaWVyIC0gdGhlIGJ1bmRsZSBpZGVudGlmaWVyIG9wdGlvbnNcbiAgICovXG4gIHNldEJ1bmRsZUlkZW50aWZpZXIoYnVuZGxlSWRlbnRpZmllcikge1xuICAgIHRoaXMuX2J1bmRsZUlkQ29ubmVjdG9yID0gYnVuZGxlSWRlbnRpZmllci5jb25uZWN0b3IgPz8gdGhpcy5fYnVuZGxlSWRDb25uZWN0b3I7XG4gICAgdGhpcy5fY3JlYXRlQnVuZGxlQXNzZXRJZCA9IGJ1bmRsZUlkZW50aWZpZXIuY3JlYXRlQnVuZGxlQXNzZXRJZCA/PyB0aGlzLl9jcmVhdGVCdW5kbGVBc3NldElkO1xuICAgIHRoaXMuX2V4dHJhY3RBc3NldElkRnJvbUJ1bmRsZSA9IGJ1bmRsZUlkZW50aWZpZXIuZXh0cmFjdEFzc2V0SWRGcm9tQnVuZGxlID8/IHRoaXMuX2V4dHJhY3RBc3NldElkRnJvbUJ1bmRsZTtcbiAgICBpZiAodGhpcy5fZXh0cmFjdEFzc2V0SWRGcm9tQnVuZGxlKFwiZm9vXCIsIHRoaXMuX2NyZWF0ZUJ1bmRsZUFzc2V0SWQoXCJmb29cIiwgXCJiYXJcIikpICE9PSBcImJhclwiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJbUmVzb2x2ZXJdIEdlbmVyYXRlQnVuZGxlQXNzZXRJZCBhcmUgbm90IHdvcmtpbmcgY29ycmVjdGx5XCIpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogTGV0IHRoZSByZXNvbHZlciBrbm93IHdoaWNoIGFzc2V0cyB5b3UgcHJlZmVyIHRvIHVzZSB3aGVuIHJlc29sdmluZyBhc3NldHMuXG4gICAqIE11bHRpcGxlIHByZWZlciB1c2VyIGRlZmluZWQgcnVsZXMgY2FuIGJlIGFkZGVkLlxuICAgKiBAZXhhbXBsZVxuICAgKiByZXNvbHZlci5wcmVmZXIoe1xuICAgKiAgICAgLy8gZmlyc3QgbG9vayBmb3Igc29tZXRoaW5nIHdpdGggdGhlIGNvcnJlY3QgZm9ybWF0LCBhbmQgdGhlbiB0aGVuIGNvcnJlY3QgcmVzb2x1dGlvblxuICAgKiAgICAgcHJpb3JpdHk6IFsnZm9ybWF0JywgJ3Jlc29sdXRpb24nXSxcbiAgICogICAgIHBhcmFtczp7XG4gICAqICAgICAgICAgZm9ybWF0Oid3ZWJwJywgLy8gcHJlZmVyIHdlYnAgaW1hZ2VzXG4gICAqICAgICAgICAgcmVzb2x1dGlvbjogMiwgLy8gcHJlZmVyIGEgcmVzb2x1dGlvbiBvZiAyXG4gICAqICAgICB9XG4gICAqIH0pXG4gICAqIHJlc29sdmVyLmFkZCgnZm9vJywgWydiYXJAMngud2VicCcsICdiYXJAMngucG5nJywgJ2Jhci53ZWJwJywgJ2Jhci5wbmcnXSk7XG4gICAqIHJlc29sdmVyLnJlc29sdmVVcmwoJ2ZvbycpIC8vID0+ICdiYXJAMngud2VicCdcbiAgICogQHBhcmFtIHByZWZlck9yZGVycyAtIHRoZSBwcmVmZXIgb3B0aW9uc1xuICAgKi9cbiAgcHJlZmVyKC4uLnByZWZlck9yZGVycykge1xuICAgIHByZWZlck9yZGVycy5mb3JFYWNoKChwcmVmZXIpID0+IHtcbiAgICAgIHRoaXMuX3ByZWZlcnJlZE9yZGVyLnB1c2gocHJlZmVyKTtcbiAgICAgIGlmICghcHJlZmVyLnByaW9yaXR5KSB7XG4gICAgICAgIHByZWZlci5wcmlvcml0eSA9IE9iamVjdC5rZXlzKHByZWZlci5wYXJhbXMpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHRoaXMuX3Jlc29sdmVySGFzaCA9IHt9O1xuICB9XG4gIC8qKlxuICAgKiBTZXQgdGhlIGJhc2UgcGF0aCB0byBwcmVwZW5kIHRvIGFsbCB1cmxzIHdoZW4gcmVzb2x2aW5nXG4gICAqIEBleGFtcGxlXG4gICAqIHJlc29sdmVyLmJhc2VQYXRoID0gJ2h0dHBzOi8vaG9tZS5jb20vJztcbiAgICogcmVzb2x2ZXIuYWRkKCdmb28nLCAnYmFyLm9uZycpO1xuICAgKiByZXNvbHZlci5yZXNvbHZlVXJsKCdmb28nLCAnYmFyLnBuZycpOyAvLyA9PiAnaHR0cHM6Ly9ob21lLmNvbS9iYXIucG5nJ1xuICAgKiBAcGFyYW0gYmFzZVBhdGggLSB0aGUgYmFzZSBwYXRoIHRvIHVzZVxuICAgKi9cbiAgc2V0IGJhc2VQYXRoKGJhc2VQYXRoKSB7XG4gICAgdGhpcy5fYmFzZVBhdGggPSBiYXNlUGF0aDtcbiAgfVxuICBnZXQgYmFzZVBhdGgoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2Jhc2VQYXRoO1xuICB9XG4gIC8qKlxuICAgKiBTZXQgdGhlIHJvb3QgcGF0aCBmb3Igcm9vdC1yZWxhdGl2ZSBVUkxzLiBCeSBkZWZhdWx0IHRoZSBgYmFzZVBhdGhgJ3Mgcm9vdCBpcyB1c2VkLiBJZiBubyBgYmFzZVBhdGhgIGlzIHNldCwgdGhlbiB0aGVcbiAgICogZGVmYXVsdCB2YWx1ZSBmb3IgYnJvd3NlcnMgaXMgYHdpbmRvdy5sb2NhdGlvbi5vcmlnaW5gXG4gICAqIEBleGFtcGxlXG4gICAqIC8vIEFwcGxpY2F0aW9uIGhvc3RlZCBvbiBodHRwczovL2hvbWUuY29tL3NvbWUtcGF0aC9pbmRleC5odG1sXG4gICAqIHJlc29sdmVyLmJhc2VQYXRoID0gJ2h0dHBzOi8vaG9tZS5jb20vc29tZS1wYXRoLyc7XG4gICAqIHJlc29sdmVyLnJvb3RQYXRoID0gJ2h0dHBzOi8vaG9tZS5jb20vJztcbiAgICogcmVzb2x2ZXIuYWRkKCdmb28nLCAnL2Jhci5wbmcnKTtcbiAgICogcmVzb2x2ZXIucmVzb2x2ZVVybCgnZm9vJywgJy9iYXIucG5nJyk7IC8vID0+ICdodHRwczovL2hvbWUuY29tL2Jhci5wbmcnXG4gICAqIEBwYXJhbSByb290UGF0aCAtIHRoZSByb290IHBhdGggdG8gdXNlXG4gICAqL1xuICBzZXQgcm9vdFBhdGgocm9vdFBhdGgpIHtcbiAgICB0aGlzLl9yb290UGF0aCA9IHJvb3RQYXRoO1xuICB9XG4gIGdldCByb290UGF0aCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcm9vdFBhdGg7XG4gIH1cbiAgLyoqXG4gICAqIEFsbCB0aGUgYWN0aXZlIFVSTCBwYXJzZXJzIHRoYXQgaGVscCB0aGUgcGFyc2VyIHRvIGV4dHJhY3QgaW5mb3JtYXRpb24gYW5kIGNyZWF0ZVxuICAgKiBhbiBhc3NldCBvYmplY3QtYmFzZWQgb24gcGFyc2luZyB0aGUgVVJMIGl0c2VsZi5cbiAgICpcbiAgICogQ2FuIGJlIGFkZGVkIHVzaW5nIHRoZSBleHRlbnNpb25zIEFQSVxuICAgKiBAZXhhbXBsZVxuICAgKiByZXNvbHZlci5hZGQoJ2ZvbycsIFtcbiAgICogICAgIHtcbiAgICogICAgICAgICByZXNvbHV0aW9uOiAyLFxuICAgKiAgICAgICAgIGZvcm1hdDogJ3BuZycsXG4gICAqICAgICAgICAgc3JjOiAnaW1hZ2VAMngucG5nJyxcbiAgICogICAgIH0sXG4gICAqICAgICB7XG4gICAqICAgICAgICAgcmVzb2x1dGlvbjoxLFxuICAgKiAgICAgICAgIGZvcm1hdDoncG5nJyxcbiAgICogICAgICAgICBzcmM6ICdpbWFnZS5wbmcnLFxuICAgKiAgICAgfSxcbiAgICogXSk7XG4gICAqXG4gICAqIC8vIFdpdGggYSB1cmwgcGFyc2VyIHRoZSBpbmZvcm1hdGlvbiBzdWNoIGFzIHJlc29sdXRpb24gYW5kIGZpbGUgZm9ybWF0IGNvdWxkIGV4dHJhY3RlZCBmcm9tIHRoZSB1cmwgaXRzZWxmOlxuICAgKiBleHRlbnNpb25zLmFkZCh7XG4gICAqICAgICBleHRlbnNpb246IEV4dGVuc2lvblR5cGUuUmVzb2x2ZVBhcnNlcixcbiAgICogICAgIHRlc3Q6IGxvYWRUZXh0dXJlcy50ZXN0LCAvLyB0ZXN0IGlmIHVybCBlbmRzIGluIGFuIGltYWdlXG4gICAqICAgICBwYXJzZTogKHZhbHVlOiBzdHJpbmcpID0+XG4gICAqICAgICAoe1xuICAgKiAgICAgICAgIHJlc29sdXRpb246IHBhcnNlRmxvYXQoUmVzb2x2ZXIuUkVUSU5BX1BSRUZJWC5leGVjKHZhbHVlKT8uWzFdID8/ICcxJyksXG4gICAqICAgICAgICAgZm9ybWF0OiB2YWx1ZS5zcGxpdCgnLicpLnBvcCgpLFxuICAgKiAgICAgICAgIHNyYzogdmFsdWUsXG4gICAqICAgICB9KSxcbiAgICogfSk7XG4gICAqXG4gICAqIC8vIE5vdyByZXNvbHV0aW9uIGFuZCBmb3JtYXQgY2FuIGJlIGV4dHJhY3RlZCBmcm9tIHRoZSB1cmxcbiAgICogcmVzb2x2ZXIuYWRkKCdmb28nLCBbXG4gICAqICAgICAnaW1hZ2VAMngucG5nJyxcbiAgICogICAgICdpbWFnZS5wbmcnLFxuICAgKiBdKTtcbiAgICovXG4gIGdldCBwYXJzZXJzKCkge1xuICAgIHJldHVybiB0aGlzLl9wYXJzZXJzO1xuICB9XG4gIC8qKiBVc2VkIGZvciB0ZXN0aW5nLCB0aGlzIHJlc2V0cyB0aGUgcmVzb2x2ZXIgdG8gaXRzIGluaXRpYWwgc3RhdGUgKi9cbiAgcmVzZXQoKSB7XG4gICAgdGhpcy5zZXRCdW5kbGVJZGVudGlmaWVyKHRoaXMuX2RlZmF1bHRCdW5kbGVJZGVudGlmaWVyT3B0aW9ucyk7XG4gICAgdGhpcy5fYXNzZXRNYXAgPSB7fTtcbiAgICB0aGlzLl9wcmVmZXJyZWRPcmRlciA9IFtdO1xuICAgIHRoaXMuX3Jlc29sdmVySGFzaCA9IHt9O1xuICAgIHRoaXMuX3Jvb3RQYXRoID0gbnVsbDtcbiAgICB0aGlzLl9iYXNlUGF0aCA9IG51bGw7XG4gICAgdGhpcy5fbWFuaWZlc3QgPSBudWxsO1xuICAgIHRoaXMuX2J1bmRsZXMgPSB7fTtcbiAgICB0aGlzLl9kZWZhdWx0U2VhcmNoUGFyYW1zID0gbnVsbDtcbiAgfVxuICAvKipcbiAgICogU2V0cyB0aGUgZGVmYXVsdCBVUkwgc2VhcmNoIHBhcmFtZXRlcnMgZm9yIHRoZSBVUkwgcmVzb2x2ZXIuIFRoZSB1cmxzIGNhbiBiZSBzcGVjaWZpZWQgYXMgYSBzdHJpbmcgb3IgYW4gb2JqZWN0LlxuICAgKiBAcGFyYW0gc2VhcmNoUGFyYW1zIC0gdGhlIGRlZmF1bHQgdXJsIHBhcmFtZXRlcnMgdG8gYXBwZW5kIHdoZW4gcmVzb2x2aW5nIHVybHNcbiAgICovXG4gIHNldERlZmF1bHRTZWFyY2hQYXJhbXMoc2VhcmNoUGFyYW1zKSB7XG4gICAgaWYgKHR5cGVvZiBzZWFyY2hQYXJhbXMgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHRoaXMuX2RlZmF1bHRTZWFyY2hQYXJhbXMgPSBzZWFyY2hQYXJhbXM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHF1ZXJ5VmFsdWVzID0gc2VhcmNoUGFyYW1zO1xuICAgICAgdGhpcy5fZGVmYXVsdFNlYXJjaFBhcmFtcyA9IE9iamVjdC5rZXlzKHF1ZXJ5VmFsdWVzKS5tYXAoKGtleSkgPT4gYCR7ZW5jb2RlVVJJQ29tcG9uZW50KGtleSl9PSR7ZW5jb2RlVVJJQ29tcG9uZW50KHF1ZXJ5VmFsdWVzW2tleV0pfWApLmpvaW4oXCImXCIpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogUmV0dXJucyB0aGUgYWxpYXNlcyBmb3IgYSBnaXZlbiBhc3NldFxuICAgKiBAcGFyYW0gYXNzZXQgLSB0aGUgYXNzZXQgdG8gZ2V0IHRoZSBhbGlhc2VzIGZvclxuICAgKi9cbiAgZ2V0QWxpYXMoYXNzZXQpIHtcbiAgICBjb25zdCB7IGFsaWFzLCBzcmMgfSA9IGFzc2V0O1xuICAgIGNvbnN0IGFsaWFzZXNUb1VzZSA9IGNvbnZlcnRUb0xpc3QoXG4gICAgICBhbGlhcyB8fCBzcmMsXG4gICAgICAodmFsdWUpID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIHZhbHVlO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiB2YWx1ZS5tYXAoKHYpID0+IHY/LnNyYyA/PyB2KTtcbiAgICAgICAgaWYgKHZhbHVlPy5zcmMpIHJldHVybiB2YWx1ZS5zcmM7XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgIH0sXG4gICAgICB0cnVlXG4gICAgKTtcbiAgICByZXR1cm4gYWxpYXNlc1RvVXNlO1xuICB9XG4gIC8qKlxuICAgKiBSZW1vdmVzIHRoZSBzcGVjaWZpZWQgYWxpYXMgZm9yIGFuIGFzc2V0LlxuICAgKlxuICAgKiBUaGlzIG9ubHkgcmVtb3ZlcyB0aGUgYWxpYXMgbWFwcGluZy4gSXQgZG9lcyAqKm5vdCoqIHJlbW92ZSwgdW5sb2FkLCBvciBkZXN0cm95IHRoZVxuICAgKiB1bmRlcmx5aW5nIGFzc2V0LiBJZiB0aGUgYXNzZXQgaXMgYWxyZWFkeSBjYWNoZWQsIGl0IHN0YXlzIGluIG1lbW9yeSB1bnRpbCB5b3UgY2FsbFxuICAgKiBgQXNzZXRzLnVubG9hZGAuXG4gICAqXG4gICAqIElmIGBhc3NldGAgaXMgcHJvdmlkZWQsIHRoZSBhbGlhcyBpcyBvbmx5IHJlbW92ZWQgd2hlbiB0aGUgcmVzb2x2ZXIncyBjdXJyZW50IG1hcHBpbmcgZm9yXG4gICAqIHRoYXQgYWxpYXMgbWF0Y2hlcyB0aGUgZ2l2ZW4gYFJlc29sdmVkQXNzZXRgLiBUaGlzIGxldHMgeW91IGF2b2lkIGFjY2lkZW50YWxseSByZW1vdmluZyBhblxuICAgKiBhbGlhcyB0aGF0IGhhcyBiZWVuIHJlYXNzaWduZWQuXG4gICAqXG4gICAqIFNpbGVudGx5IHJldHVybnMgaWYgdGhlIGFsaWFzIGRvZXMgbm90IGV4aXN0IG9yIHRoZSBhc3NldCBkb2VzIG5vdCBtYXRjaC5cbiAgICogQHBhcmFtIGFsaWFzIC0gdGhlIGFsaWFzIHRvIHJlbW92ZVxuICAgKiBAcGFyYW0gYXNzZXQgLSBvbmx5IHJlbW92ZSB0aGUgYWxpYXMgaWYgaXQgaXMgY3VycmVudGx5IGFzc2lnbmVkIHRvIHRoaXMgYXNzZXRcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogcmVzb2x2ZXIuYWRkKHsgYWxpYXM6ICdoZXJvJywgc3JjOiAnaGVyby5wbmcnIH0pO1xuICAgKlxuICAgKiAvLyBTaW1wbGUgcmVtb3ZhbFxuICAgKiByZXNvbHZlci5yZW1vdmVBbGlhcygnaGVybycpO1xuICAgKlxuICAgKiAvLyBDb25kaXRpb25hbCByZW1vdmFsIOKAlCBvbmx5IGlmIGFsaWFzIGN1cnJlbnRseSBtYXBzIHRvIGEgc3BlY2lmaWMgYXNzZXRcbiAgICogY29uc3QgcmVzb2x2ZWQgPSByZXNvbHZlci5yZXNvbHZlKCdoZXJvJyk7XG4gICAqIHJlc29sdmVyLnJlbW92ZUFsaWFzKCdoZXJvJywgcmVzb2x2ZWQpO1xuICAgKiBgYGBcbiAgICovXG4gIHJlbW92ZUFsaWFzKGFsaWFzLCBhc3NldCkge1xuICAgIGlmICghdGhpcy5fYXNzZXRNYXBbYWxpYXNdKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChhc3NldCAmJiBhc3NldCAhPT0gdGhpcy5fcmVzb2x2ZXJIYXNoW2FsaWFzXSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBkZWxldGUgdGhpcy5fcmVzb2x2ZXJIYXNoW2FsaWFzXTtcbiAgICBkZWxldGUgdGhpcy5fYXNzZXRNYXBbYWxpYXNdO1xuICB9XG4gIC8qKlxuICAgKiBBZGQgYSBtYW5pZmVzdCB0byB0aGUgYXNzZXQgcmVzb2x2ZXIuIFRoaXMgaXMgYSBuaWNlIHdheSB0byBhZGQgYWxsIHRoZSBhc3NldCBpbmZvcm1hdGlvbiBpbiBvbmUgZ28uXG4gICAqIGdlbmVyYWxseSBhIG1hbmlmZXN0IHdvdWxkIGJlIGJ1aWx0IHVzaW5nIGEgdG9vbC5cbiAgICogQHBhcmFtIG1hbmlmZXN0IC0gdGhlIG1hbmlmZXN0IHRvIGFkZCB0byB0aGUgcmVzb2x2ZXJcbiAgICovXG4gIGFkZE1hbmlmZXN0KG1hbmlmZXN0KSB7XG4gICAgaWYgKHRoaXMuX21hbmlmZXN0KSB7XG4gICAgICB3YXJuKFwiW1Jlc29sdmVyXSBNYW5pZmVzdCBhbHJlYWR5IGV4aXN0cywgdGhpcyB3aWxsIGJlIG92ZXJ3cml0dGVuXCIpO1xuICAgIH1cbiAgICB0aGlzLl9tYW5pZmVzdCA9IG1hbmlmZXN0O1xuICAgIG1hbmlmZXN0LmJ1bmRsZXMuZm9yRWFjaCgoYnVuZGxlKSA9PiB7XG4gICAgICB0aGlzLmFkZEJ1bmRsZShidW5kbGUubmFtZSwgYnVuZGxlLmFzc2V0cyk7XG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFRoaXMgYWRkcyBhIGJ1bmRsZSBvZiBhc3NldHMgaW4gb25lIGdvIHNvIHRoYXQgeW91IGNhbiByZXNvbHZlIHRoZW0gYXMgYSBncm91cC5cbiAgICogRm9yIGV4YW1wbGUgeW91IGNvdWxkIGFkZCBhIGJ1bmRsZSBmb3IgZWFjaCBzY3JlZW4gaW4geW91IHBpeGkgYXBwXG4gICAqIEBleGFtcGxlXG4gICAqIHJlc29sdmVyLmFkZEJ1bmRsZSgnYW5pbWFscycsIFtcbiAgICogIHsgYWxpYXM6ICdidW5ueScsIHNyYzogJ2J1bm55LnBuZycgfSxcbiAgICogIHsgYWxpYXM6ICdjaGlja2VuJywgc3JjOiAnY2hpY2tlbi5wbmcnIH0sXG4gICAqICB7IGFsaWFzOiAndGh1bXBlcicsIHNyYzogJ3RodW1wZXIucG5nJyB9LFxuICAgKiBdKTtcbiAgICogLy8gb3JcbiAgICogcmVzb2x2ZXIuYWRkQnVuZGxlKCdhbmltYWxzJywge1xuICAgKiAgICAgYnVubnk6ICdidW5ueS5wbmcnLFxuICAgKiAgICAgY2hpY2tlbjogJ2NoaWNrZW4ucG5nJyxcbiAgICogICAgIHRodW1wZXI6ICd0aHVtcGVyLnBuZycsXG4gICAqIH0pO1xuICAgKlxuICAgKiBjb25zdCByZXNvbHZlZEFzc2V0cyA9IGF3YWl0IHJlc29sdmVyLnJlc29sdmVCdW5kbGUoJ2FuaW1hbHMnKTtcbiAgICogQHBhcmFtIGJ1bmRsZUlkIC0gVGhlIGlkIG9mIHRoZSBidW5kbGUgdG8gYWRkXG4gICAqIEBwYXJhbSBhc3NldHMgLSBBIHJlY29yZCBvZiB0aGUgYXNzZXQgb3IgYXNzZXRzIHRoYXQgd2lsbCBiZSBjaG9zZW4gZnJvbSB3aGVuIGxvYWRpbmcgdmlhIHRoZSBzcGVjaWZpZWQga2V5XG4gICAqL1xuICBhZGRCdW5kbGUoYnVuZGxlSWQsIGFzc2V0cykge1xuICAgIGNvbnN0IGFzc2V0TmFtZXMgPSBbXTtcbiAgICBsZXQgY29udmVydGVkQXNzZXRzID0gYXNzZXRzO1xuICAgIGlmICghQXJyYXkuaXNBcnJheShhc3NldHMpKSB7XG4gICAgICBjb252ZXJ0ZWRBc3NldHMgPSBPYmplY3QuZW50cmllcyhhc3NldHMpLm1hcCgoW2FsaWFzLCBzcmNdKSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2Ygc3JjID09PSBcInN0cmluZ1wiIHx8IEFycmF5LmlzQXJyYXkoc3JjKSkge1xuICAgICAgICAgIHJldHVybiB7IGFsaWFzLCBzcmMgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4geyBhbGlhcywgLi4uc3JjIH07XG4gICAgICB9KTtcbiAgICB9XG4gICAgY29udmVydGVkQXNzZXRzLmZvckVhY2goKGFzc2V0KSA9PiB7XG4gICAgICBjb25zdCBzcmNzID0gYXNzZXQuc3JjO1xuICAgICAgY29uc3QgYWxpYXNlcyA9IGFzc2V0LmFsaWFzO1xuICAgICAgbGV0IGlkcztcbiAgICAgIGlmICh0eXBlb2YgYWxpYXNlcyA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICBjb25zdCBidW5kbGVBc3NldElkID0gdGhpcy5fY3JlYXRlQnVuZGxlQXNzZXRJZChidW5kbGVJZCwgYWxpYXNlcyk7XG4gICAgICAgIGFzc2V0TmFtZXMucHVzaChidW5kbGVBc3NldElkKTtcbiAgICAgICAgaWRzID0gW2FsaWFzZXMsIGJ1bmRsZUFzc2V0SWRdO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgYnVuZGxlSWRzID0gYWxpYXNlcy5tYXAoKG5hbWUpID0+IHRoaXMuX2NyZWF0ZUJ1bmRsZUFzc2V0SWQoYnVuZGxlSWQsIG5hbWUpKTtcbiAgICAgICAgYXNzZXROYW1lcy5wdXNoKC4uLmJ1bmRsZUlkcyk7XG4gICAgICAgIGlkcyA9IFsuLi5hbGlhc2VzLCAuLi5idW5kbGVJZHNdO1xuICAgICAgfVxuICAgICAgdGhpcy5hZGQoe1xuICAgICAgICAuLi5hc3NldCxcbiAgICAgICAgLi4ue1xuICAgICAgICAgIGFsaWFzOiBpZHMsXG4gICAgICAgICAgc3JjOiBzcmNzXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIHRoaXMuX2J1bmRsZXNbYnVuZGxlSWRdID0gYXNzZXROYW1lcztcbiAgfVxuICAvKipcbiAgICogVGVsbHMgdGhlIHJlc29sdmVyIHdoYXQga2V5cyBhcmUgYXNzb2NpYXRlZCB3aXRoIHdpdGNoIGFzc2V0LlxuICAgKiBUaGUgbW9zdCBpbXBvcnRhbnQgdGhpbmcgdGhlIHJlc29sdmVyIGRvZXNcbiAgICogQGV4YW1wbGVcbiAgICogLy8gU2luZ2xlIGtleSwgc2luZ2xlIGFzc2V0OlxuICAgKiByZXNvbHZlci5hZGQoe2FsaWFzOiAnZm9vJywgc3JjOiAnYmFyLnBuZycpO1xuICAgKiByZXNvbHZlci5yZXNvbHZlVXJsKCdmb28nKSAvLyA9PiAnYmFyLnBuZydcbiAgICpcbiAgICogLy8gTXVsdGlwbGUga2V5cywgc2luZ2xlIGFzc2V0OlxuICAgKiByZXNvbHZlci5hZGQoe2FsaWFzOiBbJ2ZvbycsICdib28nXSwgc3JjOiAnYmFyLnBuZyd9KTtcbiAgICogcmVzb2x2ZXIucmVzb2x2ZVVybCgnZm9vJykgLy8gPT4gJ2Jhci5wbmcnXG4gICAqIHJlc29sdmVyLnJlc29sdmVVcmwoJ2JvbycpIC8vID0+ICdiYXIucG5nJ1xuICAgKlxuICAgKiAvLyBNdWx0aXBsZSBrZXlzLCBtdWx0aXBsZSBhc3NldHM6XG4gICAqIHJlc29sdmVyLmFkZCh7YWxpYXM6IFsnZm9vJywgJ2JvbyddLCBzcmM6IFsnYmFyLnBuZycsICdiYXIud2VicCddfSk7XG4gICAqIHJlc29sdmVyLnJlc29sdmVVcmwoJ2ZvbycpIC8vID0+ICdiYXIucG5nJ1xuICAgKlxuICAgKiAvLyBBZGQgY3VzdG9tIGRhdGEgYXR0YWNoZWQgdG8gdGhlIHJlc29sdmVyXG4gICAqIFJlc29sdmVyLmFkZCh7XG4gICAqICAgICBhbGlhczogJ2J1bm55Qm9vQm9vU21vb3RoJyxcbiAgICogICAgIHNyYzogJ2J1bm55e3BuZyx3ZWJwfScsXG4gICAqICAgICBkYXRhOiB7IHNjYWxlTW9kZTpTQ0FMRV9NT0RFUy5ORUFSRVNUIH0sIC8vIEJhc2UgdGV4dHVyZSBvcHRpb25zXG4gICAqIH0pO1xuICAgKlxuICAgKiByZXNvbHZlci5yZXNvbHZlKCdidW5ueUJvb0Jvb1Ntb290aCcpIC8vID0+IHsgc3JjOiAnYnVubnkucG5nJywgZGF0YTogeyBzY2FsZU1vZGU6IFNDQUxFX01PREVTLk5FQVJFU1QgfSB9XG4gICAqIEBwYXJhbSBhbGlhc2VzIC0gdGhlIFVucmVzb2x2ZWRBc3NldCBvciBhcnJheSBvZiBVbnJlc29sdmVkQXNzZXRzIHRvIGFkZCB0byB0aGUgcmVzb2x2ZXJcbiAgICovXG4gIGFkZChhbGlhc2VzKSB7XG4gICAgY29uc3QgYXNzZXRzID0gW107XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoYWxpYXNlcykpIHtcbiAgICAgIGFzc2V0cy5wdXNoKC4uLmFsaWFzZXMpO1xuICAgIH0gZWxzZSB7XG4gICAgICBhc3NldHMucHVzaChhbGlhc2VzKTtcbiAgICB9XG4gICAgbGV0IGtleUNoZWNrO1xuICAgIGtleUNoZWNrID0gKGtleSkgPT4ge1xuICAgICAgaWYgKHRoaXMuaGFzS2V5KGtleSkpIHtcbiAgICAgICAgd2FybihgW1Jlc29sdmVyXSBhbHJlYWR5IGhhcyBrZXk6ICR7a2V5fSBvdmVyd3JpdGluZ2ApO1xuICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgYXNzZXRBcnJheSA9IGNvbnZlcnRUb0xpc3QoYXNzZXRzKTtcbiAgICBhc3NldEFycmF5LmZvckVhY2goKGFzc2V0KSA9PiB7XG4gICAgICBjb25zdCB7IHNyYyB9ID0gYXNzZXQ7XG4gICAgICBsZXQge1xuICAgICAgICBkYXRhLFxuICAgICAgICBmb3JtYXQsXG4gICAgICAgIGxvYWRQYXJzZXI6IHVzZXJEZWZpbmVkTG9hZFBhcnNlcixcbiAgICAgICAgcGFyc2VyOiB1c2VyRGVmaW5lZFBhcnNlclxuICAgICAgfSA9IGFzc2V0O1xuICAgICAgY29uc3Qgc3Jjc1RvVXNlID0gY29udmVydFRvTGlzdChzcmMpLm1hcCgoc3JjMikgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIHNyYzIgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICByZXR1cm4gY3JlYXRlU3RyaW5nVmFyaWF0aW9ucyhzcmMyKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gQXJyYXkuaXNBcnJheShzcmMyKSA/IHNyYzIgOiBbc3JjMl07XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IGFsaWFzZXNUb1VzZSA9IHRoaXMuZ2V0QWxpYXMoYXNzZXQpO1xuICAgICAgQXJyYXkuaXNBcnJheShhbGlhc2VzVG9Vc2UpID8gYWxpYXNlc1RvVXNlLmZvckVhY2goa2V5Q2hlY2spIDoga2V5Q2hlY2soYWxpYXNlc1RvVXNlKTtcbiAgICAgIGNvbnN0IHJlc29sdmVkQXNzZXRzID0gW107XG4gICAgICBjb25zdCBwYXJzZVVybCA9ICh1cmwpID0+IHtcbiAgICAgICAgY29uc3QgcGFyc2VyID0gdGhpcy5fcGFyc2Vycy5maW5kKChwKSA9PiBwLnRlc3QodXJsKSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3JjOiB1cmwsXG4gICAgICAgICAgLi4ucGFyc2VyPy5wYXJzZSh1cmwpXG4gICAgICAgIH07XG4gICAgICB9O1xuICAgICAgc3Jjc1RvVXNlLmZvckVhY2goKHNyY3MpID0+IHtcbiAgICAgICAgc3Jjcy5mb3JFYWNoKChzcmMyKSA9PiB7XG4gICAgICAgICAgbGV0IGZvcm1hdHRlZEFzc2V0ID0ge307XG4gICAgICAgICAgaWYgKHR5cGVvZiBzcmMyICE9PSBcIm9iamVjdFwiKSB7XG4gICAgICAgICAgICBmb3JtYXR0ZWRBc3NldCA9IHBhcnNlVXJsKHNyYzIpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBkYXRhID0gc3JjMi5kYXRhID8/IGRhdGE7XG4gICAgICAgICAgICBmb3JtYXQgPSBzcmMyLmZvcm1hdCA/PyBmb3JtYXQ7XG4gICAgICAgICAgICBpZiAoc3JjMi5sb2FkUGFyc2VyIHx8IHNyYzIucGFyc2VyKSB7XG4gICAgICAgICAgICAgIHVzZXJEZWZpbmVkTG9hZFBhcnNlciA9IHNyYzIubG9hZFBhcnNlciA/PyB1c2VyRGVmaW5lZExvYWRQYXJzZXI7XG4gICAgICAgICAgICAgIHVzZXJEZWZpbmVkUGFyc2VyID0gc3JjMi5wYXJzZXIgPz8gdXNlckRlZmluZWRQYXJzZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmb3JtYXR0ZWRBc3NldCA9IHtcbiAgICAgICAgICAgICAgLi4ucGFyc2VVcmwoc3JjMi5zcmMpLFxuICAgICAgICAgICAgICAuLi5zcmMyXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoIWFsaWFzZXNUb1VzZSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBbUmVzb2x2ZXJdIGFsaWFzIGlzIHVuZGVmaW5lZCBmb3IgdGhpcyBhc3NldDogJHtmb3JtYXR0ZWRBc3NldC5zcmN9YCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGZvcm1hdHRlZEFzc2V0ID0gdGhpcy5fYnVpbGRSZXNvbHZlZEFzc2V0KGZvcm1hdHRlZEFzc2V0LCB7XG4gICAgICAgICAgICBhbGlhc2VzOiBhbGlhc2VzVG9Vc2UsXG4gICAgICAgICAgICBkYXRhLFxuICAgICAgICAgICAgZm9ybWF0LFxuICAgICAgICAgICAgbG9hZFBhcnNlcjogdXNlckRlZmluZWRMb2FkUGFyc2VyLFxuICAgICAgICAgICAgcGFyc2VyOiB1c2VyRGVmaW5lZFBhcnNlcixcbiAgICAgICAgICAgIHByb2dyZXNzU2l6ZTogYXNzZXQucHJvZ3Jlc3NTaXplXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcmVzb2x2ZWRBc3NldHMucHVzaChmb3JtYXR0ZWRBc3NldCk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgICBhbGlhc2VzVG9Vc2UuZm9yRWFjaCgoYWxpYXMpID0+IHtcbiAgICAgICAgdGhpcy5fYXNzZXRNYXBbYWxpYXNdID0gcmVzb2x2ZWRBc3NldHM7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuICAvLyBUT0RPOiB0aGlzIG5lZWRzIGFuIG92ZXJsb2FkIGxpa2UgbG9hZCBkaWQgaW4gQXNzZXRzXG4gIC8qKlxuICAgKiBJZiB0aGUgcmVzb2x2ZXIgaGFzIGhhZCBhIG1hbmlmZXN0IHNldCB2aWEgc2V0TWFuaWZlc3QsIHRoaXMgd2lsbCByZXR1cm4gdGhlIGFzc2V0cyB1cmxzIGZvclxuICAgKiBhIGdpdmVuIGJ1bmRsZUlkIG9yIGJ1bmRsZUlkcy5cbiAgICogQGV4YW1wbGVcbiAgICogLy8gTWFuaWZlc3QgRXhhbXBsZVxuICAgKiBjb25zdCBtYW5pZmVzdCA9IHtcbiAgICogICAgIGJ1bmRsZXM6IFtcbiAgICogICAgICAgICB7XG4gICAqICAgICAgICAgICAgIG5hbWU6ICdsb2FkLXNjcmVlbicsXG4gICAqICAgICAgICAgICAgIGFzc2V0czogW1xuICAgKiAgICAgICAgICAgICAgICAge1xuICAgKiAgICAgICAgICAgICAgICAgICAgIGFsaWFzOiAnYmFja2dyb3VuZCcsXG4gICAqICAgICAgICAgICAgICAgICAgICAgc3JjOiAnc3Vuc2V0LnBuZycsXG4gICAqICAgICAgICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAgICAgICAge1xuICAgKiAgICAgICAgICAgICAgICAgICAgIGFsaWFzOiAnYmFyJyxcbiAgICogICAgICAgICAgICAgICAgICAgICBzcmM6ICdsb2FkLWJhci57cG5nLHdlYnB9JyxcbiAgICogICAgICAgICAgICAgICAgIH0sXG4gICAqICAgICAgICAgICAgIF0sXG4gICAqICAgICAgICAgfSxcbiAgICogICAgICAgICB7XG4gICAqICAgICAgICAgICAgIG5hbWU6ICdnYW1lLXNjcmVlbicsXG4gICAqICAgICAgICAgICAgIGFzc2V0czogW1xuICAgKiAgICAgICAgICAgICAgICAge1xuICAgKiAgICAgICAgICAgICAgICAgICAgIGFsaWFzOiAnY2hhcmFjdGVyJyxcbiAgICogICAgICAgICAgICAgICAgICAgICBzcmM6ICdyb2JvdC5wbmcnLFxuICAgKiAgICAgICAgICAgICAgICAgfSxcbiAgICogICAgICAgICAgICAgICAgIHtcbiAgICogICAgICAgICAgICAgICAgICAgICBhbGlhczogJ2VuZW15JyxcbiAgICogICAgICAgICAgICAgICAgICAgICBzcmM6ICdiYWQtZ3V5LnBuZycsXG4gICAqICAgICAgICAgICAgICAgICB9LFxuICAgKiAgICAgICAgICAgICBdLFxuICAgKiAgICAgICAgIH0sXG4gICAqICAgICBdXG4gICAqIH07XG4gICAqXG4gICAqIHJlc29sdmVyLnNldE1hbmlmZXN0KG1hbmlmZXN0KTtcbiAgICogY29uc3QgcmVzb2x2ZWQgPSByZXNvbHZlci5yZXNvbHZlQnVuZGxlKCdsb2FkLXNjcmVlbicpO1xuICAgKiBAcGFyYW0gYnVuZGxlSWRzIC0gVGhlIGJ1bmRsZSBpZHMgdG8gcmVzb2x2ZVxuICAgKiBAcmV0dXJucyBBbGwgdGhlIGJ1bmRsZXMgYXNzZXRzIG9yIGEgaGFzaCBvZiBhc3NldHMgZm9yIGVhY2ggYnVuZGxlIHNwZWNpZmllZFxuICAgKi9cbiAgcmVzb2x2ZUJ1bmRsZShidW5kbGVJZHMpIHtcbiAgICBjb25zdCBzaW5nbGVBc3NldCA9IGlzU2luZ2xlSXRlbShidW5kbGVJZHMpO1xuICAgIGJ1bmRsZUlkcyA9IGNvbnZlcnRUb0xpc3QoYnVuZGxlSWRzKTtcbiAgICBjb25zdCBvdXQgPSB7fTtcbiAgICBidW5kbGVJZHMuZm9yRWFjaCgoYnVuZGxlSWQpID0+IHtcbiAgICAgIGNvbnN0IGFzc2V0TmFtZXMgPSB0aGlzLl9idW5kbGVzW2J1bmRsZUlkXTtcbiAgICAgIGlmIChhc3NldE5hbWVzKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdHMgPSB0aGlzLnJlc29sdmUoYXNzZXROYW1lcyk7XG4gICAgICAgIGNvbnN0IGFzc2V0cyA9IHt9O1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiByZXN1bHRzKSB7XG4gICAgICAgICAgY29uc3QgYXNzZXQgPSByZXN1bHRzW2tleV07XG4gICAgICAgICAgYXNzZXRzW3RoaXMuX2V4dHJhY3RBc3NldElkRnJvbUJ1bmRsZShidW5kbGVJZCwga2V5KV0gPSBhc3NldDtcbiAgICAgICAgfVxuICAgICAgICBvdXRbYnVuZGxlSWRdID0gYXNzZXRzO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBzaW5nbGVBc3NldCA/IG91dFtidW5kbGVJZHNbMF1dIDogb3V0O1xuICB9XG4gIC8qKlxuICAgKiBEb2VzIGV4YWN0bHkgd2hhdCByZXNvbHZlIGRvZXMsIGJ1dCByZXR1cm5zIGp1c3QgdGhlIFVSTCByYXRoZXIgdGhhbiB0aGUgd2hvbGUgYXNzZXQgb2JqZWN0XG4gICAqIEBwYXJhbSBrZXkgLSBUaGUga2V5IG9yIGtleXMgdG8gcmVzb2x2ZVxuICAgKiBAcmV0dXJucyAtIFRoZSBVUkxzIGFzc29jaWF0ZWQgd2l0aCB0aGUga2V5KHMpXG4gICAqL1xuICByZXNvbHZlVXJsKGtleSkge1xuICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMucmVzb2x2ZShrZXkpO1xuICAgIGlmICh0eXBlb2Yga2V5ICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICBjb25zdCBvdXQgPSB7fTtcbiAgICAgIGZvciAoY29uc3QgaSBpbiByZXN1bHQpIHtcbiAgICAgICAgb3V0W2ldID0gcmVzdWx0W2ldLnNyYztcbiAgICAgIH1cbiAgICAgIHJldHVybiBvdXQ7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQuc3JjO1xuICB9XG4gIHJlc29sdmUoa2V5cykge1xuICAgIGNvbnN0IHNpbmdsZUFzc2V0ID0gaXNTaW5nbGVJdGVtKGtleXMpO1xuICAgIGtleXMgPSBjb252ZXJ0VG9MaXN0KGtleXMpO1xuICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgIGtleXMuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICBpZiAoIXRoaXMuX3Jlc29sdmVySGFzaFtrZXldKSB7XG4gICAgICAgIGlmICh0aGlzLl9hc3NldE1hcFtrZXldKSB7XG4gICAgICAgICAgbGV0IGFzc2V0cyA9IHRoaXMuX2Fzc2V0TWFwW2tleV07XG4gICAgICAgICAgY29uc3QgcHJlZmVycmVkT3JkZXIgPSB0aGlzLl9nZXRQcmVmZXJyZWRPcmRlcihhc3NldHMpO1xuICAgICAgICAgIHByZWZlcnJlZE9yZGVyPy5wcmlvcml0eS5mb3JFYWNoKChwcmlvcml0eUtleSkgPT4ge1xuICAgICAgICAgICAgcHJlZmVycmVkT3JkZXIucGFyYW1zW3ByaW9yaXR5S2V5XS5mb3JFYWNoKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBmaWx0ZXJlZEFzc2V0cyA9IGFzc2V0cy5maWx0ZXIoKGFzc2V0KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGFzc2V0W3ByaW9yaXR5S2V5XSkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGFzc2V0W3ByaW9yaXR5S2V5XSA9PT0gdmFsdWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIGlmIChmaWx0ZXJlZEFzc2V0cy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICBhc3NldHMgPSBmaWx0ZXJlZEFzc2V0cztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgdGhpcy5fcmVzb2x2ZXJIYXNoW2tleV0gPSBhc3NldHNbMF07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5fcmVzb2x2ZXJIYXNoW2tleV0gPSB0aGlzLl9idWlsZFJlc29sdmVkQXNzZXQoe1xuICAgICAgICAgICAgYWxpYXM6IFtrZXldLFxuICAgICAgICAgICAgc3JjOiBrZXlcbiAgICAgICAgICB9LCB7fSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJlc3VsdFtrZXldID0gdGhpcy5fcmVzb2x2ZXJIYXNoW2tleV07XG4gICAgfSk7XG4gICAgcmV0dXJuIHNpbmdsZUFzc2V0ID8gcmVzdWx0W2tleXNbMF1dIDogcmVzdWx0O1xuICB9XG4gIC8qKlxuICAgKiBDaGVja3MgaWYgYW4gYXNzZXQgd2l0aCBhIGdpdmVuIGtleSBleGlzdHMgaW4gdGhlIHJlc29sdmVyXG4gICAqIEBwYXJhbSBrZXkgLSBUaGUga2V5IG9mIHRoZSBhc3NldFxuICAgKi9cbiAgaGFzS2V5KGtleSkge1xuICAgIHJldHVybiAhIXRoaXMuX2Fzc2V0TWFwW2tleV07XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyBpZiBhIGJ1bmRsZSB3aXRoIHRoZSBnaXZlbiBrZXkgZXhpc3RzIGluIHRoZSByZXNvbHZlclxuICAgKiBAcGFyYW0ga2V5IC0gVGhlIGtleSBvZiB0aGUgYnVuZGxlXG4gICAqL1xuICBoYXNCdW5kbGUoa2V5KSB7XG4gICAgcmV0dXJuICEhdGhpcy5fYnVuZGxlc1trZXldO1xuICB9XG4gIC8qKlxuICAgKiBJbnRlcm5hbCBmdW5jdGlvbiBmb3IgZmlndXJpbmcgb3V0IHdoYXQgcHJlZmVyIGNyaXRlcmlhIGFuIGFzc2V0IHNob3VsZCB1c2UuXG4gICAqIEBwYXJhbSBhc3NldHNcbiAgICovXG4gIF9nZXRQcmVmZXJyZWRPcmRlcihhc3NldHMpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFzc2V0cy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgYXNzZXQgPSBhc3NldHNbaV07XG4gICAgICBjb25zdCBwcmVmZXJyZWQgPSB0aGlzLl9wcmVmZXJyZWRPcmRlci5maW5kKChwcmVmZXJlbmNlKSA9PiBwcmVmZXJlbmNlLnBhcmFtcy5mb3JtYXQuaW5jbHVkZXMoYXNzZXQuZm9ybWF0KSk7XG4gICAgICBpZiAocHJlZmVycmVkKSB7XG4gICAgICAgIHJldHVybiBwcmVmZXJyZWQ7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9wcmVmZXJyZWRPcmRlclswXTtcbiAgfVxuICAvKipcbiAgICogQXBwZW5kcyB0aGUgZGVmYXVsdCB1cmwgcGFyYW1ldGVycyB0byB0aGUgdXJsXG4gICAqIEBwYXJhbSB1cmwgLSBUaGUgdXJsIHRvIGFwcGVuZCB0aGUgZGVmYXVsdCBwYXJhbWV0ZXJzIHRvXG4gICAqIEByZXR1cm5zIC0gVGhlIHVybCB3aXRoIHRoZSBkZWZhdWx0IHBhcmFtZXRlcnMgYXBwZW5kZWRcbiAgICovXG4gIF9hcHBlbmREZWZhdWx0U2VhcmNoUGFyYW1zKHVybCkge1xuICAgIGlmICghdGhpcy5fZGVmYXVsdFNlYXJjaFBhcmFtcykgcmV0dXJuIHVybDtcbiAgICBjb25zdCBwYXJhbUNvbm5lY3RvciA9IC9cXD8vLnRlc3QodXJsKSA/IFwiJlwiIDogXCI/XCI7XG4gICAgcmV0dXJuIGAke3VybH0ke3BhcmFtQ29ubmVjdG9yfSR7dGhpcy5fZGVmYXVsdFNlYXJjaFBhcmFtc31gO1xuICB9XG4gIF9idWlsZFJlc29sdmVkQXNzZXQoZm9ybWF0dGVkQXNzZXQsIGRhdGEpIHtcbiAgICBjb25zdCB7IGFsaWFzZXMsIGRhdGE6IGFzc2V0RGF0YSwgbG9hZFBhcnNlciwgcGFyc2VyLCBmb3JtYXQsIHByb2dyZXNzU2l6ZSB9ID0gZGF0YTtcbiAgICBpZiAodGhpcy5fYmFzZVBhdGggfHwgdGhpcy5fcm9vdFBhdGgpIHtcbiAgICAgIGZvcm1hdHRlZEFzc2V0LnNyYyA9IHBhdGgudG9BYnNvbHV0ZShmb3JtYXR0ZWRBc3NldC5zcmMsIHRoaXMuX2Jhc2VQYXRoLCB0aGlzLl9yb290UGF0aCk7XG4gICAgfVxuICAgIGZvcm1hdHRlZEFzc2V0LmFsaWFzID0gYWxpYXNlcyA/PyBmb3JtYXR0ZWRBc3NldC5hbGlhcyA/PyBbZm9ybWF0dGVkQXNzZXQuc3JjXTtcbiAgICBmb3JtYXR0ZWRBc3NldC5zcmMgPSB0aGlzLl9hcHBlbmREZWZhdWx0U2VhcmNoUGFyYW1zKGZvcm1hdHRlZEFzc2V0LnNyYyk7XG4gICAgZm9ybWF0dGVkQXNzZXQuZGF0YSA9IHsgLi4uYXNzZXREYXRhIHx8IHt9LCAuLi5mb3JtYXR0ZWRBc3NldC5kYXRhIH07XG4gICAgZm9ybWF0dGVkQXNzZXQubG9hZFBhcnNlciA9IGxvYWRQYXJzZXIgPz8gZm9ybWF0dGVkQXNzZXQubG9hZFBhcnNlcjtcbiAgICBmb3JtYXR0ZWRBc3NldC5wYXJzZXIgPSBwYXJzZXIgPz8gZm9ybWF0dGVkQXNzZXQucGFyc2VyO1xuICAgIGZvcm1hdHRlZEFzc2V0LmZvcm1hdCA9IGZvcm1hdCA/PyBmb3JtYXR0ZWRBc3NldC5mb3JtYXQgPz8gZ2V0VXJsRXh0ZW5zaW9uKGZvcm1hdHRlZEFzc2V0LnNyYyk7XG4gICAgaWYgKHByb2dyZXNzU2l6ZSAhPT0gdm9pZCAwKSB7XG4gICAgICBmb3JtYXR0ZWRBc3NldC5wcm9ncmVzc1NpemUgPSBwcm9ncmVzc1NpemU7XG4gICAgfVxuICAgIHJldHVybiBmb3JtYXR0ZWRBc3NldDtcbiAgfVxufVxuLyoqXG4gKiBUaGUgcHJlZml4IHRoYXQgZGVub3RlcyBhIFVSTCBpcyBmb3IgYSByZXRpbmEgYXNzZXQuXG4gKiBAZGVmYXVsdCAvQChbMC05XFwuXSspeC9cbiAqIEBleGFtcGxlIGBAMnhgXG4gKi9cblJlc29sdmVyLlJFVElOQV9QUkVGSVggPSAvQChbMC05XFwuXSspeC87XG5mdW5jdGlvbiBnZXRVcmxFeHRlbnNpb24odXJsKSB7XG4gIHJldHVybiB1cmwuc3BsaXQoXCIuXCIpLnBvcCgpLnNwbGl0KFwiP1wiKS5zaGlmdCgpLnNwbGl0KFwiI1wiKS5zaGlmdCgpO1xufVxuXG5leHBvcnQgeyBSZXNvbHZlciwgZ2V0VXJsRXh0ZW5zaW9uIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1SZXNvbHZlci5tanMubWFwXG4iLCJcInVzZSBzdHJpY3RcIjtcbmNvbnN0IGNvcHlTZWFyY2hQYXJhbXMgPSAodGFyZ2V0VXJsLCBzb3VyY2VVcmwpID0+IHtcbiAgY29uc3Qgc2VhcmNoUGFyYW1zID0gc291cmNlVXJsLnNwbGl0KFwiP1wiKVsxXTtcbiAgaWYgKHNlYXJjaFBhcmFtcykge1xuICAgIHRhcmdldFVybCArPSBgPyR7c2VhcmNoUGFyYW1zfWA7XG4gIH1cbiAgcmV0dXJuIHRhcmdldFVybDtcbn07XG5cbmV4cG9ydCB7IGNvcHlTZWFyY2hQYXJhbXMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvcHlTZWFyY2hQYXJhbXMubWpzLm1hcFxuIiwiaW1wb3J0IHsgUmVjdGFuZ2xlIH0gZnJvbSAnLi4vbWF0aHMvc2hhcGVzL1JlY3RhbmdsZS5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVNvdXJjZSB9IGZyb20gJy4uL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvc291cmNlcy9UZXh0dXJlU291cmNlLm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlIH0gZnJvbSAnLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9UZXh0dXJlLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgX1Nwcml0ZXNoZWV0ID0gY2xhc3MgX1Nwcml0ZXNoZWV0IHtcbiAgY29uc3RydWN0b3Iob3B0aW9uc09yVGV4dHVyZSwgYXJnMSkge1xuICAgIC8qKiBGb3IgbXVsdGktcGFja2VkIHNwcml0ZXNoZWV0cywgdGhpcyBjb250YWlucyBhIHJlZmVyZW5jZSB0byBhbGwgdGhlIG90aGVyIHNwcml0ZXNoZWV0cyBpdCBkZXBlbmRzIG9uLiAqL1xuICAgIHRoaXMubGlua2VkU2hlZXRzID0gW107XG4gICAgbGV0IG9wdGlvbnMgPSBvcHRpb25zT3JUZXh0dXJlO1xuICAgIGlmIChvcHRpb25zT3JUZXh0dXJlPy5zb3VyY2UgaW5zdGFuY2VvZiBUZXh0dXJlU291cmNlKSB7XG4gICAgICBvcHRpb25zID0ge1xuICAgICAgICB0ZXh0dXJlOiBvcHRpb25zT3JUZXh0dXJlLFxuICAgICAgICBkYXRhOiBhcmcxXG4gICAgICB9O1xuICAgIH1cbiAgICBjb25zdCB7IHRleHR1cmUsIGRhdGEsIGNhY2hlUHJlZml4ID0gXCJcIiB9ID0gb3B0aW9ucztcbiAgICB0aGlzLmNhY2hlUHJlZml4ID0gY2FjaGVQcmVmaXg7XG4gICAgdGhpcy5fdGV4dHVyZSA9IHRleHR1cmUgaW5zdGFuY2VvZiBUZXh0dXJlID8gdGV4dHVyZSA6IG51bGw7XG4gICAgdGhpcy50ZXh0dXJlU291cmNlID0gdGV4dHVyZS5zb3VyY2U7XG4gICAgdGhpcy50ZXh0dXJlcyA9IHt9O1xuICAgIHRoaXMuYW5pbWF0aW9ucyA9IHt9O1xuICAgIHRoaXMuZGF0YSA9IGRhdGE7XG4gICAgY29uc3QgbWV0YVJlc29sdXRpb24gPSBwYXJzZUZsb2F0KGRhdGEubWV0YS5zY2FsZSk7XG4gICAgaWYgKG1ldGFSZXNvbHV0aW9uKSB7XG4gICAgICB0aGlzLnJlc29sdXRpb24gPSBtZXRhUmVzb2x1dGlvbjtcbiAgICAgIHRleHR1cmUuc291cmNlLnJlc29sdXRpb24gPSB0aGlzLnJlc29sdXRpb247XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMucmVzb2x1dGlvbiA9IHRleHR1cmUuc291cmNlLl9yZXNvbHV0aW9uO1xuICAgIH1cbiAgICB0aGlzLl9mcmFtZXMgPSB0aGlzLmRhdGEuZnJhbWVzO1xuICAgIHRoaXMuX2ZyYW1lS2V5cyA9IE9iamVjdC5rZXlzKHRoaXMuX2ZyYW1lcyk7XG4gICAgdGhpcy5fYmF0Y2hJbmRleCA9IDA7XG4gICAgdGhpcy5fY2FsbGJhY2sgPSBudWxsO1xuICB9XG4gIC8qKlxuICAgKiBQYXJzZSBzcHJpdGVzaGVldCBmcm9tIGxvYWRlZCBkYXRhLiBUaGlzIGlzIGRvbmUgYXN5bmNocm9ub3VzbHlcbiAgICogdG8gcHJldmVudCBjcmVhdGluZyB0b28gbWFueSBUZXh0dXJlIHdpdGhpbiBhIHNpbmdsZSBwcm9jZXNzLlxuICAgKi9cbiAgcGFyc2UoKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICB0aGlzLl9jYWxsYmFjayA9IHJlc29sdmU7XG4gICAgICB0aGlzLl9iYXRjaEluZGV4ID0gMDtcbiAgICAgIGlmICh0aGlzLl9mcmFtZUtleXMubGVuZ3RoIDw9IF9TcHJpdGVzaGVldC5CQVRDSF9TSVpFKSB7XG4gICAgICAgIHRoaXMuX3Byb2Nlc3NGcmFtZXMoMCk7XG4gICAgICAgIHRoaXMuX3Byb2Nlc3NBbmltYXRpb25zKCk7XG4gICAgICAgIHRoaXMuX3BhcnNlQ29tcGxldGUoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX25leHRCYXRjaCgpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBQYXJzZSBzcHJpdGVzaGVldCBmcm9tIGxvYWRlZCBkYXRhLiBUaGlzIGlzIGRvbmUgc3luY2hyb25vdXNseVxuICAgKiBhbmQgaXMgb25seSBzdWl0YWJsZSBmb3Igc21hbGxlciBzcHJpdGVzaGVldHMgKGxlc3MgdGhhbiB+MTAwMCBmcmFtZXMpXG4gICAqIG9yIG1heSBjYXVzZSB0b28gbWFueSBUZXh0dXJlIHdpdGhpbiBhIHNpbmdsZSBwcm9jZXNzLiBIb3dldmVyLCBzeW5jaHJvbm91cyBwYXJzaW5nIG1heSBiZVxuICAgKiBtb3JlIGNvbnZlbmllbnQgc2luY2UgdGhlIGNhbGxlZCBkb2VzIG5vdCBuZWVkIHRvIGJlIGFzeW5jaHJvbm91cyBhbmQgaXMgc2FmZSBmb3JcbiAgICogc21hbGwtdG8tbWVkaXVtIHNpemVkIHNwcml0ZXNoZWV0cy5cbiAgICpcbiAgICogT3RoZXIgdGhhbiBiZWluZyBzeW5jaHJvbm91cywgYHBhcnNlU3luY2AgaXMgb3RoZXJ3aXNlIGlkZW50aWNhbCB0byBgLnBhcnNlKClgLlxuICAgKi9cbiAgcGFyc2VTeW5jKCkge1xuICAgIHRoaXMuX3Byb2Nlc3NGcmFtZXMoMCwgdHJ1ZSk7XG4gICAgdGhpcy5fcHJvY2Vzc0FuaW1hdGlvbnMoKTtcbiAgICByZXR1cm4gdGhpcy50ZXh0dXJlcztcbiAgfVxuICAvKipcbiAgICogUHJvY2VzcyBhIGJhdGNoIG9mIGZyYW1lc1xuICAgKiBAcGFyYW0gaW5pdGlhbEZyYW1lSW5kZXggLSBUaGUgaW5kZXggb2YgZnJhbWUgdG8gc3RhcnQuXG4gICAqIEBwYXJhbSBwcm9jZXNzQWxsIC0gaWYgdHJ1ZSB3aWxsIHByb2Nlc3MgYWxsIGZyYW1lcyBpbiBhIHNpbmdsZSBiYXRjaCwgaWdub3JpbmcgQkFUQ0hfU0laRSAtIHRoaXNcbiAgICogaXMgdXNlZCBmb3Igc3luY2hyb25vdXMgcGFyc2luZy5cbiAgICovXG4gIF9wcm9jZXNzRnJhbWVzKGluaXRpYWxGcmFtZUluZGV4LCBwcm9jZXNzQWxsID0gZmFsc2UpIHtcbiAgICBsZXQgZnJhbWVJbmRleCA9IGluaXRpYWxGcmFtZUluZGV4O1xuICAgIGNvbnN0IG1heEZyYW1lcyA9IHByb2Nlc3NBbGwgPyBJbmZpbml0eSA6IF9TcHJpdGVzaGVldC5CQVRDSF9TSVpFO1xuICAgIHdoaWxlIChmcmFtZUluZGV4IC0gaW5pdGlhbEZyYW1lSW5kZXggPCBtYXhGcmFtZXMgJiYgZnJhbWVJbmRleCA8IHRoaXMuX2ZyYW1lS2V5cy5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IGkgPSB0aGlzLl9mcmFtZUtleXNbZnJhbWVJbmRleF07XG4gICAgICBjb25zdCBkYXRhID0gdGhpcy5fZnJhbWVzW2ldO1xuICAgICAgY29uc3QgcmVjdCA9IGRhdGEuZnJhbWU7XG4gICAgICBpZiAocmVjdCkge1xuICAgICAgICBsZXQgZnJhbWUgPSBudWxsO1xuICAgICAgICBsZXQgdHJpbSA9IG51bGw7XG4gICAgICAgIGNvbnN0IHNvdXJjZVNpemUgPSBkYXRhLnRyaW1tZWQgIT09IGZhbHNlICYmIGRhdGEuc291cmNlU2l6ZSA/IGRhdGEuc291cmNlU2l6ZSA6IGRhdGEuZnJhbWU7XG4gICAgICAgIGNvbnN0IG9yaWcgPSBuZXcgUmVjdGFuZ2xlKFxuICAgICAgICAgIDAsXG4gICAgICAgICAgMCxcbiAgICAgICAgICBNYXRoLmZsb29yKHNvdXJjZVNpemUudykgLyB0aGlzLnJlc29sdXRpb24sXG4gICAgICAgICAgTWF0aC5mbG9vcihzb3VyY2VTaXplLmgpIC8gdGhpcy5yZXNvbHV0aW9uXG4gICAgICAgICk7XG4gICAgICAgIGlmIChkYXRhLnJvdGF0ZWQpIHtcbiAgICAgICAgICBmcmFtZSA9IG5ldyBSZWN0YW5nbGUoXG4gICAgICAgICAgICBNYXRoLmZsb29yKHJlY3QueCkgLyB0aGlzLnJlc29sdXRpb24sXG4gICAgICAgICAgICBNYXRoLmZsb29yKHJlY3QueSkgLyB0aGlzLnJlc29sdXRpb24sXG4gICAgICAgICAgICBNYXRoLmZsb29yKHJlY3QuaCkgLyB0aGlzLnJlc29sdXRpb24sXG4gICAgICAgICAgICBNYXRoLmZsb29yKHJlY3QudykgLyB0aGlzLnJlc29sdXRpb25cbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGZyYW1lID0gbmV3IFJlY3RhbmdsZShcbiAgICAgICAgICAgIE1hdGguZmxvb3IocmVjdC54KSAvIHRoaXMucmVzb2x1dGlvbixcbiAgICAgICAgICAgIE1hdGguZmxvb3IocmVjdC55KSAvIHRoaXMucmVzb2x1dGlvbixcbiAgICAgICAgICAgIE1hdGguZmxvb3IocmVjdC53KSAvIHRoaXMucmVzb2x1dGlvbixcbiAgICAgICAgICAgIE1hdGguZmxvb3IocmVjdC5oKSAvIHRoaXMucmVzb2x1dGlvblxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGRhdGEudHJpbW1lZCAhPT0gZmFsc2UgJiYgZGF0YS5zcHJpdGVTb3VyY2VTaXplKSB7XG4gICAgICAgICAgdHJpbSA9IG5ldyBSZWN0YW5nbGUoXG4gICAgICAgICAgICBNYXRoLmZsb29yKGRhdGEuc3ByaXRlU291cmNlU2l6ZS54KSAvIHRoaXMucmVzb2x1dGlvbixcbiAgICAgICAgICAgIE1hdGguZmxvb3IoZGF0YS5zcHJpdGVTb3VyY2VTaXplLnkpIC8gdGhpcy5yZXNvbHV0aW9uLFxuICAgICAgICAgICAgTWF0aC5mbG9vcihyZWN0LncpIC8gdGhpcy5yZXNvbHV0aW9uLFxuICAgICAgICAgICAgTWF0aC5mbG9vcihyZWN0LmgpIC8gdGhpcy5yZXNvbHV0aW9uXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnRleHR1cmVzW2ldID0gbmV3IFRleHR1cmUoe1xuICAgICAgICAgIHNvdXJjZTogdGhpcy50ZXh0dXJlU291cmNlLFxuICAgICAgICAgIGZyYW1lLFxuICAgICAgICAgIG9yaWcsXG4gICAgICAgICAgdHJpbSxcbiAgICAgICAgICByb3RhdGU6IGRhdGEucm90YXRlZCA/IDIgOiAwLFxuICAgICAgICAgIGRlZmF1bHRBbmNob3I6IGRhdGEuYW5jaG9yLFxuICAgICAgICAgIGRlZmF1bHRCb3JkZXJzOiBkYXRhLmJvcmRlcnMsXG4gICAgICAgICAgbGFiZWw6IGkudG9TdHJpbmcoKVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGZyYW1lSW5kZXgrKztcbiAgICB9XG4gIH1cbiAgLyoqIFBhcnNlIGFuaW1hdGlvbnMgY29uZmlnLiAqL1xuICBfcHJvY2Vzc0FuaW1hdGlvbnMoKSB7XG4gICAgY29uc3QgYW5pbWF0aW9ucyA9IHRoaXMuZGF0YS5hbmltYXRpb25zIHx8IHt9O1xuICAgIGZvciAoY29uc3QgYW5pbU5hbWUgaW4gYW5pbWF0aW9ucykge1xuICAgICAgdGhpcy5hbmltYXRpb25zW2FuaW1OYW1lXSA9IFtdO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhbmltYXRpb25zW2FuaW1OYW1lXS5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBmcmFtZU5hbWUgPSBhbmltYXRpb25zW2FuaW1OYW1lXVtpXTtcbiAgICAgICAgdGhpcy5hbmltYXRpb25zW2FuaW1OYW1lXS5wdXNoKHRoaXMudGV4dHVyZXNbZnJhbWVOYW1lXSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIC8qKiBUaGUgcGFyc2UgaGFzIGNvbXBsZXRlZC4gKi9cbiAgX3BhcnNlQ29tcGxldGUoKSB7XG4gICAgY29uc3QgY2FsbGJhY2sgPSB0aGlzLl9jYWxsYmFjaztcbiAgICB0aGlzLl9jYWxsYmFjayA9IG51bGw7XG4gICAgdGhpcy5fYmF0Y2hJbmRleCA9IDA7XG4gICAgY2FsbGJhY2suY2FsbCh0aGlzLCB0aGlzLnRleHR1cmVzKTtcbiAgfVxuICAvKiogQmVnaW4gdGhlIG5leHQgYmF0Y2ggb2YgdGV4dHVyZXMuICovXG4gIF9uZXh0QmF0Y2goKSB7XG4gICAgdGhpcy5fcHJvY2Vzc0ZyYW1lcyh0aGlzLl9iYXRjaEluZGV4ICogX1Nwcml0ZXNoZWV0LkJBVENIX1NJWkUpO1xuICAgIHRoaXMuX2JhdGNoSW5kZXgrKztcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGlmICh0aGlzLl9iYXRjaEluZGV4ICogX1Nwcml0ZXNoZWV0LkJBVENIX1NJWkUgPCB0aGlzLl9mcmFtZUtleXMubGVuZ3RoKSB7XG4gICAgICAgIHRoaXMuX25leHRCYXRjaCgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5fcHJvY2Vzc0FuaW1hdGlvbnMoKTtcbiAgICAgICAgdGhpcy5fcGFyc2VDb21wbGV0ZSgpO1xuICAgICAgfVxuICAgIH0sIDApO1xuICB9XG4gIC8qKlxuICAgKiBEZXN0cm95IFNwcml0ZXNoZWV0IGFuZCBkb24ndCB1c2UgYWZ0ZXIgdGhpcy5cbiAgICogQHBhcmFtIHtib29sZWFufSBbZGVzdHJveUJhc2U9ZmFsc2VdIC0gV2hldGhlciB0byBkZXN0cm95IHRoZSBiYXNlIHRleHR1cmUgYXMgd2VsbFxuICAgKi9cbiAgZGVzdHJveShkZXN0cm95QmFzZSA9IGZhbHNlKSB7XG4gICAgZm9yIChjb25zdCBpIGluIHRoaXMudGV4dHVyZXMpIHtcbiAgICAgIHRoaXMudGV4dHVyZXNbaV0uZGVzdHJveSgpO1xuICAgIH1cbiAgICB0aGlzLl9mcmFtZXMgPSBudWxsO1xuICAgIHRoaXMuX2ZyYW1lS2V5cyA9IG51bGw7XG4gICAgdGhpcy5kYXRhID0gbnVsbDtcbiAgICB0aGlzLnRleHR1cmVzID0gbnVsbDtcbiAgICBpZiAoZGVzdHJveUJhc2UpIHtcbiAgICAgIHRoaXMuX3RleHR1cmU/LmRlc3Ryb3koKTtcbiAgICAgIHRoaXMudGV4dHVyZVNvdXJjZS5kZXN0cm95KCk7XG4gICAgfVxuICAgIHRoaXMuX3RleHR1cmUgPSBudWxsO1xuICAgIHRoaXMudGV4dHVyZVNvdXJjZSA9IG51bGw7XG4gICAgdGhpcy5saW5rZWRTaGVldHMgPSBbXTtcbiAgfVxufTtcbi8qKlxuICogVGhlIG1heGltdW0gbnVtYmVyIG9mIFRleHR1cmVzIHRvIGJ1aWxkIHBlciBwcm9jZXNzLlxuICogQGFkdmFuY2VkXG4gKi9cbl9TcHJpdGVzaGVldC5CQVRDSF9TSVpFID0gMWUzO1xubGV0IFNwcml0ZXNoZWV0ID0gX1Nwcml0ZXNoZWV0O1xuXG5leHBvcnQgeyBTcHJpdGVzaGVldCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9U3ByaXRlc2hlZXQubWpzLm1hcFxuIiwiaW1wb3J0IHsgTG9hZGVyUGFyc2VyUHJpb3JpdHkgfSBmcm9tICcuLi9hc3NldHMvbG9hZGVyL3BhcnNlcnMvTG9hZGVyUGFyc2VyLm1qcyc7XG5pbXBvcnQgeyBSZXNvbHZlciB9IGZyb20gJy4uL2Fzc2V0cy9yZXNvbHZlci9SZXNvbHZlci5tanMnO1xuaW1wb3J0IHsgY29weVNlYXJjaFBhcmFtcyB9IGZyb20gJy4uL2Fzc2V0cy91dGlscy9jb3B5U2VhcmNoUGFyYW1zLm1qcyc7XG5pbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBUZXh0dXJlIH0gZnJvbSAnLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9UZXh0dXJlLm1qcyc7XG5pbXBvcnQgeyBwYXRoIH0gZnJvbSAnLi4vdXRpbHMvcGF0aC5tanMnO1xuaW1wb3J0IHsgU3ByaXRlc2hlZXQgfSBmcm9tICcuL1Nwcml0ZXNoZWV0Lm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY29uc3QgdmFsaWRJbWFnZXMgPSBbXG4gIFwianBnXCIsXG4gIFwicG5nXCIsXG4gIFwianBlZ1wiLFxuICBcImF2aWZcIixcbiAgXCJ3ZWJwXCIsXG4gIFwiYmFzaXNcIixcbiAgXCJldGMyXCIsXG4gIFwiYmM3XCIsXG4gIFwiYmM2aFwiLFxuICBcImJjNVwiLFxuICBcImJjNFwiLFxuICBcImJjM1wiLFxuICBcImJjMlwiLFxuICBcImJjMVwiLFxuICBcImVhY1wiLFxuICBcImFzdGNcIlxuXTtcbmZ1bmN0aW9uIGdldENhY2hlYWJsZUFzc2V0cyhrZXlzLCBhc3NldCwgaWdub3JlTXVsdGlQYWNrKSB7XG4gIGNvbnN0IG91dCA9IHt9O1xuICBrZXlzLmZvckVhY2goKGtleSkgPT4ge1xuICAgIG91dFtrZXldID0gYXNzZXQ7XG4gIH0pO1xuICBPYmplY3Qua2V5cyhhc3NldC50ZXh0dXJlcykuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgb3V0W2Ake2Fzc2V0LmNhY2hlUHJlZml4fSR7a2V5fWBdID0gYXNzZXQudGV4dHVyZXNba2V5XTtcbiAgfSk7XG4gIGlmICghaWdub3JlTXVsdGlQYWNrKSB7XG4gICAgY29uc3QgYmFzZVBhdGggPSBwYXRoLmRpcm5hbWUoa2V5c1swXSk7XG4gICAgYXNzZXQubGlua2VkU2hlZXRzLmZvckVhY2goKGl0ZW0sIGkpID0+IHtcbiAgICAgIGNvbnN0IG91dDIgPSBnZXRDYWNoZWFibGVBc3NldHMoW2Ake2Jhc2VQYXRofS8ke2Fzc2V0LmRhdGEubWV0YS5yZWxhdGVkX211bHRpX3BhY2tzW2ldfWBdLCBpdGVtLCB0cnVlKTtcbiAgICAgIE9iamVjdC5hc3NpZ24ob3V0LCBvdXQyKTtcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuY29uc3Qgc3ByaXRlc2hlZXRBc3NldCA9IHtcbiAgZXh0ZW5zaW9uOiBFeHRlbnNpb25UeXBlLkFzc2V0LFxuICAvKiogSGFuZGxlIHRoZSBjYWNoaW5nIG9mIHRoZSByZWxhdGVkIFNwcml0ZXNoZWV0IFRleHR1cmVzICovXG4gIGNhY2hlOiB7XG4gICAgdGVzdDogKGFzc2V0KSA9PiBhc3NldCBpbnN0YW5jZW9mIFNwcml0ZXNoZWV0LFxuICAgIGdldENhY2hlYWJsZUFzc2V0czogKGtleXMsIGFzc2V0KSA9PiBnZXRDYWNoZWFibGVBc3NldHMoa2V5cywgYXNzZXQsIGZhbHNlKVxuICB9LFxuICAvKiogUmVzb2x2ZSB0aGUgcmVzb2x1dGlvbiBvZiB0aGUgYXNzZXQuICovXG4gIHJlc29sdmVyOiB7XG4gICAgZXh0ZW5zaW9uOiB7XG4gICAgICB0eXBlOiBFeHRlbnNpb25UeXBlLlJlc29sdmVQYXJzZXIsXG4gICAgICBuYW1lOiBcInJlc29sdmVTcHJpdGVzaGVldFwiXG4gICAgfSxcbiAgICB0ZXN0OiAodmFsdWUpID0+IHtcbiAgICAgIGNvbnN0IHRlbXBVUkwgPSB2YWx1ZS5zcGxpdChcIj9cIilbMF07XG4gICAgICBjb25zdCBzcGxpdCA9IHRlbXBVUkwuc3BsaXQoXCIuXCIpO1xuICAgICAgY29uc3QgZXh0ZW5zaW9uID0gc3BsaXQucG9wKCk7XG4gICAgICBjb25zdCBmb3JtYXQgPSBzcGxpdC5wb3AoKTtcbiAgICAgIHJldHVybiBleHRlbnNpb24gPT09IFwianNvblwiICYmIHZhbGlkSW1hZ2VzLmluY2x1ZGVzKGZvcm1hdCk7XG4gICAgfSxcbiAgICBwYXJzZTogKHZhbHVlKSA9PiB7XG4gICAgICBjb25zdCBzcGxpdCA9IHZhbHVlLnNwbGl0KFwiLlwiKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHJlc29sdXRpb246IHBhcnNlRmxvYXQoUmVzb2x2ZXIuUkVUSU5BX1BSRUZJWC5leGVjKHZhbHVlKT8uWzFdID8/IFwiMVwiKSxcbiAgICAgICAgZm9ybWF0OiBzcGxpdFtzcGxpdC5sZW5ndGggLSAyXSxcbiAgICAgICAgc3JjOiB2YWx1ZVxuICAgICAgfTtcbiAgICB9XG4gIH0sXG4gIC8qKlxuICAgKiBMb2FkZXIgcGx1Z2luIHRoYXQgcGFyc2VzIHNwcml0ZSBzaGVldHMhXG4gICAqIG9uY2UgdGhlIEpTT04gaGFzIGJlZW4gbG9hZGVkIHRoaXMgY2hlY2tzIHRvIHNlZSBpZiB0aGUgSlNPTiBpcyBzcHJpdGVzaGVldCBkYXRhLlxuICAgKiBJZiBpdCBpcywgd2UgbG9hZCB0aGUgc3ByaXRlc2hlZXRzIGltYWdlIGFuZCBwYXJzZSB0aGUgZGF0YSBpbnRvIFNwcml0ZXNoZWV0XG4gICAqIEFsbCB0ZXh0dXJlcyBpbiB0aGUgc3ByaXRlIHNoZWV0IGFyZSB0aGVuIGFkZGVkIHRvIHRoZSBjYWNoZVxuICAgKi9cbiAgbG9hZGVyOiB7XG4gICAgLyoqIHVzZWQgZm9yIGRlcHJlY2F0aW9uIHB1cnBvc2VzICovXG4gICAgbmFtZTogXCJzcHJpdGVzaGVldExvYWRlclwiLFxuICAgIGlkOiBcInNwcml0ZXNoZWV0XCIsXG4gICAgZXh0ZW5zaW9uOiB7XG4gICAgICB0eXBlOiBFeHRlbnNpb25UeXBlLkxvYWRQYXJzZXIsXG4gICAgICBwcmlvcml0eTogTG9hZGVyUGFyc2VyUHJpb3JpdHkuTm9ybWFsLFxuICAgICAgbmFtZTogXCJzcHJpdGVzaGVldExvYWRlclwiXG4gICAgfSxcbiAgICBhc3luYyB0ZXN0UGFyc2UoYXNzZXQsIG9wdGlvbnMpIHtcbiAgICAgIHJldHVybiBwYXRoLmV4dG5hbWUob3B0aW9ucy5zcmMpLnRvTG93ZXJDYXNlKCkgPT09IFwiLmpzb25cIiAmJiAhIWFzc2V0LmZyYW1lcztcbiAgICB9LFxuICAgIGFzeW5jIHBhcnNlKGFzc2V0LCBvcHRpb25zLCBsb2FkZXIpIHtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgdGV4dHVyZTogaW1hZ2VUZXh0dXJlLFxuICAgICAgICAvLyBpZiB1c2VyIG5lZWQgdG8gdXNlIHByZWxvYWRlZCB0ZXh0dXJlXG4gICAgICAgIGltYWdlRmlsZW5hbWUsXG4gICAgICAgIC8vIGlmIHVzZXIgbmVlZCB0byB1c2UgY3VzdG9tIGZpbGVuYW1lIChub3QgZnJvbSBqc29uRmlsZS5tZXRhLmltYWdlKVxuICAgICAgICB0ZXh0dXJlT3B0aW9ucyxcbiAgICAgICAgLy8gaWYgdXNlciBuZWVkIHRvIHNldCB0ZXh0dXJlIG9wdGlvbnMgb24gdGV4dHVyZVxuICAgICAgICBjYWNoZVByZWZpeFxuICAgICAgICAvLyBpZiB1c2VyIG5lZWQgdG8gdXNlIGN1c3RvbSBjYWNoZSBwcmVmaXhcbiAgICAgIH0gPSBvcHRpb25zPy5kYXRhID8/IHt9O1xuICAgICAgbGV0IGJhc2VQYXRoID0gcGF0aC5kaXJuYW1lKG9wdGlvbnMuc3JjKTtcbiAgICAgIGlmIChiYXNlUGF0aCAmJiBiYXNlUGF0aC5sYXN0SW5kZXhPZihcIi9cIikgIT09IGJhc2VQYXRoLmxlbmd0aCAtIDEpIHtcbiAgICAgICAgYmFzZVBhdGggKz0gXCIvXCI7XG4gICAgICB9XG4gICAgICBsZXQgdGV4dHVyZTtcbiAgICAgIGlmIChpbWFnZVRleHR1cmUgaW5zdGFuY2VvZiBUZXh0dXJlKSB7XG4gICAgICAgIHRleHR1cmUgPSBpbWFnZVRleHR1cmU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBpbWFnZVBhdGggPSBjb3B5U2VhcmNoUGFyYW1zKGJhc2VQYXRoICsgKGltYWdlRmlsZW5hbWUgPz8gYXNzZXQubWV0YS5pbWFnZSksIG9wdGlvbnMuc3JjKTtcbiAgICAgICAgY29uc3QgYXNzZXRzID0gYXdhaXQgbG9hZGVyLmxvYWQoW3sgc3JjOiBpbWFnZVBhdGgsIGRhdGE6IHRleHR1cmVPcHRpb25zIH1dKTtcbiAgICAgICAgdGV4dHVyZSA9IGFzc2V0c1tpbWFnZVBhdGhdO1xuICAgICAgfVxuICAgICAgY29uc3Qgc3ByaXRlc2hlZXQgPSBuZXcgU3ByaXRlc2hlZXQoe1xuICAgICAgICB0ZXh0dXJlOiB0ZXh0dXJlLnNvdXJjZSxcbiAgICAgICAgZGF0YTogYXNzZXQsXG4gICAgICAgIGNhY2hlUHJlZml4XG4gICAgICB9KTtcbiAgICAgIGF3YWl0IHNwcml0ZXNoZWV0LnBhcnNlKCk7XG4gICAgICBjb25zdCBtdWx0aVBhY2tzID0gYXNzZXQ/Lm1ldGE/LnJlbGF0ZWRfbXVsdGlfcGFja3M7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShtdWx0aVBhY2tzKSkge1xuICAgICAgICBjb25zdCBwcm9taXNlcyA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgbXVsdGlQYWNrcykge1xuICAgICAgICAgIGlmICh0eXBlb2YgaXRlbSAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGxldCBpdGVtVXJsID0gYmFzZVBhdGggKyBpdGVtO1xuICAgICAgICAgIGlmIChvcHRpb25zLmRhdGE/Lmlnbm9yZU11bHRpUGFjaykge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGl0ZW1VcmwgPSBjb3B5U2VhcmNoUGFyYW1zKGl0ZW1VcmwsIG9wdGlvbnMuc3JjKTtcbiAgICAgICAgICBwcm9taXNlcy5wdXNoKGxvYWRlci5sb2FkKHtcbiAgICAgICAgICAgIHNyYzogaXRlbVVybCxcbiAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgdGV4dHVyZU9wdGlvbnMsXG4gICAgICAgICAgICAgIGlnbm9yZU11bHRpUGFjazogdHJ1ZVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBQcm9taXNlLmFsbChwcm9taXNlcyk7XG4gICAgICAgIHNwcml0ZXNoZWV0LmxpbmtlZFNoZWV0cyA9IHJlcztcbiAgICAgICAgcmVzLmZvckVhY2goKGl0ZW0pID0+IHtcbiAgICAgICAgICBpdGVtLmxpbmtlZFNoZWV0cyA9IFtzcHJpdGVzaGVldF0uY29uY2F0KHNwcml0ZXNoZWV0LmxpbmtlZFNoZWV0cy5maWx0ZXIoKHNwKSA9PiBzcCAhPT0gaXRlbSkpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBzcHJpdGVzaGVldDtcbiAgICB9LFxuICAgIGFzeW5jIHVubG9hZChzcHJpdGVzaGVldCwgX3Jlc29sdmVkQXNzZXQsIGxvYWRlcikge1xuICAgICAgYXdhaXQgbG9hZGVyLnVubG9hZChzcHJpdGVzaGVldC50ZXh0dXJlU291cmNlLl9zb3VyY2VPcmlnaW4pO1xuICAgICAgc3ByaXRlc2hlZXQuZGVzdHJveShmYWxzZSk7XG4gICAgfVxuICB9XG59O1xuXG5leHBvcnQgeyBzcHJpdGVzaGVldEFzc2V0IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zcHJpdGVzaGVldEFzc2V0Lm1qcy5tYXBcbiIsImltcG9ydCB7IGV4dGVuc2lvbnMgfSBmcm9tICcuLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IHNwcml0ZXNoZWV0QXNzZXQgfSBmcm9tICcuL3Nwcml0ZXNoZWV0QXNzZXQubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5leHRlbnNpb25zLmFkZChzcHJpdGVzaGVldEFzc2V0KTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluaXQubWpzLm1hcFxuIiwiaW1wb3J0ICcuLi8uLi8uLi9tYXRocy9pbmRleC5tanMnO1xuaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vLi4vLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IHRlbXBQcm9qZWN0aW9uTWF0cml4ID0gbmV3IE1hdHJpeCgpO1xuZnVuY3Rpb24gZ2V0R2xvYmFsUmVuZGVyYWJsZUJvdW5kcyhyZW5kZXJhYmxlcywgYm91bmRzKSB7XG4gIGJvdW5kcy5jbGVhcigpO1xuICBjb25zdCBhY3R1YWxNYXRyaXggPSBib3VuZHMubWF0cml4O1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHJlbmRlcmFibGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgcmVuZGVyYWJsZSA9IHJlbmRlcmFibGVzW2ldO1xuICAgIGlmIChyZW5kZXJhYmxlLmdsb2JhbERpc3BsYXlTdGF0dXMgPCA3KSB7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgcmVuZGVyR3JvdXAgPSByZW5kZXJhYmxlLnJlbmRlckdyb3VwID8/IHJlbmRlcmFibGUucGFyZW50UmVuZGVyR3JvdXA7XG4gICAgaWYgKHJlbmRlckdyb3VwPy5pc0NhY2hlZEFzVGV4dHVyZSkge1xuICAgICAgYm91bmRzLm1hdHJpeCA9IHRlbXBQcm9qZWN0aW9uTWF0cml4LmNvcHlGcm9tKHJlbmRlckdyb3VwLnRleHR1cmVPZmZzZXRJbnZlcnNlVHJhbnNmb3JtKS5hcHBlbmQocmVuZGVyYWJsZS53b3JsZFRyYW5zZm9ybSk7XG4gICAgfSBlbHNlIGlmIChyZW5kZXJHcm91cD8uX3BhcmVudENhY2hlQXNUZXh0dXJlUmVuZGVyR3JvdXApIHtcbiAgICAgIGJvdW5kcy5tYXRyaXggPSB0ZW1wUHJvamVjdGlvbk1hdHJpeC5jb3B5RnJvbShyZW5kZXJHcm91cC5fcGFyZW50Q2FjaGVBc1RleHR1cmVSZW5kZXJHcm91cC5pbnZlcnNlV29ybGRUcmFuc2Zvcm0pLmFwcGVuZChyZW5kZXJhYmxlLmdyb3VwVHJhbnNmb3JtKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYm91bmRzLm1hdHJpeCA9IHJlbmRlcmFibGUud29ybGRUcmFuc2Zvcm07XG4gICAgfVxuICAgIGJvdW5kcy5hZGRCb3VuZHMocmVuZGVyYWJsZS5ib3VuZHMpO1xuICB9XG4gIGJvdW5kcy5tYXRyaXggPSBhY3R1YWxNYXRyaXg7XG4gIHJldHVybiBib3VuZHM7XG59XG5cbmV4cG9ydCB7IGdldEdsb2JhbFJlbmRlcmFibGVCb3VuZHMgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWdldFJlbmRlcmFibGVCb3VuZHMubWpzLm1hcFxuIiwiaW1wb3J0IHsgVGV4dHVyZVBvb2wgfSBmcm9tICcuLi8uLi8uLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL1RleHR1cmVQb29sLm1qcyc7XG5pbXBvcnQgeyBCb3VuZHMgfSBmcm9tICcuLi8uLi9jb250YWluZXIvYm91bmRzL0JvdW5kcy5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IHRlbXBCb3VuZHMgPSBuZXcgQm91bmRzKCk7XG5mdW5jdGlvbiBnZXRQbzJUZXh0dXJlRnJvbVNvdXJjZShpbWFnZSwgd2lkdGgsIGhlaWdodCwgcmVzb2x1dGlvbiwgYXV0b0dlbmVyYXRlTWlwbWFwcyA9IGZhbHNlLCBzY2FsZU1vZGUpIHtcbiAgY29uc3QgYm91bmRzID0gdGVtcEJvdW5kcztcbiAgYm91bmRzLm1pblggPSAwO1xuICBib3VuZHMubWluWSA9IDA7XG4gIGJvdW5kcy5tYXhYID0gaW1hZ2Uud2lkdGggLyByZXNvbHV0aW9uIHwgMDtcbiAgYm91bmRzLm1heFkgPSBpbWFnZS5oZWlnaHQgLyByZXNvbHV0aW9uIHwgMDtcbiAgY29uc3QgdGV4dHVyZSA9IFRleHR1cmVQb29sLmdldE9wdGltYWxUZXh0dXJlKHtcbiAgICB3aWR0aDogYm91bmRzLndpZHRoLFxuICAgIGhlaWdodDogYm91bmRzLmhlaWdodCxcbiAgICByZXNvbHV0aW9uLFxuICAgIGF1dG9HZW5lcmF0ZU1pcG1hcHMsXG4gICAgc2NhbGVNb2RlXG4gIH0pO1xuICB0ZXh0dXJlLnNvdXJjZS51cGxvYWRNZXRob2RJZCA9IFwiaW1hZ2VcIjtcbiAgdGV4dHVyZS5zb3VyY2UucmVzb3VyY2UgPSBpbWFnZTtcbiAgdGV4dHVyZS5zb3VyY2UuYWxwaGFNb2RlID0gXCJwcmVtdWx0aXBseS1hbHBoYS1vbi11cGxvYWRcIjtcbiAgdGV4dHVyZS5mcmFtZS53aWR0aCA9IHdpZHRoIC8gcmVzb2x1dGlvbjtcbiAgdGV4dHVyZS5mcmFtZS5oZWlnaHQgPSBoZWlnaHQgLyByZXNvbHV0aW9uO1xuICB0ZXh0dXJlLnNvdXJjZS5lbWl0KFwidXBkYXRlXCIsIHRleHR1cmUuc291cmNlKTtcbiAgdGV4dHVyZS51cGRhdGVVdnMoKTtcbiAgcmV0dXJuIHRleHR1cmU7XG59XG5cbmV4cG9ydCB7IGdldFBvMlRleHR1cmVGcm9tU291cmNlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1nZXRQbzJUZXh0dXJlRnJvbVNvdXJjZS5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBjYW52YXNVdGlscyB9IGZyb20gJy4uL3JlbmRlcmluZy9yZW5kZXJlcnMvY2FudmFzL3V0aWxzL2NhbnZhc1V0aWxzLm1qcyc7XG5pbXBvcnQgeyBDYW52YXNQb29sIH0gZnJvbSAnLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvdGV4dHVyZS9DYW52YXNQb29sLm1qcyc7XG5pbXBvcnQgeyBCb3VuZHMgfSBmcm9tICcuLi9zY2VuZS9jb250YWluZXIvYm91bmRzL0JvdW5kcy5tanMnO1xuaW1wb3J0IHsgZ2V0R2xvYmFsUmVuZGVyYWJsZUJvdW5kcyB9IGZyb20gJy4uL3NjZW5lL2NvbnRhaW5lci9ib3VuZHMvZ2V0UmVuZGVyYWJsZUJvdW5kcy5tanMnO1xuaW1wb3J0IHsgZ2V0UG8yVGV4dHVyZUZyb21Tb3VyY2UgfSBmcm9tICcuLi9zY2VuZS90ZXh0L3V0aWxzL2dldFBvMlRleHR1cmVGcm9tU291cmNlLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuZnVuY3Rpb24gaXNDYW52YXNGaWx0ZXJDYXBhYmxlKGZpbHRlcikge1xuICByZXR1cm4gdHlwZW9mIGZpbHRlci5nZXRDYW52YXNGaWx0ZXJTdHJpbmcgPT09IFwiZnVuY3Rpb25cIjtcbn1cbmNsYXNzIENhbnZhc0ZpbHRlckZyYW1lIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5za2lwID0gZmFsc2U7XG4gICAgdGhpcy51c2VDbGlwID0gZmFsc2U7XG4gICAgdGhpcy5maWx0ZXJzID0gbnVsbDtcbiAgICB0aGlzLmNvbnRhaW5lciA9IG51bGw7XG4gICAgdGhpcy5ib3VuZHMgPSBuZXcgQm91bmRzKCk7XG4gICAgdGhpcy5jc3NGaWx0ZXJTdHJpbmcgPSBcIlwiO1xuICB9XG59XG5jbGFzcyBDYW52YXNGaWx0ZXJTeXN0ZW0ge1xuICAvKipcbiAgICogQHBhcmFtIHJlbmRlcmVyIC0gVGhlIENhbnZhcyByZW5kZXJlclxuICAgKiBAcGFyYW0gcmVuZGVyZXIuY2FudmFzQ29udGV4dFxuICAgKiBAcGFyYW0gcmVuZGVyZXIuY2FudmFzQ29udGV4dC5hY3RpdmVDb250ZXh0XG4gICAqIEBwYXJhbSByZW5kZXJlci5jYW52YXNDb250ZXh0LmFjdGl2ZVJlc29sdXRpb25cbiAgICovXG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgdGhpcy5fZmlsdGVyU3RhY2sgPSBbXTtcbiAgICB0aGlzLl9maWx0ZXJTdGFja0luZGV4ID0gMDtcbiAgICB0aGlzLl9zYXZlZFN0YXRlcyA9IFtdO1xuICAgIHRoaXMuX2FscGhhTXVsdGlwbGllciA9IDE7XG4gICAgdGhpcy5fd2FybmVkRmlsdGVyVHlwZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICAgIHRoaXMucmVuZGVyZXIgPSByZW5kZXJlcjtcbiAgfVxuICAvKipcbiAgICogUHVzaCBhIGZpbHRlciBpbnN0cnVjdGlvbiBvbnRvIHRoZSBzdGFjay5cbiAgICogQ2FsbGVkIHdoZW4gZW50ZXJpbmcgYSBmaWx0ZXJlZCBjb250YWluZXIuXG4gICAqIEBwYXJhbSBpbnN0cnVjdGlvbiAtIFRoZSBmaWx0ZXIgaW5zdHJ1Y3Rpb24gZnJvbSBGaWx0ZXJQaXBlXG4gICAqL1xuICBwdXNoKGluc3RydWN0aW9uKSB7XG4gICAgY29uc3QgZmlsdGVyRnJhbWUgPSB0aGlzLl9wdXNoRmlsdGVyRnJhbWUoKTtcbiAgICBjb25zdCBmaWx0ZXJzID0gaW5zdHJ1Y3Rpb24uZmlsdGVyRWZmZWN0LmZpbHRlcnM7XG4gICAgZmlsdGVyRnJhbWUuc2tpcCA9IGZhbHNlO1xuICAgIGZpbHRlckZyYW1lLnVzZUNsaXAgPSBmYWxzZTtcbiAgICBmaWx0ZXJGcmFtZS5maWx0ZXJzID0gZmlsdGVycztcbiAgICBmaWx0ZXJGcmFtZS5jb250YWluZXIgPSBpbnN0cnVjdGlvbi5jb250YWluZXI7XG4gICAgZmlsdGVyRnJhbWUuY3NzRmlsdGVyU3RyaW5nID0gXCJcIjtcbiAgICBpZiAoZmlsdGVycy5ldmVyeSgoZmlsdGVyKSA9PiAhZmlsdGVyLmVuYWJsZWQpKSB7XG4gICAgICBmaWx0ZXJGcmFtZS5za2lwID0gdHJ1ZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgY3NzRmlsdGVycyA9IFtdO1xuICAgIGNvbnN0IGFscGhhTXVsdGlwbGllciA9IDE7XG4gICAgZm9yIChjb25zdCBmaWx0ZXIgb2YgZmlsdGVycykge1xuICAgICAgaWYgKCFmaWx0ZXIuZW5hYmxlZCkgY29udGludWU7XG4gICAgICBpZiAoIWlzQ2FudmFzRmlsdGVyQ2FwYWJsZShmaWx0ZXIpKSB7XG4gICAgICAgIHRoaXMuX3dhcm5VbnN1cHBvcnRlZEZpbHRlcihmaWx0ZXIpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNzc1N0cmluZyA9IGZpbHRlci5nZXRDYW52YXNGaWx0ZXJTdHJpbmcoKTtcbiAgICAgIGlmIChjc3NTdHJpbmcgPT09IG51bGwpIHtcbiAgICAgICAgdGhpcy5fd2FyblVuc3VwcG9ydGVkRmlsdGVyKGZpbHRlcik7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYgKGNzc1N0cmluZykge1xuICAgICAgICBjc3NGaWx0ZXJzLnB1c2goY3NzU3RyaW5nKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGNzc0ZpbHRlcnMubGVuZ3RoID09PSAwICYmIGFscGhhTXVsdGlwbGllciA9PT0gMSkge1xuICAgICAgZmlsdGVyRnJhbWUuc2tpcCA9IHRydWU7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGZpbHRlckZyYW1lLmNzc0ZpbHRlclN0cmluZyA9IGNzc0ZpbHRlcnMuam9pbihcIiBcIik7XG4gICAgdGhpcy5fY2FsY3VsYXRlRmlsdGVyQXJlYShpbnN0cnVjdGlvbiwgZmlsdGVyRnJhbWUuYm91bmRzKTtcbiAgICBmaWx0ZXJGcmFtZS51c2VDbGlwID0gISFpbnN0cnVjdGlvbi5maWx0ZXJFZmZlY3QuZmlsdGVyQXJlYTtcbiAgICBjb25zdCBjb250ZXh0ID0gdGhpcy5yZW5kZXJlci5jYW52YXNDb250ZXh0LmFjdGl2ZUNvbnRleHQ7XG4gICAgY29uc3QgcHJldmlvdXNGaWx0ZXIgPSBjb250ZXh0LmZpbHRlciB8fCBcIm5vbmVcIjtcbiAgICB0aGlzLl9zYXZlZFN0YXRlcy5wdXNoKHsgZmlsdGVyOiBwcmV2aW91c0ZpbHRlciwgYWxwaGFNdWx0aXBsaWVyOiB0aGlzLl9hbHBoYU11bHRpcGxpZXIgfSk7XG4gICAgaWYgKGZpbHRlckZyYW1lLnVzZUNsaXAgJiYgTnVtYmVyLmlzRmluaXRlKGZpbHRlckZyYW1lLmJvdW5kcy53aWR0aCkgJiYgTnVtYmVyLmlzRmluaXRlKGZpbHRlckZyYW1lLmJvdW5kcy5oZWlnaHQpICYmIGZpbHRlckZyYW1lLmJvdW5kcy53aWR0aCA+IDAgJiYgZmlsdGVyRnJhbWUuYm91bmRzLmhlaWdodCA+IDApIHtcbiAgICAgIGNvbnN0IHJlc29sdXRpb24gPSB0aGlzLnJlbmRlcmVyLmNhbnZhc0NvbnRleHQuYWN0aXZlUmVzb2x1dGlvbiB8fCAxO1xuICAgICAgY29udGV4dC5zYXZlKCk7XG4gICAgICBjb250ZXh0LnNldFRyYW5zZm9ybSgxLCAwLCAwLCAxLCAwLCAwKTtcbiAgICAgIGNvbnRleHQuYmVnaW5QYXRoKCk7XG4gICAgICBjb250ZXh0LnJlY3QoXG4gICAgICAgIGZpbHRlckZyYW1lLmJvdW5kcy54ICogcmVzb2x1dGlvbixcbiAgICAgICAgZmlsdGVyRnJhbWUuYm91bmRzLnkgKiByZXNvbHV0aW9uLFxuICAgICAgICBmaWx0ZXJGcmFtZS5ib3VuZHMud2lkdGggKiByZXNvbHV0aW9uLFxuICAgICAgICBmaWx0ZXJGcmFtZS5ib3VuZHMuaGVpZ2h0ICogcmVzb2x1dGlvblxuICAgICAgKTtcbiAgICAgIGNvbnRleHQuY2xpcCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBmaWx0ZXJGcmFtZS51c2VDbGlwID0gZmFsc2U7XG4gICAgfVxuICAgIGlmIChhbHBoYU11bHRpcGxpZXIgIT09IDEpIHtcbiAgICAgIHRoaXMuX2FscGhhTXVsdGlwbGllciAqPSBhbHBoYU11bHRpcGxpZXI7XG4gICAgfVxuICAgIGlmIChmaWx0ZXJGcmFtZS5jc3NGaWx0ZXJTdHJpbmcpIHtcbiAgICAgIGNvbnRleHQuZmlsdGVyID0gcHJldmlvdXNGaWx0ZXIgIT09IFwibm9uZVwiID8gYCR7cHJldmlvdXNGaWx0ZXJ9ICR7ZmlsdGVyRnJhbWUuY3NzRmlsdGVyU3RyaW5nfWAgOiBmaWx0ZXJGcmFtZS5jc3NGaWx0ZXJTdHJpbmc7XG4gICAgfVxuICB9XG4gIC8qKiBQb3AgYSBmaWx0ZXIgZnJvbSB0aGUgc3RhY2suIENhbGxlZCB3aGVuIGV4aXRpbmcgYSBmaWx0ZXJlZCBjb250YWluZXIuICovXG4gIHBvcCgpIHtcbiAgICBjb25zdCBmaWx0ZXJGcmFtZSA9IHRoaXMuX3BvcEZpbHRlckZyYW1lKCk7XG4gICAgaWYgKGZpbHRlckZyYW1lLnNraXApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgc2F2ZWRTdGF0ZSA9IHRoaXMuX3NhdmVkU3RhdGVzLnBvcCgpO1xuICAgIGlmICghc2F2ZWRTdGF0ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjb250ZXh0ID0gdGhpcy5yZW5kZXJlci5jYW52YXNDb250ZXh0LmFjdGl2ZUNvbnRleHQ7XG4gICAgaWYgKGZpbHRlckZyYW1lLnVzZUNsaXApIHtcbiAgICAgIGNvbnRleHQucmVzdG9yZSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb250ZXh0LmZpbHRlciA9IHNhdmVkU3RhdGUuZmlsdGVyO1xuICAgIH1cbiAgICB0aGlzLl9hbHBoYU11bHRpcGxpZXIgPSBzYXZlZFN0YXRlLmFscGhhTXVsdGlwbGllcjtcbiAgfVxuICAvKipcbiAgICogQXBwbGllcyBzdXBwb3J0ZWQgZmlsdGVycyB0byBhIHRleHR1cmUgYW5kIHJldHVybnMgYSBuZXcgdGV4dHVyZS5cbiAgICogVW5zdXBwb3J0ZWQgZmlsdGVycyBhcmUgc2tpcHBlZCB3aXRoIGEgd2Fybi1vbmNlIG1lc3NhZ2UuXG4gICAqIEBwYXJhbSBwYXJhbXMgLSBUaGUgcGFyYW1ldGVycyBmb3IgYXBwbHlpbmcgZmlsdGVycy5cbiAgICogQHBhcmFtIHBhcmFtcy50ZXh0dXJlXG4gICAqIEBwYXJhbSBwYXJhbXMuZmlsdGVyc1xuICAgKiBAcmV0dXJucyBUaGUgcmVzdWx0aW5nIHRleHR1cmUgYWZ0ZXIgZmlsdGVycyBhcmUgYXBwbGllZC5cbiAgICovXG4gIGdlbmVyYXRlRmlsdGVyZWRUZXh0dXJlKHsgdGV4dHVyZSwgZmlsdGVycyB9KSB7XG4gICAgaWYgKCFmaWx0ZXJzPy5sZW5ndGggfHwgZmlsdGVycy5ldmVyeSgoZmlsdGVyKSA9PiAhZmlsdGVyLmVuYWJsZWQpKSB7XG4gICAgICByZXR1cm4gdGV4dHVyZTtcbiAgICB9XG4gICAgY29uc3QgY3NzRmlsdGVycyA9IFtdO1xuICAgIGNvbnN0IGFscGhhTXVsdGlwbGllciA9IDE7XG4gICAgZm9yIChjb25zdCBmaWx0ZXIgb2YgZmlsdGVycykge1xuICAgICAgaWYgKCFmaWx0ZXIuZW5hYmxlZCkgY29udGludWU7XG4gICAgICBpZiAoIWlzQ2FudmFzRmlsdGVyQ2FwYWJsZShmaWx0ZXIpKSB7XG4gICAgICAgIHRoaXMuX3dhcm5VbnN1cHBvcnRlZEZpbHRlcihmaWx0ZXIpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNzc1N0cmluZyA9IGZpbHRlci5nZXRDYW52YXNGaWx0ZXJTdHJpbmcoKTtcbiAgICAgIGlmIChjc3NTdHJpbmcgPT09IG51bGwpIHtcbiAgICAgICAgdGhpcy5fd2FyblVuc3VwcG9ydGVkRmlsdGVyKGZpbHRlcik7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYgKGNzc1N0cmluZykge1xuICAgICAgICBjc3NGaWx0ZXJzLnB1c2goY3NzU3RyaW5nKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGNzc0ZpbHRlcnMubGVuZ3RoID09PSAwICYmIGFscGhhTXVsdGlwbGllciA9PT0gMSkge1xuICAgICAgcmV0dXJuIHRleHR1cmU7XG4gICAgfVxuICAgIGNvbnN0IHNvdXJjZSA9IGNhbnZhc1V0aWxzLmdldENhbnZhc1NvdXJjZSh0ZXh0dXJlKTtcbiAgICBpZiAoIXNvdXJjZSkge1xuICAgICAgcmV0dXJuIHRleHR1cmU7XG4gICAgfVxuICAgIGNvbnN0IGZyYW1lID0gdGV4dHVyZS5mcmFtZTtcbiAgICBjb25zdCByZXNvbHV0aW9uID0gdGV4dHVyZS5zb3VyY2UuX3Jlc29sdXRpb24gPz8gdGV4dHVyZS5zb3VyY2UucmVzb2x1dGlvbiA/PyAxO1xuICAgIGNvbnN0IHdpZHRoID0gZnJhbWUud2lkdGg7XG4gICAgY29uc3QgaGVpZ2h0ID0gZnJhbWUuaGVpZ2h0O1xuICAgIGNvbnN0IGNhbnZhc0FuZENvbnRleHQgPSBDYW52YXNQb29sLmdldE9wdGltYWxDYW52YXNBbmRDb250ZXh0KHdpZHRoLCBoZWlnaHQsIHJlc29sdXRpb24pO1xuICAgIGNvbnN0IHsgY2FudmFzLCBjb250ZXh0IH0gPSBjYW52YXNBbmRDb250ZXh0O1xuICAgIGNvbnRleHQuc2V0VHJhbnNmb3JtKDEsIDAsIDAsIDEsIDAsIDApO1xuICAgIGNvbnRleHQuY2xlYXJSZWN0KDAsIDAsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCk7XG4gICAgaWYgKGNzc0ZpbHRlcnMubGVuZ3RoKSB7XG4gICAgICBjb250ZXh0LmZpbHRlciA9IGNzc0ZpbHRlcnMuam9pbihcIiBcIik7XG4gICAgfVxuICAgIGlmIChhbHBoYU11bHRpcGxpZXIgIT09IDEpIHtcbiAgICAgIGNvbnRleHQuZ2xvYmFsQWxwaGEgPSBhbHBoYU11bHRpcGxpZXI7XG4gICAgfVxuICAgIGNvbnN0IHN4ID0gZnJhbWUueCAqIHJlc29sdXRpb247XG4gICAgY29uc3Qgc3kgPSBmcmFtZS55ICogcmVzb2x1dGlvbjtcbiAgICBjb25zdCBzdyA9IHdpZHRoICogcmVzb2x1dGlvbjtcbiAgICBjb25zdCBzaCA9IGhlaWdodCAqIHJlc29sdXRpb247XG4gICAgY29udGV4dC5kcmF3SW1hZ2UoXG4gICAgICBzb3VyY2UsXG4gICAgICBzeCxcbiAgICAgIHN5LFxuICAgICAgc3csXG4gICAgICBzaCxcbiAgICAgIDAsXG4gICAgICAwLFxuICAgICAgc3csXG4gICAgICBzaFxuICAgICk7XG4gICAgY29udGV4dC5maWx0ZXIgPSBcIm5vbmVcIjtcbiAgICBjb250ZXh0Lmdsb2JhbEFscGhhID0gMTtcbiAgICByZXR1cm4gZ2V0UG8yVGV4dHVyZUZyb21Tb3VyY2UoY2FudmFzLCB3aWR0aCwgaGVpZ2h0LCByZXNvbHV0aW9uKTtcbiAgfVxuICAvKipcbiAgICogQ2FsY3VsYXRlIHRoZSBmaWx0ZXIgYXJlYSBib3VuZHMuXG4gICAqIEBwYXJhbSBpbnN0cnVjdGlvbiAtIEZpbHRlciBpbnN0cnVjdGlvblxuICAgKiBAcGFyYW0gYm91bmRzIC0gQm91bmRzIG9iamVjdCB0byBwb3B1bGF0ZVxuICAgKi9cbiAgX2NhbGN1bGF0ZUZpbHRlckFyZWEoaW5zdHJ1Y3Rpb24sIGJvdW5kcykge1xuICAgIGlmIChpbnN0cnVjdGlvbi5yZW5kZXJhYmxlcykge1xuICAgICAgZ2V0R2xvYmFsUmVuZGVyYWJsZUJvdW5kcyhpbnN0cnVjdGlvbi5yZW5kZXJhYmxlcywgYm91bmRzKTtcbiAgICB9IGVsc2UgaWYgKGluc3RydWN0aW9uLmZpbHRlckVmZmVjdC5maWx0ZXJBcmVhKSB7XG4gICAgICBib3VuZHMuY2xlYXIoKTtcbiAgICAgIGJvdW5kcy5hZGRSZWN0KGluc3RydWN0aW9uLmZpbHRlckVmZmVjdC5maWx0ZXJBcmVhKTtcbiAgICAgIGJvdW5kcy5hcHBseU1hdHJpeChpbnN0cnVjdGlvbi5jb250YWluZXIud29ybGRUcmFuc2Zvcm0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBpbnN0cnVjdGlvbi5jb250YWluZXIuZ2V0RmFzdEdsb2JhbEJvdW5kcyh0cnVlLCBib3VuZHMpO1xuICAgIH1cbiAgICBpZiAoaW5zdHJ1Y3Rpb24uY29udGFpbmVyKSB7XG4gICAgICBjb25zdCByZW5kZXJHcm91cCA9IGluc3RydWN0aW9uLmNvbnRhaW5lci5yZW5kZXJHcm91cCB8fCBpbnN0cnVjdGlvbi5jb250YWluZXIucGFyZW50UmVuZGVyR3JvdXA7XG4gICAgICBjb25zdCBmaWx0ZXJGcmFtZVRyYW5zZm9ybSA9IHJlbmRlckdyb3VwPy5jYWNoZVRvTG9jYWxUcmFuc2Zvcm07XG4gICAgICBpZiAoZmlsdGVyRnJhbWVUcmFuc2Zvcm0pIHtcbiAgICAgICAgYm91bmRzLmFwcGx5TWF0cml4KGZpbHRlckZyYW1lVHJhbnNmb3JtKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgX3dhcm5VbnN1cHBvcnRlZEZpbHRlcihmaWx0ZXIpIHtcbiAgICBjb25zdCBmaWx0ZXJOYW1lID0gZmlsdGVyPy5jb25zdHJ1Y3Rvcj8ubmFtZSB8fCBcIkZpbHRlclwiO1xuICAgIGlmICh0aGlzLl93YXJuZWRGaWx0ZXJUeXBlcy5oYXMoZmlsdGVyTmFtZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5fd2FybmVkRmlsdGVyVHlwZXMuYWRkKGZpbHRlck5hbWUpO1xuICAgIGNvbnNvbGUud2FybihcbiAgICAgIGBDYW52YXNSZW5kZXJlcjogZmlsdGVyIFwiJHtmaWx0ZXJOYW1lfVwiIGlzIG5vdCBzdXBwb3J0ZWQgaW4gQ2FudmFzMkQgYW5kIHdpbGwgYmUgc2tpcHBlZC5gXG4gICAgKTtcbiAgfVxuICBnZXQgYWxwaGFNdWx0aXBsaWVyKCkge1xuICAgIHJldHVybiB0aGlzLl9hbHBoYU11bHRpcGxpZXI7XG4gIH1cbiAgX3B1c2hGaWx0ZXJGcmFtZSgpIHtcbiAgICBsZXQgZmlsdGVyRnJhbWUgPSB0aGlzLl9maWx0ZXJTdGFja1t0aGlzLl9maWx0ZXJTdGFja0luZGV4XTtcbiAgICBpZiAoIWZpbHRlckZyYW1lKSB7XG4gICAgICBmaWx0ZXJGcmFtZSA9IHRoaXMuX2ZpbHRlclN0YWNrW3RoaXMuX2ZpbHRlclN0YWNrSW5kZXhdID0gbmV3IENhbnZhc0ZpbHRlckZyYW1lKCk7XG4gICAgfVxuICAgIHRoaXMuX2ZpbHRlclN0YWNrSW5kZXgrKztcbiAgICByZXR1cm4gZmlsdGVyRnJhbWU7XG4gIH1cbiAgX3BvcEZpbHRlckZyYW1lKCkge1xuICAgIGlmICh0aGlzLl9maWx0ZXJTdGFja0luZGV4IDw9IDApIHtcbiAgICAgIHJldHVybiB0aGlzLl9maWx0ZXJTdGFja1swXTtcbiAgICB9XG4gICAgdGhpcy5fZmlsdGVyU3RhY2tJbmRleC0tO1xuICAgIHJldHVybiB0aGlzLl9maWx0ZXJTdGFja1t0aGlzLl9maWx0ZXJTdGFja0luZGV4XTtcbiAgfVxuICAvKiogRGVzdHJveXMgdGhlIHN5c3RlbSAqL1xuICBkZXN0cm95KCkge1xuICAgIHRoaXMuX2ZpbHRlclN0YWNrID0gbnVsbDtcbiAgICB0aGlzLl9zYXZlZFN0YXRlcyA9IG51bGw7XG4gICAgdGhpcy5fd2FybmVkRmlsdGVyVHlwZXMgPSBudWxsO1xuICAgIHRoaXMuX2FscGhhTXVsdGlwbGllciA9IDE7XG4gIH1cbn1cbi8qKiBAaWdub3JlICovXG5DYW52YXNGaWx0ZXJTeXN0ZW0uZXh0ZW5zaW9uID0ge1xuICB0eXBlOiBbRXh0ZW5zaW9uVHlwZS5DYW52YXNTeXN0ZW1dLFxuICBuYW1lOiBcImZpbHRlclwiXG59O1xuXG5leHBvcnQgeyBDYW52YXNGaWx0ZXJTeXN0ZW0sIGlzQ2FudmFzRmlsdGVyQ2FwYWJsZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Q2FudmFzRmlsdGVyU3lzdGVtLm1qcy5tYXBcbiIsInZhciB2ZXJ0ZXggPSBcImluIHZlYzIgYVBvc2l0aW9uO1xcbm91dCB2ZWMyIHZUZXh0dXJlQ29vcmQ7XFxuXFxudW5pZm9ybSB2ZWM0IHVJbnB1dFNpemU7XFxudW5pZm9ybSB2ZWM0IHVPdXRwdXRGcmFtZTtcXG51bmlmb3JtIHZlYzQgdU91dHB1dFRleHR1cmU7XFxuXFxudmVjNCBmaWx0ZXJWZXJ0ZXhQb3NpdGlvbiggdm9pZCApXFxue1xcbiAgICB2ZWMyIHBvc2l0aW9uID0gYVBvc2l0aW9uICogdU91dHB1dEZyYW1lLnp3ICsgdU91dHB1dEZyYW1lLnh5O1xcbiAgICBcXG4gICAgcG9zaXRpb24ueCA9IHBvc2l0aW9uLnggKiAoMi4wIC8gdU91dHB1dFRleHR1cmUueCkgLSAxLjA7XFxuICAgIHBvc2l0aW9uLnkgPSBwb3NpdGlvbi55ICogKDIuMCp1T3V0cHV0VGV4dHVyZS56IC8gdU91dHB1dFRleHR1cmUueSkgLSB1T3V0cHV0VGV4dHVyZS56O1xcblxcbiAgICByZXR1cm4gdmVjNChwb3NpdGlvbiwgMC4wLCAxLjApO1xcbn1cXG5cXG52ZWMyIGZpbHRlclRleHR1cmVDb29yZCggdm9pZCApXFxue1xcbiAgICByZXR1cm4gYVBvc2l0aW9uICogKHVPdXRwdXRGcmFtZS56dyAqIHVJbnB1dFNpemUuencpO1xcbn1cXG5cXG52b2lkIG1haW4odm9pZClcXG57XFxuICAgIGdsX1Bvc2l0aW9uID0gZmlsdGVyVmVydGV4UG9zaXRpb24oKTtcXG4gICAgdlRleHR1cmVDb29yZCA9IGZpbHRlclRleHR1cmVDb29yZCgpO1xcbn1cXG5cIjtcblxuZXhwb3J0IHsgdmVydGV4IGFzIGRlZmF1bHQgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRlZmF1bHRGaWx0ZXIudmVydC5tanMubWFwXG4iLCJ2YXIgZnJhZ21lbnQgPSBcImluIHZlYzIgdlRleHR1cmVDb29yZDtcXG5vdXQgdmVjNCBmaW5hbENvbG9yO1xcbnVuaWZvcm0gc2FtcGxlcjJEIHVUZXh0dXJlO1xcbnZvaWQgbWFpbigpIHtcXG4gICAgZmluYWxDb2xvciA9IHRleHR1cmUodVRleHR1cmUsIHZUZXh0dXJlQ29vcmQpO1xcbn1cXG5cIjtcblxuZXhwb3J0IHsgZnJhZ21lbnQgYXMgZGVmYXVsdCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cGFzc3Rocm91Z2guZnJhZy5tanMubWFwXG4iLCJ2YXIgc291cmNlID0gXCJzdHJ1Y3QgR2xvYmFsRmlsdGVyVW5pZm9ybXMge1xcbiAgdUlucHV0U2l6ZTogdmVjNDxmMzI+LFxcbiAgdUlucHV0UGl4ZWw6IHZlYzQ8ZjMyPixcXG4gIHVJbnB1dENsYW1wOiB2ZWM0PGYzMj4sXFxuICB1T3V0cHV0RnJhbWU6IHZlYzQ8ZjMyPixcXG4gIHVHbG9iYWxGcmFtZTogdmVjNDxmMzI+LFxcbiAgdU91dHB1dFRleHR1cmU6IHZlYzQ8ZjMyPixcXG59O1xcblxcbkBncm91cCgwKSBAYmluZGluZygwKSB2YXIgPHVuaWZvcm0+IGdmdTogR2xvYmFsRmlsdGVyVW5pZm9ybXM7XFxuQGdyb3VwKDApIEBiaW5kaW5nKDEpIHZhciB1VGV4dHVyZTogdGV4dHVyZV8yZDxmMzI+O1xcbkBncm91cCgwKSBAYmluZGluZygyKSB2YXIgdVNhbXBsZXI6IHNhbXBsZXI7XFxuXFxuc3RydWN0IFZTT3V0cHV0IHtcXG4gIEBidWlsdGluKHBvc2l0aW9uKSBwb3NpdGlvbjogdmVjNDxmMzI+LFxcbiAgQGxvY2F0aW9uKDApIHV2OiB2ZWMyPGYzMj5cXG59O1xcblxcbmZuIGZpbHRlclZlcnRleFBvc2l0aW9uKGFQb3NpdGlvbjogdmVjMjxmMzI+KSAtPiB2ZWM0PGYzMj5cXG57XFxuICAgIHZhciBwb3NpdGlvbiA9IGFQb3NpdGlvbiAqIGdmdS51T3V0cHV0RnJhbWUuencgKyBnZnUudU91dHB1dEZyYW1lLnh5O1xcblxcbiAgICBwb3NpdGlvbi54ID0gcG9zaXRpb24ueCAqICgyLjAgLyBnZnUudU91dHB1dFRleHR1cmUueCkgLSAxLjA7XFxuICAgIHBvc2l0aW9uLnkgPSBwb3NpdGlvbi55ICogKDIuMCAqIGdmdS51T3V0cHV0VGV4dHVyZS56IC8gZ2Z1LnVPdXRwdXRUZXh0dXJlLnkpIC0gZ2Z1LnVPdXRwdXRUZXh0dXJlLno7XFxuXFxuICAgIHJldHVybiB2ZWM0KHBvc2l0aW9uLCAwLjAsIDEuMCk7XFxufVxcblxcbmZuIGZpbHRlclRleHR1cmVDb29yZChhUG9zaXRpb246IHZlYzI8ZjMyPikgLT4gdmVjMjxmMzI+XFxue1xcbiAgICByZXR1cm4gYVBvc2l0aW9uICogKGdmdS51T3V0cHV0RnJhbWUuencgKiBnZnUudUlucHV0U2l6ZS56dyk7XFxufVxcblxcbkB2ZXJ0ZXhcXG5mbiBtYWluVmVydGV4KFxcbiAgQGxvY2F0aW9uKDApIGFQb3NpdGlvbjogdmVjMjxmMzI+LFxcbikgLT4gVlNPdXRwdXQge1xcbiAgcmV0dXJuIFZTT3V0cHV0KFxcbiAgIGZpbHRlclZlcnRleFBvc2l0aW9uKGFQb3NpdGlvbiksXFxuICAgZmlsdGVyVGV4dHVyZUNvb3JkKGFQb3NpdGlvbilcXG4gICk7XFxufVxcblxcbkBmcmFnbWVudFxcbmZuIG1haW5GcmFnbWVudChcXG4gIEBsb2NhdGlvbigwKSB1djogdmVjMjxmMzI+LFxcbikgLT4gQGxvY2F0aW9uKDApIHZlYzQ8ZjMyPiB7XFxuICAgIHJldHVybiB0ZXh0dXJlU2FtcGxlKHVUZXh0dXJlLCB1U2FtcGxlciwgdXYpO1xcbn1cXG5cIjtcblxuZXhwb3J0IHsgc291cmNlIGFzIGRlZmF1bHQgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhc3N0aHJvdWdoLndnc2wubWpzLm1hcFxuIiwiaW1wb3J0IHsgR2xQcm9ncmFtIH0gZnJvbSAnLi4vLi4vLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9nbC9zaGFkZXIvR2xQcm9ncmFtLm1qcyc7XG5pbXBvcnQgeyBHcHVQcm9ncmFtIH0gZnJvbSAnLi4vLi4vLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9ncHUvc2hhZGVyL0dwdVByb2dyYW0ubWpzJztcbmltcG9ydCB7IEZpbHRlciB9IGZyb20gJy4uLy4uL0ZpbHRlci5tanMnO1xuaW1wb3J0IHZlcnRleCBmcm9tICcuLi9kZWZhdWx0RmlsdGVyLnZlcnQubWpzJztcbmltcG9ydCBmcmFnbWVudCBmcm9tICcuL3Bhc3N0aHJvdWdoLmZyYWcubWpzJztcbmltcG9ydCBzb3VyY2UgZnJvbSAnLi9wYXNzdGhyb3VnaC53Z3NsLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgUGFzc3Rocm91Z2hGaWx0ZXIgZXh0ZW5kcyBGaWx0ZXIge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBjb25zdCBncHVQcm9ncmFtID0gR3B1UHJvZ3JhbS5mcm9tKHtcbiAgICAgIHZlcnRleDogeyBzb3VyY2UsIGVudHJ5UG9pbnQ6IFwibWFpblZlcnRleFwiIH0sXG4gICAgICBmcmFnbWVudDogeyBzb3VyY2UsIGVudHJ5UG9pbnQ6IFwibWFpbkZyYWdtZW50XCIgfSxcbiAgICAgIG5hbWU6IFwicGFzc3Rocm91Z2gtZmlsdGVyXCJcbiAgICB9KTtcbiAgICBjb25zdCBnbFByb2dyYW0gPSBHbFByb2dyYW0uZnJvbSh7XG4gICAgICB2ZXJ0ZXgsXG4gICAgICBmcmFnbWVudCxcbiAgICAgIG5hbWU6IFwicGFzc3Rocm91Z2gtZmlsdGVyXCJcbiAgICB9KTtcbiAgICBzdXBlcih7XG4gICAgICBncHVQcm9ncmFtLFxuICAgICAgZ2xQcm9ncmFtXG4gICAgfSk7XG4gIH1cbn1cblxuZXhwb3J0IHsgUGFzc3Rocm91Z2hGaWx0ZXIgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVBhc3N0aHJvdWdoRmlsdGVyLm1qcy5tYXBcbiIsImltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBGaWx0ZXJQaXBlIHtcbiAgY29uc3RydWN0b3IocmVuZGVyZXIpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IHJlbmRlcmVyO1xuICB9XG4gIHB1c2goZmlsdGVyRWZmZWN0LCBjb250YWluZXIsIGluc3RydWN0aW9uU2V0KSB7XG4gICAgY29uc3QgcmVuZGVyUGlwZXMgPSB0aGlzLl9yZW5kZXJlci5yZW5kZXJQaXBlcztcbiAgICByZW5kZXJQaXBlcy5iYXRjaC5icmVhayhpbnN0cnVjdGlvblNldCk7XG4gICAgaW5zdHJ1Y3Rpb25TZXQuYWRkKHtcbiAgICAgIHJlbmRlclBpcGVJZDogXCJmaWx0ZXJcIixcbiAgICAgIGNhbkJ1bmRsZTogZmFsc2UsXG4gICAgICBhY3Rpb246IFwicHVzaEZpbHRlclwiLFxuICAgICAgY29udGFpbmVyLFxuICAgICAgZmlsdGVyRWZmZWN0XG4gICAgfSk7XG4gIH1cbiAgcG9wKF9maWx0ZXJFZmZlY3QsIF9jb250YWluZXIsIGluc3RydWN0aW9uU2V0KSB7XG4gICAgdGhpcy5fcmVuZGVyZXIucmVuZGVyUGlwZXMuYmF0Y2guYnJlYWsoaW5zdHJ1Y3Rpb25TZXQpO1xuICAgIGluc3RydWN0aW9uU2V0LmFkZCh7XG4gICAgICByZW5kZXJQaXBlSWQ6IFwiZmlsdGVyXCIsXG4gICAgICBhY3Rpb246IFwicG9wRmlsdGVyXCIsXG4gICAgICBjYW5CdW5kbGU6IGZhbHNlXG4gICAgfSk7XG4gIH1cbiAgZXhlY3V0ZShpbnN0cnVjdGlvbikge1xuICAgIGlmIChpbnN0cnVjdGlvbi5hY3Rpb24gPT09IFwicHVzaEZpbHRlclwiKSB7XG4gICAgICB0aGlzLl9yZW5kZXJlci5maWx0ZXIucHVzaChpbnN0cnVjdGlvbik7XG4gICAgfSBlbHNlIGlmIChpbnN0cnVjdGlvbi5hY3Rpb24gPT09IFwicG9wRmlsdGVyXCIpIHtcbiAgICAgIHRoaXMuX3JlbmRlcmVyLmZpbHRlci5wb3AoKTtcbiAgICB9XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLl9yZW5kZXJlciA9IG51bGw7XG4gIH1cbn1cbkZpbHRlclBpcGUuZXh0ZW5zaW9uID0ge1xuICB0eXBlOiBbXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHTFBpcGVzLFxuICAgIEV4dGVuc2lvblR5cGUuV2ViR1BVUGlwZXMsXG4gICAgRXh0ZW5zaW9uVHlwZS5DYW52YXNQaXBlc1xuICBdLFxuICBuYW1lOiBcImZpbHRlclwiXG59O1xuXG5leHBvcnQgeyBGaWx0ZXJQaXBlIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1GaWx0ZXJQaXBlLm1qcy5tYXBcbiIsImltcG9ydCB7IEV4dGVuc2lvblR5cGUgfSBmcm9tICcuLi9leHRlbnNpb25zL0V4dGVuc2lvbnMubWpzJztcbmltcG9ydCB7IFBhc3N0aHJvdWdoRmlsdGVyIH0gZnJvbSAnLi9kZWZhdWx0cy9wYXNzdGhyb3VnaC9QYXNzdGhyb3VnaEZpbHRlci5tanMnO1xuaW1wb3J0IHsgTWF0cml4IH0gZnJvbSAnLi4vbWF0aHMvbWF0cml4L01hdHJpeC5tanMnO1xuaW1wb3J0IHsgQmluZEdyb3VwIH0gZnJvbSAnLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9ncHUvc2hhZGVyL0JpbmRHcm91cC5tanMnO1xuaW1wb3J0IHsgR2VvbWV0cnkgfSBmcm9tICcuLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC9nZW9tZXRyeS9HZW9tZXRyeS5tanMnO1xuaW1wb3J0IHsgVW5pZm9ybUdyb3VwIH0gZnJvbSAnLi4vcmVuZGVyaW5nL3JlbmRlcmVycy9zaGFyZWQvc2hhZGVyL1VuaWZvcm1Hcm91cC5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZSB9IGZyb20gJy4uL3JlbmRlcmluZy9yZW5kZXJlcnMvc2hhcmVkL3RleHR1cmUvVGV4dHVyZS5tanMnO1xuaW1wb3J0IHsgVGV4dHVyZVBvb2wgfSBmcm9tICcuLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3NoYXJlZC90ZXh0dXJlL1RleHR1cmVQb29sLm1qcyc7XG5pbXBvcnQgeyBSZW5kZXJlclR5cGUgfSBmcm9tICcuLi9yZW5kZXJpbmcvcmVuZGVyZXJzL3R5cGVzLm1qcyc7XG5pbXBvcnQgeyBCb3VuZHMgfSBmcm9tICcuLi9zY2VuZS9jb250YWluZXIvYm91bmRzL0JvdW5kcy5tanMnO1xuaW1wb3J0IHsgZ2V0R2xvYmFsUmVuZGVyYWJsZUJvdW5kcyB9IGZyb20gJy4uL3NjZW5lL2NvbnRhaW5lci9ib3VuZHMvZ2V0UmVuZGVyYWJsZUJvdW5kcy5tanMnO1xuaW1wb3J0IHsgd2FybiB9IGZyb20gJy4uL3V0aWxzL2xvZ2dpbmcvd2Fybi5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IHF1YWRHZW9tZXRyeSA9IG5ldyBHZW9tZXRyeSh7XG4gIGF0dHJpYnV0ZXM6IHtcbiAgICBhUG9zaXRpb246IHtcbiAgICAgIGJ1ZmZlcjogbmV3IEZsb2F0MzJBcnJheShbMCwgMCwgMSwgMCwgMSwgMSwgMCwgMV0pLFxuICAgICAgZm9ybWF0OiBcImZsb2F0MzJ4MlwiLFxuICAgICAgc3RyaWRlOiAyICogNCxcbiAgICAgIG9mZnNldDogMFxuICAgIH1cbiAgfSxcbiAgaW5kZXhCdWZmZXI6IG5ldyBVaW50MzJBcnJheShbMCwgMSwgMiwgMCwgMiwgM10pXG59KTtcbmNsYXNzIEZpbHRlckRhdGEge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICAvKipcbiAgICAgKiBJbmRpY2F0ZXMgd2hldGhlciB0aGUgZmlsdGVyIHNob3VsZCBiZSBza2lwcGVkLlxuICAgICAqIEB0eXBlIHtib29sZWFufVxuICAgICAqL1xuICAgIHRoaXMuc2tpcCA9IGZhbHNlO1xuICAgIC8qKlxuICAgICAqIFRoZSB0ZXh0dXJlIHRvIHdoaWNoIHRoZSBmaWx0ZXIgaXMgYXBwbGllZC5cbiAgICAgKiBAdHlwZSB7VGV4dHVyZX1cbiAgICAgKi9cbiAgICB0aGlzLmlucHV0VGV4dHVyZSA9IG51bGw7XG4gICAgLyoqXG4gICAgICogVGhlIGJhY2sgdGV4dHVyZSB1c2VkIGZvciBibGVuZGluZywgaWYgcmVxdWlyZWQuXG4gICAgICogQHR5cGUge1RleHR1cmUgfCBudWxsfVxuICAgICAqL1xuICAgIHRoaXMuYmFja1RleHR1cmUgPSBudWxsO1xuICAgIC8qKlxuICAgICAqIFRoZSBsaXN0IG9mIGZpbHRlcnMgdG8gYmUgYXBwbGllZC5cbiAgICAgKiBAdHlwZSB7RmlsdGVyW119XG4gICAgICovXG4gICAgdGhpcy5maWx0ZXJzID0gbnVsbDtcbiAgICAvKipcbiAgICAgKiBUaGUgYm91bmRzIG9mIHRoZSBmaWx0ZXIgYXJlYS5cbiAgICAgKiBAdHlwZSB7Qm91bmRzfVxuICAgICAqL1xuICAgIHRoaXMuYm91bmRzID0gbmV3IEJvdW5kcygpO1xuICAgIC8qKlxuICAgICAqIFRoZSBjb250YWluZXIgdG8gd2hpY2ggdGhlIGZpbHRlciBpcyBhcHBsaWVkLlxuICAgICAqIEB0eXBlIHtDb250YWluZXJ9XG4gICAgICovXG4gICAgdGhpcy5jb250YWluZXIgPSBudWxsO1xuICAgIC8qKlxuICAgICAqIEluZGljYXRlcyB3aGV0aGVyIGJsZW5kaW5nIGlzIHJlcXVpcmVkIGZvciB0aGUgZmlsdGVyLlxuICAgICAqIEB0eXBlIHtib29sZWFufVxuICAgICAqL1xuICAgIHRoaXMuYmxlbmRSZXF1aXJlZCA9IGZhbHNlO1xuICAgIC8qKlxuICAgICAqIFRoZSByZW5kZXIgc3VyZmFjZSB3aGVyZSB0aGUgb3V0cHV0IG9mIHRoZSBmaWx0ZXIgaXMgcmVuZGVyZWQuXG4gICAgICogQHR5cGUge1JlbmRlclN1cmZhY2V9XG4gICAgICovXG4gICAgdGhpcy5vdXRwdXRSZW5kZXJTdXJmYWNlID0gbnVsbDtcbiAgICAvKiogVGhlIGZpcnN0IGVuYWJsZWQgZmlsdGVyIGluZGV4IGluIHRoZSBjdXJyZW50IGZpbHRlciBsaXN0LiAqL1xuICAgIHRoaXMuZmlyc3RFbmFibGVkSW5kZXggPSAtMTtcbiAgICAvKiogVGhlIGxhc3QgZW5hYmxlZCBmaWx0ZXIgaW5kZXggaW4gdGhlIGN1cnJlbnQgZmlsdGVyIGxpc3QuICovXG4gICAgdGhpcy5sYXN0RW5hYmxlZEluZGV4ID0gLTE7XG4gIH1cbn1cbmNsYXNzIEZpbHRlclN5c3RlbSB7XG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgdGhpcy5fZmlsdGVyU3RhY2tJbmRleCA9IDA7XG4gICAgdGhpcy5fZmlsdGVyU3RhY2sgPSBbXTtcbiAgICB0aGlzLl9maWx0ZXJHbG9iYWxVbmlmb3JtcyA9IG5ldyBVbmlmb3JtR3JvdXAoe1xuICAgICAgdUlucHV0U2l6ZTogeyB2YWx1ZTogbmV3IEZsb2F0MzJBcnJheSg0KSwgdHlwZTogXCJ2ZWM0PGYzMj5cIiB9LFxuICAgICAgdUlucHV0UGl4ZWw6IHsgdmFsdWU6IG5ldyBGbG9hdDMyQXJyYXkoNCksIHR5cGU6IFwidmVjNDxmMzI+XCIgfSxcbiAgICAgIHVJbnB1dENsYW1wOiB7IHZhbHVlOiBuZXcgRmxvYXQzMkFycmF5KDQpLCB0eXBlOiBcInZlYzQ8ZjMyPlwiIH0sXG4gICAgICB1T3V0cHV0RnJhbWU6IHsgdmFsdWU6IG5ldyBGbG9hdDMyQXJyYXkoNCksIHR5cGU6IFwidmVjNDxmMzI+XCIgfSxcbiAgICAgIHVHbG9iYWxGcmFtZTogeyB2YWx1ZTogbmV3IEZsb2F0MzJBcnJheSg0KSwgdHlwZTogXCJ2ZWM0PGYzMj5cIiB9LFxuICAgICAgdU91dHB1dFRleHR1cmU6IHsgdmFsdWU6IG5ldyBGbG9hdDMyQXJyYXkoNCksIHR5cGU6IFwidmVjNDxmMzI+XCIgfVxuICAgIH0pO1xuICAgIHRoaXMuX2dsb2JhbEZpbHRlckJpbmRHcm91cCA9IG5ldyBCaW5kR3JvdXAoe30pO1xuICAgIHRoaXMucmVuZGVyZXIgPSByZW5kZXJlcjtcbiAgfVxuICAvKipcbiAgICogVGhlIGJhY2sgdGV4dHVyZSBvZiB0aGUgY3VycmVudGx5IGFjdGl2ZSBmaWx0ZXIuIFJlcXVpcmVzIHRoZSBmaWx0ZXIgdG8gaGF2ZSBgYmxlbmRSZXF1aXJlZGAgc2V0IHRvIHRydWUuXG4gICAqIEByZWFkb25seVxuICAgKi9cbiAgZ2V0IGFjdGl2ZUJhY2tUZXh0dXJlKCkge1xuICAgIHJldHVybiB0aGlzLl9hY3RpdmVGaWx0ZXJEYXRhPy5iYWNrVGV4dHVyZTtcbiAgfVxuICAvKipcbiAgICogUHVzaGVzIGEgZmlsdGVyIGluc3RydWN0aW9uIG9udG8gdGhlIGZpbHRlciBzdGFjay5cbiAgICogQHBhcmFtIGluc3RydWN0aW9uIC0gVGhlIGluc3RydWN0aW9uIGNvbnRhaW5pbmcgdGhlIGZpbHRlciBlZmZlY3QgYW5kIGNvbnRhaW5lci5cbiAgICogQGludGVybmFsXG4gICAqL1xuICBwdXNoKGluc3RydWN0aW9uKSB7XG4gICAgY29uc3QgcmVuZGVyZXIgPSB0aGlzLnJlbmRlcmVyO1xuICAgIGNvbnN0IGZpbHRlcnMgPSBpbnN0cnVjdGlvbi5maWx0ZXJFZmZlY3QuZmlsdGVycztcbiAgICBjb25zdCBmaWx0ZXJEYXRhID0gdGhpcy5fcHVzaEZpbHRlckRhdGEoKTtcbiAgICBmaWx0ZXJEYXRhLnNraXAgPSBmYWxzZTtcbiAgICBmaWx0ZXJEYXRhLmZpbHRlcnMgPSBmaWx0ZXJzO1xuICAgIGZpbHRlckRhdGEuY29udGFpbmVyID0gaW5zdHJ1Y3Rpb24uY29udGFpbmVyO1xuICAgIGZpbHRlckRhdGEub3V0cHV0UmVuZGVyU3VyZmFjZSA9IHJlbmRlcmVyLnJlbmRlclRhcmdldC5yZW5kZXJTdXJmYWNlO1xuICAgIGNvbnN0IGNvbG9yVGV4dHVyZVNvdXJjZSA9IHJlbmRlcmVyLnJlbmRlclRhcmdldC5yZW5kZXJUYXJnZXQuY29sb3JUZXh0dXJlLnNvdXJjZTtcbiAgICBjb25zdCByb290UmVzb2x1dGlvbiA9IGNvbG9yVGV4dHVyZVNvdXJjZS5yZXNvbHV0aW9uO1xuICAgIGNvbnN0IHJvb3RBbnRpYWxpYXMgPSBjb2xvclRleHR1cmVTb3VyY2UuYW50aWFsaWFzO1xuICAgIGlmIChmaWx0ZXJzLmV2ZXJ5KChmaWx0ZXIpID0+ICFmaWx0ZXIuZW5hYmxlZCkpIHtcbiAgICAgIGZpbHRlckRhdGEuc2tpcCA9IHRydWU7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGJvdW5kcyA9IGZpbHRlckRhdGEuYm91bmRzO1xuICAgIHRoaXMuX2NhbGN1bGF0ZUZpbHRlckFyZWEoaW5zdHJ1Y3Rpb24sIGJvdW5kcyk7XG4gICAgdGhpcy5fY2FsY3VsYXRlRmlsdGVyQm91bmRzKGZpbHRlckRhdGEsIHJlbmRlcmVyLnJlbmRlclRhcmdldC5yb290Vmlld1BvcnQsIHJvb3RBbnRpYWxpYXMsIHJvb3RSZXNvbHV0aW9uLCAxKTtcbiAgICBpZiAoZmlsdGVyRGF0YS5za2lwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHByZXZpb3VzRmlsdGVyRGF0YSA9IHRoaXMuX2dldFByZXZpb3VzRmlsdGVyRGF0YSgpO1xuICAgIHRoaXMuX3NldHVwRmlsdGVyVGV4dHVyZXMoZmlsdGVyRGF0YSwgYm91bmRzLCByZW5kZXJlciwgcHJldmlvdXNGaWx0ZXJEYXRhKTtcbiAgfVxuICAvKipcbiAgICogQXBwbGllcyBmaWx0ZXJzIHRvIGEgdGV4dHVyZS5cbiAgICpcbiAgICogVGhpcyBtZXRob2QgdGFrZXMgYSB0ZXh0dXJlIGFuZCBhIGxpc3Qgb2YgZmlsdGVycywgYXBwbGllcyB0aGUgZmlsdGVycyB0byB0aGUgdGV4dHVyZSxcbiAgICogYW5kIHJldHVybnMgdGhlIHJlc3VsdGluZyB0ZXh0dXJlLlxuICAgKiBAcGFyYW0ge29iamVjdH0gcGFyYW1zIC0gVGhlIHBhcmFtZXRlcnMgZm9yIGFwcGx5aW5nIGZpbHRlcnMuXG4gICAqIEBwYXJhbSB7VGV4dHVyZX0gcGFyYW1zLnRleHR1cmUgLSBUaGUgdGV4dHVyZSB0byBhcHBseSBmaWx0ZXJzIHRvLlxuICAgKiBAcGFyYW0ge0ZpbHRlcltdfSBwYXJhbXMuZmlsdGVycyAtIFRoZSBmaWx0ZXJzIHRvIGFwcGx5LlxuICAgKiBAcmV0dXJucyB7VGV4dHVyZX0gVGhlIHJlc3VsdGluZyB0ZXh0dXJlIGFmdGVyIGFsbCBmaWx0ZXJzIGhhdmUgYmVlbiBhcHBsaWVkLlxuICAgKiBAZXhhbXBsZVxuICAgKlxuICAgKiBgYGB0c1xuICAgKiAvLyBDcmVhdGUgYSB0ZXh0dXJlIGFuZCBhIGxpc3Qgb2YgZmlsdGVyc1xuICAgKiBjb25zdCB0ZXh0dXJlID0gbmV3IFRleHR1cmUoLi4uKTtcbiAgICogY29uc3QgZmlsdGVycyA9IFtuZXcgQmx1ckZpbHRlcigpLCBuZXcgQ29sb3JNYXRyaXhGaWx0ZXIoKV07XG4gICAqXG4gICAqIC8vIEFwcGx5IHRoZSBmaWx0ZXJzIHRvIHRoZSB0ZXh0dXJlXG4gICAqIGNvbnN0IHJlc3VsdFRleHR1cmUgPSByZW5kZXJlci5maWx0ZXIuZ2VuZXJhdGVGaWx0ZXJlZFRleHR1cmUoeyB0ZXh0dXJlLCBmaWx0ZXJzIH0pO1xuICAgKlxuICAgKiAvLyBVc2UgdGhlIHJlc3VsdGluZyB0ZXh0dXJlXG4gICAqIHNwcml0ZS50ZXh0dXJlID0gcmVzdWx0VGV4dHVyZTtcbiAgICogYGBgXG4gICAqXG4gICAqIEtleSBQb2ludHM6XG4gICAqIDEuIHBhZGRpbmcgaXMgbm90IGN1cnJlbnRseSBzdXBwb3J0ZWQgaGVyZSAtIHNvIGNsaXBwaW5nIG1heSBvY2N1ciB3aXRoIGZpbHRlcnMgdGhhdCB1c2UgcGFkZGluZy5cbiAgICogMi4gSWYgYWxsIGZpbHRlcnMgYXJlIGRpc2FibGVkIG9yIHNraXBwZWQsIHRoZSBvcmlnaW5hbCB0ZXh0dXJlIGlzIHJldHVybmVkLlxuICAgKi9cbiAgZ2VuZXJhdGVGaWx0ZXJlZFRleHR1cmUoeyB0ZXh0dXJlLCBmaWx0ZXJzIH0pIHtcbiAgICBpZiAoZmlsdGVycy5ldmVyeSgoZmlsdGVyKSA9PiAhZmlsdGVyLmVuYWJsZWQpKSB7XG4gICAgICByZXR1cm4gdGV4dHVyZTtcbiAgICB9XG4gICAgY29uc3QgZmlsdGVyRGF0YSA9IHRoaXMuX3B1c2hGaWx0ZXJEYXRhKCk7XG4gICAgdGhpcy5fYWN0aXZlRmlsdGVyRGF0YSA9IGZpbHRlckRhdGE7XG4gICAgZmlsdGVyRGF0YS5za2lwID0gZmFsc2U7XG4gICAgZmlsdGVyRGF0YS5maWx0ZXJzID0gZmlsdGVycztcbiAgICBjb25zdCBjb2xvclRleHR1cmVTb3VyY2UgPSB0ZXh0dXJlLnNvdXJjZTtcbiAgICBjb25zdCByb290UmVzb2x1dGlvbiA9IGNvbG9yVGV4dHVyZVNvdXJjZS5yZXNvbHV0aW9uO1xuICAgIGNvbnN0IHJvb3RBbnRpYWxpYXMgPSBjb2xvclRleHR1cmVTb3VyY2UuYW50aWFsaWFzO1xuICAgIGNvbnN0IGJvdW5kcyA9IGZpbHRlckRhdGEuYm91bmRzO1xuICAgIGJvdW5kcy5jbGVhcigpO1xuICAgIGJvdW5kcy5hZGRSZWN0KHRleHR1cmUuZnJhbWUpO1xuICAgIHRoaXMuX2NhbGN1bGF0ZUZpbHRlckJvdW5kcyhmaWx0ZXJEYXRhLCBib3VuZHMucmVjdGFuZ2xlLCByb290QW50aWFsaWFzLCByb290UmVzb2x1dGlvbiwgMCk7XG4gICAgaWYgKGZpbHRlckRhdGEuc2tpcCkge1xuICAgICAgdGhpcy5fcG9wRmlsdGVyRGF0YSgpO1xuICAgICAgcmV0dXJuIHRleHR1cmU7XG4gICAgfVxuICAgIGZpbHRlckRhdGEub3V0cHV0UmVuZGVyU3VyZmFjZSA9IFRleHR1cmVQb29sLmdldE9wdGltYWxUZXh0dXJlKHtcbiAgICAgIHdpZHRoOiBib3VuZHMud2lkdGgsXG4gICAgICBoZWlnaHQ6IGJvdW5kcy5oZWlnaHQsXG4gICAgICByZXNvbHV0aW9uOiBmaWx0ZXJEYXRhLnJlc29sdXRpb24sXG4gICAgICBhbnRpYWxpYXM6IGZpbHRlckRhdGEuYW50aWFsaWFzXG4gICAgfSk7XG4gICAgZmlsdGVyRGF0YS5iYWNrVGV4dHVyZSA9IFRleHR1cmUuRU1QVFk7XG4gICAgZmlsdGVyRGF0YS5pbnB1dFRleHR1cmUgPSB0ZXh0dXJlO1xuICAgIGNvbnN0IHJlbmRlcmVyID0gdGhpcy5yZW5kZXJlcjtcbiAgICByZW5kZXJlci5yZW5kZXJUYXJnZXQuZmluaXNoUmVuZGVyUGFzcygpO1xuICAgIHRoaXMuX2FwcGx5RmlsdGVyc1RvVGV4dHVyZShmaWx0ZXJEYXRhLCB0cnVlKTtcbiAgICBjb25zdCBvdXRwdXRUZXh0dXJlID0gZmlsdGVyRGF0YS5vdXRwdXRSZW5kZXJTdXJmYWNlO1xuICAgIG91dHB1dFRleHR1cmUuc291cmNlLmFscGhhTW9kZSA9IFwicHJlbXVsdGlwbGllZC1hbHBoYVwiO1xuICAgIHRoaXMuX3BvcEZpbHRlckRhdGEoKTtcbiAgICByZXR1cm4gb3V0cHV0VGV4dHVyZTtcbiAgfVxuICAvKiogQGludGVybmFsICovXG4gIHBvcCgpIHtcbiAgICBjb25zdCByZW5kZXJlciA9IHRoaXMucmVuZGVyZXI7XG4gICAgY29uc3QgZmlsdGVyRGF0YSA9IHRoaXMuX3BvcEZpbHRlckRhdGEoKTtcbiAgICBpZiAoZmlsdGVyRGF0YS5za2lwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHJlbmRlcmVyLmdsb2JhbFVuaWZvcm1zLnBvcCgpO1xuICAgIHJlbmRlcmVyLnJlbmRlclRhcmdldC5maW5pc2hSZW5kZXJQYXNzKCk7XG4gICAgdGhpcy5fYWN0aXZlRmlsdGVyRGF0YSA9IGZpbHRlckRhdGE7XG4gICAgdGhpcy5fYXBwbHlGaWx0ZXJzVG9UZXh0dXJlKGZpbHRlckRhdGEsIGZhbHNlKTtcbiAgICBpZiAoZmlsdGVyRGF0YS5ibGVuZFJlcXVpcmVkKSB7XG4gICAgICBUZXh0dXJlUG9vbC5yZXR1cm5UZXh0dXJlKGZpbHRlckRhdGEuYmFja1RleHR1cmUpO1xuICAgIH1cbiAgICBUZXh0dXJlUG9vbC5yZXR1cm5UZXh0dXJlKGZpbHRlckRhdGEuaW5wdXRUZXh0dXJlKTtcbiAgfVxuICAvKipcbiAgICogQ29waWVzIHRoZSBsYXN0IHJlbmRlciBzdXJmYWNlIHRvIGEgdGV4dHVyZS5cbiAgICogQHBhcmFtIGxhc3RSZW5kZXJTdXJmYWNlIC0gVGhlIGxhc3QgcmVuZGVyIHN1cmZhY2UgdG8gY29weSBmcm9tLlxuICAgKiBAcGFyYW0gYm91bmRzIC0gVGhlIGJvdW5kcyBvZiB0aGUgYXJlYSB0byBjb3B5LlxuICAgKiBAcGFyYW0gcHJldmlvdXNCb3VuZHMgLSBUaGUgcHJldmlvdXMgYm91bmRzIHRvIHVzZSBmb3Igb2Zmc2V0dGluZyB0aGUgY29weS5cbiAgICovXG4gIGdldEJhY2tUZXh0dXJlKGxhc3RSZW5kZXJTdXJmYWNlLCBib3VuZHMsIHByZXZpb3VzQm91bmRzKSB7XG4gICAgY29uc3QgYmFja2dyb3VuZFJlc29sdXRpb24gPSBsYXN0UmVuZGVyU3VyZmFjZS5jb2xvclRleHR1cmUuc291cmNlLl9yZXNvbHV0aW9uO1xuICAgIGNvbnN0IGJhY2tUZXh0dXJlID0gVGV4dHVyZVBvb2wuZ2V0T3B0aW1hbFRleHR1cmUoe1xuICAgICAgd2lkdGg6IGJvdW5kcy53aWR0aCxcbiAgICAgIGhlaWdodDogYm91bmRzLmhlaWdodCxcbiAgICAgIHJlc29sdXRpb246IGJhY2tncm91bmRSZXNvbHV0aW9uXG4gICAgfSk7XG4gICAgbGV0IHggPSBib3VuZHMubWluWDtcbiAgICBsZXQgeSA9IGJvdW5kcy5taW5ZO1xuICAgIGlmIChwcmV2aW91c0JvdW5kcykge1xuICAgICAgeCAtPSBwcmV2aW91c0JvdW5kcy5taW5YO1xuICAgICAgeSAtPSBwcmV2aW91c0JvdW5kcy5taW5ZO1xuICAgIH1cbiAgICB4ID0gTWF0aC5mbG9vcih4ICogYmFja2dyb3VuZFJlc29sdXRpb24pO1xuICAgIHkgPSBNYXRoLmZsb29yKHkgKiBiYWNrZ3JvdW5kUmVzb2x1dGlvbik7XG4gICAgY29uc3Qgd2lkdGggPSBNYXRoLmNlaWwoYm91bmRzLndpZHRoICogYmFja2dyb3VuZFJlc29sdXRpb24pO1xuICAgIGNvbnN0IGhlaWdodCA9IE1hdGguY2VpbChib3VuZHMuaGVpZ2h0ICogYmFja2dyb3VuZFJlc29sdXRpb24pO1xuICAgIHRoaXMucmVuZGVyZXIucmVuZGVyVGFyZ2V0LmNvcHlUb1RleHR1cmUoXG4gICAgICBsYXN0UmVuZGVyU3VyZmFjZSxcbiAgICAgIGJhY2tUZXh0dXJlLFxuICAgICAgeyB4LCB5IH0sXG4gICAgICB7IHdpZHRoLCBoZWlnaHQgfSxcbiAgICAgIHsgeDogMCwgeTogMCB9XG4gICAgKTtcbiAgICByZXR1cm4gYmFja1RleHR1cmU7XG4gIH1cbiAgLyoqXG4gICAqIEFwcGxpZXMgYSBmaWx0ZXIgdG8gYSB0ZXh0dXJlLlxuICAgKiBAcGFyYW0gZmlsdGVyIC0gVGhlIGZpbHRlciB0byBhcHBseS5cbiAgICogQHBhcmFtIGlucHV0IC0gVGhlIGlucHV0IHRleHR1cmUuXG4gICAqIEBwYXJhbSBvdXRwdXQgLSBUaGUgb3V0cHV0IHJlbmRlciBzdXJmYWNlLlxuICAgKiBAcGFyYW0gY2xlYXIgLSBXaGV0aGVyIHRvIGNsZWFyIHRoZSBvdXRwdXQgc3VyZmFjZSBiZWZvcmUgYXBwbHlpbmcgdGhlIGZpbHRlci5cbiAgICovXG4gIGFwcGx5RmlsdGVyKGZpbHRlciwgaW5wdXQsIG91dHB1dCwgY2xlYXIpIHtcbiAgICBjb25zdCByZW5kZXJlciA9IHRoaXMucmVuZGVyZXI7XG4gICAgY29uc3QgZmlsdGVyRGF0YSA9IHRoaXMuX2FjdGl2ZUZpbHRlckRhdGE7XG4gICAgY29uc3Qgb3V0cHV0UmVuZGVyU3VyZmFjZSA9IGZpbHRlckRhdGEub3V0cHV0UmVuZGVyU3VyZmFjZTtcbiAgICBjb25zdCBpc0ZpbmFsVGFyZ2V0ID0gb3V0cHV0UmVuZGVyU3VyZmFjZSA9PT0gb3V0cHV0O1xuICAgIGNvbnN0IGNsb3Nlc3RGaWx0ZXJEYXRhID0gdGhpcy5fZmluZENsb3Nlc3RGaWx0ZXJEYXRhKCk7XG4gICAgY29uc3QgcmVzb2x1dGlvbiA9IGNsb3Nlc3RGaWx0ZXJEYXRhID8gY2xvc2VzdEZpbHRlckRhdGEuaW5wdXRUZXh0dXJlLnNvdXJjZS5fcmVzb2x1dGlvbiA6IHJlbmRlcmVyLnJlbmRlclRhcmdldC5yb290UmVuZGVyVGFyZ2V0LmNvbG9yVGV4dHVyZS5zb3VyY2UuX3Jlc29sdXRpb247XG4gICAgbGV0IG9mZnNldFggPSAwO1xuICAgIGxldCBvZmZzZXRZID0gMDtcbiAgICBpZiAoaXNGaW5hbFRhcmdldCAmJiBjbG9zZXN0RmlsdGVyRGF0YSkge1xuICAgICAgb2Zmc2V0WCA9IGNsb3Nlc3RGaWx0ZXJEYXRhLmJvdW5kcy5taW5YO1xuICAgICAgb2Zmc2V0WSA9IGNsb3Nlc3RGaWx0ZXJEYXRhLmJvdW5kcy5taW5ZO1xuICAgIH1cbiAgICB0aGlzLl91cGRhdGVGaWx0ZXJVbmlmb3JtcyhpbnB1dCwgb3V0cHV0LCBmaWx0ZXJEYXRhLCBvZmZzZXRYLCBvZmZzZXRZLCByZXNvbHV0aW9uLCBpc0ZpbmFsVGFyZ2V0LCBjbGVhcik7XG4gICAgY29uc3QgZmlsdGVyVG9BcHBseSA9IGZpbHRlci5lbmFibGVkID8gZmlsdGVyIDogdGhpcy5fZ2V0UGFzc3Rocm91Z2hGaWx0ZXIoKTtcbiAgICB0aGlzLl9zZXR1cEJpbmRHcm91cHNBbmRSZW5kZXIoZmlsdGVyVG9BcHBseSwgaW5wdXQsIHJlbmRlcmVyKTtcbiAgfVxuICAvKipcbiAgICogTXVsdGlwbHkgX2lucHV0IG5vcm1hbGl6ZWQgY29vcmRpbmF0ZXNfIHRvIHRoaXMgbWF0cml4IHRvIGdldCBfc3ByaXRlIHRleHR1cmUgbm9ybWFsaXplZCBjb29yZGluYXRlc18uXG4gICAqXG4gICAqIFVzZSBgb3V0cHV0TWF0cml4ICogdlRleHR1cmVDb29yZGAgaW4gdGhlIHNoYWRlci5cbiAgICogQHBhcmFtIG91dHB1dE1hdHJpeCAtIFRoZSBtYXRyaXggdG8gb3V0cHV0IHRvLlxuICAgKiBAcGFyYW0ge1Nwcml0ZX0gc3ByaXRlIC0gVGhlIHNwcml0ZSB0byBtYXAgdG8uXG4gICAqIEByZXR1cm5zIFRoZSBtYXBwZWQgbWF0cml4LlxuICAgKi9cbiAgY2FsY3VsYXRlU3ByaXRlTWF0cml4KG91dHB1dE1hdHJpeCwgc3ByaXRlKSB7XG4gICAgY29uc3QgZGF0YSA9IHRoaXMuX2FjdGl2ZUZpbHRlckRhdGE7XG4gICAgY29uc3QgbWFwcGVkTWF0cml4ID0gb3V0cHV0TWF0cml4LnNldChcbiAgICAgIGRhdGEuaW5wdXRUZXh0dXJlLl9zb3VyY2Uud2lkdGgsXG4gICAgICAwLFxuICAgICAgMCxcbiAgICAgIGRhdGEuaW5wdXRUZXh0dXJlLl9zb3VyY2UuaGVpZ2h0LFxuICAgICAgZGF0YS5ib3VuZHMubWluWCxcbiAgICAgIGRhdGEuYm91bmRzLm1pbllcbiAgICApO1xuICAgIGNvbnN0IHdvcmxkVHJhbnNmb3JtID0gc3ByaXRlLndvcmxkVHJhbnNmb3JtLmNvcHlUbyhNYXRyaXguc2hhcmVkKTtcbiAgICBjb25zdCByZW5kZXJHcm91cCA9IHNwcml0ZS5yZW5kZXJHcm91cCB8fCBzcHJpdGUucGFyZW50UmVuZGVyR3JvdXA7XG4gICAgaWYgKHJlbmRlckdyb3VwICYmIHJlbmRlckdyb3VwLmNhY2hlVG9Mb2NhbFRyYW5zZm9ybSkge1xuICAgICAgd29ybGRUcmFuc2Zvcm0ucHJlcGVuZChyZW5kZXJHcm91cC5jYWNoZVRvTG9jYWxUcmFuc2Zvcm0pO1xuICAgIH1cbiAgICB3b3JsZFRyYW5zZm9ybS5pbnZlcnQoKTtcbiAgICBtYXBwZWRNYXRyaXgucHJlcGVuZCh3b3JsZFRyYW5zZm9ybSk7XG4gICAgbWFwcGVkTWF0cml4LnNjYWxlKFxuICAgICAgMSAvIHNwcml0ZS50ZXh0dXJlLm9yaWcud2lkdGgsXG4gICAgICAxIC8gc3ByaXRlLnRleHR1cmUub3JpZy5oZWlnaHRcbiAgICApO1xuICAgIG1hcHBlZE1hdHJpeC50cmFuc2xhdGUoc3ByaXRlLmFuY2hvci54LCBzcHJpdGUuYW5jaG9yLnkpO1xuICAgIHJldHVybiBtYXBwZWRNYXRyaXg7XG4gIH1cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLl9wYXNzdGhyb3VnaEZpbHRlcj8uZGVzdHJveSh0cnVlKTtcbiAgICB0aGlzLl9wYXNzdGhyb3VnaEZpbHRlciA9IG51bGw7XG4gIH1cbiAgX2dldFBhc3N0aHJvdWdoRmlsdGVyKCkge1xuICAgIHRoaXMuX3Bhc3N0aHJvdWdoRmlsdGVyID8/ICh0aGlzLl9wYXNzdGhyb3VnaEZpbHRlciA9IG5ldyBQYXNzdGhyb3VnaEZpbHRlcigpKTtcbiAgICByZXR1cm4gdGhpcy5fcGFzc3Rocm91Z2hGaWx0ZXI7XG4gIH1cbiAgLyoqXG4gICAqIFNldHMgdXAgdGhlIGJpbmQgZ3JvdXBzIGFuZCByZW5kZXJzIHRoZSBmaWx0ZXIuXG4gICAqIEBwYXJhbSBmaWx0ZXIgLSBUaGUgZmlsdGVyIHRvIGFwcGx5XG4gICAqIEBwYXJhbSBpbnB1dCAtIFRoZSBpbnB1dCB0ZXh0dXJlXG4gICAqIEBwYXJhbSByZW5kZXJlciAtIFRoZSByZW5kZXJlciBpbnN0YW5jZVxuICAgKi9cbiAgX3NldHVwQmluZEdyb3Vwc0FuZFJlbmRlcihmaWx0ZXIsIGlucHV0LCByZW5kZXJlcikge1xuICAgIGlmIChyZW5kZXJlci5yZW5kZXJQaXBlcy51bmlmb3JtQmF0Y2gpIHtcbiAgICAgIGNvbnN0IGJhdGNoVW5pZm9ybXMgPSByZW5kZXJlci5yZW5kZXJQaXBlcy51bmlmb3JtQmF0Y2guZ2V0VWJvUmVzb3VyY2UodGhpcy5fZmlsdGVyR2xvYmFsVW5pZm9ybXMpO1xuICAgICAgdGhpcy5fZ2xvYmFsRmlsdGVyQmluZEdyb3VwLnNldFJlc291cmNlKGJhdGNoVW5pZm9ybXMsIDApO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9nbG9iYWxGaWx0ZXJCaW5kR3JvdXAuc2V0UmVzb3VyY2UodGhpcy5fZmlsdGVyR2xvYmFsVW5pZm9ybXMsIDApO1xuICAgIH1cbiAgICB0aGlzLl9nbG9iYWxGaWx0ZXJCaW5kR3JvdXAuc2V0UmVzb3VyY2UoaW5wdXQuc291cmNlLCAxKTtcbiAgICB0aGlzLl9nbG9iYWxGaWx0ZXJCaW5kR3JvdXAuc2V0UmVzb3VyY2UoaW5wdXQuc291cmNlLnN0eWxlLCAyKTtcbiAgICBmaWx0ZXIuZ3JvdXBzWzBdID0gdGhpcy5fZ2xvYmFsRmlsdGVyQmluZEdyb3VwO1xuICAgIHJlbmRlcmVyLmVuY29kZXIuZHJhdyh7XG4gICAgICBnZW9tZXRyeTogcXVhZEdlb21ldHJ5LFxuICAgICAgc2hhZGVyOiBmaWx0ZXIsXG4gICAgICBzdGF0ZTogZmlsdGVyLl9zdGF0ZSxcbiAgICAgIHRvcG9sb2d5OiBcInRyaWFuZ2xlLWxpc3RcIlxuICAgIH0pO1xuICAgIGlmIChyZW5kZXJlci50eXBlID09PSBSZW5kZXJlclR5cGUuV0VCR0wpIHtcbiAgICAgIHJlbmRlcmVyLnJlbmRlclRhcmdldC5maW5pc2hSZW5kZXJQYXNzKCk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBTZXRzIHVwIHRoZSBmaWx0ZXIgdGV4dHVyZXMgaW5jbHVkaW5nIGlucHV0IHRleHR1cmUgYW5kIGJhY2sgdGV4dHVyZSBpZiBuZWVkZWQuXG4gICAqIEBwYXJhbSBmaWx0ZXJEYXRhIC0gVGhlIGZpbHRlciBkYXRhIHRvIHVwZGF0ZVxuICAgKiBAcGFyYW0gYm91bmRzIC0gVGhlIGJvdW5kcyBmb3IgdGhlIHRleHR1cmVcbiAgICogQHBhcmFtIHJlbmRlcmVyIC0gVGhlIHJlbmRlcmVyIGluc3RhbmNlXG4gICAqIEBwYXJhbSBwcmV2aW91c0ZpbHRlckRhdGEgLSBUaGUgcHJldmlvdXMgZmlsdGVyIGRhdGEgZm9yIGJhY2sgdGV4dHVyZSBjYWxjdWxhdGlvblxuICAgKi9cbiAgX3NldHVwRmlsdGVyVGV4dHVyZXMoZmlsdGVyRGF0YSwgYm91bmRzLCByZW5kZXJlciwgcHJldmlvdXNGaWx0ZXJEYXRhKSB7XG4gICAgZmlsdGVyRGF0YS5iYWNrVGV4dHVyZSA9IFRleHR1cmUuRU1QVFk7XG4gICAgZmlsdGVyRGF0YS5pbnB1dFRleHR1cmUgPSBUZXh0dXJlUG9vbC5nZXRPcHRpbWFsVGV4dHVyZSh7XG4gICAgICB3aWR0aDogYm91bmRzLndpZHRoLFxuICAgICAgaGVpZ2h0OiBib3VuZHMuaGVpZ2h0LFxuICAgICAgcmVzb2x1dGlvbjogZmlsdGVyRGF0YS5yZXNvbHV0aW9uLFxuICAgICAgYW50aWFsaWFzOiBmaWx0ZXJEYXRhLmFudGlhbGlhc1xuICAgIH0pO1xuICAgIGlmIChmaWx0ZXJEYXRhLmJsZW5kUmVxdWlyZWQpIHtcbiAgICAgIHJlbmRlcmVyLnJlbmRlclRhcmdldC5maW5pc2hSZW5kZXJQYXNzKCk7XG4gICAgICBjb25zdCByZW5kZXJUYXJnZXQgPSByZW5kZXJlci5yZW5kZXJUYXJnZXQuZ2V0UmVuZGVyVGFyZ2V0KGZpbHRlckRhdGEub3V0cHV0UmVuZGVyU3VyZmFjZSk7XG4gICAgICBmaWx0ZXJEYXRhLmJhY2tUZXh0dXJlID0gdGhpcy5nZXRCYWNrVGV4dHVyZShyZW5kZXJUYXJnZXQsIGJvdW5kcywgcHJldmlvdXNGaWx0ZXJEYXRhPy5ib3VuZHMpO1xuICAgIH1cbiAgICByZW5kZXJlci5yZW5kZXJUYXJnZXQuYmluZCh7IHRhcmdldDogZmlsdGVyRGF0YS5pbnB1dFRleHR1cmUsIGNsZWFyOiB0cnVlIH0pO1xuICAgIHJlbmRlcmVyLmdsb2JhbFVuaWZvcm1zLnB1c2goe1xuICAgICAgb2Zmc2V0OiBib3VuZHNcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogVXBkYXRlcyB0aGUgZmlsdGVyIHVuaWZvcm1zIHdpdGggdGhlIGN1cnJlbnQgZmlsdGVyIHN0YXRlLlxuICAgKiBAcGFyYW0gaW5wdXQgLSBUaGUgaW5wdXQgdGV4dHVyZVxuICAgKiBAcGFyYW0gb3V0cHV0IC0gVGhlIG91dHB1dCByZW5kZXIgc3VyZmFjZVxuICAgKiBAcGFyYW0gZmlsdGVyRGF0YSAtIFRoZSBjdXJyZW50IGZpbHRlciBkYXRhXG4gICAqIEBwYXJhbSBvZmZzZXRYIC0gVGhlIFggb2Zmc2V0IGZvciBwb3NpdGlvbmluZ1xuICAgKiBAcGFyYW0gb2Zmc2V0WSAtIFRoZSBZIG9mZnNldCBmb3IgcG9zaXRpb25pbmdcbiAgICogQHBhcmFtIHJlc29sdXRpb24gLSBUaGUgY3VycmVudCByZXNvbHV0aW9uXG4gICAqIEBwYXJhbSBpc0ZpbmFsVGFyZ2V0IC0gV2hldGhlciB0aGlzIGlzIHRoZSBmaW5hbCByZW5kZXIgdGFyZ2V0XG4gICAqIEBwYXJhbSBjbGVhciAtIFdoZXRoZXIgdG8gY2xlYXIgdGhlIG91dHB1dCBzdXJmYWNlXG4gICAqL1xuICBfdXBkYXRlRmlsdGVyVW5pZm9ybXMoaW5wdXQsIG91dHB1dCwgZmlsdGVyRGF0YSwgb2Zmc2V0WCwgb2Zmc2V0WSwgcmVzb2x1dGlvbiwgaXNGaW5hbFRhcmdldCwgY2xlYXIpIHtcbiAgICBjb25zdCB1bmlmb3JtcyA9IHRoaXMuX2ZpbHRlckdsb2JhbFVuaWZvcm1zLnVuaWZvcm1zO1xuICAgIGNvbnN0IG91dHB1dEZyYW1lID0gdW5pZm9ybXMudU91dHB1dEZyYW1lO1xuICAgIGNvbnN0IGlucHV0U2l6ZSA9IHVuaWZvcm1zLnVJbnB1dFNpemU7XG4gICAgY29uc3QgaW5wdXRQaXhlbCA9IHVuaWZvcm1zLnVJbnB1dFBpeGVsO1xuICAgIGNvbnN0IGlucHV0Q2xhbXAgPSB1bmlmb3Jtcy51SW5wdXRDbGFtcDtcbiAgICBjb25zdCBnbG9iYWxGcmFtZSA9IHVuaWZvcm1zLnVHbG9iYWxGcmFtZTtcbiAgICBjb25zdCBvdXRwdXRUZXh0dXJlID0gdW5pZm9ybXMudU91dHB1dFRleHR1cmU7XG4gICAgaWYgKGlzRmluYWxUYXJnZXQpIHtcbiAgICAgIG91dHB1dEZyYW1lWzBdID0gZmlsdGVyRGF0YS5ib3VuZHMubWluWCAtIG9mZnNldFg7XG4gICAgICBvdXRwdXRGcmFtZVsxXSA9IGZpbHRlckRhdGEuYm91bmRzLm1pblkgLSBvZmZzZXRZO1xuICAgIH0gZWxzZSB7XG4gICAgICBvdXRwdXRGcmFtZVswXSA9IDA7XG4gICAgICBvdXRwdXRGcmFtZVsxXSA9IDA7XG4gICAgfVxuICAgIG91dHB1dEZyYW1lWzJdID0gaW5wdXQuZnJhbWUud2lkdGg7XG4gICAgb3V0cHV0RnJhbWVbM10gPSBpbnB1dC5mcmFtZS5oZWlnaHQ7XG4gICAgaW5wdXRTaXplWzBdID0gaW5wdXQuc291cmNlLndpZHRoO1xuICAgIGlucHV0U2l6ZVsxXSA9IGlucHV0LnNvdXJjZS5oZWlnaHQ7XG4gICAgaW5wdXRTaXplWzJdID0gMSAvIGlucHV0U2l6ZVswXTtcbiAgICBpbnB1dFNpemVbM10gPSAxIC8gaW5wdXRTaXplWzFdO1xuICAgIGlucHV0UGl4ZWxbMF0gPSBpbnB1dC5zb3VyY2UucGl4ZWxXaWR0aDtcbiAgICBpbnB1dFBpeGVsWzFdID0gaW5wdXQuc291cmNlLnBpeGVsSGVpZ2h0O1xuICAgIGlucHV0UGl4ZWxbMl0gPSAxIC8gaW5wdXRQaXhlbFswXTtcbiAgICBpbnB1dFBpeGVsWzNdID0gMSAvIGlucHV0UGl4ZWxbMV07XG4gICAgaW5wdXRDbGFtcFswXSA9IDAuNSAqIGlucHV0UGl4ZWxbMl07XG4gICAgaW5wdXRDbGFtcFsxXSA9IDAuNSAqIGlucHV0UGl4ZWxbM107XG4gICAgaW5wdXRDbGFtcFsyXSA9IGlucHV0LmZyYW1lLndpZHRoICogaW5wdXRTaXplWzJdIC0gMC41ICogaW5wdXRQaXhlbFsyXTtcbiAgICBpbnB1dENsYW1wWzNdID0gaW5wdXQuZnJhbWUuaGVpZ2h0ICogaW5wdXRTaXplWzNdIC0gMC41ICogaW5wdXRQaXhlbFszXTtcbiAgICBjb25zdCByb290VGV4dHVyZSA9IHRoaXMucmVuZGVyZXIucmVuZGVyVGFyZ2V0LnJvb3RSZW5kZXJUYXJnZXQuY29sb3JUZXh0dXJlO1xuICAgIGdsb2JhbEZyYW1lWzBdID0gb2Zmc2V0WCAqIHJlc29sdXRpb247XG4gICAgZ2xvYmFsRnJhbWVbMV0gPSBvZmZzZXRZICogcmVzb2x1dGlvbjtcbiAgICBnbG9iYWxGcmFtZVsyXSA9IHJvb3RUZXh0dXJlLnNvdXJjZS53aWR0aCAqIHJlc29sdXRpb247XG4gICAgZ2xvYmFsRnJhbWVbM10gPSByb290VGV4dHVyZS5zb3VyY2UuaGVpZ2h0ICogcmVzb2x1dGlvbjtcbiAgICBpZiAob3V0cHV0IGluc3RhbmNlb2YgVGV4dHVyZSkgb3V0cHV0LnNvdXJjZS5yZXNvdXJjZSA9IG51bGw7XG4gICAgY29uc3QgcmVuZGVyVGFyZ2V0ID0gdGhpcy5yZW5kZXJlci5yZW5kZXJUYXJnZXQuZ2V0UmVuZGVyVGFyZ2V0KG91dHB1dCk7XG4gICAgdGhpcy5yZW5kZXJlci5yZW5kZXJUYXJnZXQuYmluZCh7IHRhcmdldDogb3V0cHV0LCBjbGVhcjogISFjbGVhciB9KTtcbiAgICBpZiAob3V0cHV0IGluc3RhbmNlb2YgVGV4dHVyZSkge1xuICAgICAgb3V0cHV0VGV4dHVyZVswXSA9IG91dHB1dC5mcmFtZS53aWR0aDtcbiAgICAgIG91dHB1dFRleHR1cmVbMV0gPSBvdXRwdXQuZnJhbWUuaGVpZ2h0O1xuICAgIH0gZWxzZSB7XG4gICAgICBvdXRwdXRUZXh0dXJlWzBdID0gcmVuZGVyVGFyZ2V0LndpZHRoO1xuICAgICAgb3V0cHV0VGV4dHVyZVsxXSA9IHJlbmRlclRhcmdldC5oZWlnaHQ7XG4gICAgfVxuICAgIG91dHB1dFRleHR1cmVbMl0gPSByZW5kZXJUYXJnZXQuaXNSb290ID8gLTEgOiAxO1xuICAgIHRoaXMuX2ZpbHRlckdsb2JhbFVuaWZvcm1zLnVwZGF0ZSgpO1xuICB9XG4gIC8qKlxuICAgKiBGaW5kcyB0aGUgbm9uLXNraXBwZWQgZW50cnkgY2xvc2VzdCB0byB0aGUgdG9wIG9mIHRoZSBmaWx0ZXIgc3RhY2suXG4gICAqXG4gICAqIGBwb3AoKWAgcmVtb3ZlcyBpdHMgZW50cnkgYmVmb3JlIGl0IGFwcGxpZXMgdGhlIGZpbHRlcnMsIHNvIHRoZSByZXN1bHQgaXMgdGhlIGVuY2xvc2luZyBmaWx0ZXIncyBlbnRyeS5cbiAgICogYGdlbmVyYXRlRmlsdGVyZWRUZXh0dXJlKClgIGFwcGxpZXMgdGhlIGZpbHRlcnMgd2hpbGUgaXRzIGVudHJ5IGlzIHN0aWxsIG9uIHRoZSBzdGFjaywgc28gdGhlIHJlc3VsdCBpcyB0aGF0IGVudHJ5LlxuICAgKiBAcmV0dXJucyBUaGUgZW50cnksIG9yIG51bGwgaWYgdGhlcmUgaXMgbm9uZVxuICAgKi9cbiAgX2ZpbmRDbG9zZXN0RmlsdGVyRGF0YSgpIHtcbiAgICBmb3IgKGxldCBpID0gdGhpcy5fZmlsdGVyU3RhY2tJbmRleCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICBjb25zdCBmaWx0ZXJEYXRhID0gdGhpcy5fZmlsdGVyU3RhY2tbaV07XG4gICAgICBpZiAoIWZpbHRlckRhdGEuc2tpcCkgcmV0dXJuIGZpbHRlckRhdGE7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG4gIC8qKlxuICAgKiBDYWxjdWxhdGVzIHRoZSBmaWx0ZXIgYXJlYSBib3VuZHMgYmFzZWQgb24gdGhlIGluc3RydWN0aW9uIHR5cGUuXG4gICAqIEBwYXJhbSBpbnN0cnVjdGlvbiAtIFRoZSBmaWx0ZXIgaW5zdHJ1Y3Rpb25cbiAgICogQHBhcmFtIGJvdW5kcyAtIFRoZSBib3VuZHMgb2JqZWN0IHRvIHBvcHVsYXRlXG4gICAqL1xuICBfY2FsY3VsYXRlRmlsdGVyQXJlYShpbnN0cnVjdGlvbiwgYm91bmRzKSB7XG4gICAgaWYgKGluc3RydWN0aW9uLnJlbmRlcmFibGVzKSB7XG4gICAgICBnZXRHbG9iYWxSZW5kZXJhYmxlQm91bmRzKGluc3RydWN0aW9uLnJlbmRlcmFibGVzLCBib3VuZHMpO1xuICAgIH0gZWxzZSBpZiAoaW5zdHJ1Y3Rpb24uZmlsdGVyRWZmZWN0LmZpbHRlckFyZWEpIHtcbiAgICAgIGJvdW5kcy5jbGVhcigpO1xuICAgICAgYm91bmRzLmFkZFJlY3QoaW5zdHJ1Y3Rpb24uZmlsdGVyRWZmZWN0LmZpbHRlckFyZWEpO1xuICAgICAgYm91bmRzLmFwcGx5TWF0cml4KGluc3RydWN0aW9uLmNvbnRhaW5lci53b3JsZFRyYW5zZm9ybSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGluc3RydWN0aW9uLmNvbnRhaW5lci5nZXRGYXN0R2xvYmFsQm91bmRzKHRydWUsIGJvdW5kcyk7XG4gICAgfVxuICAgIGlmIChpbnN0cnVjdGlvbi5jb250YWluZXIpIHtcbiAgICAgIGNvbnN0IHJlbmRlckdyb3VwID0gaW5zdHJ1Y3Rpb24uY29udGFpbmVyLnJlbmRlckdyb3VwIHx8IGluc3RydWN0aW9uLmNvbnRhaW5lci5wYXJlbnRSZW5kZXJHcm91cDtcbiAgICAgIGNvbnN0IGZpbHRlckZyYW1lVHJhbnNmb3JtID0gcmVuZGVyR3JvdXAuY2FjaGVUb0xvY2FsVHJhbnNmb3JtO1xuICAgICAgaWYgKGZpbHRlckZyYW1lVHJhbnNmb3JtKSB7XG4gICAgICAgIGJvdW5kcy5hcHBseU1hdHJpeChmaWx0ZXJGcmFtZVRyYW5zZm9ybSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIF9hcHBseUZpbHRlcnNUb1RleHR1cmUoZmlsdGVyRGF0YSwgY2xlYXIpIHtcbiAgICBjb25zdCBpbnB1dFRleHR1cmUgPSBmaWx0ZXJEYXRhLmlucHV0VGV4dHVyZTtcbiAgICBjb25zdCBib3VuZHMgPSBmaWx0ZXJEYXRhLmJvdW5kcztcbiAgICBjb25zdCBmaWx0ZXJzID0gZmlsdGVyRGF0YS5maWx0ZXJzO1xuICAgIGNvbnN0IGZpcnN0RW5hYmxlZCA9IGZpbHRlckRhdGEuZmlyc3RFbmFibGVkSW5kZXg7XG4gICAgY29uc3QgbGFzdEVuYWJsZWQgPSBmaWx0ZXJEYXRhLmxhc3RFbmFibGVkSW5kZXg7XG4gICAgdGhpcy5fZ2xvYmFsRmlsdGVyQmluZEdyb3VwLnNldFJlc291cmNlKGlucHV0VGV4dHVyZS5zb3VyY2Uuc3R5bGUsIDIpO1xuICAgIHRoaXMuX2dsb2JhbEZpbHRlckJpbmRHcm91cC5zZXRSZXNvdXJjZShmaWx0ZXJEYXRhLmJhY2tUZXh0dXJlLnNvdXJjZSwgMyk7XG4gICAgaWYgKGZpcnN0RW5hYmxlZCA9PT0gbGFzdEVuYWJsZWQpIHtcbiAgICAgIGZpbHRlcnNbZmlyc3RFbmFibGVkXS5hcHBseSh0aGlzLCBpbnB1dFRleHR1cmUsIGZpbHRlckRhdGEub3V0cHV0UmVuZGVyU3VyZmFjZSwgY2xlYXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgZmxpcCA9IGZpbHRlckRhdGEuaW5wdXRUZXh0dXJlO1xuICAgICAgY29uc3QgdGVtcFRleHR1cmUgPSBUZXh0dXJlUG9vbC5nZXRPcHRpbWFsVGV4dHVyZSh7XG4gICAgICAgIHdpZHRoOiBib3VuZHMud2lkdGgsXG4gICAgICAgIGhlaWdodDogYm91bmRzLmhlaWdodCxcbiAgICAgICAgcmVzb2x1dGlvbjogZmxpcC5zb3VyY2UuX3Jlc29sdXRpb25cbiAgICAgIH0pO1xuICAgICAgbGV0IGZsb3AgPSB0ZW1wVGV4dHVyZTtcbiAgICAgIGZvciAobGV0IGkgPSBmaXJzdEVuYWJsZWQ7IGkgPCBsYXN0RW5hYmxlZDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGZpbHRlciA9IGZpbHRlcnNbaV07XG4gICAgICAgIGlmICghZmlsdGVyLmVuYWJsZWQpIGNvbnRpbnVlO1xuICAgICAgICBmaWx0ZXIuYXBwbHkodGhpcywgZmxpcCwgZmxvcCwgdHJ1ZSk7XG4gICAgICAgIGNvbnN0IHQgPSBmbGlwO1xuICAgICAgICBmbGlwID0gZmxvcDtcbiAgICAgICAgZmxvcCA9IHQ7XG4gICAgICB9XG4gICAgICBmaWx0ZXJzW2xhc3RFbmFibGVkXS5hcHBseSh0aGlzLCBmbGlwLCBmaWx0ZXJEYXRhLm91dHB1dFJlbmRlclN1cmZhY2UsIGNsZWFyKTtcbiAgICAgIFRleHR1cmVQb29sLnJldHVyblRleHR1cmUodGVtcFRleHR1cmUpO1xuICAgIH1cbiAgfVxuICBfY2FsY3VsYXRlRmlsdGVyQm91bmRzKGZpbHRlckRhdGEsIHZpZXdQb3J0LCByb290QW50aWFsaWFzLCByb290UmVzb2x1dGlvbiwgcGFkZGluZ011bHRpcGxpZXIpIHtcbiAgICBjb25zdCByZW5kZXJlciA9IHRoaXMucmVuZGVyZXI7XG4gICAgY29uc3QgYm91bmRzID0gZmlsdGVyRGF0YS5ib3VuZHM7XG4gICAgY29uc3QgZmlsdGVycyA9IGZpbHRlckRhdGEuZmlsdGVycztcbiAgICBsZXQgcmVzb2x1dGlvbiA9IEluZmluaXR5O1xuICAgIGxldCBwYWRkaW5nID0gMDtcbiAgICBsZXQgYW50aWFsaWFzID0gdHJ1ZTtcbiAgICBsZXQgYmxlbmRSZXF1aXJlZCA9IGZhbHNlO1xuICAgIGxldCBlbmFibGVkID0gZmFsc2U7XG4gICAgbGV0IGNsaXBUb1ZpZXdwb3J0ID0gdHJ1ZTtcbiAgICBsZXQgZmlyc3RFbmFibGVkSW5kZXggPSAtMTtcbiAgICBsZXQgbGFzdEVuYWJsZWRJbmRleCA9IC0xO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZmlsdGVycy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgZmlsdGVyID0gZmlsdGVyc1tpXTtcbiAgICAgIGlmICghZmlsdGVyLmVuYWJsZWQpIGNvbnRpbnVlO1xuICAgICAgaWYgKGZpcnN0RW5hYmxlZEluZGV4ID09PSAtMSkgZmlyc3RFbmFibGVkSW5kZXggPSBpO1xuICAgICAgbGFzdEVuYWJsZWRJbmRleCA9IGk7XG4gICAgICByZXNvbHV0aW9uID0gTWF0aC5taW4ocmVzb2x1dGlvbiwgZmlsdGVyLnJlc29sdXRpb24gPT09IFwiaW5oZXJpdFwiID8gcm9vdFJlc29sdXRpb24gOiBmaWx0ZXIucmVzb2x1dGlvbik7XG4gICAgICBwYWRkaW5nICs9IGZpbHRlci5wYWRkaW5nO1xuICAgICAgaWYgKGZpbHRlci5hbnRpYWxpYXMgPT09IFwib2ZmXCIpIHtcbiAgICAgICAgYW50aWFsaWFzID0gZmFsc2U7XG4gICAgICB9IGVsc2UgaWYgKGZpbHRlci5hbnRpYWxpYXMgPT09IFwiaW5oZXJpdFwiKSB7XG4gICAgICAgIGFudGlhbGlhcyAmJiAoYW50aWFsaWFzID0gcm9vdEFudGlhbGlhcyk7XG4gICAgICB9XG4gICAgICBpZiAoIWZpbHRlci5jbGlwVG9WaWV3cG9ydCkge1xuICAgICAgICBjbGlwVG9WaWV3cG9ydCA9IGZhbHNlO1xuICAgICAgfVxuICAgICAgY29uc3QgaXNDb21wYXRpYmxlID0gISEoZmlsdGVyLmNvbXBhdGlibGVSZW5kZXJlcnMgJiByZW5kZXJlci50eXBlKTtcbiAgICAgIGlmICghaXNDb21wYXRpYmxlKSB7XG4gICAgICAgIGVuYWJsZWQgPSBmYWxzZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBpZiAoZmlsdGVyLmJsZW5kUmVxdWlyZWQgJiYgIShyZW5kZXJlci5iYWNrQnVmZmVyPy51c2VCYWNrQnVmZmVyID8/IHRydWUpKSB7XG4gICAgICAgIHdhcm4oXCJCbGVuZCBmaWx0ZXIgcmVxdWlyZXMgYmFja0J1ZmZlciBvbiBXZWJHTCByZW5kZXJlciB0byBiZSBlbmFibGVkLiBTZXQgYHVzZUJhY2tCdWZmZXI6IHRydWVgIGluIHRoZSByZW5kZXJlciBvcHRpb25zLlwiKTtcbiAgICAgICAgZW5hYmxlZCA9IGZhbHNlO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGVuYWJsZWQgPSB0cnVlO1xuICAgICAgYmxlbmRSZXF1aXJlZCB8fCAoYmxlbmRSZXF1aXJlZCA9IGZpbHRlci5ibGVuZFJlcXVpcmVkKTtcbiAgICB9XG4gICAgaWYgKCFlbmFibGVkKSB7XG4gICAgICBmaWx0ZXJEYXRhLnNraXAgPSB0cnVlO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY2xpcFRvVmlld3BvcnQpIHtcbiAgICAgIGJvdW5kcy5maXRCb3VuZHMoMCwgdmlld1BvcnQud2lkdGggLyByb290UmVzb2x1dGlvbiwgMCwgdmlld1BvcnQuaGVpZ2h0IC8gcm9vdFJlc29sdXRpb24pO1xuICAgIH1cbiAgICBib3VuZHMuc2NhbGUocmVzb2x1dGlvbikuY2VpbCgpLnNjYWxlKDEgLyByZXNvbHV0aW9uKS5wYWQoKHBhZGRpbmcgfCAwKSAqIHBhZGRpbmdNdWx0aXBsaWVyKTtcbiAgICBpZiAoIWJvdW5kcy5pc1Bvc2l0aXZlKSB7XG4gICAgICBmaWx0ZXJEYXRhLnNraXAgPSB0cnVlO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBmaWx0ZXJEYXRhLmFudGlhbGlhcyA9IGFudGlhbGlhcztcbiAgICBmaWx0ZXJEYXRhLnJlc29sdXRpb24gPSByZXNvbHV0aW9uO1xuICAgIGZpbHRlckRhdGEuYmxlbmRSZXF1aXJlZCA9IGJsZW5kUmVxdWlyZWQ7XG4gICAgZmlsdGVyRGF0YS5maXJzdEVuYWJsZWRJbmRleCA9IGZpcnN0RW5hYmxlZEluZGV4O1xuICAgIGZpbHRlckRhdGEubGFzdEVuYWJsZWRJbmRleCA9IGxhc3RFbmFibGVkSW5kZXg7XG4gIH1cbiAgX3BvcEZpbHRlckRhdGEoKSB7XG4gICAgdGhpcy5fZmlsdGVyU3RhY2tJbmRleC0tO1xuICAgIHJldHVybiB0aGlzLl9maWx0ZXJTdGFja1t0aGlzLl9maWx0ZXJTdGFja0luZGV4XTtcbiAgfVxuICAvKipcbiAgICogRmluZHMgdGhlIGNsb3Nlc3Qgbm9uLXNraXBwZWQgZW50cnkgdGhhdCBlbmNsb3NlcyB0aGUgZmlsdGVyIGJlaW5nIHB1c2hlZC5cbiAgICpcbiAgICogYHB1c2goKWAgaGFzIGFscmVhZHkgYWRkZWQgdGhhdCBmaWx0ZXIncyBvd24gZW50cnksIHNvIHRoZSBzZWFyY2ggc3RhcnRzIG9uZSBlbnRyeSBiZWxvdyBpdC5cbiAgICogQHJldHVybnMgVGhlIGVudHJ5LCBvciBudWxsIGlmIHRoZXJlIGlzIG5vbmVcbiAgICovXG4gIF9nZXRQcmV2aW91c0ZpbHRlckRhdGEoKSB7XG4gICAgZm9yIChsZXQgaSA9IHRoaXMuX2ZpbHRlclN0YWNrSW5kZXggLSAyOyBpID49IDA7IGktLSkge1xuICAgICAgY29uc3QgZmlsdGVyRGF0YSA9IHRoaXMuX2ZpbHRlclN0YWNrW2ldO1xuICAgICAgaWYgKCFmaWx0ZXJEYXRhLnNraXApIHJldHVybiBmaWx0ZXJEYXRhO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBfcHVzaEZpbHRlckRhdGEoKSB7XG4gICAgbGV0IGZpbHRlckRhdGEgPSB0aGlzLl9maWx0ZXJTdGFja1t0aGlzLl9maWx0ZXJTdGFja0luZGV4XTtcbiAgICBpZiAoIWZpbHRlckRhdGEpIHtcbiAgICAgIGZpbHRlckRhdGEgPSB0aGlzLl9maWx0ZXJTdGFja1t0aGlzLl9maWx0ZXJTdGFja0luZGV4XSA9IG5ldyBGaWx0ZXJEYXRhKCk7XG4gICAgfVxuICAgIHRoaXMuX2ZpbHRlclN0YWNrSW5kZXgrKztcbiAgICByZXR1cm4gZmlsdGVyRGF0YTtcbiAgfVxufVxuLyoqIEBpZ25vcmUgKi9cbkZpbHRlclN5c3RlbS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMU3lzdGVtLFxuICAgIEV4dGVuc2lvblR5cGUuV2ViR1BVU3lzdGVtXG4gIF0sXG4gIG5hbWU6IFwiZmlsdGVyXCJcbn07XG5cbmV4cG9ydCB7IEZpbHRlclN5c3RlbSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9RmlsdGVyU3lzdGVtLm1qcy5tYXBcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFJQSxJQUFNQSxlQUFhLElBQUksT0FBTztBQUM5QixTQUFTLGNBQWMsTUFBTSxRQUFRLHFCQUFxQjtDQUN4RCxNQUFNLGVBQWVBO0NBQ3JCLEtBQUssYUFBYTtDQUNsQixnQkFBZ0IsTUFBTSxxQkFBcUIsWUFBWTtDQUN2RCxPQUFPLGNBQWMsWUFBWTtDQUNqQyxLQUFLLGFBQWE7QUFDcEI7OztBQ05BLFNBQVMsbUJBQW1CLE1BQU0sUUFBUSxXQUFXO0NBQ25ELE1BQU0sZUFBZSxXQUFXLElBQUk7Q0FDcEMsS0FBSyxhQUFhO0NBQ2xCLE1BQU0sYUFBYSxXQUFXLElBQUksQ0FBQyxDQUFDLFNBQVM7Q0FDN0MsTUFBTSxlQUFlLDBCQUEwQixNQUFNLFdBQVcsVUFBVTtDQUMxRSxlQUFlLE1BQU0sY0FBYyxZQUFZO0NBQy9DLEtBQUssYUFBYTtDQUNsQixPQUFPLGNBQWMsWUFBWTtDQUNqQyxXQUFXLE9BQU8sVUFBVTtDQUM1QixXQUFXLE9BQU8sWUFBWTtBQUNoQztBQUNBLFNBQVMsMEJBQTBCLFFBQVEsTUFBTSxRQUFRO0NBQ3ZELElBQUksQ0FBQyxRQUFRO0VBQ1gsS0FBSywwREFBMEQ7RUFDL0QsT0FBTztDQUNUO0NBQ0EsSUFBSSxXQUFXLE1BQU07RUFDbkIsMEJBQTBCLE9BQU8sUUFBUSxNQUFNLE1BQU07RUFDckQsT0FBTyxxQkFBcUI7RUFDNUIsT0FBTyxPQUFPLE9BQU8sY0FBYztDQUNyQztDQUNBLE9BQU87QUFDVDs7O0FDckJBLElBQU0sWUFBTixNQUFnQjtDQUNkLFlBQVksU0FBUztFQUNuQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxVQUFVO0VBQ2YsS0FBSyxPQUFPO0VBQ1osSUFBSSxTQUFTLE1BQ1gsS0FBSyxLQUFLLFFBQVEsSUFBSTtDQUUxQjtDQUNBLEtBQUssTUFBTTtFQUNULEtBQUssT0FBTztFQUNaLEtBQUssc0JBQXNCLEVBQUUsZ0JBQWdCO0VBQzdDLEtBQUssS0FBSyxhQUFhLEtBQUs7RUFDNUIsS0FBSyxLQUFLLGlCQUFpQixDQUFDLEtBQUs7RUFDakMsS0FBSyxLQUFLLGFBQWE7Q0FDekI7Q0FDQSxRQUFRO0VBQ04sSUFBSSxLQUFLLFNBQVMsTUFBTTtFQUN4QixLQUFLLEtBQUssYUFBYTtFQUN2QixLQUFLLE9BQU87Q0FDZDtDQUNBLFVBQVUsUUFBUSxxQkFBcUI7RUFDckMsSUFBSSxDQUFDLEtBQUssU0FDUixjQUFjLEtBQUssTUFBTSxRQUFRLG1CQUFtQjtDQUV4RDtDQUNBLGVBQWUsUUFBUSxXQUFXO0VBQ2hDLG1CQUFtQixLQUFLLE1BQU0sUUFBUSxTQUFTO0NBQ2pEO0NBQ0EsY0FBYyxPQUFPLFdBQVc7RUFDOUIsTUFBTSxPQUFPLEtBQUs7RUFDbEIsT0FBTyxVQUFVLE1BQU0sS0FBSztDQUM5QjtDQUNBLFVBQVU7RUFDUixLQUFLLE1BQU07Q0FDYjtDQUNBLE9BQU8sS0FBSyxNQUFNO0VBQ2hCLE9BQU8sZ0JBQWdCO0NBQ3pCO0FBQ0Y7QUFDQSxVQUFVLFlBQVksY0FBYzs7O0FDNUNwQyxJQUFNLFlBQU4sTUFBZ0I7Q0FDZCxZQUFZLFNBQVM7RUFDbkIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssT0FBTztFQUNaLElBQUksU0FBUyxNQUNYLEtBQUssS0FBSyxRQUFRLElBQUk7Q0FFMUI7Q0FDQSxLQUFLLE1BQU07RUFDVCxLQUFLLE9BQU87Q0FDZDtDQUNBLFVBQVUsQ0FDVjtDQUNBLE9BQU8sS0FBSyxNQUFNO0VBQ2hCLE9BQU8sT0FBTyxTQUFTO0NBQ3pCO0FBQ0Y7QUFDQSxVQUFVLFlBQVksY0FBYzs7O0FDZHBDLElBQU0sY0FBTixNQUFrQjtDQUNoQixZQUFZLFNBQVM7RUFDbkIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssT0FBTztFQUNaLElBQUksU0FBUyxNQUNYLEtBQUssS0FBSyxRQUFRLElBQUk7Q0FFMUI7Q0FDQSxLQUFLLE1BQU07RUFDVCxLQUFLLE9BQU87RUFDWixLQUFLLEtBQUssaUJBQWlCO0VBQzNCLEtBQUssS0FBSyxhQUFhO0NBQ3pCO0NBQ0EsUUFBUTtFQUNOLElBQUksS0FBSyxTQUFTLE1BQU07RUFDeEIsS0FBSyxLQUFLLGFBQWE7RUFDdkIsS0FBSyxLQUFLLGlCQUFpQjtFQUMzQixLQUFLLE9BQU87Q0FDZDtDQUNBLFVBQVUsUUFBUSxxQkFBcUI7RUFDckMsY0FBYyxLQUFLLE1BQU0sUUFBUSxtQkFBbUI7Q0FDdEQ7Q0FDQSxlQUFlLFFBQVEsV0FBVztFQUNoQyxtQkFBbUIsS0FBSyxNQUFNLFFBQVEsU0FBUztDQUNqRDtDQUNBLGNBQWMsT0FBTyxXQUFXO0VBQzlCLE1BQU0sT0FBTyxLQUFLO0VBQ2xCLE9BQU8sVUFBVSxNQUFNLEtBQUs7Q0FDOUI7Q0FDQSxVQUFVO0VBQ1IsS0FBSyxNQUFNO0NBQ2I7Q0FDQSxPQUFPLEtBQUssTUFBTTtFQUNoQixPQUFPLGdCQUFnQjtDQUN6QjtBQUNGO0FBQ0EsWUFBWSxZQUFZLGNBQWM7OztBQ3ZDdEMsSUFBSTtBQUNKLGVBQWUsdUJBQXVCO0NBQ3BDLFlBQVksV0FBVyxZQUFZO0VBRWpDLE1BQU0sS0FEUyxXQUFXLElBQUksQ0FBQyxDQUFDLGFBQWEsR0FBRyxDQUNoQyxDQUFDLENBQUMsV0FBVyxPQUFPO0VBQ3BDLElBQUksQ0FBQyxJQUNILE9BQU87RUFFVCxNQUFNLFFBQVEsTUFBTSxJQUFJLFNBQVMsWUFBWTtHQUMzQyxNQUFNLFNBQVMsU0FBUyxjQUFjLE9BQU87R0FDN0MsT0FBTyxxQkFBcUIsUUFBUSxNQUFNO0dBQzFDLE9BQU8sZ0JBQWdCLFFBQVEsSUFBSTtHQUNuQyxPQUFPLFdBQVc7R0FDbEIsT0FBTyxjQUFjO0dBQ3JCLE9BQU8sVUFBVTtHQUNqQixPQUFPLE1BQU07R0FDYixPQUFPLEtBQUs7RUFDZCxDQUFDO0VBQ0QsSUFBSSxDQUFDLE9BQ0gsT0FBTztFQUVULE1BQU0sVUFBVSxHQUFHLGNBQWM7RUFDakMsR0FBRyxZQUFZLEdBQUcsWUFBWSxPQUFPO0VBQ3JDLE1BQU0sY0FBYyxHQUFHLGtCQUFrQjtFQUN6QyxHQUFHLGdCQUFnQixHQUFHLGFBQWEsV0FBVztFQUM5QyxHQUFHLHFCQUNELEdBQUcsYUFDSCxHQUFHLG1CQUNILEdBQUcsWUFDSCxTQUNBLENBQ0Y7RUFDQSxHQUFHLFlBQVksR0FBRyxnQ0FBZ0MsS0FBSztFQUN2RCxHQUFHLFlBQVksR0FBRyxvQ0FBb0MsR0FBRyxJQUFJO0VBQzdELEdBQUcsV0FBVyxHQUFHLFlBQVksR0FBRyxHQUFHLE1BQU0sR0FBRyxNQUFNLEdBQUcsZUFBZSxLQUFLO0VBQ3pFLE1BQU0sd0JBQVEsSUFBSSxXQUFXLENBQUM7RUFDOUIsR0FBRyxXQUFXLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxNQUFNLEdBQUcsZUFBZSxLQUFLO0VBQzFELEdBQUcsa0JBQWtCLFdBQVc7RUFDaEMsR0FBRyxjQUFjLE9BQU87RUFDeEIsR0FBRyxhQUFhLG9CQUFvQixDQUFDLEVBQUUsWUFBWTtFQUNuRCxPQUFPLE1BQU0sTUFBTSxNQUFNLEtBQUssd0JBQXdCO0NBQ3hELEVBQUEsQ0FBRztDQUNILE9BQU87QUFDVDs7O0FDeENBLElBQU0sZUFBZSxNQUFNLHFCQUFxQixjQUFjO0NBQzVELFlBQVksU0FBUztFQUNuQixNQUFNLE9BQU87O0VBR2IsS0FBSyxVQUFVOztFQUVmLEtBQUssaUJBQWlCO0VBQ3RCLFVBQVU7R0FDUixHQUFHLGFBQWE7R0FDaEIsR0FBRztFQUNMO0VBQ0EsS0FBSyxjQUFjO0VBQ25CLEtBQUssdUJBQXVCO0VBQzVCLEtBQUssYUFBYSxRQUFRLGFBQWE7RUFDdkMsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxXQUFXLFFBQVEsYUFBYTtFQUNyQyxLQUFLLFlBQVksUUFBUSxhQUFhO0VBQ3RDLEtBQUssNkJBQTZCLEtBQUssMkJBQTJCLEtBQUssSUFBSTtFQUMzRSxLQUFLLG1DQUFtQztFQUN4QyxLQUFLLFFBQVE7RUFDYixLQUFLLFdBQVc7RUFDaEIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxhQUFhLEtBQUssV0FBVyxLQUFLLElBQUk7RUFDM0MsS0FBSyxvQkFBb0IsS0FBSyxrQkFBa0IsS0FBSyxJQUFJO0VBQ3pELEtBQUssV0FBVyxLQUFLLFNBQVMsS0FBSyxJQUFJO0VBQ3ZDLEtBQUssZUFBZSxLQUFLLGFBQWEsS0FBSyxJQUFJO0VBQy9DLEtBQUssY0FBYyxLQUFLLFlBQVksS0FBSyxJQUFJO0VBQzdDLEtBQUssWUFBWSxLQUFLLFVBQVUsS0FBSyxJQUFJO0VBQ3pDLEtBQUssb0JBQW9CLEtBQUssa0JBQWtCLEtBQUssSUFBSTtFQUN6RCxJQUFJLFFBQVEsYUFBYSxPQUN2QixLQUFVLEtBQUs7Q0FFbkI7O0NBRUEsY0FBYztFQUNaLElBQUksS0FBSyxXQUNQO0VBRUYsSUFBSSxLQUFLLFlBQVk7R0FDbkIsTUFBTSxZQUFZLE9BQU8sT0FBTyxZQUFZLEtBQUssU0FBUztHQUMxRCxLQUFLLGtCQUFrQixLQUFLLE1BQU0sS0FBSyxrQkFBa0IsU0FBUztFQUNwRTtFQUNBLElBQUksQ0FBQyxLQUFLLGNBQWMsS0FBSyxtQkFBbUIsR0FDOUMsS0FBSyxrQkFBa0IsS0FBSyxhQUFhLEtBQUssTUFBTSxNQUFNLEtBQUssVUFBVSxJQUFJO0VBRS9FLElBQUksS0FBSyxTQUNQLEtBQUssT0FBTztDQUVoQjs7Q0FFQSw2QkFBNkI7RUFDM0IsS0FBSyxZQUFZO0VBQ2pCLElBQUksS0FBSyxXQUNQLEtBQUssbUNBQW1DO09BRXhDLEtBQUssbUNBQW1DLEtBQUssU0FBUywwQkFDcEQsS0FBSywwQkFDUDtDQUVKOzs7OztDQUtBLElBQUksVUFBVTtFQUNaLE9BQU8sQ0FBQyxDQUFDLEtBQUssU0FBUyxjQUFjLENBQUMsQ0FBQyxLQUFLLFNBQVM7Q0FDdkQ7Ozs7O0NBS0EsTUFBTSxPQUFPO0VBQ1gsSUFBSSxLQUFLLE9BQ1AsT0FBTyxLQUFLO0VBRWQsTUFBTSxTQUFTLEtBQUs7RUFDcEIsTUFBTSxVQUFVLEtBQUs7RUFDckIsS0FBSyxPQUFPLGVBQWUsT0FBTyxvQkFBb0IsT0FBTyxlQUFlLE9BQU8scUJBQXFCLE9BQU8sU0FBUyxPQUFPLFFBQzdILE9BQU8sV0FBVztFQUVwQixPQUFPLGlCQUFpQixRQUFRLEtBQUssWUFBWTtFQUNqRCxPQUFPLGlCQUFpQixTQUFTLEtBQUssV0FBVztFQUNqRCxPQUFPLGlCQUFpQixVQUFVLEtBQUssU0FBUztFQUNoRCxJQUFJLENBQUMsS0FBSyxlQUFlLEdBQUc7R0FDMUIsSUFBSSxDQUFDLFFBQVEsU0FDWCxPQUFPLGlCQUFpQixXQUFXLEtBQUssVUFBVTtHQUVwRCxPQUFPLGlCQUFpQixrQkFBa0IsS0FBSyxpQkFBaUI7R0FDaEUsT0FBTyxpQkFBaUIsU0FBUyxLQUFLLFVBQVUsSUFBSTtFQUN0RCxPQUNFLEtBQUssWUFBWTtFQUVuQixJQUFJLENBQUMsS0FBSyxTQUNSLE9BQU8saUJBQWlCLGtCQUFrQixLQUFLLGlCQUFpQjtFQUVsRSxLQUFLLFlBQVksTUFBTSxxQkFBcUI7RUFDNUMsS0FBSyxRQUFRLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDNUMsSUFBSSxLQUFLLFNBQ1AsUUFBUSxJQUFJO1FBQ1A7SUFDTCxLQUFLLFdBQVc7SUFDaEIsS0FBSyxVQUFVO0lBQ2YsSUFBSSxRQUFRLHFCQUFxQixLQUFLLEdBQ3BDLEtBQUssa0JBQWtCLGlCQUFpQjtLQUN0QyxLQUFLLFNBQVMsSUFBSSxXQUFXLCtCQUErQixRQUFRLGlCQUFpQixHQUFHLENBQUM7SUFDM0YsQ0FBQztJQUVILE9BQU8sS0FBSztHQUNkO0VBQ0YsQ0FBQztFQUNELE9BQU8sS0FBSztDQUNkOzs7OztDQUtBLFNBQVMsT0FBTztFQUNkLEtBQUssU0FBUyxvQkFBb0IsU0FBUyxLQUFLLFVBQVUsSUFBSTtFQUM5RCxLQUFLLEtBQUssU0FBUyxLQUFLO0VBQ3hCLElBQUksS0FBSyxTQUFTO0dBQ2hCLEtBQUssUUFBUSxLQUFLO0dBQ2xCLEtBQUssVUFBVTtHQUNmLEtBQUssV0FBVztFQUNsQjtDQUNGOzs7OztDQUtBLG1CQUFtQjtFQUNqQixNQUFNLFNBQVMsS0FBSztFQUNwQixPQUFPLENBQUMsT0FBTyxVQUFVLENBQUMsT0FBTztDQUNuQzs7Ozs7Q0FLQSxpQkFBaUI7RUFFZixPQURlLEtBQUssU0FDTixhQUFhO0NBQzdCOztDQUVBLGVBQWU7RUFDYixLQUFLLHFCQUFxQjtDQUM1Qjs7Q0FFQSxjQUFjO0VBQ1osS0FBSyxxQkFBcUI7Q0FDNUI7O0NBRUEsWUFBWTtFQUNWLElBQUksS0FBSyxlQUFlLENBQUMsS0FBSyxpQkFBaUIsR0FBRztHQUNoRCxLQUFLLGtCQUFrQjtHQUN2QixLQUFLLFlBQVk7R0FDakIsS0FBSyxrQkFBa0I7RUFDekI7Q0FDRjs7Q0FFQSxvQkFBb0I7RUFDbEIsSUFBSSxDQUFDLEtBQUssU0FDUjtFQUVGLEtBQUssWUFBWTtDQUNuQjtDQUNBLGFBQWE7RUFFWCxLQURvQixTQUNiLG9CQUFvQixXQUFXLEtBQUssVUFBVTtFQUNyRCxLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxvQkFBb0I7RUFFbEIsS0FEb0IsU0FDYixvQkFBb0Isa0JBQWtCLEtBQUssaUJBQWlCO0VBQ25FLElBQUksS0FBSyxpQkFBaUI7R0FDeEIsYUFBYSxLQUFLLGVBQWU7R0FDakMsS0FBSyxrQkFBa0IsS0FBSztFQUM5QjtFQUNBLEtBQUssWUFBWTtDQUNuQjs7Q0FFQSxjQUFjO0VBQ1osTUFBTSxTQUFTLEtBQUs7RUFDcEIsSUFBSSxLQUFLLFNBQVM7R0FDaEIsS0FBSyxVQUFVO0dBQ2YsS0FBSyxPQUFPLE9BQU8sWUFBWSxPQUFPLFdBQVc7RUFDbkQ7RUFDQSxLQUFLLGtCQUFrQjtFQUN2QixLQUFLLFlBQVk7RUFDakIsS0FBSyxrQkFBa0I7RUFDdkIsSUFBSSxLQUFLLFlBQVksS0FBSyxTQUFTO0dBQ2pDLEtBQUssU0FBUyxJQUFJO0dBQ2xCLEtBQUssV0FBVztHQUNoQixLQUFLLFVBQVU7RUFDakI7RUFDQSxJQUFJLEtBQUssaUJBQWlCLEdBQ3hCLEtBQUssYUFBYTtPQUNiLElBQUksS0FBSyxVQUNkLEtBQVUsU0FBUyxLQUFLO0NBRTVCOztDQUVBLFVBQVU7RUFDUixLQUFLLHFCQUFxQjtFQUMxQixNQUFNLFNBQVMsS0FBSztFQUNwQixJQUFJLFFBQVE7R0FDVixPQUFPLG9CQUFvQixRQUFRLEtBQUssWUFBWTtHQUNwRCxPQUFPLG9CQUFvQixTQUFTLEtBQUssV0FBVztHQUNwRCxPQUFPLG9CQUFvQixVQUFVLEtBQUssU0FBUztHQUNuRCxPQUFPLG9CQUFvQixXQUFXLEtBQUssVUFBVTtHQUNyRCxPQUFPLG9CQUFvQixrQkFBa0IsS0FBSyxpQkFBaUI7R0FDbkUsT0FBTyxvQkFBb0Isa0JBQWtCLEtBQUssaUJBQWlCO0dBQ25FLE9BQU8sb0JBQW9CLFNBQVMsS0FBSyxVQUFVLElBQUk7R0FDdkQsT0FBTyxNQUFNO0dBQ2IsT0FBTyxNQUFNO0dBQ2IsT0FBTyxLQUFLO0VBQ2Q7RUFDQSxNQUFNLFFBQVE7Q0FDaEI7O0NBRUEsSUFBSSxhQUFhO0VBQ2YsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLFdBQVcsT0FBTztFQUNwQixJQUFJLFVBQVUsS0FBSyxhQUFhO0dBQzlCLEtBQUssY0FBYztHQUNuQixLQUFLLHFCQUFxQjtFQUM1QjtDQUNGOzs7Ozs7Q0FNQSxJQUFJLFlBQVk7RUFDZCxPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksVUFBVSxPQUFPO0VBQ25CLElBQUksVUFBVSxLQUFLLFlBQVk7R0FDN0IsS0FBSyxhQUFhO0dBQ2xCLEtBQUsscUJBQXFCO0VBQzVCO0NBQ0Y7Ozs7Ozs7Ozs7Ozs7Q0FhQSx1QkFBdUI7RUFDckIsSUFBSSxLQUFLLGVBQWUsS0FBSyxpQkFBaUIsR0FBRztHQUMvQyxJQUFJLENBQUMsS0FBSyxjQUFjLEtBQUssU0FBUywyQkFBMkI7SUFDL0QsSUFBSSxLQUFLLHNCQUFzQjtLQUM3QixPQUFPLE9BQU8sT0FBTyxLQUFLLGFBQWEsSUFBSTtLQUMzQyxLQUFLLHVCQUF1QjtLQUM1QixLQUFLLGtCQUFrQjtJQUN6QjtJQUNBLElBQUksS0FBSyxxQ0FBcUMsTUFDNUMsS0FBSyxtQ0FBbUMsS0FBSyxTQUFTLDBCQUNwRCxLQUFLLDBCQUNQO0dBRUosT0FBTztJQUNMLElBQUksS0FBSyxxQ0FBcUMsTUFBTTtLQUNsRCxLQUFLLFNBQVMseUJBQXlCLEtBQUssZ0NBQWdDO0tBQzVFLEtBQUssbUNBQW1DO0lBQzFDO0lBQ0EsSUFBSSxDQUFDLEtBQUssc0JBQXNCO0tBQzlCLE9BQU8sT0FBTyxJQUFJLEtBQUssYUFBYSxJQUFJO0tBQ3hDLEtBQUssdUJBQXVCO0tBQzVCLEtBQUssa0JBQWtCO0lBQ3pCO0dBQ0Y7RUFDRixPQUFPO0dBQ0wsSUFBSSxLQUFLLHFDQUFxQyxNQUFNO0lBQ2xELEtBQUssU0FBUyx5QkFBeUIsS0FBSyxnQ0FBZ0M7SUFDNUUsS0FBSyxtQ0FBbUM7R0FDMUM7R0FDQSxJQUFJLEtBQUssc0JBQXNCO0lBQzdCLE9BQU8sT0FBTyxPQUFPLEtBQUssYUFBYSxJQUFJO0lBQzNDLEtBQUssdUJBQXVCO0lBQzVCLEtBQUssa0JBQWtCO0dBQ3pCO0VBQ0Y7Q0FDRjtDQUNBLE9BQU8sS0FBSyxVQUFVO0VBQ3BCLE9BQU8sV0FBVyxvQkFBb0Isb0JBQW9CO0NBQzVEO0FBQ0Y7QUFDQSxhQUFhLFlBQVksY0FBYzs7QUFFdkMsYUFBYSxpQkFBaUI7Q0FDNUIsR0FBRyxjQUFjOztDQUVqQixVQUFVOztDQUVWLFVBQVU7O0NBRVYsV0FBVzs7Q0FFWCxhQUFhOztDQUViLE1BQU07O0NBRU4sT0FBTzs7Q0FFUCxhQUFhOztDQUViLFNBQVM7QUFDWDs7Ozs7QUFLQSxhQUFhLGFBQWE7Q0FDeEIsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0FBQ1A7QUFDQSxJQUFJLGNBQWM7OztBQ3BVbEIsSUFBTSxVQUFVLENBQUM7QUFDakIsV0FBVyxhQUFhLGNBQWMsZUFBZSxPQUFPO0FBQzVELFNBQVMsaUJBQWlCLFVBQVUsQ0FBQyxHQUFHO0NBQ3RDLE9BQU8sa0JBQWtCLE9BQU87QUFDbEM7QUFDQSxTQUFTLGtCQUFrQixVQUFVLENBQUMsR0FBRztDQUN2QyxNQUFNLGNBQWMsV0FBVyxRQUFRO0NBQ3ZDLE1BQU0sTUFBTSxjQUFjLFFBQVEsV0FBVztDQUM3QyxNQUFNLE9BQU8sY0FBYyxVQUFVLEVBQUUsVUFBVSxRQUFRO0NBQ3pELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztFQUN2QyxNQUFNLFNBQVMsUUFBUTtFQUN2QixJQUFJLE9BQU8sS0FBSyxHQUFHLEdBQ2pCLE9BQU8sSUFBSSxPQUFPLElBQUk7Q0FFMUI7Q0FDQSxNQUFNLElBQUksTUFBTSw4Q0FBOEMsS0FBSyxVQUFVO0FBQy9FO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVSxDQUFDLEdBQUcsWUFBWSxPQUFPO0NBQzFELE1BQU0sY0FBYyxXQUFXLFFBQVE7Q0FDdkMsTUFBTSxXQUFXLGNBQWMsUUFBUSxXQUFXO0NBQ2xELE1BQU0sT0FBTyxjQUFjLFVBQVUsRUFBRSxVQUFVLFFBQVE7Q0FDekQsSUFBSSxDQUFDLGFBQWEsTUFBTSxJQUFJLFFBQVEsR0FDbEMsT0FBTyxNQUFNLElBQUksUUFBUTtDQUUzQixNQUFNLFVBQVUsSUFBSSxRQUFRLEVBQUUsUUFBUSxrQkFBa0IsSUFBSSxFQUFFLENBQUM7Q0FDL0QsUUFBUSxHQUFHLGlCQUFpQjtFQUMxQixJQUFJLE1BQU0sSUFBSSxRQUFRLEdBQ3BCLE1BQU0sT0FBTyxRQUFRO0NBRXpCLENBQUM7Q0FDRCxJQUFJLENBQUMsV0FDSCxNQUFNLElBQUksVUFBVSxPQUFPO0NBRTdCLE9BQU87QUFDVDtBQUNBLFNBQVMsWUFBWSxJQUFJLFlBQVksT0FBTztDQUMxQyxJQUFJLE9BQU8sT0FBTyxVQUNoQixPQUFPLE1BQU0sSUFBSSxFQUFFO01BQ2QsSUFBSSxjQUFjLGVBQ3ZCLE9BQU8sSUFBSSxRQUFRLEVBQUUsUUFBUSxHQUFHLENBQUM7Q0FFbkMsT0FBTyxrQkFBa0IsSUFBSSxTQUFTO0FBQ3hDO0FBQ0EsUUFBUSxPQUFPO0FBQ2YsY0FBYyxPQUFPOzs7QUN0Q3JCLFdBQVcsSUFDVCxXQUNBLFdBQ0EsYUFDQSxhQUNBLGFBQ0EsY0FDQSxpQkFDRjs7O0FDbkJBLElBQUksdUJBQXVDLGtCQUFFLDBCQUEwQjtDQUNyRSxzQkFBc0Isc0JBQXNCLFNBQVMsS0FBSztDQUMxRCxzQkFBc0Isc0JBQXNCLFlBQVksS0FBSztDQUM3RCxzQkFBc0Isc0JBQXNCLFVBQVUsS0FBSztDQUMzRCxPQUFPO0FBQ1QsRUFBQSxDQUFHLHdCQUF3QixDQUFDLENBQUM7OztBQ0g3QixTQUFTLFdBQVcsT0FBTztDQUN6QixJQUFJLE9BQU8sVUFBVSxVQUNuQixNQUFNLElBQUksVUFBVSxtQ0FBbUMsS0FBSyxVQUFVLEtBQUssR0FBRztBQUVsRjtBQUNBLFNBQVMsZ0JBQWdCLEtBQUs7Q0FFNUIsT0FEVyxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFDakIsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZCO0FBQ0EsU0FBUyxhQUFhLFFBQVE7Q0FDNUIsT0FBTyxPQUFPLFFBQVEsdUJBQXVCLE1BQU07QUFDckQ7QUFDQSxTQUFTLFdBQVcsS0FBSyxNQUFNLFNBQVM7Q0FDdEMsT0FBTyxJQUFJLFFBQVEsSUFBSSxPQUFPLGFBQWEsSUFBSSxHQUFHLEdBQUcsR0FBRyxPQUFPO0FBQ2pFO0FBQ0EsU0FBUyxxQkFBcUIsT0FBTyxnQkFBZ0I7Q0FDbkQsSUFBSSxNQUFNO0NBQ1YsSUFBSSxvQkFBb0I7Q0FDeEIsSUFBSSxZQUFZO0NBQ2hCLElBQUksT0FBTztDQUNYLElBQUksT0FBTztDQUNYLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxNQUFNLFFBQVEsRUFBRSxHQUFHO0VBQ3RDLElBQUksSUFBSSxNQUFNLFFBQ1osT0FBTyxNQUFNLFdBQVcsQ0FBQztPQUNwQixJQUFJLFNBQVMsSUFDbEI7T0FFQSxPQUFPO0VBRVQsSUFBSSxTQUFTLElBQUk7R0FDZixJQUFJLGNBQWMsSUFBSSxLQUFLLFNBQVMsR0FBRyxDQUN2QyxPQUFPLElBQUksY0FBYyxJQUFJLEtBQUssU0FBUyxHQUFHO0lBQzVDLElBQUksSUFBSSxTQUFTLEtBQUssc0JBQXNCLEtBQUssSUFBSSxXQUFXLElBQUksU0FBUyxDQUFDLE1BQU0sTUFBTSxJQUFJLFdBQVcsSUFBSSxTQUFTLENBQUMsTUFBTSxJQUFJO0tBQy9ILElBQUksSUFBSSxTQUFTLEdBQUc7TUFDbEIsTUFBTSxpQkFBaUIsSUFBSSxZQUFZLEdBQUc7TUFDMUMsSUFBSSxtQkFBbUIsSUFBSSxTQUFTLEdBQUc7T0FDckMsSUFBSSxtQkFBbUIsSUFBSTtRQUN6QixNQUFNO1FBQ04sb0JBQW9CO09BQ3RCLE9BQU87UUFDTCxNQUFNLElBQUksTUFBTSxHQUFHLGNBQWM7UUFDakMsb0JBQW9CLElBQUksU0FBUyxJQUFJLElBQUksWUFBWSxHQUFHO09BQzFEO09BQ0EsWUFBWTtPQUNaLE9BQU87T0FDUDtNQUNGO0tBQ0YsT0FBTyxJQUFJLElBQUksV0FBVyxLQUFLLElBQUksV0FBVyxHQUFHO01BQy9DLE1BQU07TUFDTixvQkFBb0I7TUFDcEIsWUFBWTtNQUNaLE9BQU87TUFDUDtLQUNGO0lBQ0Y7SUFDQSxJQUFJLGdCQUFnQjtLQUNsQixJQUFJLElBQUksU0FBUyxHQUNmLE9BQU87VUFFUCxNQUFNO0tBRVIsb0JBQW9CO0lBQ3RCO0dBQ0YsT0FBTztJQUNMLElBQUksSUFBSSxTQUFTLEdBQ2YsT0FBTyxJQUFJLE1BQU0sTUFBTSxZQUFZLEdBQUcsQ0FBQztTQUV2QyxNQUFNLE1BQU0sTUFBTSxZQUFZLEdBQUcsQ0FBQztJQUVwQyxvQkFBb0IsSUFBSSxZQUFZO0dBQ3RDO0dBQ0EsWUFBWTtHQUNaLE9BQU87RUFDVCxPQUFPLElBQUksU0FBUyxNQUFNLFNBQVMsSUFDakMsRUFBRTtPQUVGLE9BQU87Q0FFWDtDQUNBLE9BQU87QUFDVDtBQUNBLElBQU0sT0FBTzs7Ozs7Ozs7Ozs7Q0FXWCxRQUFRLE9BQU87RUFDYixPQUFPLFdBQVcsT0FBTyxNQUFNLEdBQUc7Q0FDcEM7Ozs7Ozs7Ozs7Ozs7Q0FhQSxNQUFNLE9BQU87RUFDWCxPQUFPLFdBQVcsS0FBSyxLQUFLLFFBQVEsS0FBSyxDQUFDO0NBQzVDOzs7Ozs7Ozs7OztDQVdBLFVBQVUsT0FBTztFQUNmLE9BQU8seUlBQXlJLEtBQUssS0FBSztDQUM1Sjs7Ozs7Ozs7Ozs7Q0FXQSxVQUFVLE9BQU87RUFDZixPQUFPLE1BQU0sV0FBVyxPQUFPO0NBQ2pDOzs7Ozs7Ozs7Ozs7OztDQWNBLFlBQVksT0FBTztFQUNqQixPQUFPLFdBQVcsS0FBSyxLQUFLLFFBQVEsS0FBSyxDQUFDO0NBQzVDOzs7Ozs7Ozs7Ozs7OztDQWNBLFlBQVksT0FBTztFQUNqQixXQUFXLEtBQUs7RUFDaEIsUUFBUSxLQUFLLFFBQVEsS0FBSztFQUMxQixNQUFNLFlBQVksZUFBZSxLQUFLLEtBQUs7RUFDM0MsSUFBSSxXQUNGLE9BQU8sVUFBVTtFQUVuQixNQUFNLGdCQUFnQixrQkFBa0IsS0FBSyxLQUFLO0VBQ2xELElBQUksZUFDRixPQUFPLGNBQWM7RUFFdkIsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Ozs7O0NBZ0JBLFdBQVcsS0FBSyxlQUFlLGVBQWU7RUFDNUMsV0FBVyxHQUFHO0VBQ2QsSUFBSSxLQUFLLFVBQVUsR0FBRyxLQUFLLEtBQUssVUFBVSxHQUFHLEdBQUcsT0FBTztFQUN2RCxNQUFNLFVBQVUsZ0JBQWdCLEtBQUssUUFBUSxpQkFBaUIsV0FBVyxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztFQUM1RixNQUFNLFVBQVUsZ0JBQWdCLEtBQUssUUFBUSxpQkFBaUIsS0FBSyxTQUFTLE9BQU8sQ0FBQyxDQUFDO0VBQ3JGLE1BQU0sS0FBSyxRQUFRLEdBQUc7RUFDdEIsSUFBSSxJQUFJLFdBQVcsR0FBRyxHQUNwQixPQUFPLEtBQUssS0FBSyxTQUFTLElBQUksTUFBTSxDQUFDLENBQUM7RUFHeEMsT0FEcUIsS0FBSyxXQUFXLEdBQUcsSUFBSSxNQUFNLEtBQUssS0FBSyxTQUFTLEdBQUc7Q0FFMUU7Ozs7Ozs7Ozs7Ozs7O0NBY0EsVUFBVSxPQUFPO0VBQ2YsV0FBVyxLQUFLO0VBQ2hCLElBQUksTUFBTSxXQUFXLEdBQUcsT0FBTztFQUMvQixJQUFJLEtBQUssVUFBVSxLQUFLLEtBQUssS0FBSyxVQUFVLEtBQUssR0FBRyxPQUFPO0VBQzNELFFBQVEsS0FBSyxRQUFRLEtBQUs7RUFDMUIsSUFBSSxXQUFXO0VBQ2YsTUFBTSxhQUFhLE1BQU0sV0FBVyxHQUFHO0VBQ3ZDLElBQUksS0FBSyxZQUFZLEtBQUssR0FBRztHQUMzQixXQUFXLEtBQUssU0FBUyxLQUFLO0dBQzlCLFFBQVEsTUFBTSxNQUFNLFNBQVMsTUFBTTtFQUNyQztFQUNBLE1BQU0sb0JBQW9CLE1BQU0sU0FBUyxHQUFHO0VBQzVDLFFBQVEscUJBQXFCLE9BQU8sS0FBSztFQUN6QyxJQUFJLE1BQU0sU0FBUyxLQUFLLG1CQUFtQixTQUFTO0VBQ3BELElBQUksWUFBWSxPQUFPLElBQUk7RUFDM0IsT0FBTyxXQUFXO0NBQ3BCOzs7Ozs7Ozs7Ozs7OztDQWNBLFdBQVcsT0FBTztFQUNoQixXQUFXLEtBQUs7RUFDaEIsUUFBUSxLQUFLLFFBQVEsS0FBSztFQUMxQixJQUFJLEtBQUssWUFBWSxLQUFLLEdBQUcsT0FBTztFQUNwQyxPQUFPLE1BQU0sV0FBVyxHQUFHO0NBQzdCOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQSxLQUFLLEdBQUcsVUFBVTtFQUNoQixJQUFJLFNBQVMsV0FBVyxHQUN0QixPQUFPO0VBRVQsSUFBSTtFQUNKLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsRUFBRSxHQUFHO0dBQ3hDLE1BQU0sTUFBTSxTQUFTO0dBQ3JCLFdBQVcsR0FBRztHQUNkLElBQUksSUFBSSxTQUFTLEdBQUc7SUFDbEIsSUFBSSxXQUFXLEtBQUssR0FBRyxTQUFTO1NBQzNCO0tBQ0gsTUFBTSxVQUFVLFNBQVMsSUFBSSxNQUFNO0tBQ25DLElBQUksS0FBSyxlQUFlLFNBQVMsS0FBSyxRQUFRLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQyxHQUNsRSxVQUFVLE9BQU87VUFFakIsVUFBVSxJQUFJO0lBRWxCO0dBQ0Y7RUFDRjtFQUNBLElBQUksV0FBVyxLQUFLLEdBQ2xCLE9BQU87RUFFVCxPQUFPLEtBQUssVUFBVSxNQUFNO0NBQzlCOzs7Ozs7Ozs7Ozs7OztDQWNBLFFBQVEsT0FBTztFQUNiLFdBQVcsS0FBSztFQUNoQixJQUFJLE1BQU0sV0FBVyxHQUFHLE9BQU87RUFDL0IsUUFBUSxLQUFLLFFBQVEsS0FBSztFQUMxQixJQUFJLE9BQU8sTUFBTSxXQUFXLENBQUM7RUFDN0IsTUFBTSxVQUFVLFNBQVM7RUFDekIsSUFBSSxNQUFNO0VBQ1YsSUFBSSxlQUFlO0VBQ25CLE1BQU0sUUFBUSxLQUFLLFlBQVksS0FBSztFQUNwQyxNQUFNLFdBQVc7RUFDakIsUUFBUSxNQUFNLE1BQU0sTUFBTSxNQUFNO0VBQ2hDLEtBQUssSUFBSSxJQUFJLE1BQU0sU0FBUyxHQUFHLEtBQUssR0FBRyxFQUFFLEdBQUc7R0FDMUMsT0FBTyxNQUFNLFdBQVcsQ0FBQztHQUN6QixJQUFJLFNBQVMsSUFDUDtRQUFBLENBQUMsY0FBYztLQUNqQixNQUFNO0tBQ047SUFDRjtVQUVBLGVBQWU7RUFFbkI7RUFDQSxJQUFJLFFBQVEsSUFBSSxPQUFPLFVBQVUsTUFBTSxLQUFLLE1BQU0sUUFBUSxJQUFJLFFBQVEsUUFBUTtFQUM5RSxJQUFJLFdBQVcsUUFBUSxHQUFHLE9BQU87RUFDakMsT0FBTyxRQUFRLE1BQU0sTUFBTSxHQUFHLEdBQUc7Q0FDbkM7Ozs7Ozs7Ozs7Ozs7O0NBY0EsU0FBUyxPQUFPO0VBQ2QsV0FBVyxLQUFLO0VBQ2hCLFFBQVEsS0FBSyxRQUFRLEtBQUs7RUFDMUIsSUFBSSxPQUFPO0VBQ1gsSUFBSSxNQUFNLFdBQVcsR0FBRyxHQUFHLE9BQU87T0FFaEMsT0FBTyxLQUFLLFlBQVksS0FBSztFQUUvQixJQUFJLEtBQUssTUFBTSxLQUFLLEdBQUc7R0FDckIsTUFBTSxRQUFRLE1BQU0sUUFBUSxLQUFLLEtBQUssTUFBTTtHQUM1QyxJQUFJLFVBQVUsSUFDWixPQUFPLE1BQU0sTUFBTSxHQUFHLEtBQUs7UUFDdEIsT0FBTztHQUNkLElBQUksQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHLFFBQVE7RUFDbkM7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7Ozs7Ozs7OztDQWVBLFNBQVMsT0FBTyxLQUFLO0VBQ25CLFdBQVcsS0FBSztFQUNoQixJQUFJLEtBQUssV0FBVyxHQUFHO0VBQ3ZCLFFBQVEsZ0JBQWdCLEtBQUssUUFBUSxLQUFLLENBQUM7RUFDM0MsSUFBSSxRQUFRO0VBQ1osSUFBSSxNQUFNO0VBQ1YsSUFBSSxlQUFlO0VBQ25CLElBQUk7RUFDSixJQUFJLFFBQVEsS0FBSyxLQUFLLElBQUksU0FBUyxLQUFLLElBQUksVUFBVSxNQUFNLFFBQVE7R0FDbEUsSUFBSSxJQUFJLFdBQVcsTUFBTSxVQUFVLFFBQVEsT0FBTyxPQUFPO0dBQ3pELElBQUksU0FBUyxJQUFJLFNBQVM7R0FDMUIsSUFBSSxtQkFBbUI7R0FDdkIsS0FBSyxJQUFJLE1BQU0sU0FBUyxHQUFHLEtBQUssR0FBRyxFQUFFLEdBQUc7SUFDdEMsTUFBTSxPQUFPLE1BQU0sV0FBVyxDQUFDO0lBQy9CLElBQUksU0FBUyxJQUNQO1NBQUEsQ0FBQyxjQUFjO01BQ2pCLFFBQVEsSUFBSTtNQUNaO0tBQ0Y7V0FDSztLQUNMLElBQUkscUJBQXFCLElBQUk7TUFDM0IsZUFBZTtNQUNmLG1CQUFtQixJQUFJO0tBQ3pCO0tBQ0EsSUFBSSxVQUFVLEdBQUc7TUFDZixJQUFJLFNBQVMsSUFBSSxXQUFXLE1BQU0sR0FDNUI7V0FBQSxFQUFFLFdBQVcsSUFDZixNQUFNO01BQUEsT0FFSDtPQUNMLFNBQVM7T0FDVCxNQUFNO01BQ1I7S0FDRjtJQUNGO0dBQ0Y7R0FDQSxJQUFJLFVBQVUsS0FBSyxNQUFNO1FBQ3BCLElBQUksUUFBUSxJQUFJLE1BQU0sTUFBTTtHQUNqQyxPQUFPLE1BQU0sTUFBTSxPQUFPLEdBQUc7RUFDL0I7RUFDQSxLQUFLLElBQUksTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEVBQUUsR0FDbkMsSUFBSSxNQUFNLFdBQVcsQ0FBQyxNQUFNLElBQ3RCO09BQUEsQ0FBQyxjQUFjO0lBQ2pCLFFBQVEsSUFBSTtJQUNaO0dBQ0Y7U0FDSyxJQUFJLFFBQVEsSUFBSTtHQUNyQixlQUFlO0dBQ2YsTUFBTSxJQUFJO0VBQ1o7RUFFRixJQUFJLFFBQVEsSUFBSSxPQUFPO0VBQ3ZCLE9BQU8sTUFBTSxNQUFNLE9BQU8sR0FBRztDQUMvQjs7Ozs7Ozs7Ozs7Ozs7OztDQWdCQSxRQUFRLE9BQU87RUFDYixXQUFXLEtBQUs7RUFDaEIsUUFBUSxnQkFBZ0IsS0FBSyxRQUFRLEtBQUssQ0FBQztFQUMzQyxJQUFJLFdBQVc7RUFDZixJQUFJLFlBQVk7RUFDaEIsSUFBSSxNQUFNO0VBQ1YsSUFBSSxlQUFlO0VBQ25CLElBQUksY0FBYztFQUNsQixLQUFLLElBQUksSUFBSSxNQUFNLFNBQVMsR0FBRyxLQUFLLEdBQUcsRUFBRSxHQUFHO0dBQzFDLE1BQU0sT0FBTyxNQUFNLFdBQVcsQ0FBQztHQUMvQixJQUFJLFNBQVMsSUFBSTtJQUNmLElBQUksQ0FBQyxjQUFjO0tBQ2pCLFlBQVksSUFBSTtLQUNoQjtJQUNGO0lBQ0E7R0FDRjtHQUNBLElBQUksUUFBUSxJQUFJO0lBQ2QsZUFBZTtJQUNmLE1BQU0sSUFBSTtHQUNaO0dBQ0EsSUFBSSxTQUFTLElBQUk7SUFDZixJQUFJLGFBQWEsSUFBSSxXQUFXO1NBQzNCLElBQUksZ0JBQWdCLEdBQUcsY0FBYztHQUM1QyxPQUFPLElBQUksYUFBYSxJQUN0QixjQUFjO0VBRWxCO0VBQ0EsSUFBSSxhQUFhLE1BQU0sUUFBUSxNQUFNLGdCQUFnQixLQUFLLGdCQUFnQixLQUFLLGFBQWEsTUFBTSxLQUFLLGFBQWEsWUFBWSxHQUM5SCxPQUFPO0VBRVQsT0FBTyxNQUFNLE1BQU0sVUFBVSxHQUFHO0NBQ2xDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTBCQSxNQUFNLE9BQU87RUFDWCxXQUFXLEtBQUs7RUFDaEIsTUFBTSxNQUFNO0dBQUUsTUFBTTtHQUFJLEtBQUs7R0FBSSxNQUFNO0dBQUksS0FBSztHQUFJLE1BQU07RUFBRztFQUM3RCxJQUFJLE1BQU0sV0FBVyxHQUFHLE9BQU87RUFDL0IsUUFBUSxnQkFBZ0IsS0FBSyxRQUFRLEtBQUssQ0FBQztFQUMzQyxJQUFJLE9BQU8sTUFBTSxXQUFXLENBQUM7RUFDN0IsTUFBTSxhQUFhLEtBQUssV0FBVyxLQUFLO0VBQ3hDLElBQUk7RUFFSixJQUFJLE9BQU8sS0FBSyxTQUFTLEtBQUs7RUFDOUIsSUFBSSxjQUFjLEtBQUssWUFBWSxLQUFLLEdBQ3RDLFFBQVE7T0FFUixRQUFRO0VBRVYsSUFBSSxXQUFXO0VBQ2YsSUFBSSxZQUFZO0VBQ2hCLElBQUksTUFBTTtFQUNWLElBQUksZUFBZTtFQUNuQixJQUFJLElBQUksTUFBTSxTQUFTO0VBQ3ZCLElBQUksY0FBYztFQUNsQixPQUFPLEtBQUssT0FBTyxFQUFFLEdBQUc7R0FDdEIsT0FBTyxNQUFNLFdBQVcsQ0FBQztHQUN6QixJQUFJLFNBQVMsSUFBSTtJQUNmLElBQUksQ0FBQyxjQUFjO0tBQ2pCLFlBQVksSUFBSTtLQUNoQjtJQUNGO0lBQ0E7R0FDRjtHQUNBLElBQUksUUFBUSxJQUFJO0lBQ2QsZUFBZTtJQUNmLE1BQU0sSUFBSTtHQUNaO0dBQ0EsSUFBSSxTQUFTLElBQUk7SUFDZixJQUFJLGFBQWEsSUFBSSxXQUFXO1NBQzNCLElBQUksZ0JBQWdCLEdBQUcsY0FBYztHQUM1QyxPQUFPLElBQUksYUFBYSxJQUN0QixjQUFjO0VBRWxCO0VBQ0EsSUFBSSxhQUFhLE1BQU0sUUFBUSxNQUFNLGdCQUFnQixLQUFLLGdCQUFnQixLQUFLLGFBQWEsTUFBTSxLQUFLLGFBQWEsWUFBWSxHQUMxSDtPQUFBLFFBQVEsSUFBSTtJQUNkLElBQUksY0FBYyxLQUFLLFlBQVksSUFBSSxPQUFPLElBQUksT0FBTyxNQUFNLE1BQU0sR0FBRyxHQUFHO1NBQ3RFLElBQUksT0FBTyxJQUFJLE9BQU8sTUFBTSxNQUFNLFdBQVcsR0FBRztHQUN2RDtTQUNLO0dBQ0wsSUFBSSxjQUFjLEtBQUssWUFBWTtJQUNqQyxJQUFJLE9BQU8sTUFBTSxNQUFNLEdBQUcsUUFBUTtJQUNsQyxJQUFJLE9BQU8sTUFBTSxNQUFNLEdBQUcsR0FBRztHQUMvQixPQUFPO0lBQ0wsSUFBSSxPQUFPLE1BQU0sTUFBTSxXQUFXLFFBQVE7SUFDMUMsSUFBSSxPQUFPLE1BQU0sTUFBTSxXQUFXLEdBQUc7R0FDdkM7R0FDQSxJQUFJLE1BQU0sTUFBTSxNQUFNLFVBQVUsR0FBRztFQUNyQztFQUNBLElBQUksTUFBTSxLQUFLLFFBQVEsS0FBSztFQUU1QixPQUFPO0NBQ1Q7Q0FDQSxLQUFLO0NBQ0wsV0FBVztDQUNYLGdCQUFnQixDQUFDLE9BQU87QUFDMUI7OztBQ3hqQkEsU0FBUyxTQUFTLE1BQU0sS0FBSyxPQUFPLFFBQVEsTUFBTTtDQUNoRCxNQUFNLEtBQUssSUFBSTtDQUNmLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLFFBQVEsS0FBSztFQUNsQyxNQUFNLFFBQVEsR0FBRztFQUNqQixJQUFJLFFBQVEsSUFBSSxTQUFTLEdBQ3ZCLFNBQVMsS0FBSyxRQUFRLE9BQU8sUUFBUSxLQUFLLEdBQUcsS0FBSyxRQUFRLEdBQUcsUUFBUSxJQUFJO09BRXpFLEtBQUssS0FBSyxLQUFLLFFBQVEsT0FBTyxRQUFRLEtBQUssQ0FBQztDQUVoRDtBQUNGO0FBQ0EsU0FBUyx1QkFBdUIsUUFBUTtDQUV0QyxNQUFNLFNBQVMsT0FBTyxNQUFNLFlBQUs7Q0FDakMsTUFBTSxPQUFPLENBQUM7Q0FDZCxJQUFJLFFBQVE7RUFDVixNQUFNLE1BQU0sQ0FBQztFQUNiLE9BQU8sU0FBUyxTQUFTO0dBQ3ZCLE1BQU0sUUFBUSxLQUFLLFVBQVUsR0FBRyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHO0dBQzFELElBQUksS0FBSyxLQUFLO0VBQ2hCLENBQUM7RUFDRCxTQUFTLFFBQVEsS0FBSyxHQUFHLFFBQVEsSUFBSTtDQUN2QyxPQUNFLEtBQUssS0FBSyxNQUFNO0NBRWxCLE9BQU87QUFDVDs7O0FDMUJBLElBQU0sZ0JBQWdCLFNBQVMsQ0FBQyxNQUFNLFFBQVEsSUFBSTs7O0FDTWxELElBQU0sV0FBTixNQUFlO0NBQ2IsY0FBYztFQUNaLEtBQUssa0NBQWtDO0dBQ3JDLFdBQVc7R0FDWCxzQkFBc0IsVUFBVSxZQUFZLEdBQUcsV0FBVyxLQUFLLHFCQUFxQjtHQUNwRiwyQkFBMkIsVUFBVSxrQkFBa0IsY0FBYyxRQUFRLEdBQUcsV0FBVyxLQUFLLHNCQUFzQixFQUFFO0VBQzFIOztFQUVBLEtBQUsscUJBQXFCLEtBQUssZ0NBQWdDOzs7Ozs7O0VBTy9ELEtBQUssdUJBQXVCLEtBQUssZ0NBQWdDOzs7Ozs7O0VBT2pFLEtBQUssNEJBQTRCLEtBQUssZ0NBQWdDO0VBQ3RFLEtBQUssWUFBWSxDQUFDO0VBQ2xCLEtBQUssa0JBQWtCLENBQUM7RUFDeEIsS0FBSyxXQUFXLENBQUM7RUFDakIsS0FBSyxnQkFBZ0IsQ0FBQztFQUN0QixLQUFLLFdBQVcsQ0FBQztDQUNuQjs7Ozs7O0NBTUEsb0JBQW9CLGtCQUFrQjtFQUNwQyxLQUFLLHFCQUFxQixpQkFBaUIsYUFBYSxLQUFLO0VBQzdELEtBQUssdUJBQXVCLGlCQUFpQix1QkFBdUIsS0FBSztFQUN6RSxLQUFLLDRCQUE0QixpQkFBaUIsNEJBQTRCLEtBQUs7RUFDbkYsSUFBSSxLQUFLLDBCQUEwQixPQUFPLEtBQUsscUJBQXFCLE9BQU8sS0FBSyxDQUFDLE1BQU0sT0FDckYsTUFBTSxJQUFJLE1BQU0sNERBQTREO0NBRWhGOzs7Ozs7Ozs7Ozs7Ozs7OztDQWlCQSxPQUFPLEdBQUcsY0FBYztFQUN0QixhQUFhLFNBQVMsV0FBVztHQUMvQixLQUFLLGdCQUFnQixLQUFLLE1BQU07R0FDaEMsSUFBSSxDQUFDLE9BQU8sVUFDVixPQUFPLFdBQVcsT0FBTyxLQUFLLE9BQU8sTUFBTTtFQUUvQyxDQUFDO0VBQ0QsS0FBSyxnQkFBZ0IsQ0FBQztDQUN4Qjs7Ozs7Ozs7O0NBU0EsSUFBSSxTQUFTLFVBQVU7RUFDckIsS0FBSyxZQUFZO0NBQ25CO0NBQ0EsSUFBSSxXQUFXO0VBQ2IsT0FBTyxLQUFLO0NBQ2Q7Ozs7Ozs7Ozs7OztDQVlBLElBQUksU0FBUyxVQUFVO0VBQ3JCLEtBQUssWUFBWTtDQUNuQjtDQUNBLElBQUksV0FBVztFQUNiLE9BQU8sS0FBSztDQUNkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNDQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUs7Q0FDZDs7Q0FFQSxRQUFRO0VBQ04sS0FBSyxvQkFBb0IsS0FBSywrQkFBK0I7RUFDN0QsS0FBSyxZQUFZLENBQUM7RUFDbEIsS0FBSyxrQkFBa0IsQ0FBQztFQUN4QixLQUFLLGdCQUFnQixDQUFDO0VBQ3RCLEtBQUssWUFBWTtFQUNqQixLQUFLLFlBQVk7RUFDakIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssV0FBVyxDQUFDO0VBQ2pCLEtBQUssdUJBQXVCO0NBQzlCOzs7OztDQUtBLHVCQUF1QixjQUFjO0VBQ25DLElBQUksT0FBTyxpQkFBaUIsVUFDMUIsS0FBSyx1QkFBdUI7T0FDdkI7R0FDTCxNQUFNLGNBQWM7R0FDcEIsS0FBSyx1QkFBdUIsT0FBTyxLQUFLLFdBQVcsQ0FBQyxDQUFDLEtBQUssUUFBUSxHQUFHLG1CQUFtQixHQUFHLEVBQUUsR0FBRyxtQkFBbUIsWUFBWSxJQUFJLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRztFQUNsSjtDQUNGOzs7OztDQUtBLFNBQVMsT0FBTztFQUNkLE1BQU0sRUFBRSxPQUFPLFFBQVE7RUFXdkIsT0FWcUIsY0FDbkIsU0FBUyxNQUNSLFVBQVU7R0FDVCxJQUFJLE9BQU8sVUFBVSxVQUFVLE9BQU87R0FDdEMsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHLE9BQU8sTUFBTSxLQUFLLE1BQU0sR0FBRyxPQUFPLENBQUM7R0FDN0QsSUFBSSxPQUFPLEtBQUssT0FBTyxNQUFNO0dBQzdCLE9BQU87RUFDVCxHQUNBLElBRWdCO0NBQ3BCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EyQkEsWUFBWSxPQUFPLE9BQU87RUFDeEIsSUFBSSxDQUFDLEtBQUssVUFBVSxRQUNsQjtFQUVGLElBQUksU0FBUyxVQUFVLEtBQUssY0FBYyxRQUN4QztFQUVGLE9BQU8sS0FBSyxjQUFjO0VBQzFCLE9BQU8sS0FBSyxVQUFVO0NBQ3hCOzs7Ozs7Q0FNQSxZQUFZLFVBQVU7RUFDcEIsSUFBSSxLQUFLLFdBQ1AsS0FBSyw4REFBOEQ7RUFFckUsS0FBSyxZQUFZO0VBQ2pCLFNBQVMsUUFBUSxTQUFTLFdBQVc7R0FDbkMsS0FBSyxVQUFVLE9BQU8sTUFBTSxPQUFPLE1BQU07RUFDM0MsQ0FBQztDQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FxQkEsVUFBVSxVQUFVLFFBQVE7RUFDMUIsTUFBTSxhQUFhLENBQUM7RUFDcEIsSUFBSSxrQkFBa0I7RUFDdEIsSUFBSSxDQUFDLE1BQU0sUUFBUSxNQUFNLEdBQ3ZCLGtCQUFrQixPQUFPLFFBQVEsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sU0FBUztHQUM3RCxJQUFJLE9BQU8sUUFBUSxZQUFZLE1BQU0sUUFBUSxHQUFHLEdBQzlDLE9BQU87SUFBRTtJQUFPO0dBQUk7R0FFdEIsT0FBTztJQUFFO0lBQU8sR0FBRztHQUFJO0VBQ3pCLENBQUM7RUFFSCxnQkFBZ0IsU0FBUyxVQUFVO0dBQ2pDLE1BQU0sT0FBTyxNQUFNO0dBQ25CLE1BQU0sVUFBVSxNQUFNO0dBQ3RCLElBQUk7R0FDSixJQUFJLE9BQU8sWUFBWSxVQUFVO0lBQy9CLE1BQU0sZ0JBQWdCLEtBQUsscUJBQXFCLFVBQVUsT0FBTztJQUNqRSxXQUFXLEtBQUssYUFBYTtJQUM3QixNQUFNLENBQUMsU0FBUyxhQUFhO0dBQy9CLE9BQU87SUFDTCxNQUFNLFlBQVksUUFBUSxLQUFLLFNBQVMsS0FBSyxxQkFBcUIsVUFBVSxJQUFJLENBQUM7SUFDakYsV0FBVyxLQUFLLEdBQUcsU0FBUztJQUM1QixNQUFNLENBQUMsR0FBRyxTQUFTLEdBQUcsU0FBUztHQUNqQztHQUNBLEtBQUssSUFBSTtJQUNQLEdBQUc7SUFFRCxPQUFPO0lBQ1AsS0FBSztHQUVULENBQUM7RUFDSCxDQUFDO0VBQ0QsS0FBSyxTQUFTLFlBQVk7Q0FDNUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0E0QkEsSUFBSSxTQUFTO0VBQ1gsTUFBTSxTQUFTLENBQUM7RUFDaEIsSUFBSSxNQUFNLFFBQVEsT0FBTyxHQUN2QixPQUFPLEtBQUssR0FBRyxPQUFPO09BRXRCLE9BQU8sS0FBSyxPQUFPO0VBRXJCLElBQUksWUFDUSxRQUFRO0dBQ2xCLElBQUksS0FBSyxPQUFPLEdBQUcsR0FDakIsS0FBSywrQkFBK0IsSUFBSSxhQUFhO0VBRXpEO0VBRUEsY0FEaUMsTUFDeEIsQ0FBQyxDQUFDLFNBQVMsVUFBVTtHQUM1QixNQUFNLEVBQUUsUUFBUTtHQUNoQixJQUFJLEVBQ0YsTUFDQSxRQUNBLFlBQVksdUJBQ1osUUFBUSxzQkFDTjtHQUNKLE1BQU0sWUFBWSxjQUFjLEdBQUcsQ0FBQyxDQUFDLEtBQUssU0FBUztJQUNqRCxJQUFJLE9BQU8sU0FBUyxVQUNsQixPQUFPLHVCQUF1QixJQUFJO0lBRXBDLE9BQU8sTUFBTSxRQUFRLElBQUksSUFBSSxPQUFPLENBQUMsSUFBSTtHQUMzQyxDQUFDO0dBQ0QsTUFBTSxlQUFlLEtBQUssU0FBUyxLQUFLO0dBQ3hDLE1BQU0sUUFBUSxZQUFZLElBQUksYUFBYSxRQUFRLFFBQVEsSUFBSSxTQUFTLFlBQVk7R0FDcEYsTUFBTSxpQkFBaUIsQ0FBQztHQUN4QixNQUFNLFlBQVksUUFBUTtJQUV4QixPQUFPO0tBQ0wsS0FBSztLQUNMLEdBSGEsS0FBSyxTQUFTLE1BQU0sTUFBTSxFQUFFLEtBQUssR0FBRyxDQUd6QyxDQUFDLEVBQUUsTUFBTSxHQUFHO0lBQ3RCO0dBQ0Y7R0FDQSxVQUFVLFNBQVMsU0FBUztJQUMxQixLQUFLLFNBQVMsU0FBUztLQUNyQixJQUFJLGlCQUFpQixDQUFDO0tBQ3RCLElBQUksT0FBTyxTQUFTLFVBQ2xCLGlCQUFpQixTQUFTLElBQUk7VUFDekI7TUFDTCxPQUFPLEtBQUssUUFBUTtNQUNwQixTQUFTLEtBQUssVUFBVTtNQUN4QixJQUFJLEtBQUssY0FBYyxLQUFLLFFBQVE7T0FDbEMsd0JBQXdCLEtBQUssY0FBYztPQUMzQyxvQkFBb0IsS0FBSyxVQUFVO01BQ3JDO01BQ0EsaUJBQWlCO09BQ2YsR0FBRyxTQUFTLEtBQUssR0FBRztPQUNwQixHQUFHO01BQ0w7S0FDRjtLQUNBLElBQUksQ0FBQyxjQUNILE1BQU0sSUFBSSxNQUFNLGlEQUFpRCxlQUFlLEtBQUs7S0FFdkYsaUJBQWlCLEtBQUssb0JBQW9CLGdCQUFnQjtNQUN4RCxTQUFTO01BQ1Q7TUFDQTtNQUNBLFlBQVk7TUFDWixRQUFRO01BQ1IsY0FBYyxNQUFNO0tBQ3RCLENBQUM7S0FDRCxlQUFlLEtBQUssY0FBYztJQUNwQyxDQUFDO0dBQ0gsQ0FBQztHQUNELGFBQWEsU0FBUyxVQUFVO0lBQzlCLEtBQUssVUFBVSxTQUFTO0dBQzFCLENBQUM7RUFDSCxDQUFDO0NBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJDQSxjQUFjLFdBQVc7RUFDdkIsTUFBTSxjQUFjLGFBQWEsU0FBUztFQUMxQyxZQUFZLGNBQWMsU0FBUztFQUNuQyxNQUFNLE1BQU0sQ0FBQztFQUNiLFVBQVUsU0FBUyxhQUFhO0dBQzlCLE1BQU0sYUFBYSxLQUFLLFNBQVM7R0FDakMsSUFBSSxZQUFZO0lBQ2QsTUFBTSxVQUFVLEtBQUssUUFBUSxVQUFVO0lBQ3ZDLE1BQU0sU0FBUyxDQUFDO0lBQ2hCLEtBQUssTUFBTSxPQUFPLFNBQVM7S0FDekIsTUFBTSxRQUFRLFFBQVE7S0FDdEIsT0FBTyxLQUFLLDBCQUEwQixVQUFVLEdBQUcsS0FBSztJQUMxRDtJQUNBLElBQUksWUFBWTtHQUNsQjtFQUNGLENBQUM7RUFDRCxPQUFPLGNBQWMsSUFBSSxVQUFVLE1BQU07Q0FDM0M7Ozs7OztDQU1BLFdBQVcsS0FBSztFQUNkLE1BQU0sU0FBUyxLQUFLLFFBQVEsR0FBRztFQUMvQixJQUFJLE9BQU8sUUFBUSxVQUFVO0dBQzNCLE1BQU0sTUFBTSxDQUFDO0dBQ2IsS0FBSyxNQUFNLEtBQUssUUFDZCxJQUFJLEtBQUssT0FBTyxFQUFFLENBQUM7R0FFckIsT0FBTztFQUNUO0VBQ0EsT0FBTyxPQUFPO0NBQ2hCO0NBQ0EsUUFBUSxNQUFNO0VBQ1osTUFBTSxjQUFjLGFBQWEsSUFBSTtFQUNyQyxPQUFPLGNBQWMsSUFBSTtFQUN6QixNQUFNLFNBQVMsQ0FBQztFQUNoQixLQUFLLFNBQVMsUUFBUTtHQUNwQixJQUFJLENBQUMsS0FBSyxjQUFjLE1BQU07SUFDNUIsSUFBSSxLQUFLLFVBQVUsTUFBTTtLQUN2QixJQUFJLFNBQVMsS0FBSyxVQUFVO0tBQzVCLE1BQU0saUJBQWlCLEtBQUssbUJBQW1CLE1BQU07S0FDckQsZ0JBQWdCLFNBQVMsU0FBUyxnQkFBZ0I7TUFDaEQsZUFBZSxPQUFPLFlBQVksQ0FBQyxTQUFTLFVBQVU7T0FDcEQsTUFBTSxpQkFBaUIsT0FBTyxRQUFRLFVBQVU7UUFDOUMsSUFBSSxNQUFNLGNBQ1IsT0FBTyxNQUFNLGlCQUFpQjtRQUVoQyxPQUFPO09BQ1QsQ0FBQztPQUNELElBQUksZUFBZSxRQUNqQixTQUFTO01BRWIsQ0FBQztLQUNILENBQUM7S0FDRCxLQUFLLGNBQWMsT0FBTyxPQUFPO0lBQ25DLE9BQ0UsS0FBSyxjQUFjLE9BQU8sS0FBSyxvQkFBb0I7S0FDakQsT0FBTyxDQUFDLEdBQUc7S0FDWCxLQUFLO0lBQ1AsR0FBRyxDQUFDLENBQUM7R0FFVDtHQUNBLE9BQU8sT0FBTyxLQUFLLGNBQWM7RUFDbkMsQ0FBQztFQUNELE9BQU8sY0FBYyxPQUFPLEtBQUssTUFBTTtDQUN6Qzs7Ozs7Q0FLQSxPQUFPLEtBQUs7RUFDVixPQUFPLENBQUMsQ0FBQyxLQUFLLFVBQVU7Q0FDMUI7Ozs7O0NBS0EsVUFBVSxLQUFLO0VBQ2IsT0FBTyxDQUFDLENBQUMsS0FBSyxTQUFTO0NBQ3pCOzs7OztDQUtBLG1CQUFtQixRQUFRO0VBQ3pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsS0FBSztHQUN0QyxNQUFNLFFBQVEsT0FBTztHQUNyQixNQUFNLFlBQVksS0FBSyxnQkFBZ0IsTUFBTSxlQUFlLFdBQVcsT0FBTyxPQUFPLFNBQVMsTUFBTSxNQUFNLENBQUM7R0FDM0csSUFBSSxXQUNGLE9BQU87RUFFWDtFQUNBLE9BQU8sS0FBSyxnQkFBZ0I7Q0FDOUI7Ozs7OztDQU1BLDJCQUEyQixLQUFLO0VBQzlCLElBQUksQ0FBQyxLQUFLLHNCQUFzQixPQUFPO0VBRXZDLE9BQU8sR0FBRyxNQURhLEtBQUssS0FBSyxHQUFHLElBQUksTUFBTSxNQUNiLEtBQUs7Q0FDeEM7Q0FDQSxvQkFBb0IsZ0JBQWdCLE1BQU07RUFDeEMsTUFBTSxFQUFFLFNBQVMsTUFBTSxXQUFXLFlBQVksUUFBUSxRQUFRLGlCQUFpQjtFQUMvRSxJQUFJLEtBQUssYUFBYSxLQUFLLFdBQ3pCLGVBQWUsTUFBTSxLQUFLLFdBQVcsZUFBZSxLQUFLLEtBQUssV0FBVyxLQUFLLFNBQVM7RUFFekYsZUFBZSxRQUFRLFdBQVcsZUFBZSxTQUFTLENBQUMsZUFBZSxHQUFHO0VBQzdFLGVBQWUsTUFBTSxLQUFLLDJCQUEyQixlQUFlLEdBQUc7RUFDdkUsZUFBZSxPQUFPO0dBQUUsR0FBRyxhQUFhLENBQUM7R0FBRyxHQUFHLGVBQWU7RUFBSztFQUNuRSxlQUFlLGFBQWEsY0FBYyxlQUFlO0VBQ3pELGVBQWUsU0FBUyxVQUFVLGVBQWU7RUFDakQsZUFBZSxTQUFTLFVBQVUsZUFBZSxVQUFVLGdCQUFnQixlQUFlLEdBQUc7RUFDN0YsSUFBSSxpQkFBaUIsS0FBSyxHQUN4QixlQUFlLGVBQWU7RUFFaEMsT0FBTztDQUNUO0FBQ0Y7Ozs7OztBQU1BLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsZ0JBQWdCLEtBQUs7Q0FDNUIsT0FBTyxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU07QUFDbEU7OztBQ3BqQkEsSUFBTSxvQkFBb0IsV0FBVyxjQUFjO0NBQ2pELE1BQU0sZUFBZSxVQUFVLE1BQU0sR0FBRyxDQUFDLENBQUM7Q0FDMUMsSUFBSSxjQUNGLGFBQWEsSUFBSTtDQUVuQixPQUFPO0FBQ1Q7OztBQ0ZBLElBQU0sZUFBZSxNQUFNLGFBQWE7Q0FDdEMsWUFBWSxrQkFBa0IsTUFBTTs7RUFFbEMsS0FBSyxlQUFlLENBQUM7RUFDckIsSUFBSSxVQUFVO0VBQ2QsSUFBSSxrQkFBa0Isa0JBQWtCLGVBQ3RDLFVBQVU7R0FDUixTQUFTO0dBQ1QsTUFBTTtFQUNSO0VBRUYsTUFBTSxFQUFFLFNBQVMsTUFBTSxjQUFjLE9BQU87RUFDNUMsS0FBSyxjQUFjO0VBQ25CLEtBQUssV0FBVyxtQkFBbUIsVUFBVSxVQUFVO0VBQ3ZELEtBQUssZ0JBQWdCLFFBQVE7RUFDN0IsS0FBSyxXQUFXLENBQUM7RUFDakIsS0FBSyxhQUFhLENBQUM7RUFDbkIsS0FBSyxPQUFPO0VBQ1osTUFBTSxpQkFBaUIsV0FBVyxLQUFLLEtBQUssS0FBSztFQUNqRCxJQUFJLGdCQUFnQjtHQUNsQixLQUFLLGFBQWE7R0FDbEIsUUFBUSxPQUFPLGFBQWEsS0FBSztFQUNuQyxPQUNFLEtBQUssYUFBYSxRQUFRLE9BQU87RUFFbkMsS0FBSyxVQUFVLEtBQUssS0FBSztFQUN6QixLQUFLLGFBQWEsT0FBTyxLQUFLLEtBQUssT0FBTztFQUMxQyxLQUFLLGNBQWM7RUFDbkIsS0FBSyxZQUFZO0NBQ25COzs7OztDQUtBLFFBQVE7RUFDTixPQUFPLElBQUksU0FBUyxZQUFZO0dBQzlCLEtBQUssWUFBWTtHQUNqQixLQUFLLGNBQWM7R0FDbkIsSUFBSSxLQUFLLFdBQVcsVUFBVSxhQUFhLFlBQVk7SUFDckQsS0FBSyxlQUFlLENBQUM7SUFDckIsS0FBSyxtQkFBbUI7SUFDeEIsS0FBSyxlQUFlO0dBQ3RCLE9BQ0UsS0FBSyxXQUFXO0VBRXBCLENBQUM7Q0FDSDs7Ozs7Ozs7OztDQVVBLFlBQVk7RUFDVixLQUFLLGVBQWUsR0FBRyxJQUFJO0VBQzNCLEtBQUssbUJBQW1CO0VBQ3hCLE9BQU8sS0FBSztDQUNkOzs7Ozs7O0NBT0EsZUFBZSxtQkFBbUIsYUFBYSxPQUFPO0VBQ3BELElBQUksYUFBYTtFQUNqQixNQUFNLFlBQVksYUFBYSxXQUFXLGFBQWE7RUFDdkQsT0FBTyxhQUFhLG9CQUFvQixhQUFhLGFBQWEsS0FBSyxXQUFXLFFBQVE7R0FDeEYsTUFBTSxJQUFJLEtBQUssV0FBVztHQUMxQixNQUFNLE9BQU8sS0FBSyxRQUFRO0dBQzFCLE1BQU0sT0FBTyxLQUFLO0dBQ2xCLElBQUksTUFBTTtJQUNSLElBQUksUUFBUTtJQUNaLElBQUksT0FBTztJQUNYLE1BQU0sYUFBYSxLQUFLLFlBQVksU0FBUyxLQUFLLGFBQWEsS0FBSyxhQUFhLEtBQUs7SUFDdEYsTUFBTSxPQUFPLElBQUksVUFDZixHQUNBLEdBQ0EsS0FBSyxNQUFNLFdBQVcsQ0FBQyxJQUFJLEtBQUssWUFDaEMsS0FBSyxNQUFNLFdBQVcsQ0FBQyxJQUFJLEtBQUssVUFDbEM7SUFDQSxJQUFJLEtBQUssU0FDUCxRQUFRLElBQUksVUFDVixLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUksS0FBSyxZQUMxQixLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUksS0FBSyxZQUMxQixLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUksS0FBSyxZQUMxQixLQUFLLE1BQU0sS0FBSyxDQUFDLElBQUksS0FBSyxVQUM1QjtTQUVBLFFBQVEsSUFBSSxVQUNWLEtBQUssTUFBTSxLQUFLLENBQUMsSUFBSSxLQUFLLFlBQzFCLEtBQUssTUFBTSxLQUFLLENBQUMsSUFBSSxLQUFLLFlBQzFCLEtBQUssTUFBTSxLQUFLLENBQUMsSUFBSSxLQUFLLFlBQzFCLEtBQUssTUFBTSxLQUFLLENBQUMsSUFBSSxLQUFLLFVBQzVCO0lBRUYsSUFBSSxLQUFLLFlBQVksU0FBUyxLQUFLLGtCQUNqQyxPQUFPLElBQUksVUFDVCxLQUFLLE1BQU0sS0FBSyxpQkFBaUIsQ0FBQyxJQUFJLEtBQUssWUFDM0MsS0FBSyxNQUFNLEtBQUssaUJBQWlCLENBQUMsSUFBSSxLQUFLLFlBQzNDLEtBQUssTUFBTSxLQUFLLENBQUMsSUFBSSxLQUFLLFlBQzFCLEtBQUssTUFBTSxLQUFLLENBQUMsSUFBSSxLQUFLLFVBQzVCO0lBRUYsS0FBSyxTQUFTLEtBQUssSUFBSSxRQUFRO0tBQzdCLFFBQVEsS0FBSztLQUNiO0tBQ0E7S0FDQTtLQUNBLFFBQVEsS0FBSyxVQUFVLElBQUk7S0FDM0IsZUFBZSxLQUFLO0tBQ3BCLGdCQUFnQixLQUFLO0tBQ3JCLE9BQU8sRUFBRSxTQUFTO0lBQ3BCLENBQUM7R0FDSDtHQUNBO0VBQ0Y7Q0FDRjs7Q0FFQSxxQkFBcUI7RUFDbkIsTUFBTSxhQUFhLEtBQUssS0FBSyxjQUFjLENBQUM7RUFDNUMsS0FBSyxNQUFNLFlBQVksWUFBWTtHQUNqQyxLQUFLLFdBQVcsWUFBWSxDQUFDO0dBQzdCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFNBQVMsQ0FBQyxRQUFRLEtBQUs7SUFDcEQsTUFBTSxZQUFZLFdBQVcsU0FBUyxDQUFDO0lBQ3ZDLEtBQUssV0FBVyxTQUFTLENBQUMsS0FBSyxLQUFLLFNBQVMsVUFBVTtHQUN6RDtFQUNGO0NBQ0Y7O0NBRUEsaUJBQWlCO0VBQ2YsTUFBTSxXQUFXLEtBQUs7RUFDdEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssY0FBYztFQUNuQixTQUFTLEtBQUssTUFBTSxLQUFLLFFBQVE7Q0FDbkM7O0NBRUEsYUFBYTtFQUNYLEtBQUssZUFBZSxLQUFLLGNBQWMsYUFBYSxVQUFVO0VBQzlELEtBQUs7RUFDTCxpQkFBaUI7R0FDZixJQUFJLEtBQUssY0FBYyxhQUFhLGFBQWEsS0FBSyxXQUFXLFFBQy9ELEtBQUssV0FBVztRQUNYO0lBQ0wsS0FBSyxtQkFBbUI7SUFDeEIsS0FBSyxlQUFlO0dBQ3RCO0VBQ0YsR0FBRyxDQUFDO0NBQ047Ozs7O0NBS0EsUUFBUSxjQUFjLE9BQU87RUFDM0IsS0FBSyxNQUFNLEtBQUssS0FBSyxVQUNuQixLQUFLLFNBQVMsRUFBRSxDQUFDLFFBQVE7RUFFM0IsS0FBSyxVQUFVO0VBQ2YsS0FBSyxhQUFhO0VBQ2xCLEtBQUssT0FBTztFQUNaLEtBQUssV0FBVztFQUNoQixJQUFJLGFBQWE7R0FDZixLQUFLLFVBQVUsUUFBUTtHQUN2QixLQUFLLGNBQWMsUUFBUTtFQUM3QjtFQUNBLEtBQUssV0FBVztFQUNoQixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLGVBQWUsQ0FBQztDQUN2QjtBQUNGOzs7OztBQUtBLGFBQWEsYUFBYTtBQUMxQixJQUFJLGNBQWM7OztBQzlLbEIsSUFBTSxjQUFjO0NBQ2xCO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Y7QUFDQSxTQUFTLG1CQUFtQixNQUFNLE9BQU8saUJBQWlCO0NBQ3hELE1BQU0sTUFBTSxDQUFDO0NBQ2IsS0FBSyxTQUFTLFFBQVE7RUFDcEIsSUFBSSxPQUFPO0NBQ2IsQ0FBQztDQUNELE9BQU8sS0FBSyxNQUFNLFFBQVEsQ0FBQyxDQUFDLFNBQVMsUUFBUTtFQUMzQyxJQUFJLEdBQUcsTUFBTSxjQUFjLFNBQVMsTUFBTSxTQUFTO0NBQ3JELENBQUM7Q0FDRCxJQUFJLENBQUMsaUJBQWlCO0VBQ3BCLE1BQU0sV0FBVyxLQUFLLFFBQVEsS0FBSyxFQUFFO0VBQ3JDLE1BQU0sYUFBYSxTQUFTLE1BQU0sTUFBTTtHQUN0QyxNQUFNLE9BQU8sbUJBQW1CLENBQUMsR0FBRyxTQUFTLEdBQUcsTUFBTSxLQUFLLEtBQUssb0JBQW9CLElBQUksR0FBRyxNQUFNLElBQUk7R0FDckcsT0FBTyxPQUFPLEtBQUssSUFBSTtFQUN6QixDQUFDO0NBQ0g7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxJQUFNLG1CQUFtQjtDQUN2QixXQUFXLGNBQWM7O0NBRXpCLE9BQU87RUFDTCxPQUFPLFVBQVUsaUJBQWlCO0VBQ2xDLHFCQUFxQixNQUFNLFVBQVUsbUJBQW1CLE1BQU0sT0FBTyxLQUFLO0NBQzVFOztDQUVBLFVBQVU7RUFDUixXQUFXO0dBQ1QsTUFBTSxjQUFjO0dBQ3BCLE1BQU07RUFDUjtFQUNBLE9BQU8sVUFBVTtHQUVmLE1BQU0sUUFEVSxNQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFDWixDQUFDLE1BQU0sR0FBRztHQUMvQixNQUFNLFlBQVksTUFBTSxJQUFJO0dBQzVCLE1BQU0sU0FBUyxNQUFNLElBQUk7R0FDekIsT0FBTyxjQUFjLFVBQVUsWUFBWSxTQUFTLE1BQU07RUFDNUQ7RUFDQSxRQUFRLFVBQVU7R0FDaEIsTUFBTSxRQUFRLE1BQU0sTUFBTSxHQUFHO0dBQzdCLE9BQU87SUFDTCxZQUFZLFdBQVcsU0FBUyxjQUFjLEtBQUssS0FBSyxDQUFDLEdBQUcsTUFBTSxHQUFHO0lBQ3JFLFFBQVEsTUFBTSxNQUFNLFNBQVM7SUFDN0IsS0FBSztHQUNQO0VBQ0Y7Q0FDRjs7Ozs7OztDQU9BLFFBQVE7O0VBRU4sTUFBTTtFQUNOLElBQUk7RUFDSixXQUFXO0dBQ1QsTUFBTSxjQUFjO0dBQ3BCLFVBQVUscUJBQXFCO0dBQy9CLE1BQU07RUFDUjtFQUNBLE1BQU0sVUFBVSxPQUFPLFNBQVM7R0FDOUIsT0FBTyxLQUFLLFFBQVEsUUFBUSxHQUFHLENBQUMsQ0FBQyxZQUFZLE1BQU0sV0FBVyxDQUFDLENBQUMsTUFBTTtFQUN4RTtFQUNBLE1BQU0sTUFBTSxPQUFPLFNBQVMsUUFBUTtHQUNsQyxNQUFNLEVBQ0osU0FBUyxjQUVULGVBRUEsZ0JBRUEsZ0JBRUUsU0FBUyxRQUFRLENBQUM7R0FDdEIsSUFBSSxXQUFXLEtBQUssUUFBUSxRQUFRLEdBQUc7R0FDdkMsSUFBSSxZQUFZLFNBQVMsWUFBWSxHQUFHLE1BQU0sU0FBUyxTQUFTLEdBQzlELFlBQVk7R0FFZCxJQUFJO0dBQ0osSUFBSSx3QkFBd0IsU0FDMUIsVUFBVTtRQUNMO0lBQ0wsTUFBTSxZQUFZLGlCQUFpQixZQUFZLGlCQUFpQixNQUFNLEtBQUssUUFBUSxRQUFRLEdBQUc7SUFFOUYsV0FBVSxNQURXLE9BQU8sS0FBSyxDQUFDO0tBQUUsS0FBSztLQUFXLE1BQU07SUFBZSxDQUFDLENBQUMsRUFBQSxDQUMxRDtHQUNuQjtHQUNBLE1BQU0sY0FBYyxJQUFJLFlBQVk7SUFDbEMsU0FBUyxRQUFRO0lBQ2pCLE1BQU07SUFDTjtHQUNGLENBQUM7R0FDRCxNQUFNLFlBQVksTUFBTTtHQUN4QixNQUFNLGFBQWEsT0FBTyxNQUFNO0dBQ2hDLElBQUksTUFBTSxRQUFRLFVBQVUsR0FBRztJQUM3QixNQUFNLFdBQVcsQ0FBQztJQUNsQixLQUFLLE1BQU0sUUFBUSxZQUFZO0tBQzdCLElBQUksT0FBTyxTQUFTLFVBQ2xCO0tBRUYsSUFBSSxVQUFVLFdBQVc7S0FDekIsSUFBSSxRQUFRLE1BQU0saUJBQ2hCO0tBRUYsVUFBVSxpQkFBaUIsU0FBUyxRQUFRLEdBQUc7S0FDL0MsU0FBUyxLQUFLLE9BQU8sS0FBSztNQUN4QixLQUFLO01BQ0wsTUFBTTtPQUNKO09BQ0EsaUJBQWlCO01BQ25CO0tBQ0YsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxNQUFNLE1BQU0sTUFBTSxRQUFRLElBQUksUUFBUTtJQUN0QyxZQUFZLGVBQWU7SUFDM0IsSUFBSSxTQUFTLFNBQVM7S0FDcEIsS0FBSyxlQUFlLENBQUMsV0FBVyxDQUFDLENBQUMsT0FBTyxZQUFZLGFBQWEsUUFBUSxPQUFPLE9BQU8sSUFBSSxDQUFDO0lBQy9GLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVDtFQUNBLE1BQU0sT0FBTyxhQUFhLGdCQUFnQixRQUFRO0dBQ2hELE1BQU0sT0FBTyxPQUFPLFlBQVksY0FBYyxhQUFhO0dBQzNELFlBQVksUUFBUSxLQUFLO0VBQzNCO0NBQ0Y7QUFDRjs7O0FDckpBLFdBQVcsSUFBSSxnQkFBZ0I7OztBQ0EvQixJQUFNLHVCQUF1QixJQUFJLE9BQU87QUFDeEMsU0FBUywwQkFBMEIsYUFBYSxRQUFRO0NBQ3RELE9BQU8sTUFBTTtDQUNiLE1BQU0sZUFBZSxPQUFPO0NBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxZQUFZLFFBQVEsS0FBSztFQUMzQyxNQUFNLGFBQWEsWUFBWTtFQUMvQixJQUFJLFdBQVcsc0JBQXNCLEdBQ25DO0VBRUYsTUFBTSxjQUFjLFdBQVcsZUFBZSxXQUFXO0VBQ3pELElBQUksYUFBYSxtQkFDZixPQUFPLFNBQVMscUJBQXFCLFNBQVMsWUFBWSw2QkFBNkIsQ0FBQyxDQUFDLE9BQU8sV0FBVyxjQUFjO09BQ3BILElBQUksYUFBYSxrQ0FDdEIsT0FBTyxTQUFTLHFCQUFxQixTQUFTLFlBQVksaUNBQWlDLHFCQUFxQixDQUFDLENBQUMsT0FBTyxXQUFXLGNBQWM7T0FFbEosT0FBTyxTQUFTLFdBQVc7RUFFN0IsT0FBTyxVQUFVLFdBQVcsTUFBTTtDQUNwQztDQUNBLE9BQU8sU0FBUztDQUNoQixPQUFPO0FBQ1Q7OztBQ3JCQSxJQUFNLGFBQWEsSUFBSSxPQUFPO0FBQzlCLFNBQVMsd0JBQXdCLE9BQU8sT0FBTyxRQUFRLFlBQVksc0JBQXNCLE9BQU8sV0FBVztDQUN6RyxNQUFNLFNBQVM7Q0FDZixPQUFPLE9BQU87Q0FDZCxPQUFPLE9BQU87Q0FDZCxPQUFPLE9BQU8sTUFBTSxRQUFRLGFBQWE7Q0FDekMsT0FBTyxPQUFPLE1BQU0sU0FBUyxhQUFhO0NBQzFDLE1BQU0sVUFBVSxZQUFZLGtCQUFrQjtFQUM1QyxPQUFPLE9BQU87RUFDZCxRQUFRLE9BQU87RUFDZjtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsUUFBUSxPQUFPLGlCQUFpQjtDQUNoQyxRQUFRLE9BQU8sV0FBVztDQUMxQixRQUFRLE9BQU8sWUFBWTtDQUMzQixRQUFRLE1BQU0sUUFBUSxRQUFRO0NBQzlCLFFBQVEsTUFBTSxTQUFTLFNBQVM7Q0FDaEMsUUFBUSxPQUFPLEtBQUssVUFBVSxRQUFRLE1BQU07Q0FDNUMsUUFBUSxVQUFVO0NBQ2xCLE9BQU87QUFDVDs7O0FDbEJBLFNBQVMsc0JBQXNCLFFBQVE7Q0FDckMsT0FBTyxPQUFPLE9BQU8sMEJBQTBCO0FBQ2pEO0FBQ0EsSUFBTSxvQkFBTixNQUF3QjtDQUN0QixjQUFjO0VBQ1osS0FBSyxPQUFPO0VBQ1osS0FBSyxVQUFVO0VBQ2YsS0FBSyxVQUFVO0VBQ2YsS0FBSyxZQUFZO0VBQ2pCLEtBQUssU0FBUyxJQUFJLE9BQU87RUFDekIsS0FBSyxrQkFBa0I7Q0FDekI7QUFDRjtBQUNBLElBQU0scUJBQU4sTUFBeUI7Ozs7Ozs7Q0FPdkIsWUFBWSxVQUFVO0VBQ3BCLEtBQUssZUFBZSxDQUFDO0VBQ3JCLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssZUFBZSxDQUFDO0VBQ3JCLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUsscUNBQXFDLElBQUksSUFBSTtFQUNsRCxLQUFLLFdBQVc7Q0FDbEI7Ozs7OztDQU1BLEtBQUssYUFBYTtFQUNoQixNQUFNLGNBQWMsS0FBSyxpQkFBaUI7RUFDMUMsTUFBTSxVQUFVLFlBQVksYUFBYTtFQUN6QyxZQUFZLE9BQU87RUFDbkIsWUFBWSxVQUFVO0VBQ3RCLFlBQVksVUFBVTtFQUN0QixZQUFZLFlBQVksWUFBWTtFQUNwQyxZQUFZLGtCQUFrQjtFQUM5QixJQUFJLFFBQVEsT0FBTyxXQUFXLENBQUMsT0FBTyxPQUFPLEdBQUc7R0FDOUMsWUFBWSxPQUFPO0dBQ25CO0VBQ0Y7RUFDQSxNQUFNLGFBQWEsQ0FBQztFQUVwQixLQUFLLE1BQU0sVUFBVSxTQUFTO0dBQzVCLElBQUksQ0FBQyxPQUFPLFNBQVM7R0FDckIsSUFBSSxDQUFDLHNCQUFzQixNQUFNLEdBQUc7SUFDbEMsS0FBSyx1QkFBdUIsTUFBTTtJQUNsQztHQUNGO0dBQ0EsTUFBTSxZQUFZLE9BQU8sc0JBQXNCO0dBQy9DLElBQUksY0FBYyxNQUFNO0lBQ3RCLEtBQUssdUJBQXVCLE1BQU07SUFDbEM7R0FDRjtHQUNBLElBQUksV0FDRixXQUFXLEtBQUssU0FBUztFQUU3QjtFQUNBLElBQUksV0FBVyxXQUFXLEtBQUssTUFBdUI7R0FDcEQsWUFBWSxPQUFPO0dBQ25CO0VBQ0Y7RUFDQSxZQUFZLGtCQUFrQixXQUFXLEtBQUssR0FBRztFQUNqRCxLQUFLLHFCQUFxQixhQUFhLFlBQVksTUFBTTtFQUN6RCxZQUFZLFVBQVUsQ0FBQyxDQUFDLFlBQVksYUFBYTtFQUNqRCxNQUFNLFVBQVUsS0FBSyxTQUFTLGNBQWM7RUFDNUMsTUFBTSxpQkFBaUIsUUFBUSxVQUFVO0VBQ3pDLEtBQUssYUFBYSxLQUFLO0dBQUUsUUFBUTtHQUFnQixpQkFBaUIsS0FBSztFQUFpQixDQUFDO0VBQ3pGLElBQUksWUFBWSxXQUFXLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSyxLQUFLLE9BQU8sU0FBUyxZQUFZLE9BQU8sTUFBTSxLQUFLLFlBQVksT0FBTyxRQUFRLEtBQUssWUFBWSxPQUFPLFNBQVMsR0FBRztHQUNuTCxNQUFNLGFBQWEsS0FBSyxTQUFTLGNBQWMsb0JBQW9CO0dBQ25FLFFBQVEsS0FBSztHQUNiLFFBQVEsYUFBYSxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUNyQyxRQUFRLFVBQVU7R0FDbEIsUUFBUSxLQUNOLFlBQVksT0FBTyxJQUFJLFlBQ3ZCLFlBQVksT0FBTyxJQUFJLFlBQ3ZCLFlBQVksT0FBTyxRQUFRLFlBQzNCLFlBQVksT0FBTyxTQUFTLFVBQzlCO0dBQ0EsUUFBUSxLQUFLO0VBQ2YsT0FDRSxZQUFZLFVBQVU7RUFLeEIsSUFBSSxZQUFZLGlCQUNkLFFBQVEsU0FBUyxtQkFBbUIsU0FBUyxHQUFHLGVBQWUsR0FBRyxZQUFZLG9CQUFvQixZQUFZO0NBRWxIOztDQUVBLE1BQU07RUFDSixNQUFNLGNBQWMsS0FBSyxnQkFBZ0I7RUFDekMsSUFBSSxZQUFZLE1BQ2Q7RUFFRixNQUFNLGFBQWEsS0FBSyxhQUFhLElBQUk7RUFDekMsSUFBSSxDQUFDLFlBQ0g7RUFFRixNQUFNLFVBQVUsS0FBSyxTQUFTLGNBQWM7RUFDNUMsSUFBSSxZQUFZLFNBQ2QsUUFBUSxRQUFRO09BRWhCLFFBQVEsU0FBUyxXQUFXO0VBRTlCLEtBQUssbUJBQW1CLFdBQVc7Q0FDckM7Ozs7Ozs7OztDQVNBLHdCQUF3QixFQUFFLFNBQVMsV0FBVztFQUM1QyxJQUFJLENBQUMsU0FBUyxVQUFVLFFBQVEsT0FBTyxXQUFXLENBQUMsT0FBTyxPQUFPLEdBQy9ELE9BQU87RUFFVCxNQUFNLGFBQWEsQ0FBQztFQUVwQixLQUFLLE1BQU0sVUFBVSxTQUFTO0dBQzVCLElBQUksQ0FBQyxPQUFPLFNBQVM7R0FDckIsSUFBSSxDQUFDLHNCQUFzQixNQUFNLEdBQUc7SUFDbEMsS0FBSyx1QkFBdUIsTUFBTTtJQUNsQztHQUNGO0dBQ0EsTUFBTSxZQUFZLE9BQU8sc0JBQXNCO0dBQy9DLElBQUksY0FBYyxNQUFNO0lBQ3RCLEtBQUssdUJBQXVCLE1BQU07SUFDbEM7R0FDRjtHQUNBLElBQUksV0FDRixXQUFXLEtBQUssU0FBUztFQUU3QjtFQUNBLElBQUksV0FBVyxXQUFXLEtBQUssTUFDN0IsT0FBTztFQUVULE1BQU0sU0FBUyxZQUFZLGdCQUFnQixPQUFPO0VBQ2xELElBQUksQ0FBQyxRQUNILE9BQU87RUFFVCxNQUFNLFFBQVEsUUFBUTtFQUN0QixNQUFNLGFBQWEsUUFBUSxPQUFPLGVBQWUsUUFBUSxPQUFPLGNBQWM7RUFDOUUsTUFBTSxRQUFRLE1BQU07RUFDcEIsTUFBTSxTQUFTLE1BQU07RUFFckIsTUFBTSxFQUFFLFFBQVEsWUFEUyxXQUFXLDJCQUEyQixPQUFPLFFBQVEsVUFDbkM7RUFDM0MsUUFBUSxhQUFhLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3JDLFFBQVEsVUFBVSxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTtFQUNuRCxJQUFJLFdBQVcsUUFDYixRQUFRLFNBQVMsV0FBVyxLQUFLLEdBQUc7RUFLdEMsTUFBTSxLQUFLLE1BQU0sSUFBSTtFQUNyQixNQUFNLEtBQUssTUFBTSxJQUFJO0VBQ3JCLE1BQU0sS0FBSyxRQUFRO0VBQ25CLE1BQU0sS0FBSyxTQUFTO0VBQ3BCLFFBQVEsVUFDTixRQUNBLElBQ0EsSUFDQSxJQUNBLElBQ0EsR0FDQSxHQUNBLElBQ0EsRUFDRjtFQUNBLFFBQVEsU0FBUztFQUNqQixRQUFRLGNBQWM7RUFDdEIsT0FBTyx3QkFBd0IsUUFBUSxPQUFPLFFBQVEsVUFBVTtDQUNsRTs7Ozs7O0NBTUEscUJBQXFCLGFBQWEsUUFBUTtFQUN4QyxJQUFJLFlBQVksYUFDZCwwQkFBMEIsWUFBWSxhQUFhLE1BQU07T0FDcEQsSUFBSSxZQUFZLGFBQWEsWUFBWTtHQUM5QyxPQUFPLE1BQU07R0FDYixPQUFPLFFBQVEsWUFBWSxhQUFhLFVBQVU7R0FDbEQsT0FBTyxZQUFZLFlBQVksVUFBVSxjQUFjO0VBQ3pELE9BQ0UsWUFBWSxVQUFVLG9CQUFvQixNQUFNLE1BQU07RUFFeEQsSUFBSSxZQUFZLFdBQVc7R0FFekIsTUFBTSx3QkFEYyxZQUFZLFVBQVUsZUFBZSxZQUFZLFVBQVUsa0JBQUEsRUFDckM7R0FDMUMsSUFBSSxzQkFDRixPQUFPLFlBQVksb0JBQW9CO0VBRTNDO0NBQ0Y7Q0FDQSx1QkFBdUIsUUFBUTtFQUM3QixNQUFNLGFBQWEsUUFBUSxhQUFhLFFBQVE7RUFDaEQsSUFBSSxLQUFLLG1CQUFtQixJQUFJLFVBQVUsR0FDeEM7RUFFRixLQUFLLG1CQUFtQixJQUFJLFVBQVU7RUFDdEMsUUFBUSxLQUNOLDJCQUEyQixXQUFXLG9EQUN4QztDQUNGO0NBQ0EsSUFBSSxrQkFBa0I7RUFDcEIsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxtQkFBbUI7RUFDakIsSUFBSSxjQUFjLEtBQUssYUFBYSxLQUFLO0VBQ3pDLElBQUksQ0FBQyxhQUNILGNBQWMsS0FBSyxhQUFhLEtBQUsscUJBQXFCLElBQUksa0JBQWtCO0VBRWxGLEtBQUs7RUFDTCxPQUFPO0NBQ1Q7Q0FDQSxrQkFBa0I7RUFDaEIsSUFBSSxLQUFLLHFCQUFxQixHQUM1QixPQUFPLEtBQUssYUFBYTtFQUUzQixLQUFLO0VBQ0wsT0FBTyxLQUFLLGFBQWEsS0FBSztDQUNoQzs7Q0FFQSxVQUFVO0VBQ1IsS0FBSyxlQUFlO0VBQ3BCLEtBQUssZUFBZTtFQUNwQixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLG1CQUFtQjtDQUMxQjtBQUNGOztBQUVBLG1CQUFtQixZQUFZO0NBQzdCLE1BQU0sQ0FBQyxjQUFjLFlBQVk7Q0FDakMsTUFBTTtBQUNSOzs7QUM1UEEsSUFBSSxTQUFTOzs7QUNBYixJQUFJLFdBQVc7OztBQ0FmLElBQUksU0FBUzs7O0FDUWIsSUFBTSxvQkFBTixjQUFnQyxPQUFPO0NBQ3JDLGNBQWM7RUFDWixNQUFNLGFBQWEsV0FBVyxLQUFLO0dBQ2pDLFFBQVE7SUFBRTtJQUFRLFlBQVk7R0FBYTtHQUMzQyxVQUFVO0lBQUU7SUFBUSxZQUFZO0dBQWU7R0FDL0MsTUFBTTtFQUNSLENBQUM7RUFDRCxNQUFNLFlBQVksVUFBVSxLQUFLO0dBQy9CO0dBQ0E7R0FDQSxNQUFNO0VBQ1IsQ0FBQztFQUNELE1BQU07R0FDSjtHQUNBO0VBQ0YsQ0FBQztDQUNIO0FBQ0Y7OztBQ3RCQSxJQUFNLGFBQU4sTUFBaUI7Q0FDZixZQUFZLFVBQVU7RUFDcEIsS0FBSyxZQUFZO0NBQ25CO0NBQ0EsS0FBSyxjQUFjLFdBQVcsZ0JBQWdCO0VBRTVDLEtBRHlCLFVBQVUsWUFDdkIsTUFBTSxNQUFNLGNBQWM7RUFDdEMsZUFBZSxJQUFJO0dBQ2pCLGNBQWM7R0FDZCxXQUFXO0dBQ1gsUUFBUTtHQUNSO0dBQ0E7RUFDRixDQUFDO0NBQ0g7Q0FDQSxJQUFJLGVBQWUsWUFBWSxnQkFBZ0I7RUFDN0MsS0FBSyxVQUFVLFlBQVksTUFBTSxNQUFNLGNBQWM7RUFDckQsZUFBZSxJQUFJO0dBQ2pCLGNBQWM7R0FDZCxRQUFRO0dBQ1IsV0FBVztFQUNiLENBQUM7Q0FDSDtDQUNBLFFBQVEsYUFBYTtFQUNuQixJQUFJLFlBQVksV0FBVyxjQUN6QixLQUFLLFVBQVUsT0FBTyxLQUFLLFdBQVc7T0FDakMsSUFBSSxZQUFZLFdBQVcsYUFDaEMsS0FBSyxVQUFVLE9BQU8sSUFBSTtDQUU5QjtDQUNBLFVBQVU7RUFDUixLQUFLLFlBQVk7Q0FDbkI7QUFDRjtBQUNBLFdBQVcsWUFBWTtDQUNyQixNQUFNO0VBQ0osY0FBYztFQUNkLGNBQWM7RUFDZCxjQUFjO0NBQ2hCO0NBQ0EsTUFBTTtBQUNSOzs7QUM5QkEsSUFBTSxlQUFlLElBQUksU0FBUztDQUNoQyxZQUFZLEVBQ1YsV0FBVztFQUNULFFBQVEsSUFBSSxhQUFhO0dBQUM7R0FBRztHQUFHO0dBQUc7R0FBRztHQUFHO0dBQUc7R0FBRztFQUFDLENBQUM7RUFDakQsUUFBUTtFQUNSLFFBQVE7RUFDUixRQUFRO0NBQ1YsRUFDRjtDQUNBLGFBQWEsSUFBSSxZQUFZO0VBQUM7RUFBRztFQUFHO0VBQUc7RUFBRztFQUFHO0NBQUMsQ0FBQztBQUNqRCxDQUFDO0FBQ0QsSUFBTSxhQUFOLE1BQWlCO0NBQ2YsY0FBYzs7Ozs7RUFLWixLQUFLLE9BQU87Ozs7O0VBS1osS0FBSyxlQUFlOzs7OztFQUtwQixLQUFLLGNBQWM7Ozs7O0VBS25CLEtBQUssVUFBVTs7Ozs7RUFLZixLQUFLLFNBQVMsSUFBSSxPQUFPOzs7OztFQUt6QixLQUFLLFlBQVk7Ozs7O0VBS2pCLEtBQUssZ0JBQWdCOzs7OztFQUtyQixLQUFLLHNCQUFzQjs7RUFFM0IsS0FBSyxvQkFBb0I7O0VBRXpCLEtBQUssbUJBQW1CO0NBQzFCO0FBQ0Y7QUFDQSxJQUFNLGVBQU4sTUFBbUI7Q0FDakIsWUFBWSxVQUFVO0VBQ3BCLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssZUFBZSxDQUFDO0VBQ3JCLEtBQUssd0JBQXdCLElBQUksYUFBYTtHQUM1QyxZQUFZO0lBQUUsdUJBQU8sSUFBSSxhQUFhLENBQUM7SUFBRyxNQUFNO0dBQVk7R0FDNUQsYUFBYTtJQUFFLHVCQUFPLElBQUksYUFBYSxDQUFDO0lBQUcsTUFBTTtHQUFZO0dBQzdELGFBQWE7SUFBRSx1QkFBTyxJQUFJLGFBQWEsQ0FBQztJQUFHLE1BQU07R0FBWTtHQUM3RCxjQUFjO0lBQUUsdUJBQU8sSUFBSSxhQUFhLENBQUM7SUFBRyxNQUFNO0dBQVk7R0FDOUQsY0FBYztJQUFFLHVCQUFPLElBQUksYUFBYSxDQUFDO0lBQUcsTUFBTTtHQUFZO0dBQzlELGdCQUFnQjtJQUFFLHVCQUFPLElBQUksYUFBYSxDQUFDO0lBQUcsTUFBTTtHQUFZO0VBQ2xFLENBQUM7RUFDRCxLQUFLLHlCQUF5QixJQUFJLFVBQVUsQ0FBQyxDQUFDO0VBQzlDLEtBQUssV0FBVztDQUNsQjs7Ozs7Q0FLQSxJQUFJLG9CQUFvQjtFQUN0QixPQUFPLEtBQUssbUJBQW1CO0NBQ2pDOzs7Ozs7Q0FNQSxLQUFLLGFBQWE7RUFDaEIsTUFBTSxXQUFXLEtBQUs7RUFDdEIsTUFBTSxVQUFVLFlBQVksYUFBYTtFQUN6QyxNQUFNLGFBQWEsS0FBSyxnQkFBZ0I7RUFDeEMsV0FBVyxPQUFPO0VBQ2xCLFdBQVcsVUFBVTtFQUNyQixXQUFXLFlBQVksWUFBWTtFQUNuQyxXQUFXLHNCQUFzQixTQUFTLGFBQWE7RUFDdkQsTUFBTSxxQkFBcUIsU0FBUyxhQUFhLGFBQWEsYUFBYTtFQUMzRSxNQUFNLGlCQUFpQixtQkFBbUI7RUFDMUMsTUFBTSxnQkFBZ0IsbUJBQW1CO0VBQ3pDLElBQUksUUFBUSxPQUFPLFdBQVcsQ0FBQyxPQUFPLE9BQU8sR0FBRztHQUM5QyxXQUFXLE9BQU87R0FDbEI7RUFDRjtFQUNBLE1BQU0sU0FBUyxXQUFXO0VBQzFCLEtBQUsscUJBQXFCLGFBQWEsTUFBTTtFQUM3QyxLQUFLLHVCQUF1QixZQUFZLFNBQVMsYUFBYSxjQUFjLGVBQWUsZ0JBQWdCLENBQUM7RUFDNUcsSUFBSSxXQUFXLE1BQ2I7RUFFRixNQUFNLHFCQUFxQixLQUFLLHVCQUF1QjtFQUN2RCxLQUFLLHFCQUFxQixZQUFZLFFBQVEsVUFBVSxrQkFBa0I7Q0FDNUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0E0QkEsd0JBQXdCLEVBQUUsU0FBUyxXQUFXO0VBQzVDLElBQUksUUFBUSxPQUFPLFdBQVcsQ0FBQyxPQUFPLE9BQU8sR0FDM0MsT0FBTztFQUVULE1BQU0sYUFBYSxLQUFLLGdCQUFnQjtFQUN4QyxLQUFLLG9CQUFvQjtFQUN6QixXQUFXLE9BQU87RUFDbEIsV0FBVyxVQUFVO0VBQ3JCLE1BQU0scUJBQXFCLFFBQVE7RUFDbkMsTUFBTSxpQkFBaUIsbUJBQW1CO0VBQzFDLE1BQU0sZ0JBQWdCLG1CQUFtQjtFQUN6QyxNQUFNLFNBQVMsV0FBVztFQUMxQixPQUFPLE1BQU07RUFDYixPQUFPLFFBQVEsUUFBUSxLQUFLO0VBQzVCLEtBQUssdUJBQXVCLFlBQVksT0FBTyxXQUFXLGVBQWUsZ0JBQWdCLENBQUM7RUFDMUYsSUFBSSxXQUFXLE1BQU07R0FDbkIsS0FBSyxlQUFlO0dBQ3BCLE9BQU87RUFDVDtFQUNBLFdBQVcsc0JBQXNCLFlBQVksa0JBQWtCO0dBQzdELE9BQU8sT0FBTztHQUNkLFFBQVEsT0FBTztHQUNmLFlBQVksV0FBVztHQUN2QixXQUFXLFdBQVc7RUFDeEIsQ0FBQztFQUNELFdBQVcsY0FBYyxRQUFRO0VBQ2pDLFdBQVcsZUFBZTtFQUUxQixLQURzQixTQUNiLGFBQWEsaUJBQWlCO0VBQ3ZDLEtBQUssdUJBQXVCLFlBQVksSUFBSTtFQUM1QyxNQUFNLGdCQUFnQixXQUFXO0VBQ2pDLGNBQWMsT0FBTyxZQUFZO0VBQ2pDLEtBQUssZUFBZTtFQUNwQixPQUFPO0NBQ1Q7O0NBRUEsTUFBTTtFQUNKLE1BQU0sV0FBVyxLQUFLO0VBQ3RCLE1BQU0sYUFBYSxLQUFLLGVBQWU7RUFDdkMsSUFBSSxXQUFXLE1BQ2I7RUFFRixTQUFTLGVBQWUsSUFBSTtFQUM1QixTQUFTLGFBQWEsaUJBQWlCO0VBQ3ZDLEtBQUssb0JBQW9CO0VBQ3pCLEtBQUssdUJBQXVCLFlBQVksS0FBSztFQUM3QyxJQUFJLFdBQVcsZUFDYixZQUFZLGNBQWMsV0FBVyxXQUFXO0VBRWxELFlBQVksY0FBYyxXQUFXLFlBQVk7Q0FDbkQ7Ozs7Ozs7Q0FPQSxlQUFlLG1CQUFtQixRQUFRLGdCQUFnQjtFQUN4RCxNQUFNLHVCQUF1QixrQkFBa0IsYUFBYSxPQUFPO0VBQ25FLE1BQU0sY0FBYyxZQUFZLGtCQUFrQjtHQUNoRCxPQUFPLE9BQU87R0FDZCxRQUFRLE9BQU87R0FDZixZQUFZO0VBQ2QsQ0FBQztFQUNELElBQUksSUFBSSxPQUFPO0VBQ2YsSUFBSSxJQUFJLE9BQU87RUFDZixJQUFJLGdCQUFnQjtHQUNsQixLQUFLLGVBQWU7R0FDcEIsS0FBSyxlQUFlO0VBQ3RCO0VBQ0EsSUFBSSxLQUFLLE1BQU0sSUFBSSxvQkFBb0I7RUFDdkMsSUFBSSxLQUFLLE1BQU0sSUFBSSxvQkFBb0I7RUFDdkMsTUFBTSxRQUFRLEtBQUssS0FBSyxPQUFPLFFBQVEsb0JBQW9CO0VBQzNELE1BQU0sU0FBUyxLQUFLLEtBQUssT0FBTyxTQUFTLG9CQUFvQjtFQUM3RCxLQUFLLFNBQVMsYUFBYSxjQUN6QixtQkFDQSxhQUNBO0dBQUU7R0FBRztFQUFFLEdBQ1A7R0FBRTtHQUFPO0VBQU8sR0FDaEI7R0FBRSxHQUFHO0dBQUcsR0FBRztFQUFFLENBQ2Y7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7O0NBUUEsWUFBWSxRQUFRLE9BQU8sUUFBUSxPQUFPO0VBQ3hDLE1BQU0sV0FBVyxLQUFLO0VBQ3RCLE1BQU0sYUFBYSxLQUFLO0VBRXhCLE1BQU0sZ0JBRHNCLFdBQVcsd0JBQ087RUFDOUMsTUFBTSxvQkFBb0IsS0FBSyx1QkFBdUI7RUFDdEQsTUFBTSxhQUFhLG9CQUFvQixrQkFBa0IsYUFBYSxPQUFPLGNBQWMsU0FBUyxhQUFhLGlCQUFpQixhQUFhLE9BQU87RUFDdEosSUFBSSxVQUFVO0VBQ2QsSUFBSSxVQUFVO0VBQ2QsSUFBSSxpQkFBaUIsbUJBQW1CO0dBQ3RDLFVBQVUsa0JBQWtCLE9BQU87R0FDbkMsVUFBVSxrQkFBa0IsT0FBTztFQUNyQztFQUNBLEtBQUssc0JBQXNCLE9BQU8sUUFBUSxZQUFZLFNBQVMsU0FBUyxZQUFZLGVBQWUsS0FBSztFQUN4RyxNQUFNLGdCQUFnQixPQUFPLFVBQVUsU0FBUyxLQUFLLHNCQUFzQjtFQUMzRSxLQUFLLDBCQUEwQixlQUFlLE9BQU8sUUFBUTtDQUMvRDs7Ozs7Ozs7O0NBU0Esc0JBQXNCLGNBQWMsUUFBUTtFQUMxQyxNQUFNLE9BQU8sS0FBSztFQUNsQixNQUFNLGVBQWUsYUFBYSxJQUNoQyxLQUFLLGFBQWEsUUFBUSxPQUMxQixHQUNBLEdBQ0EsS0FBSyxhQUFhLFFBQVEsUUFDMUIsS0FBSyxPQUFPLE1BQ1osS0FBSyxPQUFPLElBQ2Q7RUFDQSxNQUFNLGlCQUFpQixPQUFPLGVBQWUsT0FBTyxPQUFPLE1BQU07RUFDakUsTUFBTSxjQUFjLE9BQU8sZUFBZSxPQUFPO0VBQ2pELElBQUksZUFBZSxZQUFZLHVCQUM3QixlQUFlLFFBQVEsWUFBWSxxQkFBcUI7RUFFMUQsZUFBZSxPQUFPO0VBQ3RCLGFBQWEsUUFBUSxjQUFjO0VBQ25DLGFBQWEsTUFDWCxJQUFJLE9BQU8sUUFBUSxLQUFLLE9BQ3hCLElBQUksT0FBTyxRQUFRLEtBQUssTUFDMUI7RUFDQSxhQUFhLFVBQVUsT0FBTyxPQUFPLEdBQUcsT0FBTyxPQUFPLENBQUM7RUFDdkQsT0FBTztDQUNUO0NBQ0EsVUFBVTtFQUNSLEtBQUssb0JBQW9CLFFBQVEsSUFBSTtFQUNyQyxLQUFLLHFCQUFxQjtDQUM1QjtDQUNBLHdCQUF3QjtFQUN0QixLQUFLLHVCQUF1QixLQUFLLHFCQUFxQixJQUFJLGtCQUFrQjtFQUM1RSxPQUFPLEtBQUs7Q0FDZDs7Ozs7OztDQU9BLDBCQUEwQixRQUFRLE9BQU8sVUFBVTtFQUNqRCxJQUFJLFNBQVMsWUFBWSxjQUFjO0dBQ3JDLE1BQU0sZ0JBQWdCLFNBQVMsWUFBWSxhQUFhLGVBQWUsS0FBSyxxQkFBcUI7R0FDakcsS0FBSyx1QkFBdUIsWUFBWSxlQUFlLENBQUM7RUFDMUQsT0FDRSxLQUFLLHVCQUF1QixZQUFZLEtBQUssdUJBQXVCLENBQUM7RUFFdkUsS0FBSyx1QkFBdUIsWUFBWSxNQUFNLFFBQVEsQ0FBQztFQUN2RCxLQUFLLHVCQUF1QixZQUFZLE1BQU0sT0FBTyxPQUFPLENBQUM7RUFDN0QsT0FBTyxPQUFPLEtBQUssS0FBSztFQUN4QixTQUFTLFFBQVEsS0FBSztHQUNwQixVQUFVO0dBQ1YsUUFBUTtHQUNSLE9BQU8sT0FBTztHQUNkLFVBQVU7RUFDWixDQUFDO0VBQ0QsSUFBSSxTQUFTLFNBQVMsYUFBYSxPQUNqQyxTQUFTLGFBQWEsaUJBQWlCO0NBRTNDOzs7Ozs7OztDQVFBLHFCQUFxQixZQUFZLFFBQVEsVUFBVSxvQkFBb0I7RUFDckUsV0FBVyxjQUFjLFFBQVE7RUFDakMsV0FBVyxlQUFlLFlBQVksa0JBQWtCO0dBQ3RELE9BQU8sT0FBTztHQUNkLFFBQVEsT0FBTztHQUNmLFlBQVksV0FBVztHQUN2QixXQUFXLFdBQVc7RUFDeEIsQ0FBQztFQUNELElBQUksV0FBVyxlQUFlO0dBQzVCLFNBQVMsYUFBYSxpQkFBaUI7R0FDdkMsTUFBTSxlQUFlLFNBQVMsYUFBYSxnQkFBZ0IsV0FBVyxtQkFBbUI7R0FDekYsV0FBVyxjQUFjLEtBQUssZUFBZSxjQUFjLFFBQVEsb0JBQW9CLE1BQU07RUFDL0Y7RUFDQSxTQUFTLGFBQWEsS0FBSztHQUFFLFFBQVEsV0FBVztHQUFjLE9BQU87RUFBSyxDQUFDO0VBQzNFLFNBQVMsZUFBZSxLQUFLLEVBQzNCLFFBQVEsT0FDVixDQUFDO0NBQ0g7Ozs7Ozs7Ozs7OztDQVlBLHNCQUFzQixPQUFPLFFBQVEsWUFBWSxTQUFTLFNBQVMsWUFBWSxlQUFlLE9BQU87RUFDbkcsTUFBTSxXQUFXLEtBQUssc0JBQXNCO0VBQzVDLE1BQU0sY0FBYyxTQUFTO0VBQzdCLE1BQU0sWUFBWSxTQUFTO0VBQzNCLE1BQU0sYUFBYSxTQUFTO0VBQzVCLE1BQU0sYUFBYSxTQUFTO0VBQzVCLE1BQU0sY0FBYyxTQUFTO0VBQzdCLE1BQU0sZ0JBQWdCLFNBQVM7RUFDL0IsSUFBSSxlQUFlO0dBQ2pCLFlBQVksS0FBSyxXQUFXLE9BQU8sT0FBTztHQUMxQyxZQUFZLEtBQUssV0FBVyxPQUFPLE9BQU87RUFDNUMsT0FBTztHQUNMLFlBQVksS0FBSztHQUNqQixZQUFZLEtBQUs7RUFDbkI7RUFDQSxZQUFZLEtBQUssTUFBTSxNQUFNO0VBQzdCLFlBQVksS0FBSyxNQUFNLE1BQU07RUFDN0IsVUFBVSxLQUFLLE1BQU0sT0FBTztFQUM1QixVQUFVLEtBQUssTUFBTSxPQUFPO0VBQzVCLFVBQVUsS0FBSyxJQUFJLFVBQVU7RUFDN0IsVUFBVSxLQUFLLElBQUksVUFBVTtFQUM3QixXQUFXLEtBQUssTUFBTSxPQUFPO0VBQzdCLFdBQVcsS0FBSyxNQUFNLE9BQU87RUFDN0IsV0FBVyxLQUFLLElBQUksV0FBVztFQUMvQixXQUFXLEtBQUssSUFBSSxXQUFXO0VBQy9CLFdBQVcsS0FBSyxLQUFNLFdBQVc7RUFDakMsV0FBVyxLQUFLLEtBQU0sV0FBVztFQUNqQyxXQUFXLEtBQUssTUFBTSxNQUFNLFFBQVEsVUFBVSxLQUFLLEtBQU0sV0FBVztFQUNwRSxXQUFXLEtBQUssTUFBTSxNQUFNLFNBQVMsVUFBVSxLQUFLLEtBQU0sV0FBVztFQUNyRSxNQUFNLGNBQWMsS0FBSyxTQUFTLGFBQWEsaUJBQWlCO0VBQ2hFLFlBQVksS0FBSyxVQUFVO0VBQzNCLFlBQVksS0FBSyxVQUFVO0VBQzNCLFlBQVksS0FBSyxZQUFZLE9BQU8sUUFBUTtFQUM1QyxZQUFZLEtBQUssWUFBWSxPQUFPLFNBQVM7RUFDN0MsSUFBSSxrQkFBa0IsU0FBUyxPQUFPLE9BQU8sV0FBVztFQUN4RCxNQUFNLGVBQWUsS0FBSyxTQUFTLGFBQWEsZ0JBQWdCLE1BQU07RUFDdEUsS0FBSyxTQUFTLGFBQWEsS0FBSztHQUFFLFFBQVE7R0FBUSxPQUFPLENBQUMsQ0FBQztFQUFNLENBQUM7RUFDbEUsSUFBSSxrQkFBa0IsU0FBUztHQUM3QixjQUFjLEtBQUssT0FBTyxNQUFNO0dBQ2hDLGNBQWMsS0FBSyxPQUFPLE1BQU07RUFDbEMsT0FBTztHQUNMLGNBQWMsS0FBSyxhQUFhO0dBQ2hDLGNBQWMsS0FBSyxhQUFhO0VBQ2xDO0VBQ0EsY0FBYyxLQUFLLGFBQWEsU0FBUyxLQUFLO0VBQzlDLEtBQUssc0JBQXNCLE9BQU87Q0FDcEM7Ozs7Ozs7O0NBUUEseUJBQXlCO0VBQ3ZCLEtBQUssSUFBSSxJQUFJLEtBQUssb0JBQW9CLEdBQUcsS0FBSyxHQUFHLEtBQUs7R0FDcEQsTUFBTSxhQUFhLEtBQUssYUFBYTtHQUNyQyxJQUFJLENBQUMsV0FBVyxNQUFNLE9BQU87RUFDL0I7RUFDQSxPQUFPO0NBQ1Q7Ozs7OztDQU1BLHFCQUFxQixhQUFhLFFBQVE7RUFDeEMsSUFBSSxZQUFZLGFBQ2QsMEJBQTBCLFlBQVksYUFBYSxNQUFNO09BQ3BELElBQUksWUFBWSxhQUFhLFlBQVk7R0FDOUMsT0FBTyxNQUFNO0dBQ2IsT0FBTyxRQUFRLFlBQVksYUFBYSxVQUFVO0dBQ2xELE9BQU8sWUFBWSxZQUFZLFVBQVUsY0FBYztFQUN6RCxPQUNFLFlBQVksVUFBVSxvQkFBb0IsTUFBTSxNQUFNO0VBRXhELElBQUksWUFBWSxXQUFXO0dBRXpCLE1BQU0sd0JBRGMsWUFBWSxVQUFVLGVBQWUsWUFBWSxVQUFVLGtCQUFBLENBQ3RDO0dBQ3pDLElBQUksc0JBQ0YsT0FBTyxZQUFZLG9CQUFvQjtFQUUzQztDQUNGO0NBQ0EsdUJBQXVCLFlBQVksT0FBTztFQUN4QyxNQUFNLGVBQWUsV0FBVztFQUNoQyxNQUFNLFNBQVMsV0FBVztFQUMxQixNQUFNLFVBQVUsV0FBVztFQUMzQixNQUFNLGVBQWUsV0FBVztFQUNoQyxNQUFNLGNBQWMsV0FBVztFQUMvQixLQUFLLHVCQUF1QixZQUFZLGFBQWEsT0FBTyxPQUFPLENBQUM7RUFDcEUsS0FBSyx1QkFBdUIsWUFBWSxXQUFXLFlBQVksUUFBUSxDQUFDO0VBQ3hFLElBQUksaUJBQWlCLGFBQ25CLFFBQVEsYUFBYSxDQUFDLE1BQU0sTUFBTSxjQUFjLFdBQVcscUJBQXFCLEtBQUs7T0FDaEY7R0FDTCxJQUFJLE9BQU8sV0FBVztHQUN0QixNQUFNLGNBQWMsWUFBWSxrQkFBa0I7SUFDaEQsT0FBTyxPQUFPO0lBQ2QsUUFBUSxPQUFPO0lBQ2YsWUFBWSxLQUFLLE9BQU87R0FDMUIsQ0FBQztHQUNELElBQUksT0FBTztHQUNYLEtBQUssSUFBSSxJQUFJLGNBQWMsSUFBSSxhQUFhLEtBQUs7SUFDL0MsTUFBTSxTQUFTLFFBQVE7SUFDdkIsSUFBSSxDQUFDLE9BQU8sU0FBUztJQUNyQixPQUFPLE1BQU0sTUFBTSxNQUFNLE1BQU0sSUFBSTtJQUNuQyxNQUFNLElBQUk7SUFDVixPQUFPO0lBQ1AsT0FBTztHQUNUO0dBQ0EsUUFBUSxZQUFZLENBQUMsTUFBTSxNQUFNLE1BQU0sV0FBVyxxQkFBcUIsS0FBSztHQUM1RSxZQUFZLGNBQWMsV0FBVztFQUN2QztDQUNGO0NBQ0EsdUJBQXVCLFlBQVksVUFBVSxlQUFlLGdCQUFnQixtQkFBbUI7RUFDN0YsTUFBTSxXQUFXLEtBQUs7RUFDdEIsTUFBTSxTQUFTLFdBQVc7RUFDMUIsTUFBTSxVQUFVLFdBQVc7RUFDM0IsSUFBSSxhQUFhO0VBQ2pCLElBQUksVUFBVTtFQUNkLElBQUksWUFBWTtFQUNoQixJQUFJLGdCQUFnQjtFQUNwQixJQUFJLFVBQVU7RUFDZCxJQUFJLGlCQUFpQjtFQUNyQixJQUFJLG9CQUFvQjtFQUN4QixJQUFJLG1CQUFtQjtFQUN2QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7R0FDdkMsTUFBTSxTQUFTLFFBQVE7R0FDdkIsSUFBSSxDQUFDLE9BQU8sU0FBUztHQUNyQixJQUFJLHNCQUFzQixJQUFJLG9CQUFvQjtHQUNsRCxtQkFBbUI7R0FDbkIsYUFBYSxLQUFLLElBQUksWUFBWSxPQUFPLGVBQWUsWUFBWSxpQkFBaUIsT0FBTyxVQUFVO0dBQ3RHLFdBQVcsT0FBTztHQUNsQixJQUFJLE9BQU8sY0FBYyxPQUN2QixZQUFZO1FBQ1AsSUFBSSxPQUFPLGNBQWMsV0FDOUIsY0FBYyxZQUFZO0dBRTVCLElBQUksQ0FBQyxPQUFPLGdCQUNWLGlCQUFpQjtHQUduQixJQUFJLENBQUMsQ0FEaUIsRUFBRSxPQUFPLHNCQUFzQixTQUFTLE9BQzNDO0lBQ2pCLFVBQVU7SUFDVjtHQUNGO0dBQ0EsSUFBSSxPQUFPLGlCQUFpQixFQUFFLFNBQVMsWUFBWSxpQkFBaUIsT0FBTztJQUN6RSxLQUFLLHNIQUFzSDtJQUMzSCxVQUFVO0lBQ1Y7R0FDRjtHQUNBLFVBQVU7R0FDVixrQkFBa0IsZ0JBQWdCLE9BQU87RUFDM0M7RUFDQSxJQUFJLENBQUMsU0FBUztHQUNaLFdBQVcsT0FBTztHQUNsQjtFQUNGO0VBQ0EsSUFBSSxnQkFDRixPQUFPLFVBQVUsR0FBRyxTQUFTLFFBQVEsZ0JBQWdCLEdBQUcsU0FBUyxTQUFTLGNBQWM7RUFFMUYsT0FBTyxNQUFNLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sSUFBSSxVQUFVLENBQUMsQ0FBQyxLQUFLLFVBQVUsS0FBSyxpQkFBaUI7RUFDM0YsSUFBSSxDQUFDLE9BQU8sWUFBWTtHQUN0QixXQUFXLE9BQU87R0FDbEI7RUFDRjtFQUNBLFdBQVcsWUFBWTtFQUN2QixXQUFXLGFBQWE7RUFDeEIsV0FBVyxnQkFBZ0I7RUFDM0IsV0FBVyxvQkFBb0I7RUFDL0IsV0FBVyxtQkFBbUI7Q0FDaEM7Q0FDQSxpQkFBaUI7RUFDZixLQUFLO0VBQ0wsT0FBTyxLQUFLLGFBQWEsS0FBSztDQUNoQzs7Ozs7OztDQU9BLHlCQUF5QjtFQUN2QixLQUFLLElBQUksSUFBSSxLQUFLLG9CQUFvQixHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ3BELE1BQU0sYUFBYSxLQUFLLGFBQWE7R0FDckMsSUFBSSxDQUFDLFdBQVcsTUFBTSxPQUFPO0VBQy9CO0VBQ0EsT0FBTztDQUNUO0NBQ0Esa0JBQWtCO0VBQ2hCLElBQUksYUFBYSxLQUFLLGFBQWEsS0FBSztFQUN4QyxJQUFJLENBQUMsWUFDSCxhQUFhLEtBQUssYUFBYSxLQUFLLHFCQUFxQixJQUFJLFdBQVc7RUFFMUUsS0FBSztFQUNMLE9BQU87Q0FDVDtBQUNGOztBQUVBLGFBQWEsWUFBWTtDQUN2QixNQUFNLENBQ0osY0FBYyxhQUNkLGNBQWMsWUFDaEI7Q0FDQSxNQUFNO0FBQ1IiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNl19
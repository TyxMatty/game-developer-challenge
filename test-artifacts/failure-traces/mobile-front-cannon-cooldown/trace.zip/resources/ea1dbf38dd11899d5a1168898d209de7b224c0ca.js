import { H as warn, _t as ExtensionType, ft as Point, gt as eventemitter3_default } from "/node_modules/.vite/deps/CanvasPool-BcIVNj8Y.js?v=7ab6e4ce";
import { B as removeItems, i as Ticker, o as UPDATE_PRIORITY } from "/node_modules/.vite/deps/Filter-BpcfXGWT.js?v=7ab6e4ce";
//#region node_modules/pixi.js/lib/dom/CanvasObserver.mjs
var CanvasObserver = class {
	constructor(options) {
		/** A cached value of the last transform applied to the DOM element. */
		this._lastTransform = "";
		/** A ResizeObserver instance to observe changes in the canvas size. */
		this._observer = null;
		/** A flag to indicate whether the observer is attached to the Ticker for continuous updates. */
		this._tickerAttached = false;
		/**
		* Updates the transform of the DOM element based on the canvas size and position.
		* This method calculates the scale and translation needed to keep the DOM element in sync with the canvas.
		*/
		this.updateTranslation = () => {
			if (!this._canvas) return;
			const rect = this._canvas.getBoundingClientRect();
			const contentWidth = this._canvas.width;
			const contentHeight = this._canvas.height;
			const sx = rect.width / contentWidth * this._renderer.resolution;
			const sy = rect.height / contentHeight * this._renderer.resolution;
			const newTransform = `translate(${rect.left}px, ${rect.top}px) scale(${sx}, ${sy})`;
			if (newTransform !== this._lastTransform) {
				this._domElement.style.transform = newTransform;
				this._lastTransform = newTransform;
			}
		};
		this._domElement = options.domElement;
		this._renderer = options.renderer;
		if (globalThis.OffscreenCanvas && this._renderer.canvas instanceof OffscreenCanvas) return;
		this._canvas = this._renderer.canvas;
		this._attachObserver();
	}
	/** The canvas element that this CanvasObserver is associated with. */
	get canvas() {
		return this._canvas;
	}
	/** Attaches the DOM element to the canvas parent if it is not already attached. */
	ensureAttached() {
		if (!this._domElement.parentNode && this._canvas.parentNode) {
			this._canvas.parentNode.appendChild(this._domElement);
			this.updateTranslation();
		}
	}
	/** Sets up a ResizeObserver if available. This ensures that the DOM element is kept in sync with the canvas size . */
	_attachObserver() {
		if ("ResizeObserver" in globalThis) {
			if (this._observer) {
				this._observer.disconnect();
				this._observer = null;
			}
			this._observer = new ResizeObserver((entries) => {
				for (const entry of entries) {
					if (entry.target !== this._canvas) continue;
					const contentWidth = this.canvas.width;
					const contentHeight = this.canvas.height;
					const sx = entry.contentRect.width / contentWidth * this._renderer.resolution;
					const sy = entry.contentRect.height / contentHeight * this._renderer.resolution;
					if (this._lastScaleX !== sx || this._lastScaleY !== sy) {
						this.updateTranslation();
						this._lastScaleX = sx;
						this._lastScaleY = sy;
					}
				}
			});
			this._observer.observe(this._canvas);
		} else if (!this._tickerAttached) Ticker.shared.add(this.updateTranslation, this, UPDATE_PRIORITY.HIGH);
	}
	/** Destroys the CanvasObserver instance, cleaning up observers and Ticker. */
	destroy() {
		if (this._observer) {
			this._observer.disconnect();
			this._observer = null;
		} else if (this._tickerAttached) Ticker.shared.remove(this.updateTranslation);
		this._domElement = null;
		this._renderer = null;
		this._canvas = null;
		this._tickerAttached = false;
		this._lastTransform = "";
		this._lastScaleX = null;
		this._lastScaleY = null;
	}
};
//#endregion
//#region node_modules/pixi.js/lib/events/FederatedEvent.mjs
var FederatedEvent = class FederatedEvent {
	/**
	* @param manager - The event boundary which manages this event. Propagation can only occur
	*  within the boundary's jurisdiction.
	*/
	constructor(manager) {
		/** Flags whether this event bubbles. This will take effect only if it is set before propagation. */
		this.bubbles = true;
		/** @deprecated since 7.0.0 */
		this.cancelBubble = true;
		/**
		* Flags whether this event can be canceled using {@link FederatedEvent.preventDefault}. This is always
		* false (for now).
		*/
		this.cancelable = false;
		/**
		* Flag added for compatibility with DOM `Event`. It is not used in the Federated Events
		* API.
		* @see https://dom.spec.whatwg.org/#dom-event-composed
		* @ignore
		*/
		this.composed = false;
		/** Flags whether the default response of the user agent was prevent through this event. */
		this.defaultPrevented = false;
		/**
		* The propagation phase.
		* @default {@link FederatedEvent.NONE}
		*/
		this.eventPhase = FederatedEvent.prototype.NONE;
		/** Flags whether propagation was stopped. */
		this.propagationStopped = false;
		/** Flags whether propagation was immediately stopped. */
		this.propagationImmediatelyStopped = false;
		/** The coordinates of the event relative to the nearest DOM layer. This is a non-standard property. */
		this.layer = new Point();
		/** The coordinates of the event relative to the DOM document. This is a non-standard property. */
		this.page = new Point();
		/**
		* The event propagation phase NONE that indicates that the event is not in any phase.
		* @default 0
		* @advanced
		*/
		this.NONE = 0;
		/**
		* The event propagation phase CAPTURING_PHASE that indicates that the event is in the capturing phase.
		* @default 1
		* @advanced
		*/
		this.CAPTURING_PHASE = 1;
		/**
		* The event propagation phase AT_TARGET that indicates that the event is at the target.
		* @default 2
		* @advanced
		*/
		this.AT_TARGET = 2;
		/**
		* The event propagation phase BUBBLING_PHASE that indicates that the event is in the bubbling phase.
		* @default 3
		* @advanced
		*/
		this.BUBBLING_PHASE = 3;
		this.manager = manager;
	}
	/** @readonly */
	get layerX() {
		return this.layer.x;
	}
	/** @readonly */
	get layerY() {
		return this.layer.y;
	}
	/** @readonly */
	get pageX() {
		return this.page.x;
	}
	/** @readonly */
	get pageY() {
		return this.page.y;
	}
	/**
	* Fallback for the deprecated `InteractionEvent.data`.
	* @deprecated since 7.0.0
	*/
	get data() {
		return this;
	}
	/**
	* The propagation path for this event. Alias for {@link EventBoundary.propagationPath}.
	* @advanced
	*/
	composedPath() {
		if (this.manager && (!this.path || this.path[this.path.length - 1] !== this.target)) this.path = this.target ? this.manager.propagationPath(this.target) : [];
		return this.path;
	}
	/**
	* Unimplemented method included for implementing the DOM interface `Event`. It will throw an `Error`.
	* @deprecated
	* @ignore
	* @param _type
	* @param _bubbles
	* @param _cancelable
	*/
	initEvent(_type, _bubbles, _cancelable) {
		throw new Error("initEvent() is a legacy DOM API. It is not implemented in the Federated Events API.");
	}
	/**
	* Unimplemented method included for implementing the DOM interface `UIEvent`. It will throw an `Error`.
	* @ignore
	* @deprecated
	* @param _typeArg
	* @param _bubblesArg
	* @param _cancelableArg
	* @param _viewArg
	* @param _detailArg
	*/
	initUIEvent(_typeArg, _bubblesArg, _cancelableArg, _viewArg, _detailArg) {
		throw new Error("initUIEvent() is a legacy DOM API. It is not implemented in the Federated Events API.");
	}
	/**
	* Prevent default behavior of both PixiJS and the user agent.
	* @example
	* ```ts
	* sprite.on('click', (event) => {
	*     // Prevent both browser's default click behavior
	*     // and PixiJS's default handling
	*     event.preventDefault();
	*
	*     // Custom handling
	*     customClickHandler();
	* });
	* ```
	* @remarks
	* - Only works if the native event is cancelable
	* - Does not stop event propagation
	*/
	preventDefault() {
		if (this.nativeEvent instanceof Event && this.nativeEvent.cancelable) this.nativeEvent.preventDefault();
		this.defaultPrevented = true;
	}
	/**
	* Stop this event from propagating to any additional listeners, including those
	* on the current target and any following targets in the propagation path.
	* @example
	* ```ts
	* container.on('pointerdown', (event) => {
	*     // Stop all further event handling
	*     event.stopImmediatePropagation();
	*
	*     // These handlers won't be called:
	*     // - Other pointerdown listeners on this container
	*     // - Any pointerdown listeners on parent containers
	* });
	* ```
	* @remarks
	* - Immediately stops all event propagation
	* - Prevents other listeners on same target from being called
	* - More aggressive than stopPropagation()
	*/
	stopImmediatePropagation() {
		this.propagationImmediatelyStopped = true;
	}
	/**
	* Stop this event from propagating to the next target in the propagation path.
	* The rest of the listeners on the current target will still be notified.
	* @example
	* ```ts
	* child.on('pointermove', (event) => {
	*     // Handle event on child
	*     updateChild();
	*
	*     // Prevent parent handlers from being called
	*     event.stopPropagation();
	* });
	*
	* // This won't be called if child handles the event
	* parent.on('pointermove', (event) => {
	*     updateParent();
	* });
	* ```
	* @remarks
	* - Stops event bubbling to parent containers
	* - Does not prevent other listeners on same target
	* - Less aggressive than stopImmediatePropagation()
	*/
	stopPropagation() {
		this.propagationStopped = true;
	}
};
//#endregion
//#region node_modules/ismobilejs/esm/isMobile.js
var appleIphone = /iPhone/i;
var appleIpod = /iPod/i;
var appleTablet = /iPad/i;
var appleUniversal = /\biOS-universal(?:.+)Mac\b/i;
var androidPhone = /\bAndroid(?:.+)Mobile\b/i;
var androidTablet = /Android/i;
var amazonPhone = /(?:SD4930UR|\bSilk(?:.+)Mobile\b)/i;
var amazonTablet = /Silk/i;
var windowsPhone = /Windows Phone/i;
var windowsTablet = /\bWindows(?:.+)ARM\b/i;
var otherBlackBerry = /BlackBerry/i;
var otherBlackBerry10 = /BB10/i;
var otherOpera = /Opera Mini/i;
var otherChrome = /\b(CriOS|Chrome)(?:.+)Mobile/i;
var otherFirefox = /Mobile(?:.+)Firefox\b/i;
var isAppleTabletOnIos13 = function(navigator) {
	return typeof navigator !== "undefined" && navigator.platform === "MacIntel" && typeof navigator.maxTouchPoints === "number" && navigator.maxTouchPoints > 1 && typeof MSStream === "undefined";
};
function createMatch(userAgent) {
	return function(regex) {
		return regex.test(userAgent);
	};
}
function isMobile$1(param) {
	var nav = {
		userAgent: "",
		platform: "",
		maxTouchPoints: 0
	};
	if (!param && typeof navigator !== "undefined") nav = {
		userAgent: navigator.userAgent,
		platform: navigator.platform,
		maxTouchPoints: navigator.maxTouchPoints || 0
	};
	else if (typeof param === "string") nav.userAgent = param;
	else if (param && param.userAgent) nav = {
		userAgent: param.userAgent,
		platform: param.platform,
		maxTouchPoints: param.maxTouchPoints || 0
	};
	var userAgent = nav.userAgent;
	var tmp = userAgent.split("[FBAN");
	if (typeof tmp[1] !== "undefined") userAgent = tmp[0];
	tmp = userAgent.split("Twitter");
	if (typeof tmp[1] !== "undefined") userAgent = tmp[0];
	var match = createMatch(userAgent);
	var result = {
		apple: {
			phone: match(appleIphone) && !match(windowsPhone),
			ipod: match(appleIpod),
			tablet: !match(appleIphone) && (match(appleTablet) || isAppleTabletOnIos13(nav)) && !match(windowsPhone),
			universal: match(appleUniversal),
			device: (match(appleIphone) || match(appleIpod) || match(appleTablet) || match(appleUniversal) || isAppleTabletOnIos13(nav)) && !match(windowsPhone)
		},
		amazon: {
			phone: match(amazonPhone),
			tablet: !match(amazonPhone) && match(amazonTablet),
			device: match(amazonPhone) || match(amazonTablet)
		},
		android: {
			phone: !match(windowsPhone) && match(amazonPhone) || !match(windowsPhone) && match(androidPhone),
			tablet: !match(windowsPhone) && !match(amazonPhone) && !match(androidPhone) && (match(amazonTablet) || match(androidTablet)),
			device: !match(windowsPhone) && (match(amazonPhone) || match(amazonTablet) || match(androidPhone) || match(androidTablet)) || match(/\bokhttp\b/i)
		},
		windows: {
			phone: match(windowsPhone),
			tablet: match(windowsTablet),
			device: match(windowsPhone) || match(windowsTablet)
		},
		other: {
			blackberry: match(otherBlackBerry),
			blackberry10: match(otherBlackBerry10),
			opera: match(otherOpera),
			firefox: match(otherFirefox),
			chrome: match(otherChrome),
			device: match(otherBlackBerry) || match(otherBlackBerry10) || match(otherOpera) || match(otherFirefox) || match(otherChrome)
		},
		any: false,
		phone: false,
		tablet: false
	};
	result.any = result.apple.device || result.android.device || result.windows.device || result.other.device;
	result.phone = result.apple.phone || result.android.phone || result.windows.phone;
	result.tablet = result.apple.tablet || result.android.tablet || result.windows.tablet;
	return result;
}
//#endregion
//#region node_modules/pixi.js/lib/utils/browser/isMobile.mjs
var isMobile = (isMobile$1.default ?? isMobile$1)(globalThis.navigator);
//#endregion
//#region node_modules/pixi.js/lib/accessibility/AccessibilitySystem.mjs
var KEY_CODE_TAB = 9;
var DIV_TOUCH_SIZE = 100;
var DIV_TOUCH_POS_X = 0;
var DIV_TOUCH_POS_Y = 0;
var DIV_TOUCH_ZINDEX = 2;
var DIV_HOOK_SIZE = 1;
var DIV_HOOK_POS_X = -1e3;
var DIV_HOOK_POS_Y = -1e3;
var DIV_HOOK_ZINDEX = 2;
var _AccessibilitySystem = class _AccessibilitySystem {
	/**
	* @param {WebGLRenderer|WebGPURenderer} renderer - A reference to the current renderer
	*/
	constructor(renderer, _mobileInfo = isMobile) {
		this._mobileInfo = _mobileInfo;
		/** Whether accessibility divs are visible for debugging */
		this.debug = false;
		/** Whether to activate on tab key press */
		this._activateOnTab = true;
		/** Whether to deactivate accessibility when mouse moves */
		this._deactivateOnMouseMove = true;
		/** Internal variable, see isActive getter. */
		this._isActive = false;
		/** Internal variable, see isMobileAccessibility getter. */
		this._isMobileAccessibility = false;
		/** This is the dom element that will sit over the PixiJS element. This is where the div overlays will go. */
		this._div = null;
		/** A simple pool for storing divs. */
		this._pools = {};
		/** This is a tick used to check if an object is no longer being rendered. */
		this._renderId = 0;
		/** The array of currently active accessible items. */
		this._children = [];
		/** Count to throttle div updates on android devices. */
		this._androidUpdateCount = 0;
		/**  The frequency to update the div elements. */
		this._androidUpdateFrequency = 500;
		this._isRunningTests = false;
		/** Bound function references for proper event listener removal */
		this._boundOnKeyDown = this._onKeyDown.bind(this);
		this._boundOnMouseMove = this._onMouseMove.bind(this);
		this._hookDiv = null;
		if (_mobileInfo.tablet || _mobileInfo.phone) this._createTouchHook();
		this._renderer = renderer;
	}
	/**
	* Value of `true` if accessibility is currently active and accessibility layers are showing.
	* @type {boolean}
	* @readonly
	*/
	get isActive() {
		return this._isActive;
	}
	/**
	* Value of `true` if accessibility is enabled for touch devices.
	* @type {boolean}
	* @readonly
	*/
	get isMobileAccessibility() {
		return this._isMobileAccessibility;
	}
	/**
	* Button element for handling touch hooks.
	* @readonly
	*/
	get hookDiv() {
		return this._hookDiv;
	}
	/**
	* The DOM element that will sit over the PixiJS element. This is where the div overlays will go.
	* @readonly
	*/
	get div() {
		return this._div;
	}
	/**
	* Creates the touch hooks.
	* @private
	*/
	_createTouchHook() {
		const hookDiv = document.createElement("button");
		hookDiv.style.width = `${DIV_HOOK_SIZE}px`;
		hookDiv.style.height = `${DIV_HOOK_SIZE}px`;
		hookDiv.style.position = "absolute";
		hookDiv.style.top = `${DIV_HOOK_POS_X}px`;
		hookDiv.style.left = `${DIV_HOOK_POS_Y}px`;
		hookDiv.style.zIndex = DIV_HOOK_ZINDEX.toString();
		hookDiv.style.backgroundColor = "#FF0000";
		hookDiv.title = "select to enable accessibility for this content";
		hookDiv.addEventListener("focus", () => {
			this._isMobileAccessibility = true;
			this._activate();
			this._destroyTouchHook();
		});
		document.body.appendChild(hookDiv);
		this._hookDiv = hookDiv;
	}
	/**
	* Destroys the touch hooks.
	* @private
	*/
	_destroyTouchHook() {
		if (!this._hookDiv) return;
		document.body.removeChild(this._hookDiv);
		this._hookDiv = null;
	}
	/**
	* Activating will cause the Accessibility layer to be shown.
	* This is called when a user presses the tab key.
	* @private
	*/
	_activate() {
		if (this._isActive) return;
		this._isActive = true;
		if (!this._div) {
			this._div = document.createElement("div");
			this._div.style.position = "absolute";
			this._div.style.top = `${DIV_TOUCH_POS_X}px`;
			this._div.style.left = `${DIV_TOUCH_POS_Y}px`;
			this._div.style.pointerEvents = "none";
			this._div.style.zIndex = DIV_TOUCH_ZINDEX.toString();
			this._canvasObserver = new CanvasObserver({
				domElement: this._div,
				renderer: this._renderer
			});
		}
		if (this._deactivateOnMouseMove) globalThis.document.addEventListener("mousemove", this._boundOnMouseMove, true);
		const canvas = this._renderer.view.canvas;
		if (!canvas.parentNode) {
			const observer = new MutationObserver(() => {
				if (canvas.parentNode) {
					observer.disconnect();
					this._canvasObserver.ensureAttached();
					this._initAccessibilitySetup();
				}
			});
			observer.observe(document.body, {
				childList: true,
				subtree: true
			});
		} else {
			this._canvasObserver.ensureAttached();
			this._initAccessibilitySetup();
		}
	}
	_initAccessibilitySetup() {
		this._renderer.runners.postrender.add(this);
		if (this._renderer.lastObjectRendered) this._updateAccessibleObjects(this._renderer.lastObjectRendered);
	}
	/**
	* Deactivates the accessibility system. Removes listeners and accessibility elements.
	* @private
	*/
	_deactivate() {
		if (!this._isActive || this._isMobileAccessibility) return;
		this._isActive = false;
		globalThis.document.removeEventListener("mousemove", this._boundOnMouseMove, true);
		this._renderer.runners.postrender.remove(this);
		for (const child of this._children) {
			if (child._accessibleDiv?.parentNode) {
				child._accessibleDiv.parentNode.removeChild(child._accessibleDiv);
				child._accessibleDiv = null;
			}
			child._accessibleActive = false;
		}
		for (const accessibleType in this._pools) {
			this._pools[accessibleType].forEach((div) => {
				if (div.parentNode) div.parentNode.removeChild(div);
			});
			delete this._pools[accessibleType];
		}
		if (this._div?.parentNode) this._div.parentNode.removeChild(this._div);
		this._pools = {};
		this._children = [];
	}
	/**
	* This recursive function will run through the scene graph and add any new accessible objects to the DOM layer.
	* @private
	* @param {Container} container - The Container to check.
	*/
	_updateAccessibleObjects(container) {
		if (!container.visible || !container.accessibleChildren) return;
		if (container.accessible) {
			if (!container._accessibleActive) this._addChild(container);
			container._renderId = this._renderId;
		}
		const children = container.children;
		if (children) for (let i = 0; i < children.length; i++) this._updateAccessibleObjects(children[i]);
	}
	/**
	* Runner init called, view is available at this point.
	* @ignore
	*/
	init(options) {
		const mergedOptions = { accessibilityOptions: {
			..._AccessibilitySystem.defaultOptions,
			...options?.accessibilityOptions || {}
		} };
		this.debug = mergedOptions.accessibilityOptions.debug;
		this._activateOnTab = mergedOptions.accessibilityOptions.activateOnTab;
		this._deactivateOnMouseMove = mergedOptions.accessibilityOptions.deactivateOnMouseMove;
		if (this._activateOnTab) globalThis.addEventListener("keydown", this._boundOnKeyDown, false);
		if (mergedOptions.accessibilityOptions.enabledByDefault) this._activate();
		this._renderer.runners.postrender.remove(this);
	}
	/**
	* Updates the accessibility layer during rendering.
	* - Removes divs for containers no longer in the scene
	* - Updates the position and dimensions of the root div
	* - Updates positions of active accessibility divs
	* Only fires while the accessibility system is active.
	* @ignore
	*/
	postrender() {
		const now = performance.now();
		if (this._mobileInfo.android.device && now < this._androidUpdateCount) return;
		this._androidUpdateCount = now + this._androidUpdateFrequency;
		if ((!this._renderer.renderingToScreen || !this._renderer.view.canvas) && !this._isRunningTests) return;
		const activeIds = /* @__PURE__ */ new Set();
		if (this._renderer.lastObjectRendered) {
			this._updateAccessibleObjects(this._renderer.lastObjectRendered);
			for (const child of this._children) if (child._renderId === this._renderId) activeIds.add(this._children.indexOf(child));
		}
		for (let i = this._children.length - 1; i >= 0; i--) {
			const child = this._children[i];
			if (!activeIds.has(i)) {
				if (child._accessibleDiv && child._accessibleDiv.parentNode) {
					child._accessibleDiv.parentNode.removeChild(child._accessibleDiv);
					this._getPool(child.accessibleType).push(child._accessibleDiv);
					child._accessibleDiv = null;
				}
				child._accessibleActive = false;
				removeItems(this._children, i, 1);
			}
		}
		if (this._renderer.renderingToScreen) this._canvasObserver.ensureAttached();
		for (let i = 0; i < this._children.length; i++) {
			const child = this._children[i];
			if (!child._accessibleActive || !child._accessibleDiv) continue;
			const div = child._accessibleDiv;
			const hitArea = child.hitArea || child.getBounds().rectangle;
			if (child.hitArea) {
				const wt = child.worldTransform;
				div.style.left = `${wt.tx + hitArea.x * wt.a}px`;
				div.style.top = `${wt.ty + hitArea.y * wt.d}px`;
				div.style.width = `${hitArea.width * wt.a}px`;
				div.style.height = `${hitArea.height * wt.d}px`;
			} else {
				this._capHitArea(hitArea);
				div.style.left = `${hitArea.x}px`;
				div.style.top = `${hitArea.y}px`;
				div.style.width = `${hitArea.width}px`;
				div.style.height = `${hitArea.height}px`;
			}
		}
		this._renderId++;
	}
	/**
	* private function that will visually add the information to the
	* accessibility div
	* @param {HTMLElement} div -
	*/
	_updateDebugHTML(div) {
		div.innerHTML = `type: ${div.type}</br> title : ${div.title}</br> tabIndex: ${div.tabIndex}`;
	}
	/**
	* Adjust the hit area based on the bounds of a display object
	* @param {Rectangle} hitArea - Bounds of the child
	*/
	_capHitArea(hitArea) {
		if (hitArea.x < 0) {
			hitArea.width += hitArea.x;
			hitArea.x = 0;
		}
		if (hitArea.y < 0) {
			hitArea.height += hitArea.y;
			hitArea.y = 0;
		}
		const { width: viewWidth, height: viewHeight } = this._renderer;
		if (hitArea.x + hitArea.width > viewWidth) hitArea.width = viewWidth - hitArea.x;
		if (hitArea.y + hitArea.height > viewHeight) hitArea.height = viewHeight - hitArea.y;
	}
	/**
	* Creates or reuses a div element for a Container and adds it to the accessibility layer.
	* Sets up ARIA attributes, event listeners, and positioning based on the container's properties.
	* @private
	* @param {Container} container - The child to make accessible.
	*/
	_addChild(container) {
		let div = this._getPool(container.accessibleType).pop();
		if (div) {
			div.innerHTML = "";
			div.removeAttribute("title");
			div.removeAttribute("aria-label");
			div.tabIndex = 0;
		} else {
			if (container.accessibleType === "button") {
				div = document.createElement("button");
				if (!this.debug) div.style.color = "transparent";
			} else {
				div = document.createElement(container.accessibleType);
				div.style.cssText = `
                        color: transparent;
                        pointer-events: none;
                        padding: 0;
                        margin: 0;
                        border: 0;
                        outline: 0;
                        background: transparent;
                        box-sizing: border-box;
                        user-select: none;
                        -webkit-user-select: none;
                        -moz-user-select: none;
                        -ms-user-select: none;
                    `;
			}
			div.style.width = `${DIV_TOUCH_SIZE}px`;
			div.style.height = `${DIV_TOUCH_SIZE}px`;
			div.style.backgroundColor = this.debug ? "rgba(255,255,255,0.5)" : "transparent";
			div.style.position = "absolute";
			div.style.zIndex = DIV_TOUCH_ZINDEX.toString();
			div.style.borderStyle = "none";
			if (navigator.userAgent.toLowerCase().includes("chrome")) div.setAttribute("aria-live", "off");
			else div.setAttribute("aria-live", "polite");
			if (navigator.userAgent.match(/rv:.*Gecko\//)) div.setAttribute("aria-relevant", "additions");
			else div.setAttribute("aria-relevant", "text");
			div.addEventListener("click", this._onClick.bind(this));
			div.addEventListener("focus", this._onFocus.bind(this));
			div.addEventListener("focusout", this._onFocusOut.bind(this));
		}
		div.style.pointerEvents = container.accessiblePointerEvents;
		div.type = container.accessibleType;
		if (container.accessibleText) div.innerText = container.accessibleText;
		if (container.accessibleTitle && container.accessibleTitle !== null) div.title = container.accessibleTitle;
		else if (!container.accessibleHint || container.accessibleHint === null) div.title = `container ${container.tabIndex}`;
		if (container.accessibleHint && container.accessibleHint !== null) div.setAttribute("aria-label", container.accessibleHint);
		if (container.interactive) div.tabIndex = container.tabIndex;
		else div.tabIndex = 0;
		if (this.debug) this._updateDebugHTML(div);
		container._accessibleActive = true;
		container._accessibleDiv = div;
		div.container = container;
		this._children.push(container);
		this._div.appendChild(container._accessibleDiv);
	}
	/**
	* Dispatch events with the EventSystem.
	* @param e
	* @param type
	* @private
	*/
	_dispatchEvent(e, type) {
		const { container: target } = e.target;
		const boundary = this._renderer.events.rootBoundary;
		const event = Object.assign(new FederatedEvent(boundary), { target });
		boundary.rootTarget = this._renderer.lastObjectRendered;
		type.forEach((type2) => boundary.dispatchEvent(event, type2));
	}
	/**
	* Maps the div button press to pixi's EventSystem (click)
	* @private
	* @param {MouseEvent} e - The click event.
	*/
	_onClick(e) {
		this._dispatchEvent(e, [
			"click",
			"pointertap",
			"tap"
		]);
	}
	/**
	* Maps the div focus events to pixi's EventSystem (mouseover)
	* @private
	* @param {FocusEvent} e - The focus event.
	*/
	_onFocus(e) {
		if (!e.target.getAttribute("aria-live")) e.target.setAttribute("aria-live", "assertive");
		this._dispatchEvent(e, ["mouseover"]);
	}
	/**
	* Maps the div focus events to pixi's EventSystem (mouseout)
	* @private
	* @param {FocusEvent} e - The focusout event.
	*/
	_onFocusOut(e) {
		if (!e.target.getAttribute("aria-live")) e.target.setAttribute("aria-live", "polite");
		this._dispatchEvent(e, ["mouseout"]);
	}
	/**
	* Is called when a key is pressed
	* @private
	* @param {KeyboardEvent} e - The keydown event.
	*/
	_onKeyDown(e) {
		if (e.keyCode !== KEY_CODE_TAB || !this._activateOnTab) return;
		this._activate();
	}
	/**
	* Is called when the mouse moves across the renderer element
	* @private
	* @param {MouseEvent} e - The mouse event.
	*/
	_onMouseMove(e) {
		if (e.movementX === 0 && e.movementY === 0) return;
		this._deactivate();
	}
	/**
	* Destroys the accessibility system. Removes all elements and listeners.
	* > [!IMPORTANT] This is typically called automatically when the {@link Application} is destroyed.
	* > A typically user should not need to call this method directly.
	*/
	destroy() {
		this._deactivate();
		this._destroyTouchHook();
		this._canvasObserver?.destroy();
		this._canvasObserver = null;
		this._div = null;
		this._pools = null;
		this._children = null;
		this._renderer = null;
		this._hookDiv = null;
		globalThis.removeEventListener("keydown", this._boundOnKeyDown);
		this._boundOnKeyDown = null;
		globalThis.document.removeEventListener("mousemove", this._boundOnMouseMove, true);
		this._boundOnMouseMove = null;
	}
	/**
	* Enables or disables the accessibility system.
	* @param enabled - Whether to enable or disable accessibility.
	* @example
	* ```js
	* app.renderer.accessibility.setAccessibilityEnabled(true); // Enable accessibility
	* app.renderer.accessibility.setAccessibilityEnabled(false); // Disable accessibility
	* ```
	*/
	setAccessibilityEnabled(enabled) {
		if (enabled) this._activate();
		else this._deactivate();
	}
	_getPool(accessibleType) {
		if (!this._pools[accessibleType]) this._pools[accessibleType] = [];
		return this._pools[accessibleType];
	}
};
/** @ignore */
_AccessibilitySystem.extension = {
	type: [ExtensionType.WebGLSystem, ExtensionType.WebGPUSystem],
	name: "accessibility"
};
/**
* The default options used by the system.
* You can set these before initializing the {@link Application} to change the default behavior.
* @example
* ```js
* import { AccessibilitySystem } from 'pixi.js';
*
* AccessibilitySystem.defaultOptions.enabledByDefault = true;
*
* const app = new Application()
* app.init()
* ```
*/
_AccessibilitySystem.defaultOptions = {
	/**
	* Whether to enable accessibility features on initialization
	* @default false
	*/
	enabledByDefault: false,
	/**
	* Whether to visually show the accessibility divs for debugging
	* @default false
	*/
	debug: false,
	/**
	* Whether to activate accessibility when tab key is pressed
	* @default true
	*/
	activateOnTab: true,
	/**
	* Whether to deactivate accessibility when mouse moves
	* @default true
	*/
	deactivateOnMouseMove: true
};
var AccessibilitySystem = _AccessibilitySystem;
//#endregion
//#region node_modules/pixi.js/lib/accessibility/accessibilityTarget.mjs
var accessibilityTarget = {
	accessible: false,
	accessibleTitle: null,
	accessibleHint: null,
	tabIndex: 0,
	accessibleType: "button",
	accessibleText: null,
	accessiblePointerEvents: "auto",
	accessibleChildren: true,
	_accessibleActive: false,
	_accessibleDiv: null,
	_renderId: -1
};
//#endregion
//#region node_modules/pixi.js/lib/dom/DOMPipe.mjs
var DOMPipe = class {
	/**
	* Constructor for the DOMPipe class.
	* @param renderer - The renderer instance that this DOMPipe will be associated with.
	*/
	constructor(renderer) {
		/** Array to keep track of attached DOM elements */
		this._attachedDomElements = [];
		this._renderer = renderer;
		this._renderer.runners.postrender.add(this);
		this._renderer.runners.init.add(this);
		this._domElement = document.createElement("div");
		this._domElement.style.position = "absolute";
		this._domElement.style.top = "0";
		this._domElement.style.left = "0";
		this._domElement.style.pointerEvents = "none";
		this._domElement.style.zIndex = "1000";
	}
	/** Initializes the DOMPipe, setting up the main DOM element and adding it to the document body. */
	init() {
		this._canvasObserver = new CanvasObserver({
			domElement: this._domElement,
			renderer: this._renderer
		});
	}
	/**
	* Adds a renderable DOM container to the list of attached elements.
	* @param domContainer - The DOM container to be added.
	* @param _instructionSet - The instruction set (unused).
	*/
	addRenderable(domContainer, _instructionSet) {
		if (!this._attachedDomElements.includes(domContainer)) this._attachedDomElements.push(domContainer);
	}
	/**
	* Updates a renderable DOM container.
	* @param _domContainer - The DOM container to be updated (unused).
	*/
	updateRenderable(_domContainer) {}
	/**
	* Validates a renderable DOM container.
	* @param _domContainer - The DOM container to be validated (unused).
	* @returns Always returns true as validation is not required.
	*/
	validateRenderable(_domContainer) {
		return true;
	}
	/** Handles the post-rendering process, ensuring DOM elements are correctly positioned and visible. */
	postrender() {
		const attachedDomElements = this._attachedDomElements;
		if (attachedDomElements.length === 0) {
			this._domElement.remove();
			return;
		}
		this._canvasObserver.ensureAttached();
		for (let i = 0; i < attachedDomElements.length; i++) {
			const domContainer = attachedDomElements[i];
			const element = domContainer.element;
			if (!domContainer.parent || domContainer.globalDisplayStatus < 7) {
				element?.remove();
				attachedDomElements.splice(i, 1);
				i--;
			} else {
				if (!this._domElement.contains(element)) {
					element.style.position = "absolute";
					element.style.pointerEvents = "auto";
					this._domElement.appendChild(element);
				}
				const wt = domContainer.worldTransform;
				const anchor = domContainer._anchor;
				const ax = domContainer.width * anchor.x;
				const ay = domContainer.height * anchor.y;
				element.style.transformOrigin = `${ax}px ${ay}px`;
				element.style.transform = `matrix(${wt.a}, ${wt.b}, ${wt.c}, ${wt.d}, ${wt.tx - ax}, ${wt.ty - ay})`;
				element.style.opacity = domContainer.groupAlpha.toString();
			}
		}
	}
	/** Destroys the DOMPipe, removing all attached DOM elements and cleaning up resources. */
	destroy() {
		this._renderer.runners.postrender.remove(this);
		for (let i = 0; i < this._attachedDomElements.length; i++) this._attachedDomElements[i].element?.remove();
		this._attachedDomElements.length = 0;
		this._domElement.remove();
		this._canvasObserver.destroy();
		this._renderer = null;
	}
};
/**
* Static property defining the extension type and name for the DOMPipe.
* This is used to register the DOMPipe with different rendering pipelines.
*/
DOMPipe.extension = {
	type: [
		ExtensionType.WebGLPipes,
		ExtensionType.WebGPUPipes,
		ExtensionType.CanvasPipes
	],
	name: "dom"
};
//#endregion
//#region node_modules/pixi.js/lib/events/EventTicker.mjs
var EventsTickerClass = class {
	constructor() {
		/** The frequency that fake events will be fired. */
		this.interactionFrequency = 10;
		this._deltaTime = 0;
		this._didMove = false;
		this._tickerAdded = false;
		this._pauseUpdate = true;
	}
	/**
	* Initializes the event ticker.
	* @param events - The event system.
	*/
	init(events) {
		this.removeTickerListener();
		this.events = events;
		this.interactionFrequency = 10;
		this._deltaTime = 0;
		this._didMove = false;
		this._tickerAdded = false;
		this._pauseUpdate = true;
	}
	/** Whether to pause the update checks or not. */
	get pauseUpdate() {
		return this._pauseUpdate;
	}
	set pauseUpdate(paused) {
		this._pauseUpdate = paused;
	}
	/** Adds the ticker listener. */
	addTickerListener() {
		if (this._tickerAdded || !this.domElement) return;
		Ticker.system.add(this._tickerUpdate, this, UPDATE_PRIORITY.INTERACTION);
		this._tickerAdded = true;
	}
	/** Removes the ticker listener. */
	removeTickerListener() {
		if (!this._tickerAdded) return;
		Ticker.system.remove(this._tickerUpdate, this);
		this._tickerAdded = false;
	}
	/** Sets flag to not fire extra events when the user has already moved there mouse */
	pointerMoved() {
		this._didMove = true;
	}
	/** Updates the state of interactive objects. */
	_update() {
		if (!this.domElement || this._pauseUpdate) return;
		if (this._didMove) {
			this._didMove = false;
			return;
		}
		const rootPointerEvent = this.events["_rootPointerEvent"];
		if (this.events.supportsTouchEvents && rootPointerEvent.pointerType === "touch") return;
		globalThis.document.dispatchEvent(this.events.supportsPointerEvents ? new PointerEvent("pointermove", {
			clientX: rootPointerEvent.clientX,
			clientY: rootPointerEvent.clientY,
			pointerType: rootPointerEvent.pointerType,
			pointerId: rootPointerEvent.pointerId
		}) : new MouseEvent("mousemove", {
			clientX: rootPointerEvent.clientX,
			clientY: rootPointerEvent.clientY
		}));
	}
	/**
	* Updates the state of interactive objects if at least {@link interactionFrequency}
	* milliseconds have passed since the last invocation.
	*
	* Invoked by a throttled ticker update from {@link Ticker.system}.
	* @param ticker - The throttled ticker.
	*/
	_tickerUpdate(ticker) {
		this._deltaTime += ticker.deltaTime;
		if (this._deltaTime < this.interactionFrequency) return;
		this._deltaTime = 0;
		this._update();
	}
	/** Destroys the event ticker. */
	destroy() {
		this.removeTickerListener();
		this.events = null;
		this.domElement = null;
		this._deltaTime = 0;
		this._didMove = false;
		this._tickerAdded = false;
		this._pauseUpdate = true;
	}
};
var EventsTicker = new EventsTickerClass();
//#endregion
//#region node_modules/pixi.js/lib/events/FederatedMouseEvent.mjs
var FederatedMouseEvent = class extends FederatedEvent {
	constructor() {
		super(...arguments);
		/** The coordinates of the mouse event relative to the canvas. */
		this.client = new Point();
		/** The movement in this pointer relative to the last `mousemove` event. */
		this.movement = new Point();
		/** The offset of the pointer coordinates w.r.t. target Container in world space. This is not supported at the moment. */
		this.offset = new Point();
		/** The pointer coordinates in world space. */
		this.global = new Point();
		/**
		* The pointer coordinates in the renderer's {@link AbstractRenderer.screen screen}. This has slightly
		* different semantics than native PointerEvent screenX/screenY.
		*/
		this.screen = new Point();
	}
	/** @readonly */
	get clientX() {
		return this.client.x;
	}
	/** @readonly */
	get clientY() {
		return this.client.y;
	}
	/**
	* Alias for {@link FederatedMouseEvent.clientX this.clientX}.
	* @readonly
	*/
	get x() {
		return this.clientX;
	}
	/**
	* Alias for {@link FederatedMouseEvent.clientY this.clientY}.
	* @readonly
	*/
	get y() {
		return this.clientY;
	}
	/** @readonly */
	get movementX() {
		return this.movement.x;
	}
	/** @readonly */
	get movementY() {
		return this.movement.y;
	}
	/** @readonly */
	get offsetX() {
		return this.offset.x;
	}
	/** @readonly */
	get offsetY() {
		return this.offset.y;
	}
	/** @readonly */
	get globalX() {
		return this.global.x;
	}
	/** @readonly */
	get globalY() {
		return this.global.y;
	}
	/**
	* The pointer coordinates in the renderer's screen. Alias for `screen.x`.
	* @readonly
	*/
	get screenX() {
		return this.screen.x;
	}
	/**
	* The pointer coordinates in the renderer's screen. Alias for `screen.y`.
	* @readonly
	*/
	get screenY() {
		return this.screen.y;
	}
	/**
	* Converts global coordinates into container-local coordinates.
	*
	* This method transforms coordinates from world space to a container's local space,
	* useful for precise positioning and hit testing.
	* @param container - The Container to get local coordinates for
	* @param point - Optional Point object to store the result. If not provided, a new Point will be created
	* @param globalPos - Optional custom global coordinates. If not provided, the event's global position is used
	* @returns The local coordinates as a Point object
	* @example
	* ```ts
	* // Basic usage - get local coordinates relative to a container
	* sprite.on('pointermove', (event: FederatedMouseEvent) => {
	*     // Get position relative to the sprite
	*     const localPos = event.getLocalPosition(sprite);
	*     console.log('Local position:', localPos.x, localPos.y);
	* });
	* // Using custom global coordinates
	* const customGlobal = new Point(100, 100);
	* sprite.on('pointermove', (event: FederatedMouseEvent) => {
	*     // Transform custom coordinates
	*     const localPos = event.getLocalPosition(sprite, undefined, customGlobal);
	*     console.log('Custom local position:', localPos.x, localPos.y);
	* });
	* ```
	* @see {@link Container.worldTransform} For the transformation matrix
	* @see {@link Point} For the point class used to store coordinates
	*/
	getLocalPosition(container, point, globalPos) {
		return container.worldTransform.applyInverse(globalPos || this.global, point);
	}
	/**
	* Whether the modifier key was pressed when this event natively occurred.
	* @param key - The modifier key.
	*/
	getModifierState(key) {
		return "getModifierState" in this.nativeEvent && this.nativeEvent.getModifierState(key);
	}
	/**
	* Not supported.
	* @param _typeArg
	* @param _canBubbleArg
	* @param _cancelableArg
	* @param _viewArg
	* @param _detailArg
	* @param _screenXArg
	* @param _screenYArg
	* @param _clientXArg
	* @param _clientYArg
	* @param _ctrlKeyArg
	* @param _altKeyArg
	* @param _shiftKeyArg
	* @param _metaKeyArg
	* @param _buttonArg
	* @param _relatedTargetArg
	* @deprecated since 7.0.0
	* @ignore
	*/
	initMouseEvent(_typeArg, _canBubbleArg, _cancelableArg, _viewArg, _detailArg, _screenXArg, _screenYArg, _clientXArg, _clientYArg, _ctrlKeyArg, _altKeyArg, _shiftKeyArg, _metaKeyArg, _buttonArg, _relatedTargetArg) {
		throw new Error("Method not implemented.");
	}
};
//#endregion
//#region node_modules/pixi.js/lib/events/FederatedPointerEvent.mjs
var FederatedPointerEvent = class extends FederatedMouseEvent {
	constructor() {
		super(...arguments);
		/**
		* The width of the pointer's contact along the x-axis, measured in CSS pixels.
		* radiusX of TouchEvents will be represented by this value.
		* @see https://developer.mozilla.org/en-US/docs/Web/API/PointerEvent/width
		*/
		this.width = 0;
		/**
		* The height of the pointer's contact along the y-axis, measured in CSS pixels.
		* radiusY of TouchEvents will be represented by this value.
		* @see https://developer.mozilla.org/en-US/docs/Web/API/PointerEvent/height
		*/
		this.height = 0;
		/**
		* Indicates whether or not the pointer device that created the event is the primary pointer.
		* @see https://developer.mozilla.org/en-US/docs/Web/API/PointerEvent/isPrimary
		*/
		this.isPrimary = false;
		/**
		* A unique identifier for the pointing device generating the event, that persists across events.
		* @see https://developer.mozilla.org/en-US/docs/Web/API/PointerEvent/persistentDeviceId
		*/
		this.persistentDeviceId = 0;
	}
	/**
	* Only included for completeness for now
	* @ignore
	*/
	getCoalescedEvents() {
		if (this.type === "pointermove" || this.type === "mousemove" || this.type === "touchmove") return [this];
		return [];
	}
	/**
	* Only included for completeness for now
	* @ignore
	*/
	getPredictedEvents() {
		throw new Error("getPredictedEvents is not supported!");
	}
};
//#endregion
//#region node_modules/pixi.js/lib/events/FederatedWheelEvent.mjs
var FederatedWheelEvent = class extends FederatedMouseEvent {
	constructor() {
		super(...arguments);
		/**
		* Units specified in pixels.
		* @ignore
		*/
		this.DOM_DELTA_PIXEL = 0;
		/**
		* Units specified in lines.
		* @ignore
		*/
		this.DOM_DELTA_LINE = 1;
		/**
		* Units specified in pages.
		* @ignore
		*/
		this.DOM_DELTA_PAGE = 2;
	}
};
/**
* Units specified in pixels.
* @ignore
*/
FederatedWheelEvent.DOM_DELTA_PIXEL = 0;
/**
* Units specified in lines.
* @ignore
*/
FederatedWheelEvent.DOM_DELTA_LINE = 1;
/**
* Units specified in pages.
* @ignore
*/
FederatedWheelEvent.DOM_DELTA_PAGE = 2;
//#endregion
//#region node_modules/pixi.js/lib/events/EventBoundary.mjs
var PROPAGATION_LIMIT = 2048;
var tempHitLocation = new Point();
var tempLocalMapping = new Point();
var EventBoundary = class {
	/**
	* @param rootTarget - The holder of the event boundary.
	*/
	constructor(rootTarget) {
		/**
		* Emits events after they were dispatched into the scene graph.
		*
		* This can be used for global events listening, regardless of the scene graph being used. It should
		* not be used by interactive libraries for normal use.
		*
		* Special events that do not bubble all the way to the root target are not emitted from here,
		* e.g. pointerenter, pointerleave, click.
		*/
		this.dispatch = new eventemitter3_default();
		/**
		* This flag would emit `pointermove`, `touchmove`, and `mousemove` events on all Containers.
		*
		* The `moveOnAll` semantics mirror those of earlier versions of PixiJS. This was disabled in favor of
		* the Pointer Event API's approach.
		*/
		this.moveOnAll = false;
		/** Enables the global move events. `globalpointermove`, `globaltouchmove`, and `globalmousemove` */
		this.enableGlobalMoveEvents = true;
		/**
		* State object for mapping methods.
		* @see EventBoundary#trackingData
		*/
		this.mappingState = { trackingData: {} };
		/**
		* The event pool maps event constructors to an free pool of instances of those specific events.
		* @see EventBoundary#allocateEvent
		* @see EventBoundary#freeEvent
		*/
		this.eventPool = /* @__PURE__ */ new Map();
		/** Every interactive element gathered from the scene. Only used in `pointermove` */
		this._allInteractiveElements = [];
		/** Every element that passed the hit test. Only used in `pointermove` */
		this._hitElements = [];
		/** Whether or not to collect all the interactive elements from the scene. Enabled in `pointermove` */
		this._isPointerMoveEvent = false;
		this.rootTarget = rootTarget;
		this.hitPruneFn = this.hitPruneFn.bind(this);
		this.hitTestFn = this.hitTestFn.bind(this);
		this.mapPointerDown = this.mapPointerDown.bind(this);
		this.mapPointerMove = this.mapPointerMove.bind(this);
		this.mapPointerOut = this.mapPointerOut.bind(this);
		this.mapPointerOver = this.mapPointerOver.bind(this);
		this.mapPointerUp = this.mapPointerUp.bind(this);
		this.mapPointerUpOutside = this.mapPointerUpOutside.bind(this);
		this.mapWheel = this.mapWheel.bind(this);
		this.mapContextMenu = this.mapContextMenu.bind(this);
		this.mappingTable = {};
		this.addEventMapping("pointerdown", this.mapPointerDown);
		this.addEventMapping("pointermove", this.mapPointerMove);
		this.addEventMapping("pointerout", this.mapPointerOut);
		this.addEventMapping("pointerleave", this.mapPointerOut);
		this.addEventMapping("pointerover", this.mapPointerOver);
		this.addEventMapping("pointerup", this.mapPointerUp);
		this.addEventMapping("pointerupoutside", this.mapPointerUpOutside);
		this.addEventMapping("wheel", this.mapWheel);
		this.addEventMapping("contextmenu", this.mapContextMenu);
	}
	/**
	* Adds an event mapping for the event `type` handled by `fn`.
	*
	* Event mappings can be used to implement additional or custom events. They take an event
	* coming from the upstream scene (or directly from the {@link EventSystem}) and dispatch new downstream events
	* generally trickling down and bubbling up to {@link EventBoundary.rootTarget this.rootTarget}.
	*
	* To modify the semantics of existing events, the built-in mapping methods of EventBoundary should be overridden
	* instead.
	* @param type - The type of upstream event to map.
	* @param fn - The mapping method. The context of this function must be bound manually, if desired.
	*/
	addEventMapping(type, fn) {
		if (!this.mappingTable[type]) this.mappingTable[type] = [];
		this.mappingTable[type].push({
			fn,
			priority: 0
		});
		this.mappingTable[type].sort((a, b) => a.priority - b.priority);
	}
	/**
	* Dispatches the given event
	* @param e - The event to dispatch.
	* @param type - The type of event to dispatch. Defaults to `e.type`.
	*/
	dispatchEvent(e, type) {
		e.propagationStopped = false;
		e.propagationImmediatelyStopped = false;
		this.propagate(e, type);
		this.dispatch.emit(type || e.type, e);
	}
	/**
	* Maps the given upstream event through the event boundary and propagates it downstream.
	* @param e - The event to map.
	*/
	mapEvent(e) {
		if (!this.rootTarget) return;
		const mappers = this.mappingTable[e.type];
		if (mappers) for (let i = 0, j = mappers.length; i < j; i++) mappers[i].fn(e);
		else warn(`[EventBoundary]: Event mapping not defined for ${e.type}`);
	}
	/**
	* Finds the Container that is the target of a event at the given coordinates.
	*
	* The passed (x,y) coordinates are in the world space above this event boundary.
	* @param x - The x coordinate of the event.
	* @param y - The y coordinate of the event.
	*/
	hitTest(x, y) {
		EventsTicker.pauseUpdate = true;
		const fn = this._isPointerMoveEvent && this.enableGlobalMoveEvents ? "hitTestMoveRecursive" : "hitTestRecursive";
		const invertedPath = this[fn](this.rootTarget, this.rootTarget.eventMode, tempHitLocation.set(x, y), this.hitTestFn, this.hitPruneFn);
		return invertedPath && invertedPath[0];
	}
	/**
	* Propagate the passed event from from {@link EventBoundary.rootTarget this.rootTarget} to its
	* target `e.target`.
	* @param e - The event to propagate.
	* @param type - The type of event to propagate. Defaults to `e.type`.
	*/
	propagate(e, type) {
		if (!e.target) return;
		const composedPath = e.composedPath();
		e.eventPhase = e.CAPTURING_PHASE;
		for (let i = 0, j = composedPath.length - 1; i < j; i++) {
			e.currentTarget = composedPath[i];
			this.notifyTarget(e, type);
			if (e.propagationStopped || e.propagationImmediatelyStopped) return;
		}
		e.eventPhase = e.AT_TARGET;
		e.currentTarget = e.target;
		this.notifyTarget(e, type);
		if (e.propagationStopped || e.propagationImmediatelyStopped) return;
		e.eventPhase = e.BUBBLING_PHASE;
		for (let i = composedPath.length - 2; i >= 0; i--) {
			e.currentTarget = composedPath[i];
			this.notifyTarget(e, type);
			if (e.propagationStopped || e.propagationImmediatelyStopped) return;
		}
	}
	/**
	* Emits the event `e` to all interactive containers. The event is propagated in the bubbling phase always.
	*
	* This is used in the `globalpointermove` event.
	* @param e - The emitted event.
	* @param type - The listeners to notify.
	* @param targets - The targets to notify.
	*/
	all(e, type, targets = this._allInteractiveElements) {
		if (targets.length === 0) return;
		e.eventPhase = e.BUBBLING_PHASE;
		const events = Array.isArray(type) ? type : [type];
		for (let i = targets.length - 1; i >= 0; i--) events.forEach((event) => {
			e.currentTarget = targets[i];
			this.notifyTarget(e, event);
		});
	}
	/**
	* Finds the propagation path from {@link EventBoundary.rootTarget rootTarget} to the passed
	* `target`. The last element in the path is `target`.
	* @param target - The target to find the propagation path to.
	*/
	propagationPath(target) {
		const propagationPath = [target];
		for (let i = 0; i < PROPAGATION_LIMIT && target !== this.rootTarget && target.parent; i++) {
			if (!target.parent) throw new Error("Cannot find propagation path to disconnected target");
			propagationPath.push(target.parent);
			target = target.parent;
		}
		propagationPath.reverse();
		return propagationPath;
	}
	hitTestMoveRecursive(currentTarget, eventMode, location, testFn, pruneFn, ignore = false) {
		let shouldReturn = false;
		if (this._interactivePrune(currentTarget)) return null;
		if (currentTarget.eventMode === "dynamic" || eventMode === "dynamic") EventsTicker.pauseUpdate = false;
		if (currentTarget.interactiveChildren && currentTarget.children) {
			const children = currentTarget.children;
			for (let i = children.length - 1; i >= 0; i--) {
				const child = children[i];
				const nestedHit = this.hitTestMoveRecursive(child, this._isInteractive(eventMode) ? eventMode : child.eventMode, location, testFn, pruneFn, ignore || pruneFn(currentTarget, location));
				if (nestedHit) {
					if (nestedHit.length > 0 && !nestedHit[nestedHit.length - 1].parent) continue;
					const isInteractive = currentTarget.isInteractive();
					if (nestedHit.length > 0 || isInteractive) {
						if (isInteractive) this._allInteractiveElements.push(currentTarget);
						nestedHit.push(currentTarget);
					}
					if (this._hitElements.length === 0) this._hitElements = nestedHit;
					shouldReturn = true;
				}
			}
		}
		const isInteractiveMode = this._isInteractive(eventMode);
		const isInteractiveTarget = currentTarget.isInteractive();
		if (isInteractiveTarget && isInteractiveTarget) this._allInteractiveElements.push(currentTarget);
		if (ignore || this._hitElements.length > 0) return null;
		if (shouldReturn) return this._hitElements;
		if (isInteractiveMode && !pruneFn(currentTarget, location) && testFn(currentTarget, location)) return isInteractiveTarget ? [currentTarget] : [];
		return null;
	}
	/**
	* Recursive implementation for {@link EventBoundary.hitTest hitTest}.
	* @param currentTarget - The Container that is to be hit tested.
	* @param eventMode - The event mode for the `currentTarget` or one of its parents.
	* @param location - The location that is being tested for overlap.
	* @param testFn - Callback that determines whether the target passes hit testing. This callback
	*  can assume that `pruneFn` failed to prune the container.
	* @param pruneFn - Callback that determiness whether the target and all of its children
	*  cannot pass the hit test. It is used as a preliminary optimization to prune entire subtrees
	*  of the scene graph.
	* @returns An array holding the hit testing target and all its ancestors in order. The first element
	*  is the target itself and the last is {@link EventBoundary.rootTarget rootTarget}. This is the opposite
	*  order w.r.t. the propagation path. If no hit testing target is found, null is returned.
	*/
	hitTestRecursive(currentTarget, eventMode, location, testFn, pruneFn) {
		if (this._interactivePrune(currentTarget) || pruneFn(currentTarget, location)) return null;
		if (currentTarget.eventMode === "dynamic" || eventMode === "dynamic") EventsTicker.pauseUpdate = false;
		if (currentTarget.interactiveChildren && currentTarget.children) {
			const children = currentTarget.children;
			const relativeLocation = location;
			for (let i = children.length - 1; i >= 0; i--) {
				const child = children[i];
				const nestedHit = this.hitTestRecursive(child, this._isInteractive(eventMode) ? eventMode : child.eventMode, relativeLocation, testFn, pruneFn);
				if (nestedHit) {
					if (nestedHit.length > 0 && !nestedHit[nestedHit.length - 1].parent) continue;
					const isInteractive = currentTarget.isInteractive();
					if (nestedHit.length > 0 || isInteractive) nestedHit.push(currentTarget);
					return nestedHit;
				}
			}
		}
		const isInteractiveMode = this._isInteractive(eventMode);
		const isInteractiveTarget = currentTarget.isInteractive();
		if (isInteractiveMode && testFn(currentTarget, location)) return isInteractiveTarget ? [currentTarget] : [];
		return null;
	}
	_isInteractive(int) {
		return int === "static" || int === "dynamic";
	}
	_interactivePrune(container) {
		if (!container || !container.visible || !container.renderable || !container.measurable) return true;
		if (container.eventMode === "none") return true;
		if (container.eventMode === "passive" && !container.interactiveChildren) return true;
		return false;
	}
	/**
	* Checks whether the container or any of its children cannot pass the hit test at all.
	*
	* {@link EventBoundary}'s implementation uses the {@link Container.hitArea hitArea}
	* and {@link Container._maskEffect} for pruning.
	* @param container - The container to prune.
	* @param location - The location to test for overlap.
	*/
	hitPruneFn(container, location) {
		if (container.hitArea) {
			container.worldTransform.applyInverse(location, tempLocalMapping);
			if (!container.hitArea.contains(tempLocalMapping.x, tempLocalMapping.y)) return true;
		}
		if (container.effects && container.effects.length) for (let i = 0; i < container.effects.length; i++) {
			const effect = container.effects[i];
			if (effect.containsPoint) {
				if (!effect.containsPoint(location, this.hitTestFn)) return true;
			}
		}
		return false;
	}
	/**
	* Checks whether the container passes hit testing for the given location.
	* @param container - The container to test.
	* @param location - The location to test for overlap.
	* @returns - Whether `container` passes hit testing for `location`.
	*/
	hitTestFn(container, location) {
		if (container.hitArea) return true;
		if (container?.containsPoint) {
			container.worldTransform.applyInverse(location, tempLocalMapping);
			return container.containsPoint(tempLocalMapping);
		}
		return false;
	}
	/**
	* Notify all the listeners to the event's `currentTarget`.
	*
	* If the `currentTarget` contains the property `on<type>`, then it is called here,
	* simulating the behavior from version 6.x and prior.
	* @param e - The event passed to the target.
	* @param type - The type of event to notify. Defaults to `e.type`.
	*/
	notifyTarget(e, type) {
		if (!e.currentTarget.isInteractive()) return;
		type ?? (type = e.type);
		const handlerKey = `on${type}`;
		e.currentTarget[handlerKey]?.(e);
		const key = e.eventPhase === e.CAPTURING_PHASE || e.eventPhase === e.AT_TARGET ? `${type}capture` : type;
		this._notifyListeners(e, key);
		if (e.eventPhase === e.AT_TARGET) this._notifyListeners(e, type);
	}
	/**
	* Maps the upstream `pointerdown` events to a downstream `pointerdown` event.
	*
	* `touchstart`, `rightdown`, `mousedown` events are also dispatched for specific pointer types.
	* @param from - The upstream `pointerdown` event.
	*/
	mapPointerDown(from) {
		if (!(from instanceof FederatedPointerEvent)) {
			warn("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		const e = this.createPointerEvent(from);
		this.dispatchEvent(e, "pointerdown");
		if (e.pointerType === "touch") this.dispatchEvent(e, "touchstart");
		else if (e.pointerType === "mouse" || e.pointerType === "pen") {
			const isRightButton = e.button === 2;
			this.dispatchEvent(e, isRightButton ? "rightdown" : "mousedown");
		}
		const trackingData = this.trackingData(from.pointerId);
		trackingData.pressTargetsByButton[from.button] = e.composedPath();
		this.freeEvent(e);
	}
	/**
	* Maps the upstream `pointermove` to downstream `pointerout`, `pointerover`, and `pointermove` events, in that order.
	*
	* The tracking data for the specific pointer has an updated `overTarget`. `mouseout`, `mouseover`,
	* `mousemove`, and `touchmove` events are fired as well for specific pointer types.
	* @param from - The upstream `pointermove` event.
	*/
	mapPointerMove(from) {
		if (!(from instanceof FederatedPointerEvent)) {
			warn("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		this._allInteractiveElements.length = 0;
		this._hitElements.length = 0;
		this._isPointerMoveEvent = true;
		const e = this.createPointerEvent(from);
		this._isPointerMoveEvent = false;
		const isMouse = e.pointerType === "mouse" || e.pointerType === "pen";
		const trackingData = this.trackingData(from.pointerId);
		const outTarget = this.findMountedTarget(trackingData.overTargets);
		if (trackingData.overTargets?.length > 0 && outTarget !== e.target) {
			const outType = from.type === "mousemove" ? "mouseout" : "pointerout";
			const outEvent = this.createPointerEvent(from, outType, outTarget);
			this.dispatchEvent(outEvent, "pointerout");
			if (isMouse) this.dispatchEvent(outEvent, "mouseout");
			if (!e.composedPath().includes(outTarget)) {
				const leaveEvent = this.createPointerEvent(from, "pointerleave", outTarget);
				leaveEvent.eventPhase = leaveEvent.AT_TARGET;
				while (leaveEvent.target && !e.composedPath().includes(leaveEvent.target)) {
					leaveEvent.currentTarget = leaveEvent.target;
					this.notifyTarget(leaveEvent);
					if (isMouse) this.notifyTarget(leaveEvent, "mouseleave");
					leaveEvent.target = leaveEvent.target.parent;
				}
				this.freeEvent(leaveEvent);
			}
			this.freeEvent(outEvent);
		}
		if (outTarget !== e.target) {
			const overType = from.type === "mousemove" ? "mouseover" : "pointerover";
			const overEvent = this.clonePointerEvent(e, overType);
			this.dispatchEvent(overEvent, "pointerover");
			if (isMouse) this.dispatchEvent(overEvent, "mouseover");
			let overTargetAncestor = outTarget?.parent;
			while (overTargetAncestor && overTargetAncestor !== this.rootTarget.parent) {
				if (overTargetAncestor === e.target) break;
				overTargetAncestor = overTargetAncestor.parent;
			}
			if (!overTargetAncestor || overTargetAncestor === this.rootTarget.parent) {
				const enterEvent = this.clonePointerEvent(e, "pointerenter");
				enterEvent.eventPhase = enterEvent.AT_TARGET;
				while (enterEvent.target && enterEvent.target !== outTarget && enterEvent.target !== this.rootTarget.parent) {
					enterEvent.currentTarget = enterEvent.target;
					this.notifyTarget(enterEvent);
					if (isMouse) this.notifyTarget(enterEvent, "mouseenter");
					enterEvent.target = enterEvent.target.parent;
				}
				this.freeEvent(enterEvent);
			}
			this.freeEvent(overEvent);
		}
		const allMethods = [];
		const allowGlobalPointerEvents = this.enableGlobalMoveEvents ?? true;
		this.moveOnAll ? allMethods.push("pointermove") : this.dispatchEvent(e, "pointermove");
		allowGlobalPointerEvents && allMethods.push("globalpointermove");
		if (e.pointerType === "touch") {
			this.moveOnAll ? allMethods.splice(1, 0, "touchmove") : this.dispatchEvent(e, "touchmove");
			allowGlobalPointerEvents && allMethods.push("globaltouchmove");
		}
		if (isMouse) {
			this.moveOnAll ? allMethods.splice(1, 0, "mousemove") : this.dispatchEvent(e, "mousemove");
			allowGlobalPointerEvents && allMethods.push("globalmousemove");
			this.cursor = e.target?.cursor;
		}
		if (allMethods.length > 0) this.all(e, allMethods);
		this._allInteractiveElements.length = 0;
		this._hitElements.length = 0;
		trackingData.overTargets = e.composedPath();
		this.freeEvent(e);
	}
	/**
	* Maps the upstream `pointerover` to downstream `pointerover` and `pointerenter` events, in that order.
	*
	* The tracking data for the specific pointer gets a new `overTarget`.
	* @param from - The upstream `pointerover` event.
	*/
	mapPointerOver(from) {
		if (!(from instanceof FederatedPointerEvent)) {
			warn("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		const trackingData = this.trackingData(from.pointerId);
		const e = this.createPointerEvent(from);
		const isMouse = e.pointerType === "mouse" || e.pointerType === "pen";
		this.dispatchEvent(e, "pointerover");
		if (isMouse) this.dispatchEvent(e, "mouseover");
		if (e.pointerType === "mouse") this.cursor = e.target?.cursor;
		const enterEvent = this.clonePointerEvent(e, "pointerenter");
		enterEvent.eventPhase = enterEvent.AT_TARGET;
		while (enterEvent.target && enterEvent.target !== this.rootTarget.parent) {
			enterEvent.currentTarget = enterEvent.target;
			this.notifyTarget(enterEvent);
			if (isMouse) this.notifyTarget(enterEvent, "mouseenter");
			enterEvent.target = enterEvent.target.parent;
		}
		trackingData.overTargets = e.composedPath();
		this.freeEvent(e);
		this.freeEvent(enterEvent);
	}
	/**
	* Maps the upstream `pointerout` to downstream `pointerout`, `pointerleave` events, in that order.
	*
	* The tracking data for the specific pointer is cleared of a `overTarget`.
	* @param from - The upstream `pointerout` event.
	*/
	mapPointerOut(from) {
		if (!(from instanceof FederatedPointerEvent)) {
			warn("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		const trackingData = this.trackingData(from.pointerId);
		if (trackingData.overTargets) {
			const isMouse = from.pointerType === "mouse" || from.pointerType === "pen";
			const outTarget = this.findMountedTarget(trackingData.overTargets);
			const outEvent = this.createPointerEvent(from, "pointerout", outTarget);
			this.dispatchEvent(outEvent);
			if (isMouse) this.dispatchEvent(outEvent, "mouseout");
			const leaveEvent = this.createPointerEvent(from, "pointerleave", outTarget);
			leaveEvent.eventPhase = leaveEvent.AT_TARGET;
			while (leaveEvent.target && leaveEvent.target !== this.rootTarget.parent) {
				leaveEvent.currentTarget = leaveEvent.target;
				this.notifyTarget(leaveEvent);
				if (isMouse) this.notifyTarget(leaveEvent, "mouseleave");
				leaveEvent.target = leaveEvent.target.parent;
			}
			trackingData.overTargets = null;
			this.freeEvent(outEvent);
			this.freeEvent(leaveEvent);
		}
		this.cursor = null;
	}
	/**
	* Maps the upstream `pointerup` event to downstream `pointerup`, `pointerupoutside`,
	* and `click`/`rightclick`/`pointertap` events, in that order.
	*
	* The `pointerupoutside` event bubbles from the original `pointerdown` target to the most specific
	* ancestor of the `pointerdown` and `pointerup` targets, which is also the `click` event's target. `touchend`,
	* `rightup`, `mouseup`, `touchendoutside`, `rightupoutside`, `mouseupoutside`, and `tap` are fired as well for
	* specific pointer types.
	* @param from - The upstream `pointerup` event.
	*/
	mapPointerUp(from) {
		if (!(from instanceof FederatedPointerEvent)) {
			warn("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		const now = performance.now();
		const e = this.createPointerEvent(from);
		this.dispatchEvent(e, "pointerup");
		if (e.pointerType === "touch") this.dispatchEvent(e, "touchend");
		else if (e.pointerType === "mouse" || e.pointerType === "pen") {
			const isRightButton = e.button === 2;
			this.dispatchEvent(e, isRightButton ? "rightup" : "mouseup");
		}
		const trackingData = this.trackingData(from.pointerId);
		const pressTarget = this.findMountedTarget(trackingData.pressTargetsByButton[from.button]);
		let clickTarget = pressTarget;
		if (pressTarget && !e.composedPath().includes(pressTarget)) {
			let currentTarget = pressTarget;
			while (currentTarget && !e.composedPath().includes(currentTarget)) {
				e.currentTarget = currentTarget;
				this.notifyTarget(e, "pointerupoutside");
				if (e.pointerType === "touch") this.notifyTarget(e, "touchendoutside");
				else if (e.pointerType === "mouse" || e.pointerType === "pen") {
					const isRightButton = e.button === 2;
					this.notifyTarget(e, isRightButton ? "rightupoutside" : "mouseupoutside");
				}
				currentTarget = currentTarget.parent;
			}
			delete trackingData.pressTargetsByButton[from.button];
			clickTarget = currentTarget;
		}
		if (clickTarget) {
			const clickEvent = this.clonePointerEvent(e, "click");
			clickEvent.target = clickTarget;
			clickEvent.path = null;
			if (!trackingData.clicksByButton[from.button]) trackingData.clicksByButton[from.button] = {
				clickCount: 0,
				target: clickEvent.target,
				timeStamp: now
			};
			const clickHistory = trackingData.clicksByButton[from.button];
			if (clickHistory.target === clickEvent.target && now - clickHistory.timeStamp < 200) ++clickHistory.clickCount;
			else clickHistory.clickCount = 1;
			clickHistory.target = clickEvent.target;
			clickHistory.timeStamp = now;
			clickEvent.detail = clickHistory.clickCount;
			if (clickEvent.pointerType === "mouse") {
				const isRightButton = clickEvent.button === 2;
				this.dispatchEvent(clickEvent, isRightButton ? "rightclick" : "click");
			} else if (clickEvent.pointerType === "touch") this.dispatchEvent(clickEvent, "tap");
			this.dispatchEvent(clickEvent, "pointertap");
			this.freeEvent(clickEvent);
		}
		this.freeEvent(e);
	}
	/**
	* Maps the upstream `pointerupoutside` event to a downstream `pointerupoutside` event, bubbling from the original
	* `pointerdown` target to `rootTarget`.
	*
	* (The most specific ancestor of the `pointerdown` event and the `pointerup` event must the
	* `{@link EventBoundary}'s root because the `pointerup` event occurred outside of the boundary.)
	*
	* `touchendoutside`, `mouseupoutside`, and `rightupoutside` events are fired as well for specific pointer
	* types. The tracking data for the specific pointer is cleared of a `pressTarget`.
	* @param from - The upstream `pointerupoutside` event.
	*/
	mapPointerUpOutside(from) {
		if (!(from instanceof FederatedPointerEvent)) {
			warn("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		const trackingData = this.trackingData(from.pointerId);
		const pressTarget = this.findMountedTarget(trackingData.pressTargetsByButton[from.button]);
		const e = this.createPointerEvent(from);
		if (pressTarget) {
			let currentTarget = pressTarget;
			while (currentTarget) {
				e.currentTarget = currentTarget;
				this.notifyTarget(e, "pointerupoutside");
				if (e.pointerType === "touch") this.notifyTarget(e, "touchendoutside");
				else if (e.pointerType === "mouse" || e.pointerType === "pen") this.notifyTarget(e, e.button === 2 ? "rightupoutside" : "mouseupoutside");
				currentTarget = currentTarget.parent;
			}
			delete trackingData.pressTargetsByButton[from.button];
		}
		this.freeEvent(e);
	}
	/**
	* Maps the upstream `wheel` event to a downstream `wheel` event.
	* @param from - The upstream `wheel` event.
	*/
	mapWheel(from) {
		if (!(from instanceof FederatedWheelEvent)) {
			warn("EventBoundary cannot map a non-wheel event as a wheel event");
			return;
		}
		const wheelEvent = this.createWheelEvent(from);
		this.dispatchEvent(wheelEvent);
		this.freeEvent(wheelEvent);
	}
	/**
	* Maps the upstream `contextmenu` event to a downstream `contextmenu` event.
	* @param from - The upstream `contextmenu` event.
	*/
	mapContextMenu(from) {
		if (!(from instanceof FederatedPointerEvent)) {
			warn("EventBoundary cannot map a non-pointer event as a pointer event");
			return;
		}
		const e = this.createPointerEvent(from);
		this.dispatchEvent(e, "contextmenu");
		this.freeEvent(e);
	}
	/**
	* Finds the most specific event-target in the given propagation path that is still mounted in the scene graph.
	*
	* This is used to find the correct `pointerup` and `pointerout` target in the case that the original `pointerdown`
	* or `pointerover` target was unmounted from the scene graph.
	* @param propagationPath - The propagation path was valid in the past.
	* @returns - The most specific event-target still mounted at the same location in the scene graph.
	*/
	findMountedTarget(propagationPath) {
		if (!propagationPath) return null;
		let currentTarget = propagationPath[0];
		for (let i = 1; i < propagationPath.length; i++) if (propagationPath[i].parent === currentTarget) currentTarget = propagationPath[i];
		else break;
		return currentTarget;
	}
	/**
	* Creates an event whose `originalEvent` is `from`, with an optional `type` and `target` override.
	*
	* The event is allocated using {@link EventBoundary#allocateEvent this.allocateEvent}.
	* @param from - The `originalEvent` for the returned event.
	* @param [type=from.type] - The type of the returned event.
	* @param target - The target of the returned event.
	*/
	createPointerEvent(from, type, target) {
		const event = this.allocateEvent(FederatedPointerEvent);
		this.copyPointerData(from, event);
		this.copyMouseData(from, event);
		this.copyData(from, event);
		event.nativeEvent = from.nativeEvent;
		event.originalEvent = from;
		event.target = target ?? this.hitTest(event.global.x, event.global.y) ?? this._hitElements[0];
		if (typeof type === "string") event.type = type;
		return event;
	}
	/**
	* Creates a wheel event whose `originalEvent` is `from`.
	*
	* The event is allocated using {@link EventBoundary#allocateEvent this.allocateEvent}.
	* @param from - The upstream wheel event.
	*/
	createWheelEvent(from) {
		const event = this.allocateEvent(FederatedWheelEvent);
		this.copyWheelData(from, event);
		this.copyMouseData(from, event);
		this.copyData(from, event);
		event.nativeEvent = from.nativeEvent;
		event.originalEvent = from;
		event.target = this.hitTest(event.global.x, event.global.y);
		return event;
	}
	/**
	* Clones the event `from`, with an optional `type` override.
	*
	* The event is allocated using {@link EventBoundary#allocateEvent this.allocateEvent}.
	* @param from - The event to clone.
	* @param [type=from.type] - The type of the returned event.
	*/
	clonePointerEvent(from, type) {
		const event = this.allocateEvent(FederatedPointerEvent);
		event.nativeEvent = from.nativeEvent;
		event.originalEvent = from.originalEvent;
		this.copyPointerData(from, event);
		this.copyMouseData(from, event);
		this.copyData(from, event);
		event.target = from.target;
		event.path = from.composedPath().slice();
		event.type = type ?? event.type;
		return event;
	}
	/**
	* Copies wheel {@link FederatedWheelEvent} data from `from` into `to`.
	*
	* The following properties are copied:
	* + deltaMode
	* + deltaX
	* + deltaY
	* + deltaZ
	* @param from - The event to copy data from.
	* @param to - The event to copy data into.
	*/
	copyWheelData(from, to) {
		to.deltaMode = from.deltaMode;
		to.deltaX = from.deltaX;
		to.deltaY = from.deltaY;
		to.deltaZ = from.deltaZ;
	}
	/**
	* Copies pointer {@link FederatedPointerEvent} data from `from` into `to`.
	*
	* The following properties are copied:
	* + pointerId
	* + width
	* + height
	* + isPrimary
	* + pointerType
	* + pressure
	* + tangentialPressure
	* + tiltX
	* + tiltY
	* @param from - The event to copy data from.
	* @param to - The event to copy data into.
	*/
	copyPointerData(from, to) {
		if (!(from instanceof FederatedPointerEvent && to instanceof FederatedPointerEvent)) return;
		to.pointerId = from.pointerId;
		to.width = from.width;
		to.height = from.height;
		to.isPrimary = from.isPrimary;
		to.pointerType = from.pointerType;
		to.pressure = from.pressure;
		to.tangentialPressure = from.tangentialPressure;
		to.tiltX = from.tiltX;
		to.tiltY = from.tiltY;
		to.twist = from.twist;
		to.persistentDeviceId = from.persistentDeviceId;
	}
	/**
	* Copies mouse {@link FederatedMouseEvent} data from `from` to `to`.
	*
	* The following properties are copied:
	* + altKey
	* + button
	* + buttons
	* + clientX
	* + clientY
	* + metaKey
	* + movementX
	* + movementY
	* + pageX
	* + pageY
	* + x
	* + y
	* + screen
	* + shiftKey
	* + global
	* @param from - The event to copy data from.
	* @param to - The event to copy data into.
	*/
	copyMouseData(from, to) {
		if (!(from instanceof FederatedMouseEvent && to instanceof FederatedMouseEvent)) return;
		to.altKey = from.altKey;
		to.button = from.button;
		to.buttons = from.buttons;
		to.client.copyFrom(from.client);
		to.ctrlKey = from.ctrlKey;
		to.metaKey = from.metaKey;
		to.movement.copyFrom(from.movement);
		to.screen.copyFrom(from.screen);
		to.shiftKey = from.shiftKey;
		to.global.copyFrom(from.global);
	}
	/**
	* Copies base {@link FederatedEvent} data from `from` into `to`.
	*
	* The following properties are copied:
	* + isTrusted
	* + srcElement
	* + timeStamp
	* + type
	* @param from - The event to copy data from.
	* @param to - The event to copy data into.
	*/
	copyData(from, to) {
		to.isTrusted = from.isTrusted;
		to.srcElement = from.srcElement;
		to.timeStamp = performance.now();
		to.type = from.type;
		to.detail = from.detail;
		to.view = from.view;
		to.which = from.which;
		to.layer.copyFrom(from.layer);
		to.page.copyFrom(from.page);
	}
	/**
	* @param id - The pointer ID.
	* @returns The tracking data stored for the given pointer. If no data exists, a blank
	*  state will be created.
	*/
	trackingData(id) {
		if (!this.mappingState.trackingData[id]) this.mappingState.trackingData[id] = {
			pressTargetsByButton: {},
			clicksByButton: {},
			overTarget: null
		};
		return this.mappingState.trackingData[id];
	}
	/**
	* Allocate a specific type of event from {@link EventBoundary#eventPool this.eventPool}.
	*
	* This allocation is constructor-agnostic, as long as it only takes one argument - this event
	* boundary.
	* @param constructor - The event's constructor.
	* @returns An event of the given type.
	*/
	allocateEvent(constructor) {
		if (!this.eventPool.has(constructor)) this.eventPool.set(constructor, []);
		const event = this.eventPool.get(constructor).pop() || new constructor(this);
		event.eventPhase = event.NONE;
		event.currentTarget = null;
		event.defaultPrevented = false;
		event.path = null;
		event.target = null;
		return event;
	}
	/**
	* Frees the event and puts it back into the event pool.
	*
	* It is illegal to reuse the event until it is allocated again, using `this.allocateEvent`.
	*
	* It is also advised that events not allocated from {@link EventBoundary#allocateEvent this.allocateEvent}
	* not be freed. This is because of the possibility that the same event is freed twice, which can cause
	* it to be allocated twice & result in overwriting.
	* @param event - The event to be freed.
	* @throws Error if the event is managed by another event boundary.
	*/
	freeEvent(event) {
		if (event.manager !== this) throw new Error("It is illegal to free an event not managed by this EventBoundary!");
		const constructor = event.constructor;
		if (!this.eventPool.has(constructor)) this.eventPool.set(constructor, []);
		this.eventPool.get(constructor).push(event);
	}
	/**
	* Similar to {@link EventEmitter.emit}, except it stops if the `propagationImmediatelyStopped` flag
	* is set on the event.
	* @param e - The event to call each listener with.
	* @param type - The event key.
	*/
	_notifyListeners(e, type) {
		const listeners = e.currentTarget._events[type];
		if (!listeners) return;
		if ("fn" in listeners) {
			if (listeners.once) e.currentTarget.removeListener(type, listeners.fn, void 0, true);
			listeners.fn.call(listeners.context, e);
		} else for (let i = 0, j = listeners.length; i < j && !e.propagationImmediatelyStopped; i++) {
			if (listeners[i].once) e.currentTarget.removeListener(type, listeners[i].fn, void 0, true);
			listeners[i].fn.call(listeners[i].context, e);
		}
	}
};
//#endregion
//#region node_modules/pixi.js/lib/events/EventSystem.mjs
var MOUSE_POINTER_ID = 1;
var TOUCH_TO_POINTER = {
	touchstart: "pointerdown",
	touchend: "pointerup",
	touchendoutside: "pointerupoutside",
	touchmove: "pointermove",
	touchcancel: "pointercancel"
};
var _EventSystem = class _EventSystem {
	/**
	* @param {Renderer} renderer
	*/
	constructor(renderer) {
		/**
		* Indicates whether the current device supports touch events according to the W3C Touch Events spec.
		* This is used to determine the appropriate event handling strategy.
		* @see {@link https://www.w3.org/TR/touch-events/} W3C Touch Events Specification
		* @readonly
		* @default 'ontouchstart' in globalThis
		*/
		this.supportsTouchEvents = "ontouchstart" in globalThis;
		/**
		* Indicates whether the current device supports pointer events according to the W3C Pointer Events spec.
		* Used to optimize event handling and provide more consistent cross-device interaction.
		* @see {@link https://www.w3.org/TR/pointerevents/} W3C Pointer Events Specification
		* @readonly
		* @default !!globalThis.PointerEvent
		*/
		this.supportsPointerEvents = !!globalThis.PointerEvent;
		/**
		* The DOM element to which the root event listeners are bound. This is automatically set to
		* the renderer's {@link AbstractRenderer#canvas canvas}.
		*/
		this.domElement = null;
		/** The resolution used to convert between the DOM client space into world space. */
		this.resolution = 1;
		this.renderer = renderer;
		this.rootBoundary = new EventBoundary(null);
		EventsTicker.init(this);
		this.autoPreventDefault = true;
		this._eventsAdded = false;
		this._rootPointerEvent = new FederatedPointerEvent(null);
		this._rootWheelEvent = new FederatedWheelEvent(null);
		this._rootContextMenuEvent = new FederatedPointerEvent(null);
		this.cursorStyles = {
			default: "inherit",
			pointer: "pointer"
		};
		this.features = new Proxy({ ..._EventSystem.defaultEventFeatures }, { set: (target, key, value) => {
			if (key === "globalMove") this.rootBoundary.enableGlobalMoveEvents = value;
			target[key] = value;
			return true;
		} });
		this._onPointerDown = this._onPointerDown.bind(this);
		this._onPointerMove = this._onPointerMove.bind(this);
		this._onPointerUp = this._onPointerUp.bind(this);
		this._onPointerOverOut = this._onPointerOverOut.bind(this);
		this._onContextMenu = this._onContextMenu.bind(this);
		this.onWheel = this.onWheel.bind(this);
	}
	/**
	* The default interaction mode for all display objects.
	* @see Container.eventMode
	* @type {EventMode}
	* @readonly
	* @since 7.2.0
	*/
	static get defaultEventMode() {
		return this._defaultEventMode;
	}
	/**
	* Runner init called, view is available at this point.
	* @ignore
	*/
	init(options) {
		const { canvas, resolution } = this.renderer;
		this.setTargetElement(canvas);
		this.resolution = resolution;
		_EventSystem._defaultEventMode = options.eventMode ?? "passive";
		Object.assign(this.features, options.eventFeatures ?? {});
		this.rootBoundary.enableGlobalMoveEvents = this.features.globalMove;
	}
	/**
	* Handle changing resolution.
	* @ignore
	*/
	resolutionChange(resolution) {
		this.resolution = resolution;
	}
	/** Destroys all event listeners and detaches the renderer. */
	destroy() {
		EventsTicker.destroy();
		this.setTargetElement(null);
		this.renderer = null;
		this._currentCursor = null;
	}
	/**
	* Sets the current cursor mode, handling any callbacks or CSS style changes.
	* The cursor can be a CSS cursor string, a custom callback function, or a key from the cursorStyles dictionary.
	* @param mode - Cursor mode to set. Can be:
	* - A CSS cursor string (e.g., 'pointer', 'grab')
	* - A key from the cursorStyles dictionary
	* - null/undefined to reset to default
	* @example
	* ```ts
	* // Using predefined cursor styles
	* app.renderer.events.setCursor('pointer');    // Set standard pointer cursor
	* app.renderer.events.setCursor('grab');       // Set grab cursor
	* app.renderer.events.setCursor(null);         // Reset to default
	*
	* // Using custom cursor styles
	* app.renderer.events.cursorStyles.custom = 'url("cursor.png"), auto';
	* app.renderer.events.setCursor('custom');     // Apply custom cursor
	*
	* // Using callback-based cursor
	* app.renderer.events.cursorStyles.dynamic = (mode) => {
	*     document.body.style.cursor = mode === 'hover' ? 'pointer' : 'default';
	* };
	* app.renderer.events.setCursor('dynamic');    // Trigger cursor callback
	* ```
	* @remarks
	* - Has no effect on OffscreenCanvas except for callback-based cursors
	* - Caches current cursor to avoid unnecessary DOM updates
	* - Supports CSS cursor values, style objects, and callback functions
	* @see {@link EventSystem.cursorStyles} For defining custom cursor styles
	* @see {@link https://developer.mozilla.org/en-US/docs/Web/CSS/cursor} MDN Cursor Reference
	*/
	setCursor(mode) {
		mode || (mode = "default");
		let applyStyles = true;
		if (globalThis.OffscreenCanvas && this.domElement instanceof OffscreenCanvas) applyStyles = false;
		if (this._currentCursor === mode) return;
		this._currentCursor = mode;
		const style = this.cursorStyles[mode];
		if (style) switch (typeof style) {
			case "string":
				if (applyStyles) this.domElement.style.cursor = style;
				break;
			case "function":
				style(mode);
				break;
			case "object": if (applyStyles) Object.assign(this.domElement.style, style);
		}
		else if (applyStyles && typeof mode === "string" && !Object.prototype.hasOwnProperty.call(this.cursorStyles, mode)) this.domElement.style.cursor = mode;
	}
	/**
	* The global pointer event instance containing the most recent pointer state.
	* This is useful for accessing pointer information without listening to events.
	* @example
	* ```ts
	* // Access current pointer position at any time
	* const eventSystem = app.renderer.events;
	* const pointer = eventSystem.pointer;
	*
	* // Get global coordinates
	* console.log('Position:', pointer.global.x, pointer.global.y);
	*
	* // Check button state
	* console.log('Buttons pressed:', pointer.buttons);
	*
	* // Get pointer type and pressure
	* console.log('Type:', pointer.pointerType);
	* console.log('Pressure:', pointer.pressure);
	* ```
	* @readonly
	* @since 7.2.0
	* @see {@link FederatedPointerEvent} For all available pointer properties
	*/
	get pointer() {
		return this._rootPointerEvent;
	}
	/**
	* Event handler for pointer down events on {@link EventSystem#domElement this.domElement}.
	* @param nativeEvent - The native mouse/pointer/touch event.
	*/
	_onPointerDown(nativeEvent) {
		if (!this.features.click) return;
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
		const events = this._normalizeToPointerData(nativeEvent);
		if (this.autoPreventDefault && events[0].isNormalized) {
			if (nativeEvent.cancelable || !("cancelable" in nativeEvent)) nativeEvent.preventDefault();
		}
		for (let i = 0, j = events.length; i < j; i++) {
			const nativeEvent2 = events[i];
			const federatedEvent = this._bootstrapEvent(this._rootPointerEvent, nativeEvent2);
			this.rootBoundary.mapEvent(federatedEvent);
		}
		this.setCursor(this.rootBoundary.cursor);
	}
	/**
	* Event handler for pointer move events on on {@link EventSystem#domElement this.domElement}.
	* @param nativeEvent - The native mouse/pointer/touch events.
	*/
	_onPointerMove(nativeEvent) {
		if (!this.features.move) return;
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
		EventsTicker.pointerMoved();
		const normalizedEvents = this._normalizeToPointerData(nativeEvent);
		for (let i = 0, j = normalizedEvents.length; i < j; i++) {
			const event = this._bootstrapEvent(this._rootPointerEvent, normalizedEvents[i]);
			this.rootBoundary.mapEvent(event);
		}
		this.setCursor(this.rootBoundary.cursor);
	}
	/**
	* Event handler for pointer up events on {@link EventSystem#domElement this.domElement}.
	* @param nativeEvent - The native mouse/pointer/touch event.
	*/
	_onPointerUp(nativeEvent) {
		if (!this.features.click) return;
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
		let target = nativeEvent.target;
		if (nativeEvent.composedPath && nativeEvent.composedPath().length > 0) target = nativeEvent.composedPath()[0];
		const outside = target !== this.domElement ? "outside" : "";
		const normalizedEvents = this._normalizeToPointerData(nativeEvent);
		for (let i = 0, j = normalizedEvents.length; i < j; i++) {
			const event = this._bootstrapEvent(this._rootPointerEvent, normalizedEvents[i]);
			event.type += outside;
			this.rootBoundary.mapEvent(event);
		}
		this.setCursor(this.rootBoundary.cursor);
	}
	/**
	* Event handler for pointer over & out events on {@link EventSystem#domElement this.domElement}.
	* @param nativeEvent - The native mouse/pointer/touch event.
	*/
	_onPointerOverOut(nativeEvent) {
		if (!this.features.click) return;
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
		const normalizedEvents = this._normalizeToPointerData(nativeEvent);
		for (let i = 0, j = normalizedEvents.length; i < j; i++) {
			const event = this._bootstrapEvent(this._rootPointerEvent, normalizedEvents[i]);
			this.rootBoundary.mapEvent(event);
		}
		this.setCursor(this.rootBoundary.cursor);
	}
	/**
	* Event handler for `contextmenu` events on {@link EventSystem#domElement this.domElement}.
	*
	* {@link EventSystem#autoPreventDefault autoPreventDefault} does not apply, so the browser menu
	* opens unless a listener calls `preventDefault()`.
	* @param nativeEvent - The native mouse/pointer event.
	*/
	_onContextMenu(nativeEvent) {
		if (!this.features.click) return;
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
		const normalizedEvents = this._normalizeToPointerData(nativeEvent);
		for (let i = 0, j = normalizedEvents.length; i < j; i++) {
			const event = this._bootstrapEvent(this._rootContextMenuEvent, normalizedEvents[i]);
			this.rootBoundary.mapEvent(event);
		}
		this.setCursor(this.rootBoundary.cursor);
	}
	/**
	* Passive handler for `wheel` events on {@link EventSystem.domElement this.domElement}.
	* @param nativeEvent - The native wheel event.
	*/
	onWheel(nativeEvent) {
		if (!this.features.wheel) return;
		const wheelEvent = this.normalizeWheelEvent(nativeEvent);
		this.rootBoundary.rootTarget = this.renderer.lastObjectRendered;
		this.rootBoundary.mapEvent(wheelEvent);
	}
	/**
	* Sets the {@link EventSystem#domElement domElement} and binds event listeners.
	* This method manages the DOM event bindings for the event system, allowing you to
	* change or remove the target element that receives input events.
	* > [!IMPORTANT] This will default to the canvas element of the renderer, so you
	* > should not need to call this unless you are using a custom element.
	* @param element - The new DOM element to bind events to, or null to remove all event bindings
	* @example
	* ```ts
	* // Set a new canvas element as the target
	* const canvas = document.createElement('canvas');
	* app.renderer.events.setTargetElement(canvas);
	*
	* // Remove all event bindings
	* app.renderer.events.setTargetElement(null);
	*
	* // Switch to a different canvas
	* const newCanvas = document.querySelector('#game-canvas');
	* app.renderer.events.setTargetElement(newCanvas);
	* ```
	* @remarks
	* - Automatically removes event listeners from previous element
	* - Required for the event system to function
	* - Safe to call multiple times
	* @see {@link EventSystem#domElement} The current DOM element
	* @see {@link EventsTicker} For the ticker system that tracks pointer movement
	*/
	setTargetElement(element) {
		this._removeEvents();
		this.domElement = element;
		EventsTicker.domElement = element;
		this._addEvents();
	}
	/** Register event listeners on {@link Renderer#domElement this.domElement}. */
	_addEvents() {
		if (this._eventsAdded || !this.domElement) return;
		EventsTicker.addTickerListener();
		const style = this.domElement.style;
		if (style) {
			if (globalThis.navigator.msPointerEnabled) {
				style.msContentZooming = "none";
				style.msTouchAction = "none";
			} else if (this.supportsPointerEvents) style.touchAction = "none";
		}
		if (this.supportsPointerEvents) {
			globalThis.document.addEventListener("pointermove", this._onPointerMove, true);
			this.domElement.addEventListener("pointerdown", this._onPointerDown, true);
			this.domElement.addEventListener("pointerleave", this._onPointerOverOut, true);
			this.domElement.addEventListener("pointerover", this._onPointerOverOut, true);
			globalThis.addEventListener("pointerup", this._onPointerUp, true);
		} else {
			globalThis.document.addEventListener("mousemove", this._onPointerMove, true);
			this.domElement.addEventListener("mousedown", this._onPointerDown, true);
			this.domElement.addEventListener("mouseout", this._onPointerOverOut, true);
			this.domElement.addEventListener("mouseover", this._onPointerOverOut, true);
			globalThis.addEventListener("mouseup", this._onPointerUp, true);
			if (this.supportsTouchEvents) {
				this.domElement.addEventListener("touchstart", this._onPointerDown, true);
				this.domElement.addEventListener("touchend", this._onPointerUp, true);
				this.domElement.addEventListener("touchmove", this._onPointerMove, true);
			}
		}
		this.domElement.addEventListener("wheel", this.onWheel, {
			passive: true,
			capture: true
		});
		this.domElement.addEventListener("contextmenu", this._onContextMenu, true);
		this._eventsAdded = true;
	}
	/** Unregister event listeners on {@link EventSystem#domElement this.domElement}. */
	_removeEvents() {
		if (!this._eventsAdded || !this.domElement) return;
		EventsTicker.removeTickerListener();
		const style = this.domElement.style;
		if (style) {
			if (globalThis.navigator.msPointerEnabled) {
				style.msContentZooming = "";
				style.msTouchAction = "";
			} else if (this.supportsPointerEvents) style.touchAction = "";
		}
		if (this.supportsPointerEvents) {
			globalThis.document.removeEventListener("pointermove", this._onPointerMove, true);
			this.domElement.removeEventListener("pointerdown", this._onPointerDown, true);
			this.domElement.removeEventListener("pointerleave", this._onPointerOverOut, true);
			this.domElement.removeEventListener("pointerover", this._onPointerOverOut, true);
			globalThis.removeEventListener("pointerup", this._onPointerUp, true);
		} else {
			globalThis.document.removeEventListener("mousemove", this._onPointerMove, true);
			this.domElement.removeEventListener("mousedown", this._onPointerDown, true);
			this.domElement.removeEventListener("mouseout", this._onPointerOverOut, true);
			this.domElement.removeEventListener("mouseover", this._onPointerOverOut, true);
			globalThis.removeEventListener("mouseup", this._onPointerUp, true);
			if (this.supportsTouchEvents) {
				this.domElement.removeEventListener("touchstart", this._onPointerDown, true);
				this.domElement.removeEventListener("touchend", this._onPointerUp, true);
				this.domElement.removeEventListener("touchmove", this._onPointerMove, true);
			}
		}
		this.domElement.removeEventListener("wheel", this.onWheel, true);
		this.domElement.removeEventListener("contextmenu", this._onContextMenu, true);
		this.domElement = null;
		this._eventsAdded = false;
	}
	/**
	* Maps coordinates from DOM/screen space into PixiJS normalized coordinates.
	* This takes into account the current scale, position, and resolution of the DOM element.
	* @param point - The point to store the mapped coordinates in
	* @param x - The x coordinate in DOM/client space
	* @param y - The y coordinate in DOM/client space
	* @example
	* ```ts
	* // Map mouse coordinates to PixiJS space
	* const point = new Point();
	* app.renderer.events.mapPositionToPoint(
	*     point,
	*     event.clientX,
	*     event.clientY
	* );
	* console.log('Mapped position:', point.x, point.y);
	*
	* // Using with pointer events
	* sprite.on('pointermove', (event) => {
	*     // event.global already contains mapped coordinates
	*     console.log('Global:', event.global.x, event.global.y);
	*
	*     // Map to local coordinates
	*     const local = event.getLocalPosition(sprite);
	*     console.log('Local:', local.x, local.y);
	* });
	* ```
	* @remarks
	* - Accounts for element scaling and positioning
	* - Adjusts for device pixel ratio/resolution
	*/
	mapPositionToPoint(point, x, y) {
		const rect = this.domElement.isConnected ? this.domElement.getBoundingClientRect() : {
			x: 0,
			y: 0,
			width: this.domElement.width,
			height: this.domElement.height,
			left: 0,
			top: 0
		};
		const resolutionMultiplier = 1 / this.resolution;
		point.x = (x - rect.left) * (this.domElement.width / rect.width) * resolutionMultiplier;
		point.y = (y - rect.top) * (this.domElement.height / rect.height) * resolutionMultiplier;
	}
	/**
	* Ensures that the original event object contains all data that a regular pointer event would have
	* @param event - The original event data from a touch or mouse event
	* @returns An array containing a single normalized pointer event, in the case of a pointer
	*  or mouse event, or a multiple normalized pointer events if there are multiple changed touches
	*/
	_normalizeToPointerData(event) {
		const normalizedEvents = [];
		if (this.supportsTouchEvents && event instanceof TouchEvent) for (let i = 0, li = event.changedTouches.length; i < li; i++) {
			const touch = event.changedTouches[i];
			if (typeof touch.button === "undefined") touch.button = 0;
			if (typeof touch.buttons === "undefined") touch.buttons = 1;
			if (typeof touch.isPrimary === "undefined") touch.isPrimary = event.touches.length === 1 && event.type === "touchstart";
			if (typeof touch.width === "undefined") touch.width = touch.radiusX || 1;
			if (typeof touch.height === "undefined") touch.height = touch.radiusY || 1;
			if (typeof touch.tiltX === "undefined") touch.tiltX = 0;
			if (typeof touch.tiltY === "undefined") touch.tiltY = 0;
			if (typeof touch.pointerType === "undefined") touch.pointerType = "touch";
			if (typeof touch.pointerId === "undefined") touch.pointerId = touch.identifier || 0;
			if (typeof touch.pressure === "undefined") touch.pressure = touch.force || .5;
			if (typeof touch.twist === "undefined") touch.twist = 0;
			if (typeof touch.tangentialPressure === "undefined") touch.tangentialPressure = 0;
			if (typeof touch.layerX === "undefined") touch.layerX = touch.offsetX = touch.clientX;
			if (typeof touch.layerY === "undefined") touch.layerY = touch.offsetY = touch.clientY;
			touch.isNormalized = true;
			touch.type = event.type;
			touch.altKey ?? (touch.altKey = event.altKey);
			touch.ctrlKey ?? (touch.ctrlKey = event.ctrlKey);
			touch.metaKey ?? (touch.metaKey = event.metaKey);
			touch.shiftKey ?? (touch.shiftKey = event.shiftKey);
			normalizedEvents.push(touch);
		}
		else if (!globalThis.MouseEvent || event instanceof MouseEvent && (!this.supportsPointerEvents || !(event instanceof globalThis.PointerEvent))) {
			const tempEvent = event;
			if (typeof tempEvent.isPrimary === "undefined") tempEvent.isPrimary = true;
			if (typeof tempEvent.width === "undefined") tempEvent.width = 1;
			if (typeof tempEvent.height === "undefined") tempEvent.height = 1;
			if (typeof tempEvent.tiltX === "undefined") tempEvent.tiltX = 0;
			if (typeof tempEvent.tiltY === "undefined") tempEvent.tiltY = 0;
			if (typeof tempEvent.pointerType === "undefined") tempEvent.pointerType = "mouse";
			if (typeof tempEvent.pointerId === "undefined") tempEvent.pointerId = MOUSE_POINTER_ID;
			if (typeof tempEvent.pressure === "undefined") tempEvent.pressure = .5;
			if (typeof tempEvent.twist === "undefined") tempEvent.twist = 0;
			if (typeof tempEvent.tangentialPressure === "undefined") tempEvent.tangentialPressure = 0;
			tempEvent.isNormalized = true;
			normalizedEvents.push(tempEvent);
		} else normalizedEvents.push(event);
		return normalizedEvents;
	}
	/**
	* Normalizes the native {@link https://w3c.github.io/uievents/#interface-wheelevent WheelEvent}.
	*
	* The returned {@link FederatedWheelEvent} is a shared instance. It will not persist across
	* multiple native wheel events.
	* @param nativeEvent - The native wheel event that occurred on the canvas.
	* @returns A federated wheel event.
	*/
	normalizeWheelEvent(nativeEvent) {
		const event = this._rootWheelEvent;
		this._transferMouseData(event, nativeEvent);
		event.deltaX = nativeEvent.deltaX;
		event.deltaY = nativeEvent.deltaY;
		event.deltaZ = nativeEvent.deltaZ;
		event.deltaMode = nativeEvent.deltaMode;
		this.mapPositionToPoint(event.screen, nativeEvent.clientX, nativeEvent.clientY);
		event.global.copyFrom(event.screen);
		event.offset.copyFrom(event.screen);
		event.nativeEvent = nativeEvent;
		event.type = nativeEvent.type;
		return event;
	}
	/**
	* Normalizes the `nativeEvent` into a federateed {@link FederatedPointerEvent}.
	* @param event
	* @param nativeEvent
	*/
	_bootstrapEvent(event, nativeEvent) {
		event.originalEvent = null;
		event.nativeEvent = nativeEvent;
		event.pointerId = nativeEvent.pointerId;
		event.width = nativeEvent.width;
		event.height = nativeEvent.height;
		event.isPrimary = nativeEvent.isPrimary;
		event.pointerType = nativeEvent.pointerType;
		event.pressure = nativeEvent.pressure;
		event.tangentialPressure = nativeEvent.tangentialPressure;
		event.tiltX = nativeEvent.tiltX;
		event.tiltY = nativeEvent.tiltY;
		event.twist = nativeEvent.twist;
		this._transferMouseData(event, nativeEvent);
		this.mapPositionToPoint(event.screen, nativeEvent.clientX, nativeEvent.clientY);
		event.global.copyFrom(event.screen);
		event.offset.copyFrom(event.screen);
		event.isTrusted = nativeEvent.isTrusted;
		if (event.type === "pointerleave") event.type = "pointerout";
		if (event.type.startsWith("mouse")) event.type = event.type.replace("mouse", "pointer");
		if (event.type.startsWith("touch")) event.type = TOUCH_TO_POINTER[event.type] || event.type;
		return event;
	}
	/**
	* Transfers base & mouse event data from the `nativeEvent` to the federated event.
	* @param event
	* @param nativeEvent
	*/
	_transferMouseData(event, nativeEvent) {
		event.isTrusted = nativeEvent.isTrusted;
		event.srcElement = nativeEvent.srcElement;
		event.timeStamp = performance.now();
		event.type = nativeEvent.type;
		event.altKey = nativeEvent.altKey;
		event.button = nativeEvent.button;
		event.buttons = nativeEvent.buttons;
		event.client.x = nativeEvent.clientX;
		event.client.y = nativeEvent.clientY;
		event.ctrlKey = nativeEvent.ctrlKey;
		event.metaKey = nativeEvent.metaKey;
		event.movement.x = nativeEvent.movementX;
		event.movement.y = nativeEvent.movementY;
		event.page.x = nativeEvent.pageX;
		event.page.y = nativeEvent.pageY;
		event.relatedTarget = null;
		event.shiftKey = nativeEvent.shiftKey;
	}
};
/** @ignore */
_EventSystem.extension = {
	name: "events",
	type: [
		ExtensionType.WebGLSystem,
		ExtensionType.CanvasSystem,
		ExtensionType.WebGPUSystem
	],
	priority: -1
};
/**
* The event features that are enabled by the EventSystem
* @since 7.2.0
* @example
* ```ts
* import { EventSystem, EventSystemFeatures } from 'pixi.js';
* // Access the default event features
* EventSystem.defaultEventFeatures = {
*     // Enable pointer movement events
*     move: true,
*     // Enable global pointer move events
*     globalMove: true,
*     // Enable click events
*     click: true,
*     // Enable wheel events
*     wheel: true,
* };
* ```
*/
_EventSystem.defaultEventFeatures = {
	/** Enables pointer events associated with pointer movement. */
	move: true,
	/** Enables global pointer move events. */
	globalMove: true,
	/** Enables pointer events associated with clicking. */
	click: true,
	/** Enables wheel events. */
	wheel: true
};
var EventSystem = _EventSystem;
//#endregion
//#region node_modules/pixi.js/lib/events/FederatedEventTarget.mjs
var FederatedContainer = {
	onclick: null,
	oncontextmenu: null,
	onmousedown: null,
	onmouseenter: null,
	onmouseleave: null,
	onmousemove: null,
	onglobalmousemove: null,
	onmouseout: null,
	onmouseover: null,
	onmouseup: null,
	onmouseupoutside: null,
	onpointercancel: null,
	onpointerdown: null,
	onpointerenter: null,
	onpointerleave: null,
	onpointermove: null,
	onglobalpointermove: null,
	onpointerout: null,
	onpointerover: null,
	onpointertap: null,
	onpointerup: null,
	onpointerupoutside: null,
	onrightclick: null,
	onrightdown: null,
	onrightup: null,
	onrightupoutside: null,
	ontap: null,
	ontouchcancel: null,
	ontouchend: null,
	ontouchendoutside: null,
	ontouchmove: null,
	onglobaltouchmove: null,
	ontouchstart: null,
	onwheel: null,
	get interactive() {
		return this.eventMode === "dynamic" || this.eventMode === "static";
	},
	set interactive(value) {
		this.eventMode = value ? "static" : "passive";
	},
	_internalEventMode: void 0,
	get eventMode() {
		return this._internalEventMode ?? EventSystem.defaultEventMode;
	},
	set eventMode(value) {
		this._internalEventMode = value;
	},
	isInteractive() {
		return this.eventMode === "static" || this.eventMode === "dynamic";
	},
	interactiveChildren: true,
	hitArea: null,
	addEventListener(type, listener, options) {
		const capture = typeof options === "boolean" && options || typeof options === "object" && options.capture;
		const signal = typeof options === "object" ? options.signal : void 0;
		const once = typeof options === "object" ? options.once === true : false;
		const context = typeof listener === "function" ? void 0 : listener;
		type = capture ? `${type}capture` : type;
		const listenerFn = typeof listener === "function" ? listener : listener.handleEvent;
		const emitter = this;
		if (signal) signal.addEventListener("abort", () => {
			emitter.off(type, listenerFn, context);
		});
		if (once) emitter.once(type, listenerFn, context);
		else emitter.on(type, listenerFn, context);
	},
	removeEventListener(type, listener, options) {
		const capture = typeof options === "boolean" && options || typeof options === "object" && options.capture;
		const context = typeof listener === "function" ? void 0 : listener;
		type = capture ? `${type}capture` : type;
		listener = typeof listener === "function" ? listener : listener.handleEvent;
		this.off(type, listener, context);
	},
	dispatchEvent(e) {
		if (!(e instanceof FederatedEvent)) throw new Error("Container cannot propagate events outside of the Federated Events API");
		e.defaultPrevented = false;
		e.path = null;
		e.target = this;
		e.manager.dispatchEvent(e);
		return !e.defaultPrevented;
	}
};
//#endregion
export { FederatedPointerEvent as a, DOMPipe as c, isMobile as d, FederatedEvent as f, FederatedWheelEvent as i, accessibilityTarget as l, EventSystem as n, FederatedMouseEvent as o, CanvasObserver as p, EventBoundary as r, EventsTicker as s, FederatedContainer as t, AccessibilitySystem as u };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRmVkZXJhdGVkRXZlbnRUYXJnZXQtQmd1TkpSTG8uanMiLCJuYW1lcyI6WyJpc01vYmlsZSIsImlzTW9iaWxlSnMiLCJFdmVudEVtaXR0ZXIiXSwic291cmNlcyI6WyIuLi8uLi9waXhpLmpzL2xpYi9kb20vQ2FudmFzT2JzZXJ2ZXIubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvZXZlbnRzL0ZlZGVyYXRlZEV2ZW50Lm1qcyIsIi4uLy4uL2lzbW9iaWxlanMvZXNtL2lzTW9iaWxlLmpzIiwiLi4vLi4vcGl4aS5qcy9saWIvdXRpbHMvYnJvd3Nlci9pc01vYmlsZS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9hY2Nlc3NpYmlsaXR5L0FjY2Vzc2liaWxpdHlTeXN0ZW0ubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvYWNjZXNzaWJpbGl0eS9hY2Nlc3NpYmlsaXR5VGFyZ2V0Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2RvbS9ET01QaXBlLm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2V2ZW50cy9FdmVudFRpY2tlci5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9ldmVudHMvRmVkZXJhdGVkTW91c2VFdmVudC5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9ldmVudHMvRmVkZXJhdGVkUG9pbnRlckV2ZW50Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2V2ZW50cy9GZWRlcmF0ZWRXaGVlbEV2ZW50Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2V2ZW50cy9FdmVudEJvdW5kYXJ5Lm1qcyIsIi4uLy4uL3BpeGkuanMvbGliL2V2ZW50cy9FdmVudFN5c3RlbS5tanMiLCIuLi8uLi9waXhpLmpzL2xpYi9ldmVudHMvRmVkZXJhdGVkRXZlbnRUYXJnZXQubWpzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFVQREFURV9QUklPUklUWSB9IGZyb20gJy4uL3RpY2tlci9jb25zdC5tanMnO1xuaW1wb3J0IHsgVGlja2VyIH0gZnJvbSAnLi4vdGlja2VyL1RpY2tlci5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIENhbnZhc09ic2VydmVyIHtcbiAgY29uc3RydWN0b3Iob3B0aW9ucykge1xuICAgIC8qKiBBIGNhY2hlZCB2YWx1ZSBvZiB0aGUgbGFzdCB0cmFuc2Zvcm0gYXBwbGllZCB0byB0aGUgRE9NIGVsZW1lbnQuICovXG4gICAgdGhpcy5fbGFzdFRyYW5zZm9ybSA9IFwiXCI7XG4gICAgLyoqIEEgUmVzaXplT2JzZXJ2ZXIgaW5zdGFuY2UgdG8gb2JzZXJ2ZSBjaGFuZ2VzIGluIHRoZSBjYW52YXMgc2l6ZS4gKi9cbiAgICB0aGlzLl9vYnNlcnZlciA9IG51bGw7XG4gICAgLyoqIEEgZmxhZyB0byBpbmRpY2F0ZSB3aGV0aGVyIHRoZSBvYnNlcnZlciBpcyBhdHRhY2hlZCB0byB0aGUgVGlja2VyIGZvciBjb250aW51b3VzIHVwZGF0ZXMuICovXG4gICAgdGhpcy5fdGlja2VyQXR0YWNoZWQgPSBmYWxzZTtcbiAgICAvKipcbiAgICAgKiBVcGRhdGVzIHRoZSB0cmFuc2Zvcm0gb2YgdGhlIERPTSBlbGVtZW50IGJhc2VkIG9uIHRoZSBjYW52YXMgc2l6ZSBhbmQgcG9zaXRpb24uXG4gICAgICogVGhpcyBtZXRob2QgY2FsY3VsYXRlcyB0aGUgc2NhbGUgYW5kIHRyYW5zbGF0aW9uIG5lZWRlZCB0byBrZWVwIHRoZSBET00gZWxlbWVudCBpbiBzeW5jIHdpdGggdGhlIGNhbnZhcy5cbiAgICAgKi9cbiAgICB0aGlzLnVwZGF0ZVRyYW5zbGF0aW9uID0gKCkgPT4ge1xuICAgICAgaWYgKCF0aGlzLl9jYW52YXMpIHJldHVybjtcbiAgICAgIGNvbnN0IHJlY3QgPSB0aGlzLl9jYW52YXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICBjb25zdCBjb250ZW50V2lkdGggPSB0aGlzLl9jYW52YXMud2lkdGg7XG4gICAgICBjb25zdCBjb250ZW50SGVpZ2h0ID0gdGhpcy5fY2FudmFzLmhlaWdodDtcbiAgICAgIGNvbnN0IHN4ID0gcmVjdC53aWR0aCAvIGNvbnRlbnRXaWR0aCAqIHRoaXMuX3JlbmRlcmVyLnJlc29sdXRpb247XG4gICAgICBjb25zdCBzeSA9IHJlY3QuaGVpZ2h0IC8gY29udGVudEhlaWdodCAqIHRoaXMuX3JlbmRlcmVyLnJlc29sdXRpb247XG4gICAgICBjb25zdCB0eCA9IHJlY3QubGVmdDtcbiAgICAgIGNvbnN0IHR5ID0gcmVjdC50b3A7XG4gICAgICBjb25zdCBuZXdUcmFuc2Zvcm0gPSBgdHJhbnNsYXRlKCR7dHh9cHgsICR7dHl9cHgpIHNjYWxlKCR7c3h9LCAke3N5fSlgO1xuICAgICAgaWYgKG5ld1RyYW5zZm9ybSAhPT0gdGhpcy5fbGFzdFRyYW5zZm9ybSkge1xuICAgICAgICB0aGlzLl9kb21FbGVtZW50LnN0eWxlLnRyYW5zZm9ybSA9IG5ld1RyYW5zZm9ybTtcbiAgICAgICAgdGhpcy5fbGFzdFRyYW5zZm9ybSA9IG5ld1RyYW5zZm9ybTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHRoaXMuX2RvbUVsZW1lbnQgPSBvcHRpb25zLmRvbUVsZW1lbnQ7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSBvcHRpb25zLnJlbmRlcmVyO1xuICAgIGlmIChnbG9iYWxUaGlzLk9mZnNjcmVlbkNhbnZhcyAmJiB0aGlzLl9yZW5kZXJlci5jYW52YXMgaW5zdGFuY2VvZiBPZmZzY3JlZW5DYW52YXMpIHJldHVybjtcbiAgICB0aGlzLl9jYW52YXMgPSB0aGlzLl9yZW5kZXJlci5jYW52YXM7XG4gICAgdGhpcy5fYXR0YWNoT2JzZXJ2ZXIoKTtcbiAgfVxuICAvKiogVGhlIGNhbnZhcyBlbGVtZW50IHRoYXQgdGhpcyBDYW52YXNPYnNlcnZlciBpcyBhc3NvY2lhdGVkIHdpdGguICovXG4gIGdldCBjYW52YXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2NhbnZhcztcbiAgfVxuICAvKiogQXR0YWNoZXMgdGhlIERPTSBlbGVtZW50IHRvIHRoZSBjYW52YXMgcGFyZW50IGlmIGl0IGlzIG5vdCBhbHJlYWR5IGF0dGFjaGVkLiAqL1xuICBlbnN1cmVBdHRhY2hlZCgpIHtcbiAgICBpZiAoIXRoaXMuX2RvbUVsZW1lbnQucGFyZW50Tm9kZSAmJiB0aGlzLl9jYW52YXMucGFyZW50Tm9kZSkge1xuICAgICAgdGhpcy5fY2FudmFzLnBhcmVudE5vZGUuYXBwZW5kQ2hpbGQodGhpcy5fZG9tRWxlbWVudCk7XG4gICAgICB0aGlzLnVwZGF0ZVRyYW5zbGF0aW9uKCk7XG4gICAgfVxuICB9XG4gIC8qKiBTZXRzIHVwIGEgUmVzaXplT2JzZXJ2ZXIgaWYgYXZhaWxhYmxlLiBUaGlzIGVuc3VyZXMgdGhhdCB0aGUgRE9NIGVsZW1lbnQgaXMga2VwdCBpbiBzeW5jIHdpdGggdGhlIGNhbnZhcyBzaXplIC4gKi9cbiAgX2F0dGFjaE9ic2VydmVyKCkge1xuICAgIGlmIChcIlJlc2l6ZU9ic2VydmVyXCIgaW4gZ2xvYmFsVGhpcykge1xuICAgICAgaWYgKHRoaXMuX29ic2VydmVyKSB7XG4gICAgICAgIHRoaXMuX29ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgdGhpcy5fb2JzZXJ2ZXIgPSBudWxsO1xuICAgICAgfVxuICAgICAgdGhpcy5fb2JzZXJ2ZXIgPSBuZXcgUmVzaXplT2JzZXJ2ZXIoKGVudHJpZXMpID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBlbnRyeSBvZiBlbnRyaWVzKSB7XG4gICAgICAgICAgaWYgKGVudHJ5LnRhcmdldCAhPT0gdGhpcy5fY2FudmFzKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgY29udGVudFdpZHRoID0gdGhpcy5jYW52YXMud2lkdGg7XG4gICAgICAgICAgY29uc3QgY29udGVudEhlaWdodCA9IHRoaXMuY2FudmFzLmhlaWdodDtcbiAgICAgICAgICBjb25zdCBzeCA9IGVudHJ5LmNvbnRlbnRSZWN0LndpZHRoIC8gY29udGVudFdpZHRoICogdGhpcy5fcmVuZGVyZXIucmVzb2x1dGlvbjtcbiAgICAgICAgICBjb25zdCBzeSA9IGVudHJ5LmNvbnRlbnRSZWN0LmhlaWdodCAvIGNvbnRlbnRIZWlnaHQgKiB0aGlzLl9yZW5kZXJlci5yZXNvbHV0aW9uO1xuICAgICAgICAgIGNvbnN0IG5lZWRzVXBkYXRlID0gdGhpcy5fbGFzdFNjYWxlWCAhPT0gc3ggfHwgdGhpcy5fbGFzdFNjYWxlWSAhPT0gc3k7XG4gICAgICAgICAgaWYgKG5lZWRzVXBkYXRlKSB7XG4gICAgICAgICAgICB0aGlzLnVwZGF0ZVRyYW5zbGF0aW9uKCk7XG4gICAgICAgICAgICB0aGlzLl9sYXN0U2NhbGVYID0gc3g7XG4gICAgICAgICAgICB0aGlzLl9sYXN0U2NhbGVZID0gc3k7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIHRoaXMuX29ic2VydmVyLm9ic2VydmUodGhpcy5fY2FudmFzKTtcbiAgICB9IGVsc2UgaWYgKCF0aGlzLl90aWNrZXJBdHRhY2hlZCkge1xuICAgICAgVGlja2VyLnNoYXJlZC5hZGQodGhpcy51cGRhdGVUcmFuc2xhdGlvbiwgdGhpcywgVVBEQVRFX1BSSU9SSVRZLkhJR0gpO1xuICAgIH1cbiAgfVxuICAvKiogRGVzdHJveXMgdGhlIENhbnZhc09ic2VydmVyIGluc3RhbmNlLCBjbGVhbmluZyB1cCBvYnNlcnZlcnMgYW5kIFRpY2tlci4gKi9cbiAgZGVzdHJveSgpIHtcbiAgICBpZiAodGhpcy5fb2JzZXJ2ZXIpIHtcbiAgICAgIHRoaXMuX29ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgIHRoaXMuX29ic2VydmVyID0gbnVsbDtcbiAgICB9IGVsc2UgaWYgKHRoaXMuX3RpY2tlckF0dGFjaGVkKSB7XG4gICAgICBUaWNrZXIuc2hhcmVkLnJlbW92ZSh0aGlzLnVwZGF0ZVRyYW5zbGF0aW9uKTtcbiAgICB9XG4gICAgdGhpcy5fZG9tRWxlbWVudCA9IG51bGw7XG4gICAgdGhpcy5fcmVuZGVyZXIgPSBudWxsO1xuICAgIHRoaXMuX2NhbnZhcyA9IG51bGw7XG4gICAgdGhpcy5fdGlja2VyQXR0YWNoZWQgPSBmYWxzZTtcbiAgICB0aGlzLl9sYXN0VHJhbnNmb3JtID0gXCJcIjtcbiAgICB0aGlzLl9sYXN0U2NhbGVYID0gbnVsbDtcbiAgICB0aGlzLl9sYXN0U2NhbGVZID0gbnVsbDtcbiAgfVxufVxuXG5leHBvcnQgeyBDYW52YXNPYnNlcnZlciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Q2FudmFzT2JzZXJ2ZXIubWpzLm1hcFxuIiwiaW1wb3J0IHsgUG9pbnQgfSBmcm9tICcuLi9tYXRocy9wb2ludC9Qb2ludC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIEZlZGVyYXRlZEV2ZW50IHtcbiAgLyoqXG4gICAqIEBwYXJhbSBtYW5hZ2VyIC0gVGhlIGV2ZW50IGJvdW5kYXJ5IHdoaWNoIG1hbmFnZXMgdGhpcyBldmVudC4gUHJvcGFnYXRpb24gY2FuIG9ubHkgb2NjdXJcbiAgICogIHdpdGhpbiB0aGUgYm91bmRhcnkncyBqdXJpc2RpY3Rpb24uXG4gICAqL1xuICBjb25zdHJ1Y3RvcihtYW5hZ2VyKSB7XG4gICAgLyoqIEZsYWdzIHdoZXRoZXIgdGhpcyBldmVudCBidWJibGVzLiBUaGlzIHdpbGwgdGFrZSBlZmZlY3Qgb25seSBpZiBpdCBpcyBzZXQgYmVmb3JlIHByb3BhZ2F0aW9uLiAqL1xuICAgIHRoaXMuYnViYmxlcyA9IHRydWU7XG4gICAgLyoqIEBkZXByZWNhdGVkIHNpbmNlIDcuMC4wICovXG4gICAgdGhpcy5jYW5jZWxCdWJibGUgPSB0cnVlO1xuICAgIC8qKlxuICAgICAqIEZsYWdzIHdoZXRoZXIgdGhpcyBldmVudCBjYW4gYmUgY2FuY2VsZWQgdXNpbmcge0BsaW5rIEZlZGVyYXRlZEV2ZW50LnByZXZlbnREZWZhdWx0fS4gVGhpcyBpcyBhbHdheXNcbiAgICAgKiBmYWxzZSAoZm9yIG5vdykuXG4gICAgICovXG4gICAgdGhpcy5jYW5jZWxhYmxlID0gZmFsc2U7XG4gICAgLyoqXG4gICAgICogRmxhZyBhZGRlZCBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIERPTSBgRXZlbnRgLiBJdCBpcyBub3QgdXNlZCBpbiB0aGUgRmVkZXJhdGVkIEV2ZW50c1xuICAgICAqIEFQSS5cbiAgICAgKiBAc2VlIGh0dHBzOi8vZG9tLnNwZWMud2hhdHdnLm9yZy8jZG9tLWV2ZW50LWNvbXBvc2VkXG4gICAgICogQGlnbm9yZVxuICAgICAqL1xuICAgIHRoaXMuY29tcG9zZWQgPSBmYWxzZTtcbiAgICAvKiogRmxhZ3Mgd2hldGhlciB0aGUgZGVmYXVsdCByZXNwb25zZSBvZiB0aGUgdXNlciBhZ2VudCB3YXMgcHJldmVudCB0aHJvdWdoIHRoaXMgZXZlbnQuICovXG4gICAgdGhpcy5kZWZhdWx0UHJldmVudGVkID0gZmFsc2U7XG4gICAgLyoqXG4gICAgICogVGhlIHByb3BhZ2F0aW9uIHBoYXNlLlxuICAgICAqIEBkZWZhdWx0IHtAbGluayBGZWRlcmF0ZWRFdmVudC5OT05FfVxuICAgICAqL1xuICAgIHRoaXMuZXZlbnRQaGFzZSA9IEZlZGVyYXRlZEV2ZW50LnByb3RvdHlwZS5OT05FO1xuICAgIC8qKiBGbGFncyB3aGV0aGVyIHByb3BhZ2F0aW9uIHdhcyBzdG9wcGVkLiAqL1xuICAgIHRoaXMucHJvcGFnYXRpb25TdG9wcGVkID0gZmFsc2U7XG4gICAgLyoqIEZsYWdzIHdoZXRoZXIgcHJvcGFnYXRpb24gd2FzIGltbWVkaWF0ZWx5IHN0b3BwZWQuICovXG4gICAgdGhpcy5wcm9wYWdhdGlvbkltbWVkaWF0ZWx5U3RvcHBlZCA9IGZhbHNlO1xuICAgIC8qKiBUaGUgY29vcmRpbmF0ZXMgb2YgdGhlIGV2ZW50IHJlbGF0aXZlIHRvIHRoZSBuZWFyZXN0IERPTSBsYXllci4gVGhpcyBpcyBhIG5vbi1zdGFuZGFyZCBwcm9wZXJ0eS4gKi9cbiAgICB0aGlzLmxheWVyID0gbmV3IFBvaW50KCk7XG4gICAgLyoqIFRoZSBjb29yZGluYXRlcyBvZiB0aGUgZXZlbnQgcmVsYXRpdmUgdG8gdGhlIERPTSBkb2N1bWVudC4gVGhpcyBpcyBhIG5vbi1zdGFuZGFyZCBwcm9wZXJ0eS4gKi9cbiAgICB0aGlzLnBhZ2UgPSBuZXcgUG9pbnQoKTtcbiAgICAvKipcbiAgICAgKiBUaGUgZXZlbnQgcHJvcGFnYXRpb24gcGhhc2UgTk9ORSB0aGF0IGluZGljYXRlcyB0aGF0IHRoZSBldmVudCBpcyBub3QgaW4gYW55IHBoYXNlLlxuICAgICAqIEBkZWZhdWx0IDBcbiAgICAgKiBAYWR2YW5jZWRcbiAgICAgKi9cbiAgICB0aGlzLk5PTkUgPSAwO1xuICAgIC8qKlxuICAgICAqIFRoZSBldmVudCBwcm9wYWdhdGlvbiBwaGFzZSBDQVBUVVJJTkdfUEhBU0UgdGhhdCBpbmRpY2F0ZXMgdGhhdCB0aGUgZXZlbnQgaXMgaW4gdGhlIGNhcHR1cmluZyBwaGFzZS5cbiAgICAgKiBAZGVmYXVsdCAxXG4gICAgICogQGFkdmFuY2VkXG4gICAgICovXG4gICAgdGhpcy5DQVBUVVJJTkdfUEhBU0UgPSAxO1xuICAgIC8qKlxuICAgICAqIFRoZSBldmVudCBwcm9wYWdhdGlvbiBwaGFzZSBBVF9UQVJHRVQgdGhhdCBpbmRpY2F0ZXMgdGhhdCB0aGUgZXZlbnQgaXMgYXQgdGhlIHRhcmdldC5cbiAgICAgKiBAZGVmYXVsdCAyXG4gICAgICogQGFkdmFuY2VkXG4gICAgICovXG4gICAgdGhpcy5BVF9UQVJHRVQgPSAyO1xuICAgIC8qKlxuICAgICAqIFRoZSBldmVudCBwcm9wYWdhdGlvbiBwaGFzZSBCVUJCTElOR19QSEFTRSB0aGF0IGluZGljYXRlcyB0aGF0IHRoZSBldmVudCBpcyBpbiB0aGUgYnViYmxpbmcgcGhhc2UuXG4gICAgICogQGRlZmF1bHQgM1xuICAgICAqIEBhZHZhbmNlZFxuICAgICAqL1xuICAgIHRoaXMuQlVCQkxJTkdfUEhBU0UgPSAzO1xuICAgIHRoaXMubWFuYWdlciA9IG1hbmFnZXI7XG4gIH1cbiAgLyoqIEByZWFkb25seSAqL1xuICBnZXQgbGF5ZXJYKCkge1xuICAgIHJldHVybiB0aGlzLmxheWVyLng7XG4gIH1cbiAgLyoqIEByZWFkb25seSAqL1xuICBnZXQgbGF5ZXJZKCkge1xuICAgIHJldHVybiB0aGlzLmxheWVyLnk7XG4gIH1cbiAgLyoqIEByZWFkb25seSAqL1xuICBnZXQgcGFnZVgoKSB7XG4gICAgcmV0dXJuIHRoaXMucGFnZS54O1xuICB9XG4gIC8qKiBAcmVhZG9ubHkgKi9cbiAgZ2V0IHBhZ2VZKCkge1xuICAgIHJldHVybiB0aGlzLnBhZ2UueTtcbiAgfVxuICAvKipcbiAgICogRmFsbGJhY2sgZm9yIHRoZSBkZXByZWNhdGVkIGBJbnRlcmFjdGlvbkV2ZW50LmRhdGFgLlxuICAgKiBAZGVwcmVjYXRlZCBzaW5jZSA3LjAuMFxuICAgKi9cbiAgZ2V0IGRhdGEoKSB7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBwcm9wYWdhdGlvbiBwYXRoIGZvciB0aGlzIGV2ZW50LiBBbGlhcyBmb3Ige0BsaW5rIEV2ZW50Qm91bmRhcnkucHJvcGFnYXRpb25QYXRofS5cbiAgICogQGFkdmFuY2VkXG4gICAqL1xuICBjb21wb3NlZFBhdGgoKSB7XG4gICAgaWYgKHRoaXMubWFuYWdlciAmJiAoIXRoaXMucGF0aCB8fCB0aGlzLnBhdGhbdGhpcy5wYXRoLmxlbmd0aCAtIDFdICE9PSB0aGlzLnRhcmdldCkpIHtcbiAgICAgIHRoaXMucGF0aCA9IHRoaXMudGFyZ2V0ID8gdGhpcy5tYW5hZ2VyLnByb3BhZ2F0aW9uUGF0aCh0aGlzLnRhcmdldCkgOiBbXTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucGF0aDtcbiAgfVxuICAvKipcbiAgICogVW5pbXBsZW1lbnRlZCBtZXRob2QgaW5jbHVkZWQgZm9yIGltcGxlbWVudGluZyB0aGUgRE9NIGludGVyZmFjZSBgRXZlbnRgLiBJdCB3aWxsIHRocm93IGFuIGBFcnJvcmAuXG4gICAqIEBkZXByZWNhdGVkXG4gICAqIEBpZ25vcmVcbiAgICogQHBhcmFtIF90eXBlXG4gICAqIEBwYXJhbSBfYnViYmxlc1xuICAgKiBAcGFyYW0gX2NhbmNlbGFibGVcbiAgICovXG4gIGluaXRFdmVudChfdHlwZSwgX2J1YmJsZXMsIF9jYW5jZWxhYmxlKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiaW5pdEV2ZW50KCkgaXMgYSBsZWdhY3kgRE9NIEFQSS4gSXQgaXMgbm90IGltcGxlbWVudGVkIGluIHRoZSBGZWRlcmF0ZWQgRXZlbnRzIEFQSS5cIik7XG4gIH1cbiAgLyoqXG4gICAqIFVuaW1wbGVtZW50ZWQgbWV0aG9kIGluY2x1ZGVkIGZvciBpbXBsZW1lbnRpbmcgdGhlIERPTSBpbnRlcmZhY2UgYFVJRXZlbnRgLiBJdCB3aWxsIHRocm93IGFuIGBFcnJvcmAuXG4gICAqIEBpZ25vcmVcbiAgICogQGRlcHJlY2F0ZWRcbiAgICogQHBhcmFtIF90eXBlQXJnXG4gICAqIEBwYXJhbSBfYnViYmxlc0FyZ1xuICAgKiBAcGFyYW0gX2NhbmNlbGFibGVBcmdcbiAgICogQHBhcmFtIF92aWV3QXJnXG4gICAqIEBwYXJhbSBfZGV0YWlsQXJnXG4gICAqL1xuICBpbml0VUlFdmVudChfdHlwZUFyZywgX2J1YmJsZXNBcmcsIF9jYW5jZWxhYmxlQXJnLCBfdmlld0FyZywgX2RldGFpbEFyZykge1xuICAgIHRocm93IG5ldyBFcnJvcihcImluaXRVSUV2ZW50KCkgaXMgYSBsZWdhY3kgRE9NIEFQSS4gSXQgaXMgbm90IGltcGxlbWVudGVkIGluIHRoZSBGZWRlcmF0ZWQgRXZlbnRzIEFQSS5cIik7XG4gIH1cbiAgLyoqXG4gICAqIFByZXZlbnQgZGVmYXVsdCBiZWhhdmlvciBvZiBib3RoIFBpeGlKUyBhbmQgdGhlIHVzZXIgYWdlbnQuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIHNwcml0ZS5vbignY2xpY2snLCAoZXZlbnQpID0+IHtcbiAgICogICAgIC8vIFByZXZlbnQgYm90aCBicm93c2VyJ3MgZGVmYXVsdCBjbGljayBiZWhhdmlvclxuICAgKiAgICAgLy8gYW5kIFBpeGlKUydzIGRlZmF1bHQgaGFuZGxpbmdcbiAgICogICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAqXG4gICAqICAgICAvLyBDdXN0b20gaGFuZGxpbmdcbiAgICogICAgIGN1c3RvbUNsaWNrSGFuZGxlcigpO1xuICAgKiB9KTtcbiAgICogYGBgXG4gICAqIEByZW1hcmtzXG4gICAqIC0gT25seSB3b3JrcyBpZiB0aGUgbmF0aXZlIGV2ZW50IGlzIGNhbmNlbGFibGVcbiAgICogLSBEb2VzIG5vdCBzdG9wIGV2ZW50IHByb3BhZ2F0aW9uXG4gICAqL1xuICBwcmV2ZW50RGVmYXVsdCgpIHtcbiAgICBpZiAodGhpcy5uYXRpdmVFdmVudCBpbnN0YW5jZW9mIEV2ZW50ICYmIHRoaXMubmF0aXZlRXZlbnQuY2FuY2VsYWJsZSkge1xuICAgICAgdGhpcy5uYXRpdmVFdmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIH1cbiAgICB0aGlzLmRlZmF1bHRQcmV2ZW50ZWQgPSB0cnVlO1xuICB9XG4gIC8qKlxuICAgKiBTdG9wIHRoaXMgZXZlbnQgZnJvbSBwcm9wYWdhdGluZyB0byBhbnkgYWRkaXRpb25hbCBsaXN0ZW5lcnMsIGluY2x1ZGluZyB0aG9zZVxuICAgKiBvbiB0aGUgY3VycmVudCB0YXJnZXQgYW5kIGFueSBmb2xsb3dpbmcgdGFyZ2V0cyBpbiB0aGUgcHJvcGFnYXRpb24gcGF0aC5cbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogY29udGFpbmVyLm9uKCdwb2ludGVyZG93bicsIChldmVudCkgPT4ge1xuICAgKiAgICAgLy8gU3RvcCBhbGwgZnVydGhlciBldmVudCBoYW5kbGluZ1xuICAgKiAgICAgZXZlbnQuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAqXG4gICAqICAgICAvLyBUaGVzZSBoYW5kbGVycyB3b24ndCBiZSBjYWxsZWQ6XG4gICAqICAgICAvLyAtIE90aGVyIHBvaW50ZXJkb3duIGxpc3RlbmVycyBvbiB0aGlzIGNvbnRhaW5lclxuICAgKiAgICAgLy8gLSBBbnkgcG9pbnRlcmRvd24gbGlzdGVuZXJzIG9uIHBhcmVudCBjb250YWluZXJzXG4gICAqIH0pO1xuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBJbW1lZGlhdGVseSBzdG9wcyBhbGwgZXZlbnQgcHJvcGFnYXRpb25cbiAgICogLSBQcmV2ZW50cyBvdGhlciBsaXN0ZW5lcnMgb24gc2FtZSB0YXJnZXQgZnJvbSBiZWluZyBjYWxsZWRcbiAgICogLSBNb3JlIGFnZ3Jlc3NpdmUgdGhhbiBzdG9wUHJvcGFnYXRpb24oKVxuICAgKi9cbiAgc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCkge1xuICAgIHRoaXMucHJvcGFnYXRpb25JbW1lZGlhdGVseVN0b3BwZWQgPSB0cnVlO1xuICB9XG4gIC8qKlxuICAgKiBTdG9wIHRoaXMgZXZlbnQgZnJvbSBwcm9wYWdhdGluZyB0byB0aGUgbmV4dCB0YXJnZXQgaW4gdGhlIHByb3BhZ2F0aW9uIHBhdGguXG4gICAqIFRoZSByZXN0IG9mIHRoZSBsaXN0ZW5lcnMgb24gdGhlIGN1cnJlbnQgdGFyZ2V0IHdpbGwgc3RpbGwgYmUgbm90aWZpZWQuXG4gICAqIEBleGFtcGxlXG4gICAqIGBgYHRzXG4gICAqIGNoaWxkLm9uKCdwb2ludGVybW92ZScsIChldmVudCkgPT4ge1xuICAgKiAgICAgLy8gSGFuZGxlIGV2ZW50IG9uIGNoaWxkXG4gICAqICAgICB1cGRhdGVDaGlsZCgpO1xuICAgKlxuICAgKiAgICAgLy8gUHJldmVudCBwYXJlbnQgaGFuZGxlcnMgZnJvbSBiZWluZyBjYWxsZWRcbiAgICogICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgKiB9KTtcbiAgICpcbiAgICogLy8gVGhpcyB3b24ndCBiZSBjYWxsZWQgaWYgY2hpbGQgaGFuZGxlcyB0aGUgZXZlbnRcbiAgICogcGFyZW50Lm9uKCdwb2ludGVybW92ZScsIChldmVudCkgPT4ge1xuICAgKiAgICAgdXBkYXRlUGFyZW50KCk7XG4gICAqIH0pO1xuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBTdG9wcyBldmVudCBidWJibGluZyB0byBwYXJlbnQgY29udGFpbmVyc1xuICAgKiAtIERvZXMgbm90IHByZXZlbnQgb3RoZXIgbGlzdGVuZXJzIG9uIHNhbWUgdGFyZ2V0XG4gICAqIC0gTGVzcyBhZ2dyZXNzaXZlIHRoYW4gc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKClcbiAgICovXG4gIHN0b3BQcm9wYWdhdGlvbigpIHtcbiAgICB0aGlzLnByb3BhZ2F0aW9uU3RvcHBlZCA9IHRydWU7XG4gIH1cbn1cblxuZXhwb3J0IHsgRmVkZXJhdGVkRXZlbnQgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUZlZGVyYXRlZEV2ZW50Lm1qcy5tYXBcbiIsInZhciBhcHBsZUlwaG9uZSA9IC9pUGhvbmUvaTtcbnZhciBhcHBsZUlwb2QgPSAvaVBvZC9pO1xudmFyIGFwcGxlVGFibGV0ID0gL2lQYWQvaTtcbnZhciBhcHBsZVVuaXZlcnNhbCA9IC9cXGJpT1MtdW5pdmVyc2FsKD86LispTWFjXFxiL2k7XG52YXIgYW5kcm9pZFBob25lID0gL1xcYkFuZHJvaWQoPzouKylNb2JpbGVcXGIvaTtcbnZhciBhbmRyb2lkVGFibGV0ID0gL0FuZHJvaWQvaTtcbnZhciBhbWF6b25QaG9uZSA9IC8oPzpTRDQ5MzBVUnxcXGJTaWxrKD86LispTW9iaWxlXFxiKS9pO1xudmFyIGFtYXpvblRhYmxldCA9IC9TaWxrL2k7XG52YXIgd2luZG93c1Bob25lID0gL1dpbmRvd3MgUGhvbmUvaTtcbnZhciB3aW5kb3dzVGFibGV0ID0gL1xcYldpbmRvd3MoPzouKylBUk1cXGIvaTtcbnZhciBvdGhlckJsYWNrQmVycnkgPSAvQmxhY2tCZXJyeS9pO1xudmFyIG90aGVyQmxhY2tCZXJyeTEwID0gL0JCMTAvaTtcbnZhciBvdGhlck9wZXJhID0gL09wZXJhIE1pbmkvaTtcbnZhciBvdGhlckNocm9tZSA9IC9cXGIoQ3JpT1N8Q2hyb21lKSg/Oi4rKU1vYmlsZS9pO1xudmFyIG90aGVyRmlyZWZveCA9IC9Nb2JpbGUoPzouKylGaXJlZm94XFxiL2k7XG52YXIgaXNBcHBsZVRhYmxldE9uSW9zMTMgPSBmdW5jdGlvbiAobmF2aWdhdG9yKSB7XG4gICAgcmV0dXJuICh0eXBlb2YgbmF2aWdhdG9yICE9PSAndW5kZWZpbmVkJyAmJlxuICAgICAgICBuYXZpZ2F0b3IucGxhdGZvcm0gPT09ICdNYWNJbnRlbCcgJiZcbiAgICAgICAgdHlwZW9mIG5hdmlnYXRvci5tYXhUb3VjaFBvaW50cyA9PT0gJ251bWJlcicgJiZcbiAgICAgICAgbmF2aWdhdG9yLm1heFRvdWNoUG9pbnRzID4gMSAmJlxuICAgICAgICB0eXBlb2YgTVNTdHJlYW0gPT09ICd1bmRlZmluZWQnKTtcbn07XG5mdW5jdGlvbiBjcmVhdGVNYXRjaCh1c2VyQWdlbnQpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gKHJlZ2V4KSB7IHJldHVybiByZWdleC50ZXN0KHVzZXJBZ2VudCk7IH07XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBpc01vYmlsZShwYXJhbSkge1xuICAgIHZhciBuYXYgPSB7XG4gICAgICAgIHVzZXJBZ2VudDogJycsXG4gICAgICAgIHBsYXRmb3JtOiAnJyxcbiAgICAgICAgbWF4VG91Y2hQb2ludHM6IDBcbiAgICB9O1xuICAgIGlmICghcGFyYW0gJiYgdHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgbmF2ID0ge1xuICAgICAgICAgICAgdXNlckFnZW50OiBuYXZpZ2F0b3IudXNlckFnZW50LFxuICAgICAgICAgICAgcGxhdGZvcm06IG5hdmlnYXRvci5wbGF0Zm9ybSxcbiAgICAgICAgICAgIG1heFRvdWNoUG9pbnRzOiBuYXZpZ2F0b3IubWF4VG91Y2hQb2ludHMgfHwgMFxuICAgICAgICB9O1xuICAgIH1cbiAgICBlbHNlIGlmICh0eXBlb2YgcGFyYW0gPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIG5hdi51c2VyQWdlbnQgPSBwYXJhbTtcbiAgICB9XG4gICAgZWxzZSBpZiAocGFyYW0gJiYgcGFyYW0udXNlckFnZW50KSB7XG4gICAgICAgIG5hdiA9IHtcbiAgICAgICAgICAgIHVzZXJBZ2VudDogcGFyYW0udXNlckFnZW50LFxuICAgICAgICAgICAgcGxhdGZvcm06IHBhcmFtLnBsYXRmb3JtLFxuICAgICAgICAgICAgbWF4VG91Y2hQb2ludHM6IHBhcmFtLm1heFRvdWNoUG9pbnRzIHx8IDBcbiAgICAgICAgfTtcbiAgICB9XG4gICAgdmFyIHVzZXJBZ2VudCA9IG5hdi51c2VyQWdlbnQ7XG4gICAgdmFyIHRtcCA9IHVzZXJBZ2VudC5zcGxpdCgnW0ZCQU4nKTtcbiAgICBpZiAodHlwZW9mIHRtcFsxXSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgdXNlckFnZW50ID0gdG1wWzBdO1xuICAgIH1cbiAgICB0bXAgPSB1c2VyQWdlbnQuc3BsaXQoJ1R3aXR0ZXInKTtcbiAgICBpZiAodHlwZW9mIHRtcFsxXSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgdXNlckFnZW50ID0gdG1wWzBdO1xuICAgIH1cbiAgICB2YXIgbWF0Y2ggPSBjcmVhdGVNYXRjaCh1c2VyQWdlbnQpO1xuICAgIHZhciByZXN1bHQgPSB7XG4gICAgICAgIGFwcGxlOiB7XG4gICAgICAgICAgICBwaG9uZTogbWF0Y2goYXBwbGVJcGhvbmUpICYmICFtYXRjaCh3aW5kb3dzUGhvbmUpLFxuICAgICAgICAgICAgaXBvZDogbWF0Y2goYXBwbGVJcG9kKSxcbiAgICAgICAgICAgIHRhYmxldDogIW1hdGNoKGFwcGxlSXBob25lKSAmJlxuICAgICAgICAgICAgICAgIChtYXRjaChhcHBsZVRhYmxldCkgfHwgaXNBcHBsZVRhYmxldE9uSW9zMTMobmF2KSkgJiZcbiAgICAgICAgICAgICAgICAhbWF0Y2god2luZG93c1Bob25lKSxcbiAgICAgICAgICAgIHVuaXZlcnNhbDogbWF0Y2goYXBwbGVVbml2ZXJzYWwpLFxuICAgICAgICAgICAgZGV2aWNlOiAobWF0Y2goYXBwbGVJcGhvbmUpIHx8XG4gICAgICAgICAgICAgICAgbWF0Y2goYXBwbGVJcG9kKSB8fFxuICAgICAgICAgICAgICAgIG1hdGNoKGFwcGxlVGFibGV0KSB8fFxuICAgICAgICAgICAgICAgIG1hdGNoKGFwcGxlVW5pdmVyc2FsKSB8fFxuICAgICAgICAgICAgICAgIGlzQXBwbGVUYWJsZXRPbklvczEzKG5hdikpICYmXG4gICAgICAgICAgICAgICAgIW1hdGNoKHdpbmRvd3NQaG9uZSlcbiAgICAgICAgfSxcbiAgICAgICAgYW1hem9uOiB7XG4gICAgICAgICAgICBwaG9uZTogbWF0Y2goYW1hem9uUGhvbmUpLFxuICAgICAgICAgICAgdGFibGV0OiAhbWF0Y2goYW1hem9uUGhvbmUpICYmIG1hdGNoKGFtYXpvblRhYmxldCksXG4gICAgICAgICAgICBkZXZpY2U6IG1hdGNoKGFtYXpvblBob25lKSB8fCBtYXRjaChhbWF6b25UYWJsZXQpXG4gICAgICAgIH0sXG4gICAgICAgIGFuZHJvaWQ6IHtcbiAgICAgICAgICAgIHBob25lOiAoIW1hdGNoKHdpbmRvd3NQaG9uZSkgJiYgbWF0Y2goYW1hem9uUGhvbmUpKSB8fFxuICAgICAgICAgICAgICAgICghbWF0Y2god2luZG93c1Bob25lKSAmJiBtYXRjaChhbmRyb2lkUGhvbmUpKSxcbiAgICAgICAgICAgIHRhYmxldDogIW1hdGNoKHdpbmRvd3NQaG9uZSkgJiZcbiAgICAgICAgICAgICAgICAhbWF0Y2goYW1hem9uUGhvbmUpICYmXG4gICAgICAgICAgICAgICAgIW1hdGNoKGFuZHJvaWRQaG9uZSkgJiZcbiAgICAgICAgICAgICAgICAobWF0Y2goYW1hem9uVGFibGV0KSB8fCBtYXRjaChhbmRyb2lkVGFibGV0KSksXG4gICAgICAgICAgICBkZXZpY2U6ICghbWF0Y2god2luZG93c1Bob25lKSAmJlxuICAgICAgICAgICAgICAgIChtYXRjaChhbWF6b25QaG9uZSkgfHxcbiAgICAgICAgICAgICAgICAgICAgbWF0Y2goYW1hem9uVGFibGV0KSB8fFxuICAgICAgICAgICAgICAgICAgICBtYXRjaChhbmRyb2lkUGhvbmUpIHx8XG4gICAgICAgICAgICAgICAgICAgIG1hdGNoKGFuZHJvaWRUYWJsZXQpKSkgfHxcbiAgICAgICAgICAgICAgICBtYXRjaCgvXFxib2todHRwXFxiL2kpXG4gICAgICAgIH0sXG4gICAgICAgIHdpbmRvd3M6IHtcbiAgICAgICAgICAgIHBob25lOiBtYXRjaCh3aW5kb3dzUGhvbmUpLFxuICAgICAgICAgICAgdGFibGV0OiBtYXRjaCh3aW5kb3dzVGFibGV0KSxcbiAgICAgICAgICAgIGRldmljZTogbWF0Y2god2luZG93c1Bob25lKSB8fCBtYXRjaCh3aW5kb3dzVGFibGV0KVxuICAgICAgICB9LFxuICAgICAgICBvdGhlcjoge1xuICAgICAgICAgICAgYmxhY2tiZXJyeTogbWF0Y2gob3RoZXJCbGFja0JlcnJ5KSxcbiAgICAgICAgICAgIGJsYWNrYmVycnkxMDogbWF0Y2gob3RoZXJCbGFja0JlcnJ5MTApLFxuICAgICAgICAgICAgb3BlcmE6IG1hdGNoKG90aGVyT3BlcmEpLFxuICAgICAgICAgICAgZmlyZWZveDogbWF0Y2gob3RoZXJGaXJlZm94KSxcbiAgICAgICAgICAgIGNocm9tZTogbWF0Y2gob3RoZXJDaHJvbWUpLFxuICAgICAgICAgICAgZGV2aWNlOiBtYXRjaChvdGhlckJsYWNrQmVycnkpIHx8XG4gICAgICAgICAgICAgICAgbWF0Y2gob3RoZXJCbGFja0JlcnJ5MTApIHx8XG4gICAgICAgICAgICAgICAgbWF0Y2gob3RoZXJPcGVyYSkgfHxcbiAgICAgICAgICAgICAgICBtYXRjaChvdGhlckZpcmVmb3gpIHx8XG4gICAgICAgICAgICAgICAgbWF0Y2gob3RoZXJDaHJvbWUpXG4gICAgICAgIH0sXG4gICAgICAgIGFueTogZmFsc2UsXG4gICAgICAgIHBob25lOiBmYWxzZSxcbiAgICAgICAgdGFibGV0OiBmYWxzZVxuICAgIH07XG4gICAgcmVzdWx0LmFueSA9XG4gICAgICAgIHJlc3VsdC5hcHBsZS5kZXZpY2UgfHxcbiAgICAgICAgICAgIHJlc3VsdC5hbmRyb2lkLmRldmljZSB8fFxuICAgICAgICAgICAgcmVzdWx0LndpbmRvd3MuZGV2aWNlIHx8XG4gICAgICAgICAgICByZXN1bHQub3RoZXIuZGV2aWNlO1xuICAgIHJlc3VsdC5waG9uZSA9XG4gICAgICAgIHJlc3VsdC5hcHBsZS5waG9uZSB8fCByZXN1bHQuYW5kcm9pZC5waG9uZSB8fCByZXN1bHQud2luZG93cy5waG9uZTtcbiAgICByZXN1bHQudGFibGV0ID1cbiAgICAgICAgcmVzdWx0LmFwcGxlLnRhYmxldCB8fCByZXN1bHQuYW5kcm9pZC50YWJsZXQgfHwgcmVzdWx0LndpbmRvd3MudGFibGV0O1xuICAgIHJldHVybiByZXN1bHQ7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pc01vYmlsZS5qcy5tYXAiLCJpbXBvcnQgaXNNb2JpbGVKcyBmcm9tICdpc21vYmlsZWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBpc01vYmlsZUNhbGwgPSBpc01vYmlsZUpzLmRlZmF1bHQgPz8gaXNNb2JpbGVKcztcbmNvbnN0IGlzTW9iaWxlID0gaXNNb2JpbGVDYWxsKGdsb2JhbFRoaXMubmF2aWdhdG9yKTtcblxuZXhwb3J0IHsgaXNNb2JpbGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWlzTW9iaWxlLm1qcy5tYXBcbiIsImltcG9ydCB7IENhbnZhc09ic2VydmVyIH0gZnJvbSAnLi4vZG9tL0NhbnZhc09ic2VydmVyLm1qcyc7XG5pbXBvcnQgeyBGZWRlcmF0ZWRFdmVudCB9IGZyb20gJy4uL2V2ZW50cy9GZWRlcmF0ZWRFdmVudC5tanMnO1xuaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgaXNNb2JpbGUgfSBmcm9tICcuLi91dGlscy9icm93c2VyL2lzTW9iaWxlLm1qcyc7XG5pbXBvcnQgeyByZW1vdmVJdGVtcyB9IGZyb20gJy4uL3V0aWxzL2RhdGEvcmVtb3ZlSXRlbXMubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBLRVlfQ09ERV9UQUIgPSA5O1xuY29uc3QgRElWX1RPVUNIX1NJWkUgPSAxMDA7XG5jb25zdCBESVZfVE9VQ0hfUE9TX1ggPSAwO1xuY29uc3QgRElWX1RPVUNIX1BPU19ZID0gMDtcbmNvbnN0IERJVl9UT1VDSF9aSU5ERVggPSAyO1xuY29uc3QgRElWX0hPT0tfU0laRSA9IDE7XG5jb25zdCBESVZfSE9PS19QT1NfWCA9IC0xZTM7XG5jb25zdCBESVZfSE9PS19QT1NfWSA9IC0xZTM7XG5jb25zdCBESVZfSE9PS19aSU5ERVggPSAyO1xuY29uc3QgX0FjY2Vzc2liaWxpdHlTeXN0ZW0gPSBjbGFzcyBfQWNjZXNzaWJpbGl0eVN5c3RlbSB7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBqc2RvYy9yZXF1aXJlLXBhcmFtXG4gIC8qKlxuICAgKiBAcGFyYW0ge1dlYkdMUmVuZGVyZXJ8V2ViR1BVUmVuZGVyZXJ9IHJlbmRlcmVyIC0gQSByZWZlcmVuY2UgdG8gdGhlIGN1cnJlbnQgcmVuZGVyZXJcbiAgICovXG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyLCBfbW9iaWxlSW5mbyA9IGlzTW9iaWxlKSB7XG4gICAgdGhpcy5fbW9iaWxlSW5mbyA9IF9tb2JpbGVJbmZvO1xuICAgIC8qKiBXaGV0aGVyIGFjY2Vzc2liaWxpdHkgZGl2cyBhcmUgdmlzaWJsZSBmb3IgZGVidWdnaW5nICovXG4gICAgdGhpcy5kZWJ1ZyA9IGZhbHNlO1xuICAgIC8qKiBXaGV0aGVyIHRvIGFjdGl2YXRlIG9uIHRhYiBrZXkgcHJlc3MgKi9cbiAgICB0aGlzLl9hY3RpdmF0ZU9uVGFiID0gdHJ1ZTtcbiAgICAvKiogV2hldGhlciB0byBkZWFjdGl2YXRlIGFjY2Vzc2liaWxpdHkgd2hlbiBtb3VzZSBtb3ZlcyAqL1xuICAgIHRoaXMuX2RlYWN0aXZhdGVPbk1vdXNlTW92ZSA9IHRydWU7XG4gICAgLyoqIEludGVybmFsIHZhcmlhYmxlLCBzZWUgaXNBY3RpdmUgZ2V0dGVyLiAqL1xuICAgIHRoaXMuX2lzQWN0aXZlID0gZmFsc2U7XG4gICAgLyoqIEludGVybmFsIHZhcmlhYmxlLCBzZWUgaXNNb2JpbGVBY2Nlc3NpYmlsaXR5IGdldHRlci4gKi9cbiAgICB0aGlzLl9pc01vYmlsZUFjY2Vzc2liaWxpdHkgPSBmYWxzZTtcbiAgICAvKiogVGhpcyBpcyB0aGUgZG9tIGVsZW1lbnQgdGhhdCB3aWxsIHNpdCBvdmVyIHRoZSBQaXhpSlMgZWxlbWVudC4gVGhpcyBpcyB3aGVyZSB0aGUgZGl2IG92ZXJsYXlzIHdpbGwgZ28uICovXG4gICAgdGhpcy5fZGl2ID0gbnVsbDtcbiAgICAvKiogQSBzaW1wbGUgcG9vbCBmb3Igc3RvcmluZyBkaXZzLiAqL1xuICAgIHRoaXMuX3Bvb2xzID0ge307XG4gICAgLyoqIFRoaXMgaXMgYSB0aWNrIHVzZWQgdG8gY2hlY2sgaWYgYW4gb2JqZWN0IGlzIG5vIGxvbmdlciBiZWluZyByZW5kZXJlZC4gKi9cbiAgICB0aGlzLl9yZW5kZXJJZCA9IDA7XG4gICAgLyoqIFRoZSBhcnJheSBvZiBjdXJyZW50bHkgYWN0aXZlIGFjY2Vzc2libGUgaXRlbXMuICovXG4gICAgdGhpcy5fY2hpbGRyZW4gPSBbXTtcbiAgICAvKiogQ291bnQgdG8gdGhyb3R0bGUgZGl2IHVwZGF0ZXMgb24gYW5kcm9pZCBkZXZpY2VzLiAqL1xuICAgIHRoaXMuX2FuZHJvaWRVcGRhdGVDb3VudCA9IDA7XG4gICAgLyoqICBUaGUgZnJlcXVlbmN5IHRvIHVwZGF0ZSB0aGUgZGl2IGVsZW1lbnRzLiAqL1xuICAgIHRoaXMuX2FuZHJvaWRVcGRhdGVGcmVxdWVuY3kgPSA1MDA7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9wcmVmZXItcmVhZG9ubHlcbiAgICB0aGlzLl9pc1J1bm5pbmdUZXN0cyA9IGZhbHNlO1xuICAgIC8qKiBCb3VuZCBmdW5jdGlvbiByZWZlcmVuY2VzIGZvciBwcm9wZXIgZXZlbnQgbGlzdGVuZXIgcmVtb3ZhbCAqL1xuICAgIHRoaXMuX2JvdW5kT25LZXlEb3duID0gdGhpcy5fb25LZXlEb3duLmJpbmQodGhpcyk7XG4gICAgdGhpcy5fYm91bmRPbk1vdXNlTW92ZSA9IHRoaXMuX29uTW91c2VNb3ZlLmJpbmQodGhpcyk7XG4gICAgdGhpcy5faG9va0RpdiA9IG51bGw7XG4gICAgaWYgKF9tb2JpbGVJbmZvLnRhYmxldCB8fCBfbW9iaWxlSW5mby5waG9uZSkge1xuICAgICAgdGhpcy5fY3JlYXRlVG91Y2hIb29rKCk7XG4gICAgfVxuICAgIHRoaXMuX3JlbmRlcmVyID0gcmVuZGVyZXI7XG4gIH1cbiAgLyoqXG4gICAqIFZhbHVlIG9mIGB0cnVlYCBpZiBhY2Nlc3NpYmlsaXR5IGlzIGN1cnJlbnRseSBhY3RpdmUgYW5kIGFjY2Vzc2liaWxpdHkgbGF5ZXJzIGFyZSBzaG93aW5nLlxuICAgKiBAdHlwZSB7Ym9vbGVhbn1cbiAgICogQHJlYWRvbmx5XG4gICAqL1xuICBnZXQgaXNBY3RpdmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2lzQWN0aXZlO1xuICB9XG4gIC8qKlxuICAgKiBWYWx1ZSBvZiBgdHJ1ZWAgaWYgYWNjZXNzaWJpbGl0eSBpcyBlbmFibGVkIGZvciB0b3VjaCBkZXZpY2VzLlxuICAgKiBAdHlwZSB7Ym9vbGVhbn1cbiAgICogQHJlYWRvbmx5XG4gICAqL1xuICBnZXQgaXNNb2JpbGVBY2Nlc3NpYmlsaXR5KCkge1xuICAgIHJldHVybiB0aGlzLl9pc01vYmlsZUFjY2Vzc2liaWxpdHk7XG4gIH1cbiAgLyoqXG4gICAqIEJ1dHRvbiBlbGVtZW50IGZvciBoYW5kbGluZyB0b3VjaCBob29rcy5cbiAgICogQHJlYWRvbmx5XG4gICAqL1xuICBnZXQgaG9va0RpdigpIHtcbiAgICByZXR1cm4gdGhpcy5faG9va0RpdjtcbiAgfVxuICAvKipcbiAgICogVGhlIERPTSBlbGVtZW50IHRoYXQgd2lsbCBzaXQgb3ZlciB0aGUgUGl4aUpTIGVsZW1lbnQuIFRoaXMgaXMgd2hlcmUgdGhlIGRpdiBvdmVybGF5cyB3aWxsIGdvLlxuICAgKiBAcmVhZG9ubHlcbiAgICovXG4gIGdldCBkaXYoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2RpdjtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyB0aGUgdG91Y2ggaG9va3MuXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfY3JlYXRlVG91Y2hIb29rKCkge1xuICAgIGNvbnN0IGhvb2tEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpO1xuICAgIGhvb2tEaXYuc3R5bGUud2lkdGggPSBgJHtESVZfSE9PS19TSVpFfXB4YDtcbiAgICBob29rRGl2LnN0eWxlLmhlaWdodCA9IGAke0RJVl9IT09LX1NJWkV9cHhgO1xuICAgIGhvb2tEaXYuc3R5bGUucG9zaXRpb24gPSBcImFic29sdXRlXCI7XG4gICAgaG9va0Rpdi5zdHlsZS50b3AgPSBgJHtESVZfSE9PS19QT1NfWH1weGA7XG4gICAgaG9va0Rpdi5zdHlsZS5sZWZ0ID0gYCR7RElWX0hPT0tfUE9TX1l9cHhgO1xuICAgIGhvb2tEaXYuc3R5bGUuekluZGV4ID0gRElWX0hPT0tfWklOREVYLnRvU3RyaW5nKCk7XG4gICAgaG9va0Rpdi5zdHlsZS5iYWNrZ3JvdW5kQ29sb3IgPSBcIiNGRjAwMDBcIjtcbiAgICBob29rRGl2LnRpdGxlID0gXCJzZWxlY3QgdG8gZW5hYmxlIGFjY2Vzc2liaWxpdHkgZm9yIHRoaXMgY29udGVudFwiO1xuICAgIGhvb2tEaXYuYWRkRXZlbnRMaXN0ZW5lcihcImZvY3VzXCIsICgpID0+IHtcbiAgICAgIHRoaXMuX2lzTW9iaWxlQWNjZXNzaWJpbGl0eSA9IHRydWU7XG4gICAgICB0aGlzLl9hY3RpdmF0ZSgpO1xuICAgICAgdGhpcy5fZGVzdHJveVRvdWNoSG9vaygpO1xuICAgIH0pO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoaG9va0Rpdik7XG4gICAgdGhpcy5faG9va0RpdiA9IGhvb2tEaXY7XG4gIH1cbiAgLyoqXG4gICAqIERlc3Ryb3lzIHRoZSB0b3VjaCBob29rcy5cbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9kZXN0cm95VG91Y2hIb29rKCkge1xuICAgIGlmICghdGhpcy5faG9va0Rpdikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKHRoaXMuX2hvb2tEaXYpO1xuICAgIHRoaXMuX2hvb2tEaXYgPSBudWxsO1xuICB9XG4gIC8qKlxuICAgKiBBY3RpdmF0aW5nIHdpbGwgY2F1c2UgdGhlIEFjY2Vzc2liaWxpdHkgbGF5ZXIgdG8gYmUgc2hvd24uXG4gICAqIFRoaXMgaXMgY2FsbGVkIHdoZW4gYSB1c2VyIHByZXNzZXMgdGhlIHRhYiBrZXkuXG4gICAqIEBwcml2YXRlXG4gICAqL1xuICBfYWN0aXZhdGUoKSB7XG4gICAgaWYgKHRoaXMuX2lzQWN0aXZlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuX2lzQWN0aXZlID0gdHJ1ZTtcbiAgICBpZiAoIXRoaXMuX2Rpdikge1xuICAgICAgdGhpcy5fZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgIHRoaXMuX2Rpdi5zdHlsZS5wb3NpdGlvbiA9IFwiYWJzb2x1dGVcIjtcbiAgICAgIHRoaXMuX2Rpdi5zdHlsZS50b3AgPSBgJHtESVZfVE9VQ0hfUE9TX1h9cHhgO1xuICAgICAgdGhpcy5fZGl2LnN0eWxlLmxlZnQgPSBgJHtESVZfVE9VQ0hfUE9TX1l9cHhgO1xuICAgICAgdGhpcy5fZGl2LnN0eWxlLnBvaW50ZXJFdmVudHMgPSBcIm5vbmVcIjtcbiAgICAgIHRoaXMuX2Rpdi5zdHlsZS56SW5kZXggPSBESVZfVE9VQ0hfWklOREVYLnRvU3RyaW5nKCk7XG4gICAgICB0aGlzLl9jYW52YXNPYnNlcnZlciA9IG5ldyBDYW52YXNPYnNlcnZlcih7XG4gICAgICAgIGRvbUVsZW1lbnQ6IHRoaXMuX2RpdixcbiAgICAgICAgcmVuZGVyZXI6IHRoaXMuX3JlbmRlcmVyXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHRoaXMuX2RlYWN0aXZhdGVPbk1vdXNlTW92ZSkge1xuICAgICAgZ2xvYmFsVGhpcy5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwibW91c2Vtb3ZlXCIsIHRoaXMuX2JvdW5kT25Nb3VzZU1vdmUsIHRydWUpO1xuICAgIH1cbiAgICBjb25zdCBjYW52YXMgPSB0aGlzLl9yZW5kZXJlci52aWV3LmNhbnZhcztcbiAgICBpZiAoIWNhbnZhcy5wYXJlbnROb2RlKSB7XG4gICAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKCgpID0+IHtcbiAgICAgICAgaWYgKGNhbnZhcy5wYXJlbnROb2RlKSB7XG4gICAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICAgIHRoaXMuX2NhbnZhc09ic2VydmVyLmVuc3VyZUF0dGFjaGVkKCk7XG4gICAgICAgICAgdGhpcy5faW5pdEFjY2Vzc2liaWxpdHlTZXR1cCgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIG9ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQuYm9keSwgeyBjaGlsZExpc3Q6IHRydWUsIHN1YnRyZWU6IHRydWUgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2NhbnZhc09ic2VydmVyLmVuc3VyZUF0dGFjaGVkKCk7XG4gICAgICB0aGlzLl9pbml0QWNjZXNzaWJpbGl0eVNldHVwKCk7XG4gICAgfVxuICB9XG4gIC8vIE5ldyBtZXRob2QgdG8gaGFuZGxlIGluaXRpYWxpemF0aW9uIGFmdGVyIGRpdiBpcyByZWFkeVxuICBfaW5pdEFjY2Vzc2liaWxpdHlTZXR1cCgpIHtcbiAgICB0aGlzLl9yZW5kZXJlci5ydW5uZXJzLnBvc3RyZW5kZXIuYWRkKHRoaXMpO1xuICAgIGlmICh0aGlzLl9yZW5kZXJlci5sYXN0T2JqZWN0UmVuZGVyZWQpIHtcbiAgICAgIHRoaXMuX3VwZGF0ZUFjY2Vzc2libGVPYmplY3RzKHRoaXMuX3JlbmRlcmVyLmxhc3RPYmplY3RSZW5kZXJlZCk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBEZWFjdGl2YXRlcyB0aGUgYWNjZXNzaWJpbGl0eSBzeXN0ZW0uIFJlbW92ZXMgbGlzdGVuZXJzIGFuZCBhY2Nlc3NpYmlsaXR5IGVsZW1lbnRzLlxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgX2RlYWN0aXZhdGUoKSB7XG4gICAgaWYgKCF0aGlzLl9pc0FjdGl2ZSB8fCB0aGlzLl9pc01vYmlsZUFjY2Vzc2liaWxpdHkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5faXNBY3RpdmUgPSBmYWxzZTtcbiAgICBnbG9iYWxUaGlzLmRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtb3VzZW1vdmVcIiwgdGhpcy5fYm91bmRPbk1vdXNlTW92ZSwgdHJ1ZSk7XG4gICAgdGhpcy5fcmVuZGVyZXIucnVubmVycy5wb3N0cmVuZGVyLnJlbW92ZSh0aGlzKTtcbiAgICBmb3IgKGNvbnN0IGNoaWxkIG9mIHRoaXMuX2NoaWxkcmVuKSB7XG4gICAgICBpZiAoY2hpbGQuX2FjY2Vzc2libGVEaXY/LnBhcmVudE5vZGUpIHtcbiAgICAgICAgY2hpbGQuX2FjY2Vzc2libGVEaXYucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChjaGlsZC5fYWNjZXNzaWJsZURpdik7XG4gICAgICAgIGNoaWxkLl9hY2Nlc3NpYmxlRGl2ID0gbnVsbDtcbiAgICAgIH1cbiAgICAgIGNoaWxkLl9hY2Nlc3NpYmxlQWN0aXZlID0gZmFsc2U7XG4gICAgfVxuICAgIGZvciAoY29uc3QgYWNjZXNzaWJsZVR5cGUgaW4gdGhpcy5fcG9vbHMpIHtcbiAgICAgIGNvbnN0IHBvb2wgPSB0aGlzLl9wb29sc1thY2Nlc3NpYmxlVHlwZV07XG4gICAgICBwb29sLmZvckVhY2goKGRpdikgPT4ge1xuICAgICAgICBpZiAoZGl2LnBhcmVudE5vZGUpIHtcbiAgICAgICAgICBkaXYucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChkaXYpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGRlbGV0ZSB0aGlzLl9wb29sc1thY2Nlc3NpYmxlVHlwZV07XG4gICAgfVxuICAgIGlmICh0aGlzLl9kaXY/LnBhcmVudE5vZGUpIHtcbiAgICAgIHRoaXMuX2Rpdi5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKHRoaXMuX2Rpdik7XG4gICAgfVxuICAgIHRoaXMuX3Bvb2xzID0ge307XG4gICAgdGhpcy5fY2hpbGRyZW4gPSBbXTtcbiAgfVxuICAvKipcbiAgICogVGhpcyByZWN1cnNpdmUgZnVuY3Rpb24gd2lsbCBydW4gdGhyb3VnaCB0aGUgc2NlbmUgZ3JhcGggYW5kIGFkZCBhbnkgbmV3IGFjY2Vzc2libGUgb2JqZWN0cyB0byB0aGUgRE9NIGxheWVyLlxuICAgKiBAcHJpdmF0ZVxuICAgKiBAcGFyYW0ge0NvbnRhaW5lcn0gY29udGFpbmVyIC0gVGhlIENvbnRhaW5lciB0byBjaGVjay5cbiAgICovXG4gIF91cGRhdGVBY2Nlc3NpYmxlT2JqZWN0cyhjb250YWluZXIpIHtcbiAgICBpZiAoIWNvbnRhaW5lci52aXNpYmxlIHx8ICFjb250YWluZXIuYWNjZXNzaWJsZUNoaWxkcmVuKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChjb250YWluZXIuYWNjZXNzaWJsZSkge1xuICAgICAgaWYgKCFjb250YWluZXIuX2FjY2Vzc2libGVBY3RpdmUpIHtcbiAgICAgICAgdGhpcy5fYWRkQ2hpbGQoY29udGFpbmVyKTtcbiAgICAgIH1cbiAgICAgIGNvbnRhaW5lci5fcmVuZGVySWQgPSB0aGlzLl9yZW5kZXJJZDtcbiAgICB9XG4gICAgY29uc3QgY2hpbGRyZW4gPSBjb250YWluZXIuY2hpbGRyZW47XG4gICAgaWYgKGNoaWxkcmVuKSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHRoaXMuX3VwZGF0ZUFjY2Vzc2libGVPYmplY3RzKGNoaWxkcmVuW2ldKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIFJ1bm5lciBpbml0IGNhbGxlZCwgdmlldyBpcyBhdmFpbGFibGUgYXQgdGhpcyBwb2ludC5cbiAgICogQGlnbm9yZVxuICAgKi9cbiAgaW5pdChvcHRpb25zKSB7XG4gICAgY29uc3QgZGVmYXVsdE9wdHMgPSBfQWNjZXNzaWJpbGl0eVN5c3RlbS5kZWZhdWx0T3B0aW9ucztcbiAgICBjb25zdCBtZXJnZWRPcHRpb25zID0ge1xuICAgICAgYWNjZXNzaWJpbGl0eU9wdGlvbnM6IHtcbiAgICAgICAgLi4uZGVmYXVsdE9wdHMsXG4gICAgICAgIC4uLm9wdGlvbnM/LmFjY2Vzc2liaWxpdHlPcHRpb25zIHx8IHt9XG4gICAgICB9XG4gICAgfTtcbiAgICB0aGlzLmRlYnVnID0gbWVyZ2VkT3B0aW9ucy5hY2Nlc3NpYmlsaXR5T3B0aW9ucy5kZWJ1ZztcbiAgICB0aGlzLl9hY3RpdmF0ZU9uVGFiID0gbWVyZ2VkT3B0aW9ucy5hY2Nlc3NpYmlsaXR5T3B0aW9ucy5hY3RpdmF0ZU9uVGFiO1xuICAgIHRoaXMuX2RlYWN0aXZhdGVPbk1vdXNlTW92ZSA9IG1lcmdlZE9wdGlvbnMuYWNjZXNzaWJpbGl0eU9wdGlvbnMuZGVhY3RpdmF0ZU9uTW91c2VNb3ZlO1xuICAgIGlmICh0aGlzLl9hY3RpdmF0ZU9uVGFiKSB7XG4gICAgICBnbG9iYWxUaGlzLmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIHRoaXMuX2JvdW5kT25LZXlEb3duLCBmYWxzZSk7XG4gICAgfVxuICAgIGlmIChtZXJnZWRPcHRpb25zLmFjY2Vzc2liaWxpdHlPcHRpb25zLmVuYWJsZWRCeURlZmF1bHQpIHtcbiAgICAgIHRoaXMuX2FjdGl2YXRlKCk7XG4gICAgfVxuICAgIHRoaXMuX3JlbmRlcmVyLnJ1bm5lcnMucG9zdHJlbmRlci5yZW1vdmUodGhpcyk7XG4gIH1cbiAgLyoqXG4gICAqIFVwZGF0ZXMgdGhlIGFjY2Vzc2liaWxpdHkgbGF5ZXIgZHVyaW5nIHJlbmRlcmluZy5cbiAgICogLSBSZW1vdmVzIGRpdnMgZm9yIGNvbnRhaW5lcnMgbm8gbG9uZ2VyIGluIHRoZSBzY2VuZVxuICAgKiAtIFVwZGF0ZXMgdGhlIHBvc2l0aW9uIGFuZCBkaW1lbnNpb25zIG9mIHRoZSByb290IGRpdlxuICAgKiAtIFVwZGF0ZXMgcG9zaXRpb25zIG9mIGFjdGl2ZSBhY2Nlc3NpYmlsaXR5IGRpdnNcbiAgICogT25seSBmaXJlcyB3aGlsZSB0aGUgYWNjZXNzaWJpbGl0eSBzeXN0ZW0gaXMgYWN0aXZlLlxuICAgKiBAaWdub3JlXG4gICAqL1xuICBwb3N0cmVuZGVyKCkge1xuICAgIGNvbnN0IG5vdyA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgIGlmICh0aGlzLl9tb2JpbGVJbmZvLmFuZHJvaWQuZGV2aWNlICYmIG5vdyA8IHRoaXMuX2FuZHJvaWRVcGRhdGVDb3VudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLl9hbmRyb2lkVXBkYXRlQ291bnQgPSBub3cgKyB0aGlzLl9hbmRyb2lkVXBkYXRlRnJlcXVlbmN5O1xuICAgIGlmICgoIXRoaXMuX3JlbmRlcmVyLnJlbmRlcmluZ1RvU2NyZWVuIHx8ICF0aGlzLl9yZW5kZXJlci52aWV3LmNhbnZhcykgJiYgIXRoaXMuX2lzUnVubmluZ1Rlc3RzKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGFjdGl2ZUlkcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgaWYgKHRoaXMuX3JlbmRlcmVyLmxhc3RPYmplY3RSZW5kZXJlZCkge1xuICAgICAgdGhpcy5fdXBkYXRlQWNjZXNzaWJsZU9iamVjdHModGhpcy5fcmVuZGVyZXIubGFzdE9iamVjdFJlbmRlcmVkKTtcbiAgICAgIGZvciAoY29uc3QgY2hpbGQgb2YgdGhpcy5fY2hpbGRyZW4pIHtcbiAgICAgICAgaWYgKGNoaWxkLl9yZW5kZXJJZCA9PT0gdGhpcy5fcmVuZGVySWQpIHtcbiAgICAgICAgICBhY3RpdmVJZHMuYWRkKHRoaXMuX2NoaWxkcmVuLmluZGV4T2YoY2hpbGQpKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBmb3IgKGxldCBpID0gdGhpcy5fY2hpbGRyZW4ubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgIGNvbnN0IGNoaWxkID0gdGhpcy5fY2hpbGRyZW5baV07XG4gICAgICBpZiAoIWFjdGl2ZUlkcy5oYXMoaSkpIHtcbiAgICAgICAgaWYgKGNoaWxkLl9hY2Nlc3NpYmxlRGl2ICYmIGNoaWxkLl9hY2Nlc3NpYmxlRGl2LnBhcmVudE5vZGUpIHtcbiAgICAgICAgICBjaGlsZC5fYWNjZXNzaWJsZURpdi5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKGNoaWxkLl9hY2Nlc3NpYmxlRGl2KTtcbiAgICAgICAgICBjb25zdCBwb29sID0gdGhpcy5fZ2V0UG9vbChjaGlsZC5hY2Nlc3NpYmxlVHlwZSk7XG4gICAgICAgICAgcG9vbC5wdXNoKGNoaWxkLl9hY2Nlc3NpYmxlRGl2KTtcbiAgICAgICAgICBjaGlsZC5fYWNjZXNzaWJsZURpdiA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgY2hpbGQuX2FjY2Vzc2libGVBY3RpdmUgPSBmYWxzZTtcbiAgICAgICAgcmVtb3ZlSXRlbXModGhpcy5fY2hpbGRyZW4sIGksIDEpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAodGhpcy5fcmVuZGVyZXIucmVuZGVyaW5nVG9TY3JlZW4pIHtcbiAgICAgIHRoaXMuX2NhbnZhc09ic2VydmVyLmVuc3VyZUF0dGFjaGVkKCk7XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGhpcy5fY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGNoaWxkID0gdGhpcy5fY2hpbGRyZW5baV07XG4gICAgICBpZiAoIWNoaWxkLl9hY2Nlc3NpYmxlQWN0aXZlIHx8ICFjaGlsZC5fYWNjZXNzaWJsZURpdikge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRpdiA9IGNoaWxkLl9hY2Nlc3NpYmxlRGl2O1xuICAgICAgY29uc3QgaGl0QXJlYSA9IGNoaWxkLmhpdEFyZWEgfHwgY2hpbGQuZ2V0Qm91bmRzKCkucmVjdGFuZ2xlO1xuICAgICAgaWYgKGNoaWxkLmhpdEFyZWEpIHtcbiAgICAgICAgY29uc3Qgd3QgPSBjaGlsZC53b3JsZFRyYW5zZm9ybTtcbiAgICAgICAgZGl2LnN0eWxlLmxlZnQgPSBgJHt3dC50eCArIGhpdEFyZWEueCAqIHd0LmF9cHhgO1xuICAgICAgICBkaXYuc3R5bGUudG9wID0gYCR7d3QudHkgKyBoaXRBcmVhLnkgKiB3dC5kfXB4YDtcbiAgICAgICAgZGl2LnN0eWxlLndpZHRoID0gYCR7aGl0QXJlYS53aWR0aCAqIHd0LmF9cHhgO1xuICAgICAgICBkaXYuc3R5bGUuaGVpZ2h0ID0gYCR7aGl0QXJlYS5oZWlnaHQgKiB3dC5kfXB4YDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX2NhcEhpdEFyZWEoaGl0QXJlYSk7XG4gICAgICAgIGRpdi5zdHlsZS5sZWZ0ID0gYCR7aGl0QXJlYS54fXB4YDtcbiAgICAgICAgZGl2LnN0eWxlLnRvcCA9IGAke2hpdEFyZWEueX1weGA7XG4gICAgICAgIGRpdi5zdHlsZS53aWR0aCA9IGAke2hpdEFyZWEud2lkdGh9cHhgO1xuICAgICAgICBkaXYuc3R5bGUuaGVpZ2h0ID0gYCR7aGl0QXJlYS5oZWlnaHR9cHhgO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLl9yZW5kZXJJZCsrO1xuICB9XG4gIC8qKlxuICAgKiBwcml2YXRlIGZ1bmN0aW9uIHRoYXQgd2lsbCB2aXN1YWxseSBhZGQgdGhlIGluZm9ybWF0aW9uIHRvIHRoZVxuICAgKiBhY2Nlc3NpYmlsaXR5IGRpdlxuICAgKiBAcGFyYW0ge0hUTUxFbGVtZW50fSBkaXYgLVxuICAgKi9cbiAgX3VwZGF0ZURlYnVnSFRNTChkaXYpIHtcbiAgICBkaXYuaW5uZXJIVE1MID0gYHR5cGU6ICR7ZGl2LnR5cGV9PC9icj4gdGl0bGUgOiAke2Rpdi50aXRsZX08L2JyPiB0YWJJbmRleDogJHtkaXYudGFiSW5kZXh9YDtcbiAgfVxuICAvKipcbiAgICogQWRqdXN0IHRoZSBoaXQgYXJlYSBiYXNlZCBvbiB0aGUgYm91bmRzIG9mIGEgZGlzcGxheSBvYmplY3RcbiAgICogQHBhcmFtIHtSZWN0YW5nbGV9IGhpdEFyZWEgLSBCb3VuZHMgb2YgdGhlIGNoaWxkXG4gICAqL1xuICBfY2FwSGl0QXJlYShoaXRBcmVhKSB7XG4gICAgaWYgKGhpdEFyZWEueCA8IDApIHtcbiAgICAgIGhpdEFyZWEud2lkdGggKz0gaGl0QXJlYS54O1xuICAgICAgaGl0QXJlYS54ID0gMDtcbiAgICB9XG4gICAgaWYgKGhpdEFyZWEueSA8IDApIHtcbiAgICAgIGhpdEFyZWEuaGVpZ2h0ICs9IGhpdEFyZWEueTtcbiAgICAgIGhpdEFyZWEueSA9IDA7XG4gICAgfVxuICAgIGNvbnN0IHsgd2lkdGg6IHZpZXdXaWR0aCwgaGVpZ2h0OiB2aWV3SGVpZ2h0IH0gPSB0aGlzLl9yZW5kZXJlcjtcbiAgICBpZiAoaGl0QXJlYS54ICsgaGl0QXJlYS53aWR0aCA+IHZpZXdXaWR0aCkge1xuICAgICAgaGl0QXJlYS53aWR0aCA9IHZpZXdXaWR0aCAtIGhpdEFyZWEueDtcbiAgICB9XG4gICAgaWYgKGhpdEFyZWEueSArIGhpdEFyZWEuaGVpZ2h0ID4gdmlld0hlaWdodCkge1xuICAgICAgaGl0QXJlYS5oZWlnaHQgPSB2aWV3SGVpZ2h0IC0gaGl0QXJlYS55O1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyBvciByZXVzZXMgYSBkaXYgZWxlbWVudCBmb3IgYSBDb250YWluZXIgYW5kIGFkZHMgaXQgdG8gdGhlIGFjY2Vzc2liaWxpdHkgbGF5ZXIuXG4gICAqIFNldHMgdXAgQVJJQSBhdHRyaWJ1dGVzLCBldmVudCBsaXN0ZW5lcnMsIGFuZCBwb3NpdGlvbmluZyBiYXNlZCBvbiB0aGUgY29udGFpbmVyJ3MgcHJvcGVydGllcy5cbiAgICogQHByaXZhdGVcbiAgICogQHBhcmFtIHtDb250YWluZXJ9IGNvbnRhaW5lciAtIFRoZSBjaGlsZCB0byBtYWtlIGFjY2Vzc2libGUuXG4gICAqL1xuICBfYWRkQ2hpbGQoY29udGFpbmVyKSB7XG4gICAgY29uc3QgcG9vbCA9IHRoaXMuX2dldFBvb2woY29udGFpbmVyLmFjY2Vzc2libGVUeXBlKTtcbiAgICBsZXQgZGl2ID0gcG9vbC5wb3AoKTtcbiAgICBpZiAoZGl2KSB7XG4gICAgICBkaXYuaW5uZXJIVE1MID0gXCJcIjtcbiAgICAgIGRpdi5yZW1vdmVBdHRyaWJ1dGUoXCJ0aXRsZVwiKTtcbiAgICAgIGRpdi5yZW1vdmVBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIpO1xuICAgICAgZGl2LnRhYkluZGV4ID0gMDtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGNvbnRhaW5lci5hY2Nlc3NpYmxlVHlwZSA9PT0gXCJidXR0b25cIikge1xuICAgICAgICBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYnV0dG9uXCIpO1xuICAgICAgICBpZiAoIXRoaXMuZGVidWcpIHtcbiAgICAgICAgICBkaXYuc3R5bGUuY29sb3IgPSBcInRyYW5zcGFyZW50XCI7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoY29udGFpbmVyLmFjY2Vzc2libGVUeXBlKTtcbiAgICAgICAgZGl2LnN0eWxlLmNzc1RleHQgPSBgXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcjogdHJhbnNwYXJlbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBwb2ludGVyLWV2ZW50czogbm9uZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBvdXRsaW5lOiAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgICAgICAgICAgICAgICAgICAgICAgdXNlci1zZWxlY3Q6IG5vbmU7XG4gICAgICAgICAgICAgICAgICAgICAgICAtd2Via2l0LXVzZXItc2VsZWN0OiBub25lO1xuICAgICAgICAgICAgICAgICAgICAgICAgLW1vei11c2VyLXNlbGVjdDogbm9uZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC1tcy11c2VyLXNlbGVjdDogbm9uZTtcbiAgICAgICAgICAgICAgICAgICAgYDtcbiAgICAgIH1cbiAgICAgIGRpdi5zdHlsZS53aWR0aCA9IGAke0RJVl9UT1VDSF9TSVpFfXB4YDtcbiAgICAgIGRpdi5zdHlsZS5oZWlnaHQgPSBgJHtESVZfVE9VQ0hfU0laRX1weGA7XG4gICAgICBkaXYuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gdGhpcy5kZWJ1ZyA/IFwicmdiYSgyNTUsMjU1LDI1NSwwLjUpXCIgOiBcInRyYW5zcGFyZW50XCI7XG4gICAgICBkaXYuc3R5bGUucG9zaXRpb24gPSBcImFic29sdXRlXCI7XG4gICAgICBkaXYuc3R5bGUuekluZGV4ID0gRElWX1RPVUNIX1pJTkRFWC50b1N0cmluZygpO1xuICAgICAgZGl2LnN0eWxlLmJvcmRlclN0eWxlID0gXCJub25lXCI7XG4gICAgICBpZiAobmF2aWdhdG9yLnVzZXJBZ2VudC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKFwiY2hyb21lXCIpKSB7XG4gICAgICAgIGRpdi5zZXRBdHRyaWJ1dGUoXCJhcmlhLWxpdmVcIiwgXCJvZmZcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkaXYuc2V0QXR0cmlidXRlKFwiYXJpYS1saXZlXCIsIFwicG9saXRlXCIpO1xuICAgICAgfVxuICAgICAgaWYgKG5hdmlnYXRvci51c2VyQWdlbnQubWF0Y2goL3J2Oi4qR2Vja29cXC8vKSkge1xuICAgICAgICBkaXYuc2V0QXR0cmlidXRlKFwiYXJpYS1yZWxldmFudFwiLCBcImFkZGl0aW9uc1wiKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRpdi5zZXRBdHRyaWJ1dGUoXCJhcmlhLXJlbGV2YW50XCIsIFwidGV4dFwiKTtcbiAgICAgIH1cbiAgICAgIGRpdi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgdGhpcy5fb25DbGljay5iaW5kKHRoaXMpKTtcbiAgICAgIGRpdi5hZGRFdmVudExpc3RlbmVyKFwiZm9jdXNcIiwgdGhpcy5fb25Gb2N1cy5iaW5kKHRoaXMpKTtcbiAgICAgIGRpdi5hZGRFdmVudExpc3RlbmVyKFwiZm9jdXNvdXRcIiwgdGhpcy5fb25Gb2N1c091dC5iaW5kKHRoaXMpKTtcbiAgICB9XG4gICAgZGl2LnN0eWxlLnBvaW50ZXJFdmVudHMgPSBjb250YWluZXIuYWNjZXNzaWJsZVBvaW50ZXJFdmVudHM7XG4gICAgZGl2LnR5cGUgPSBjb250YWluZXIuYWNjZXNzaWJsZVR5cGU7XG4gICAgaWYgKGNvbnRhaW5lci5hY2Nlc3NpYmxlVGV4dCkge1xuICAgICAgZGl2LmlubmVyVGV4dCA9IGNvbnRhaW5lci5hY2Nlc3NpYmxlVGV4dDtcbiAgICB9XG4gICAgaWYgKGNvbnRhaW5lci5hY2Nlc3NpYmxlVGl0bGUgJiYgY29udGFpbmVyLmFjY2Vzc2libGVUaXRsZSAhPT0gbnVsbCkge1xuICAgICAgZGl2LnRpdGxlID0gY29udGFpbmVyLmFjY2Vzc2libGVUaXRsZTtcbiAgICB9IGVsc2UgaWYgKCFjb250YWluZXIuYWNjZXNzaWJsZUhpbnQgfHwgY29udGFpbmVyLmFjY2Vzc2libGVIaW50ID09PSBudWxsKSB7XG4gICAgICBkaXYudGl0bGUgPSBgY29udGFpbmVyICR7Y29udGFpbmVyLnRhYkluZGV4fWA7XG4gICAgfVxuICAgIGlmIChjb250YWluZXIuYWNjZXNzaWJsZUhpbnQgJiYgY29udGFpbmVyLmFjY2Vzc2libGVIaW50ICE9PSBudWxsKSB7XG4gICAgICBkaXYuc2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbFwiLCBjb250YWluZXIuYWNjZXNzaWJsZUhpbnQpO1xuICAgIH1cbiAgICBpZiAoY29udGFpbmVyLmludGVyYWN0aXZlKSB7XG4gICAgICBkaXYudGFiSW5kZXggPSBjb250YWluZXIudGFiSW5kZXg7XG4gICAgfSBlbHNlIHtcbiAgICAgIGRpdi50YWJJbmRleCA9IDA7XG4gICAgfVxuICAgIGlmICh0aGlzLmRlYnVnKSB7XG4gICAgICB0aGlzLl91cGRhdGVEZWJ1Z0hUTUwoZGl2KTtcbiAgICB9XG4gICAgY29udGFpbmVyLl9hY2Nlc3NpYmxlQWN0aXZlID0gdHJ1ZTtcbiAgICBjb250YWluZXIuX2FjY2Vzc2libGVEaXYgPSBkaXY7XG4gICAgZGl2LmNvbnRhaW5lciA9IGNvbnRhaW5lcjtcbiAgICB0aGlzLl9jaGlsZHJlbi5wdXNoKGNvbnRhaW5lcik7XG4gICAgdGhpcy5fZGl2LmFwcGVuZENoaWxkKGNvbnRhaW5lci5fYWNjZXNzaWJsZURpdik7XG4gIH1cbiAgLyoqXG4gICAqIERpc3BhdGNoIGV2ZW50cyB3aXRoIHRoZSBFdmVudFN5c3RlbS5cbiAgICogQHBhcmFtIGVcbiAgICogQHBhcmFtIHR5cGVcbiAgICogQHByaXZhdGVcbiAgICovXG4gIF9kaXNwYXRjaEV2ZW50KGUsIHR5cGUpIHtcbiAgICBjb25zdCB7IGNvbnRhaW5lcjogdGFyZ2V0IH0gPSBlLnRhcmdldDtcbiAgICBjb25zdCBib3VuZGFyeSA9IHRoaXMuX3JlbmRlcmVyLmV2ZW50cy5yb290Qm91bmRhcnk7XG4gICAgY29uc3QgZXZlbnQgPSBPYmplY3QuYXNzaWduKG5ldyBGZWRlcmF0ZWRFdmVudChib3VuZGFyeSksIHsgdGFyZ2V0IH0pO1xuICAgIGJvdW5kYXJ5LnJvb3RUYXJnZXQgPSB0aGlzLl9yZW5kZXJlci5sYXN0T2JqZWN0UmVuZGVyZWQ7XG4gICAgdHlwZS5mb3JFYWNoKCh0eXBlMikgPT4gYm91bmRhcnkuZGlzcGF0Y2hFdmVudChldmVudCwgdHlwZTIpKTtcbiAgfVxuICAvKipcbiAgICogTWFwcyB0aGUgZGl2IGJ1dHRvbiBwcmVzcyB0byBwaXhpJ3MgRXZlbnRTeXN0ZW0gKGNsaWNrKVxuICAgKiBAcHJpdmF0ZVxuICAgKiBAcGFyYW0ge01vdXNlRXZlbnR9IGUgLSBUaGUgY2xpY2sgZXZlbnQuXG4gICAqL1xuICBfb25DbGljayhlKSB7XG4gICAgdGhpcy5fZGlzcGF0Y2hFdmVudChlLCBbXCJjbGlja1wiLCBcInBvaW50ZXJ0YXBcIiwgXCJ0YXBcIl0pO1xuICB9XG4gIC8qKlxuICAgKiBNYXBzIHRoZSBkaXYgZm9jdXMgZXZlbnRzIHRvIHBpeGkncyBFdmVudFN5c3RlbSAobW91c2VvdmVyKVxuICAgKiBAcHJpdmF0ZVxuICAgKiBAcGFyYW0ge0ZvY3VzRXZlbnR9IGUgLSBUaGUgZm9jdXMgZXZlbnQuXG4gICAqL1xuICBfb25Gb2N1cyhlKSB7XG4gICAgaWYgKCFlLnRhcmdldC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxpdmVcIikpIHtcbiAgICAgIGUudGFyZ2V0LnNldEF0dHJpYnV0ZShcImFyaWEtbGl2ZVwiLCBcImFzc2VydGl2ZVwiKTtcbiAgICB9XG4gICAgdGhpcy5fZGlzcGF0Y2hFdmVudChlLCBbXCJtb3VzZW92ZXJcIl0pO1xuICB9XG4gIC8qKlxuICAgKiBNYXBzIHRoZSBkaXYgZm9jdXMgZXZlbnRzIHRvIHBpeGkncyBFdmVudFN5c3RlbSAobW91c2VvdXQpXG4gICAqIEBwcml2YXRlXG4gICAqIEBwYXJhbSB7Rm9jdXNFdmVudH0gZSAtIFRoZSBmb2N1c291dCBldmVudC5cbiAgICovXG4gIF9vbkZvY3VzT3V0KGUpIHtcbiAgICBpZiAoIWUudGFyZ2V0LmdldEF0dHJpYnV0ZShcImFyaWEtbGl2ZVwiKSkge1xuICAgICAgZS50YXJnZXQuc2V0QXR0cmlidXRlKFwiYXJpYS1saXZlXCIsIFwicG9saXRlXCIpO1xuICAgIH1cbiAgICB0aGlzLl9kaXNwYXRjaEV2ZW50KGUsIFtcIm1vdXNlb3V0XCJdKTtcbiAgfVxuICAvKipcbiAgICogSXMgY2FsbGVkIHdoZW4gYSBrZXkgaXMgcHJlc3NlZFxuICAgKiBAcHJpdmF0ZVxuICAgKiBAcGFyYW0ge0tleWJvYXJkRXZlbnR9IGUgLSBUaGUga2V5ZG93biBldmVudC5cbiAgICovXG4gIF9vbktleURvd24oZSkge1xuICAgIGlmIChlLmtleUNvZGUgIT09IEtFWV9DT0RFX1RBQiB8fCAhdGhpcy5fYWN0aXZhdGVPblRhYikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLl9hY3RpdmF0ZSgpO1xuICB9XG4gIC8qKlxuICAgKiBJcyBjYWxsZWQgd2hlbiB0aGUgbW91c2UgbW92ZXMgYWNyb3NzIHRoZSByZW5kZXJlciBlbGVtZW50XG4gICAqIEBwcml2YXRlXG4gICAqIEBwYXJhbSB7TW91c2VFdmVudH0gZSAtIFRoZSBtb3VzZSBldmVudC5cbiAgICovXG4gIF9vbk1vdXNlTW92ZShlKSB7XG4gICAgaWYgKGUubW92ZW1lbnRYID09PSAwICYmIGUubW92ZW1lbnRZID09PSAwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuX2RlYWN0aXZhdGUoKTtcbiAgfVxuICAvKipcbiAgICogRGVzdHJveXMgdGhlIGFjY2Vzc2liaWxpdHkgc3lzdGVtLiBSZW1vdmVzIGFsbCBlbGVtZW50cyBhbmQgbGlzdGVuZXJzLlxuICAgKiA+IFshSU1QT1JUQU5UXSBUaGlzIGlzIHR5cGljYWxseSBjYWxsZWQgYXV0b21hdGljYWxseSB3aGVuIHRoZSB7QGxpbmsgQXBwbGljYXRpb259IGlzIGRlc3Ryb3llZC5cbiAgICogPiBBIHR5cGljYWxseSB1c2VyIHNob3VsZCBub3QgbmVlZCB0byBjYWxsIHRoaXMgbWV0aG9kIGRpcmVjdGx5LlxuICAgKi9cbiAgZGVzdHJveSgpIHtcbiAgICB0aGlzLl9kZWFjdGl2YXRlKCk7XG4gICAgdGhpcy5fZGVzdHJveVRvdWNoSG9vaygpO1xuICAgIHRoaXMuX2NhbnZhc09ic2VydmVyPy5kZXN0cm95KCk7XG4gICAgdGhpcy5fY2FudmFzT2JzZXJ2ZXIgPSBudWxsO1xuICAgIHRoaXMuX2RpdiA9IG51bGw7XG4gICAgdGhpcy5fcG9vbHMgPSBudWxsO1xuICAgIHRoaXMuX2NoaWxkcmVuID0gbnVsbDtcbiAgICB0aGlzLl9yZW5kZXJlciA9IG51bGw7XG4gICAgdGhpcy5faG9va0RpdiA9IG51bGw7XG4gICAgZ2xvYmFsVGhpcy5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCB0aGlzLl9ib3VuZE9uS2V5RG93bik7XG4gICAgdGhpcy5fYm91bmRPbktleURvd24gPSBudWxsO1xuICAgIGdsb2JhbFRoaXMuZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1vdXNlbW92ZVwiLCB0aGlzLl9ib3VuZE9uTW91c2VNb3ZlLCB0cnVlKTtcbiAgICB0aGlzLl9ib3VuZE9uTW91c2VNb3ZlID0gbnVsbDtcbiAgfVxuICAvKipcbiAgICogRW5hYmxlcyBvciBkaXNhYmxlcyB0aGUgYWNjZXNzaWJpbGl0eSBzeXN0ZW0uXG4gICAqIEBwYXJhbSBlbmFibGVkIC0gV2hldGhlciB0byBlbmFibGUgb3IgZGlzYWJsZSBhY2Nlc3NpYmlsaXR5LlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGBqc1xuICAgKiBhcHAucmVuZGVyZXIuYWNjZXNzaWJpbGl0eS5zZXRBY2Nlc3NpYmlsaXR5RW5hYmxlZCh0cnVlKTsgLy8gRW5hYmxlIGFjY2Vzc2liaWxpdHlcbiAgICogYXBwLnJlbmRlcmVyLmFjY2Vzc2liaWxpdHkuc2V0QWNjZXNzaWJpbGl0eUVuYWJsZWQoZmFsc2UpOyAvLyBEaXNhYmxlIGFjY2Vzc2liaWxpdHlcbiAgICogYGBgXG4gICAqL1xuICBzZXRBY2Nlc3NpYmlsaXR5RW5hYmxlZChlbmFibGVkKSB7XG4gICAgaWYgKGVuYWJsZWQpIHtcbiAgICAgIHRoaXMuX2FjdGl2YXRlKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2RlYWN0aXZhdGUoKTtcbiAgICB9XG4gIH1cbiAgX2dldFBvb2woYWNjZXNzaWJsZVR5cGUpIHtcbiAgICBpZiAoIXRoaXMuX3Bvb2xzW2FjY2Vzc2libGVUeXBlXSkge1xuICAgICAgdGhpcy5fcG9vbHNbYWNjZXNzaWJsZVR5cGVdID0gW107XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9wb29sc1thY2Nlc3NpYmxlVHlwZV07XG4gIH1cbn07XG4vKiogQGlnbm9yZSAqL1xuX0FjY2Vzc2liaWxpdHlTeXN0ZW0uZXh0ZW5zaW9uID0ge1xuICB0eXBlOiBbXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHTFN5c3RlbSxcbiAgICBFeHRlbnNpb25UeXBlLldlYkdQVVN5c3RlbVxuICBdLFxuICBuYW1lOiBcImFjY2Vzc2liaWxpdHlcIlxufTtcbi8qKlxuICogVGhlIGRlZmF1bHQgb3B0aW9ucyB1c2VkIGJ5IHRoZSBzeXN0ZW0uXG4gKiBZb3UgY2FuIHNldCB0aGVzZSBiZWZvcmUgaW5pdGlhbGl6aW5nIHRoZSB7QGxpbmsgQXBwbGljYXRpb259IHRvIGNoYW5nZSB0aGUgZGVmYXVsdCBiZWhhdmlvci5cbiAqIEBleGFtcGxlXG4gKiBgYGBqc1xuICogaW1wb3J0IHsgQWNjZXNzaWJpbGl0eVN5c3RlbSB9IGZyb20gJ3BpeGkuanMnO1xuICpcbiAqIEFjY2Vzc2liaWxpdHlTeXN0ZW0uZGVmYXVsdE9wdGlvbnMuZW5hYmxlZEJ5RGVmYXVsdCA9IHRydWU7XG4gKlxuICogY29uc3QgYXBwID0gbmV3IEFwcGxpY2F0aW9uKClcbiAqIGFwcC5pbml0KClcbiAqIGBgYFxuICovXG5fQWNjZXNzaWJpbGl0eVN5c3RlbS5kZWZhdWx0T3B0aW9ucyA9IHtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gZW5hYmxlIGFjY2Vzc2liaWxpdHkgZmVhdHVyZXMgb24gaW5pdGlhbGl6YXRpb25cbiAgICogQGRlZmF1bHQgZmFsc2VcbiAgICovXG4gIGVuYWJsZWRCeURlZmF1bHQ6IGZhbHNlLFxuICAvKipcbiAgICogV2hldGhlciB0byB2aXN1YWxseSBzaG93IHRoZSBhY2Nlc3NpYmlsaXR5IGRpdnMgZm9yIGRlYnVnZ2luZ1xuICAgKiBAZGVmYXVsdCBmYWxzZVxuICAgKi9cbiAgZGVidWc6IGZhbHNlLFxuICAvKipcbiAgICogV2hldGhlciB0byBhY3RpdmF0ZSBhY2Nlc3NpYmlsaXR5IHdoZW4gdGFiIGtleSBpcyBwcmVzc2VkXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIGFjdGl2YXRlT25UYWI6IHRydWUsXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIGRlYWN0aXZhdGUgYWNjZXNzaWJpbGl0eSB3aGVuIG1vdXNlIG1vdmVzXG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIGRlYWN0aXZhdGVPbk1vdXNlTW92ZTogdHJ1ZVxufTtcbmxldCBBY2Nlc3NpYmlsaXR5U3lzdGVtID0gX0FjY2Vzc2liaWxpdHlTeXN0ZW07XG5cbmV4cG9ydCB7IEFjY2Vzc2liaWxpdHlTeXN0ZW0gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUFjY2Vzc2liaWxpdHlTeXN0ZW0ubWpzLm1hcFxuIiwiXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBhY2Nlc3NpYmlsaXR5VGFyZ2V0ID0ge1xuICBhY2Nlc3NpYmxlOiBmYWxzZSxcbiAgYWNjZXNzaWJsZVRpdGxlOiBudWxsLFxuICBhY2Nlc3NpYmxlSGludDogbnVsbCxcbiAgdGFiSW5kZXg6IDAsXG4gIGFjY2Vzc2libGVUeXBlOiBcImJ1dHRvblwiLFxuICBhY2Nlc3NpYmxlVGV4dDogbnVsbCxcbiAgYWNjZXNzaWJsZVBvaW50ZXJFdmVudHM6IFwiYXV0b1wiLFxuICBhY2Nlc3NpYmxlQ2hpbGRyZW46IHRydWUsXG4gIF9hY2Nlc3NpYmxlQWN0aXZlOiBmYWxzZSxcbiAgX2FjY2Vzc2libGVEaXY6IG51bGwsXG4gIF9yZW5kZXJJZDogLTFcbn07XG5cbmV4cG9ydCB7IGFjY2Vzc2liaWxpdHlUYXJnZXQgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFjY2Vzc2liaWxpdHlUYXJnZXQubWpzLm1hcFxuIiwiaW1wb3J0IHsgRXh0ZW5zaW9uVHlwZSB9IGZyb20gJy4uL2V4dGVuc2lvbnMvRXh0ZW5zaW9ucy5tanMnO1xuaW1wb3J0IHsgQ2FudmFzT2JzZXJ2ZXIgfSBmcm9tICcuL0NhbnZhc09ic2VydmVyLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgRE9NUGlwZSB7XG4gIC8qKlxuICAgKiBDb25zdHJ1Y3RvciBmb3IgdGhlIERPTVBpcGUgY2xhc3MuXG4gICAqIEBwYXJhbSByZW5kZXJlciAtIFRoZSByZW5kZXJlciBpbnN0YW5jZSB0aGF0IHRoaXMgRE9NUGlwZSB3aWxsIGJlIGFzc29jaWF0ZWQgd2l0aC5cbiAgICovXG4gIGNvbnN0cnVjdG9yKHJlbmRlcmVyKSB7XG4gICAgLyoqIEFycmF5IHRvIGtlZXAgdHJhY2sgb2YgYXR0YWNoZWQgRE9NIGVsZW1lbnRzICovXG4gICAgdGhpcy5fYXR0YWNoZWREb21FbGVtZW50cyA9IFtdO1xuICAgIHRoaXMuX3JlbmRlcmVyID0gcmVuZGVyZXI7XG4gICAgdGhpcy5fcmVuZGVyZXIucnVubmVycy5wb3N0cmVuZGVyLmFkZCh0aGlzKTtcbiAgICB0aGlzLl9yZW5kZXJlci5ydW5uZXJzLmluaXQuYWRkKHRoaXMpO1xuICAgIHRoaXMuX2RvbUVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIHRoaXMuX2RvbUVsZW1lbnQuc3R5bGUucG9zaXRpb24gPSBcImFic29sdXRlXCI7XG4gICAgdGhpcy5fZG9tRWxlbWVudC5zdHlsZS50b3AgPSBcIjBcIjtcbiAgICB0aGlzLl9kb21FbGVtZW50LnN0eWxlLmxlZnQgPSBcIjBcIjtcbiAgICB0aGlzLl9kb21FbGVtZW50LnN0eWxlLnBvaW50ZXJFdmVudHMgPSBcIm5vbmVcIjtcbiAgICB0aGlzLl9kb21FbGVtZW50LnN0eWxlLnpJbmRleCA9IFwiMTAwMFwiO1xuICB9XG4gIC8qKiBJbml0aWFsaXplcyB0aGUgRE9NUGlwZSwgc2V0dGluZyB1cCB0aGUgbWFpbiBET00gZWxlbWVudCBhbmQgYWRkaW5nIGl0IHRvIHRoZSBkb2N1bWVudCBib2R5LiAqL1xuICBpbml0KCkge1xuICAgIHRoaXMuX2NhbnZhc09ic2VydmVyID0gbmV3IENhbnZhc09ic2VydmVyKHtcbiAgICAgIGRvbUVsZW1lbnQ6IHRoaXMuX2RvbUVsZW1lbnQsXG4gICAgICByZW5kZXJlcjogdGhpcy5fcmVuZGVyZXJcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogQWRkcyBhIHJlbmRlcmFibGUgRE9NIGNvbnRhaW5lciB0byB0aGUgbGlzdCBvZiBhdHRhY2hlZCBlbGVtZW50cy5cbiAgICogQHBhcmFtIGRvbUNvbnRhaW5lciAtIFRoZSBET00gY29udGFpbmVyIHRvIGJlIGFkZGVkLlxuICAgKiBAcGFyYW0gX2luc3RydWN0aW9uU2V0IC0gVGhlIGluc3RydWN0aW9uIHNldCAodW51c2VkKS5cbiAgICovXG4gIGFkZFJlbmRlcmFibGUoZG9tQ29udGFpbmVyLCBfaW5zdHJ1Y3Rpb25TZXQpIHtcbiAgICBpZiAoIXRoaXMuX2F0dGFjaGVkRG9tRWxlbWVudHMuaW5jbHVkZXMoZG9tQ29udGFpbmVyKSkge1xuICAgICAgdGhpcy5fYXR0YWNoZWREb21FbGVtZW50cy5wdXNoKGRvbUNvbnRhaW5lcik7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBVcGRhdGVzIGEgcmVuZGVyYWJsZSBET00gY29udGFpbmVyLlxuICAgKiBAcGFyYW0gX2RvbUNvbnRhaW5lciAtIFRoZSBET00gY29udGFpbmVyIHRvIGJlIHVwZGF0ZWQgKHVudXNlZCkuXG4gICAqL1xuICB1cGRhdGVSZW5kZXJhYmxlKF9kb21Db250YWluZXIpIHtcbiAgfVxuICAvKipcbiAgICogVmFsaWRhdGVzIGEgcmVuZGVyYWJsZSBET00gY29udGFpbmVyLlxuICAgKiBAcGFyYW0gX2RvbUNvbnRhaW5lciAtIFRoZSBET00gY29udGFpbmVyIHRvIGJlIHZhbGlkYXRlZCAodW51c2VkKS5cbiAgICogQHJldHVybnMgQWx3YXlzIHJldHVybnMgdHJ1ZSBhcyB2YWxpZGF0aW9uIGlzIG5vdCByZXF1aXJlZC5cbiAgICovXG4gIHZhbGlkYXRlUmVuZGVyYWJsZShfZG9tQ29udGFpbmVyKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgLyoqIEhhbmRsZXMgdGhlIHBvc3QtcmVuZGVyaW5nIHByb2Nlc3MsIGVuc3VyaW5nIERPTSBlbGVtZW50cyBhcmUgY29ycmVjdGx5IHBvc2l0aW9uZWQgYW5kIHZpc2libGUuICovXG4gIHBvc3RyZW5kZXIoKSB7XG4gICAgY29uc3QgYXR0YWNoZWREb21FbGVtZW50cyA9IHRoaXMuX2F0dGFjaGVkRG9tRWxlbWVudHM7XG4gICAgaWYgKGF0dGFjaGVkRG9tRWxlbWVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aGlzLl9kb21FbGVtZW50LnJlbW92ZSgpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLl9jYW52YXNPYnNlcnZlci5lbnN1cmVBdHRhY2hlZCgpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYXR0YWNoZWREb21FbGVtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgZG9tQ29udGFpbmVyID0gYXR0YWNoZWREb21FbGVtZW50c1tpXTtcbiAgICAgIGNvbnN0IGVsZW1lbnQgPSBkb21Db250YWluZXIuZWxlbWVudDtcbiAgICAgIGlmICghZG9tQ29udGFpbmVyLnBhcmVudCB8fCBkb21Db250YWluZXIuZ2xvYmFsRGlzcGxheVN0YXR1cyA8IDcpIHtcbiAgICAgICAgZWxlbWVudD8ucmVtb3ZlKCk7XG4gICAgICAgIGF0dGFjaGVkRG9tRWxlbWVudHMuc3BsaWNlKGksIDEpO1xuICAgICAgICBpLS07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoIXRoaXMuX2RvbUVsZW1lbnQuY29udGFpbnMoZWxlbWVudCkpIHtcbiAgICAgICAgICBlbGVtZW50LnN0eWxlLnBvc2l0aW9uID0gXCJhYnNvbHV0ZVwiO1xuICAgICAgICAgIGVsZW1lbnQuc3R5bGUucG9pbnRlckV2ZW50cyA9IFwiYXV0b1wiO1xuICAgICAgICAgIHRoaXMuX2RvbUVsZW1lbnQuYXBwZW5kQ2hpbGQoZWxlbWVudCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgd3QgPSBkb21Db250YWluZXIud29ybGRUcmFuc2Zvcm07XG4gICAgICAgIGNvbnN0IGFuY2hvciA9IGRvbUNvbnRhaW5lci5fYW5jaG9yO1xuICAgICAgICBjb25zdCBheCA9IGRvbUNvbnRhaW5lci53aWR0aCAqIGFuY2hvci54O1xuICAgICAgICBjb25zdCBheSA9IGRvbUNvbnRhaW5lci5oZWlnaHQgKiBhbmNob3IueTtcbiAgICAgICAgZWxlbWVudC5zdHlsZS50cmFuc2Zvcm1PcmlnaW4gPSBgJHtheH1weCAke2F5fXB4YDtcbiAgICAgICAgZWxlbWVudC5zdHlsZS50cmFuc2Zvcm0gPSBgbWF0cml4KCR7d3QuYX0sICR7d3QuYn0sICR7d3QuY30sICR7d3QuZH0sICR7d3QudHggLSBheH0sICR7d3QudHkgLSBheX0pYDtcbiAgICAgICAgZWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gZG9tQ29udGFpbmVyLmdyb3VwQWxwaGEudG9TdHJpbmcoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgLyoqIERlc3Ryb3lzIHRoZSBET01QaXBlLCByZW1vdmluZyBhbGwgYXR0YWNoZWQgRE9NIGVsZW1lbnRzIGFuZCBjbGVhbmluZyB1cCByZXNvdXJjZXMuICovXG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5fcmVuZGVyZXIucnVubmVycy5wb3N0cmVuZGVyLnJlbW92ZSh0aGlzKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMuX2F0dGFjaGVkRG9tRWxlbWVudHMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGRvbUNvbnRhaW5lciA9IHRoaXMuX2F0dGFjaGVkRG9tRWxlbWVudHNbaV07XG4gICAgICBkb21Db250YWluZXIuZWxlbWVudD8ucmVtb3ZlKCk7XG4gICAgfVxuICAgIHRoaXMuX2F0dGFjaGVkRG9tRWxlbWVudHMubGVuZ3RoID0gMDtcbiAgICB0aGlzLl9kb21FbGVtZW50LnJlbW92ZSgpO1xuICAgIHRoaXMuX2NhbnZhc09ic2VydmVyLmRlc3Ryb3koKTtcbiAgICB0aGlzLl9yZW5kZXJlciA9IG51bGw7XG4gIH1cbn1cbi8qKlxuICogU3RhdGljIHByb3BlcnR5IGRlZmluaW5nIHRoZSBleHRlbnNpb24gdHlwZSBhbmQgbmFtZSBmb3IgdGhlIERPTVBpcGUuXG4gKiBUaGlzIGlzIHVzZWQgdG8gcmVnaXN0ZXIgdGhlIERPTVBpcGUgd2l0aCBkaWZmZXJlbnQgcmVuZGVyaW5nIHBpcGVsaW5lcy5cbiAqL1xuRE9NUGlwZS5leHRlbnNpb24gPSB7XG4gIHR5cGU6IFtcbiAgICBFeHRlbnNpb25UeXBlLldlYkdMUGlwZXMsXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHUFVQaXBlcyxcbiAgICBFeHRlbnNpb25UeXBlLkNhbnZhc1BpcGVzXG4gIF0sXG4gIG5hbWU6IFwiZG9tXCJcbn07XG5cbmV4cG9ydCB7IERPTVBpcGUgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPURPTVBpcGUubWpzLm1hcFxuIiwiaW1wb3J0IHsgVVBEQVRFX1BSSU9SSVRZIH0gZnJvbSAnLi4vdGlja2VyL2NvbnN0Lm1qcyc7XG5pbXBvcnQgeyBUaWNrZXIgfSBmcm9tICcuLi90aWNrZXIvVGlja2VyLm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgRXZlbnRzVGlja2VyQ2xhc3Mge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICAvKiogVGhlIGZyZXF1ZW5jeSB0aGF0IGZha2UgZXZlbnRzIHdpbGwgYmUgZmlyZWQuICovXG4gICAgdGhpcy5pbnRlcmFjdGlvbkZyZXF1ZW5jeSA9IDEwO1xuICAgIHRoaXMuX2RlbHRhVGltZSA9IDA7XG4gICAgdGhpcy5fZGlkTW92ZSA9IGZhbHNlO1xuICAgIHRoaXMuX3RpY2tlckFkZGVkID0gZmFsc2U7XG4gICAgdGhpcy5fcGF1c2VVcGRhdGUgPSB0cnVlO1xuICB9XG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyB0aGUgZXZlbnQgdGlja2VyLlxuICAgKiBAcGFyYW0gZXZlbnRzIC0gVGhlIGV2ZW50IHN5c3RlbS5cbiAgICovXG4gIGluaXQoZXZlbnRzKSB7XG4gICAgdGhpcy5yZW1vdmVUaWNrZXJMaXN0ZW5lcigpO1xuICAgIHRoaXMuZXZlbnRzID0gZXZlbnRzO1xuICAgIHRoaXMuaW50ZXJhY3Rpb25GcmVxdWVuY3kgPSAxMDtcbiAgICB0aGlzLl9kZWx0YVRpbWUgPSAwO1xuICAgIHRoaXMuX2RpZE1vdmUgPSBmYWxzZTtcbiAgICB0aGlzLl90aWNrZXJBZGRlZCA9IGZhbHNlO1xuICAgIHRoaXMuX3BhdXNlVXBkYXRlID0gdHJ1ZTtcbiAgfVxuICAvKiogV2hldGhlciB0byBwYXVzZSB0aGUgdXBkYXRlIGNoZWNrcyBvciBub3QuICovXG4gIGdldCBwYXVzZVVwZGF0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fcGF1c2VVcGRhdGU7XG4gIH1cbiAgc2V0IHBhdXNlVXBkYXRlKHBhdXNlZCkge1xuICAgIHRoaXMuX3BhdXNlVXBkYXRlID0gcGF1c2VkO1xuICB9XG4gIC8qKiBBZGRzIHRoZSB0aWNrZXIgbGlzdGVuZXIuICovXG4gIGFkZFRpY2tlckxpc3RlbmVyKCkge1xuICAgIGlmICh0aGlzLl90aWNrZXJBZGRlZCB8fCAhdGhpcy5kb21FbGVtZW50KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIFRpY2tlci5zeXN0ZW0uYWRkKHRoaXMuX3RpY2tlclVwZGF0ZSwgdGhpcywgVVBEQVRFX1BSSU9SSVRZLklOVEVSQUNUSU9OKTtcbiAgICB0aGlzLl90aWNrZXJBZGRlZCA9IHRydWU7XG4gIH1cbiAgLyoqIFJlbW92ZXMgdGhlIHRpY2tlciBsaXN0ZW5lci4gKi9cbiAgcmVtb3ZlVGlja2VyTGlzdGVuZXIoKSB7XG4gICAgaWYgKCF0aGlzLl90aWNrZXJBZGRlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBUaWNrZXIuc3lzdGVtLnJlbW92ZSh0aGlzLl90aWNrZXJVcGRhdGUsIHRoaXMpO1xuICAgIHRoaXMuX3RpY2tlckFkZGVkID0gZmFsc2U7XG4gIH1cbiAgLyoqIFNldHMgZmxhZyB0byBub3QgZmlyZSBleHRyYSBldmVudHMgd2hlbiB0aGUgdXNlciBoYXMgYWxyZWFkeSBtb3ZlZCB0aGVyZSBtb3VzZSAqL1xuICBwb2ludGVyTW92ZWQoKSB7XG4gICAgdGhpcy5fZGlkTW92ZSA9IHRydWU7XG4gIH1cbiAgLyoqIFVwZGF0ZXMgdGhlIHN0YXRlIG9mIGludGVyYWN0aXZlIG9iamVjdHMuICovXG4gIF91cGRhdGUoKSB7XG4gICAgaWYgKCF0aGlzLmRvbUVsZW1lbnQgfHwgdGhpcy5fcGF1c2VVcGRhdGUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHRoaXMuX2RpZE1vdmUpIHtcbiAgICAgIHRoaXMuX2RpZE1vdmUgPSBmYWxzZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgcm9vdFBvaW50ZXJFdmVudCA9IHRoaXMuZXZlbnRzW1wiX3Jvb3RQb2ludGVyRXZlbnRcIl07XG4gICAgaWYgKHRoaXMuZXZlbnRzLnN1cHBvcnRzVG91Y2hFdmVudHMgJiYgcm9vdFBvaW50ZXJFdmVudC5wb2ludGVyVHlwZSA9PT0gXCJ0b3VjaFwiKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGdsb2JhbFRoaXMuZG9jdW1lbnQuZGlzcGF0Y2hFdmVudCh0aGlzLmV2ZW50cy5zdXBwb3J0c1BvaW50ZXJFdmVudHMgPyBuZXcgUG9pbnRlckV2ZW50KFwicG9pbnRlcm1vdmVcIiwge1xuICAgICAgY2xpZW50WDogcm9vdFBvaW50ZXJFdmVudC5jbGllbnRYLFxuICAgICAgY2xpZW50WTogcm9vdFBvaW50ZXJFdmVudC5jbGllbnRZLFxuICAgICAgcG9pbnRlclR5cGU6IHJvb3RQb2ludGVyRXZlbnQucG9pbnRlclR5cGUsXG4gICAgICBwb2ludGVySWQ6IHJvb3RQb2ludGVyRXZlbnQucG9pbnRlcklkXG4gICAgfSkgOiBuZXcgTW91c2VFdmVudChcIm1vdXNlbW92ZVwiLCB7XG4gICAgICBjbGllbnRYOiByb290UG9pbnRlckV2ZW50LmNsaWVudFgsXG4gICAgICBjbGllbnRZOiByb290UG9pbnRlckV2ZW50LmNsaWVudFlcbiAgICB9KSk7XG4gIH1cbiAgLyoqXG4gICAqIFVwZGF0ZXMgdGhlIHN0YXRlIG9mIGludGVyYWN0aXZlIG9iamVjdHMgaWYgYXQgbGVhc3Qge0BsaW5rIGludGVyYWN0aW9uRnJlcXVlbmN5fVxuICAgKiBtaWxsaXNlY29uZHMgaGF2ZSBwYXNzZWQgc2luY2UgdGhlIGxhc3QgaW52b2NhdGlvbi5cbiAgICpcbiAgICogSW52b2tlZCBieSBhIHRocm90dGxlZCB0aWNrZXIgdXBkYXRlIGZyb20ge0BsaW5rIFRpY2tlci5zeXN0ZW19LlxuICAgKiBAcGFyYW0gdGlja2VyIC0gVGhlIHRocm90dGxlZCB0aWNrZXIuXG4gICAqL1xuICBfdGlja2VyVXBkYXRlKHRpY2tlcikge1xuICAgIHRoaXMuX2RlbHRhVGltZSArPSB0aWNrZXIuZGVsdGFUaW1lO1xuICAgIGlmICh0aGlzLl9kZWx0YVRpbWUgPCB0aGlzLmludGVyYWN0aW9uRnJlcXVlbmN5KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuX2RlbHRhVGltZSA9IDA7XG4gICAgdGhpcy5fdXBkYXRlKCk7XG4gIH1cbiAgLyoqIERlc3Ryb3lzIHRoZSBldmVudCB0aWNrZXIuICovXG4gIGRlc3Ryb3koKSB7XG4gICAgdGhpcy5yZW1vdmVUaWNrZXJMaXN0ZW5lcigpO1xuICAgIHRoaXMuZXZlbnRzID0gbnVsbDtcbiAgICB0aGlzLmRvbUVsZW1lbnQgPSBudWxsO1xuICAgIHRoaXMuX2RlbHRhVGltZSA9IDA7XG4gICAgdGhpcy5fZGlkTW92ZSA9IGZhbHNlO1xuICAgIHRoaXMuX3RpY2tlckFkZGVkID0gZmFsc2U7XG4gICAgdGhpcy5fcGF1c2VVcGRhdGUgPSB0cnVlO1xuICB9XG59XG5jb25zdCBFdmVudHNUaWNrZXIgPSBuZXcgRXZlbnRzVGlja2VyQ2xhc3MoKTtcblxuZXhwb3J0IHsgRXZlbnRzVGlja2VyIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1FdmVudFRpY2tlci5tanMubWFwXG4iLCJpbXBvcnQgeyBQb2ludCB9IGZyb20gJy4uL21hdGhzL3BvaW50L1BvaW50Lm1qcyc7XG5pbXBvcnQgeyBGZWRlcmF0ZWRFdmVudCB9IGZyb20gJy4vRmVkZXJhdGVkRXZlbnQubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBGZWRlcmF0ZWRNb3VzZUV2ZW50IGV4dGVuZHMgRmVkZXJhdGVkRXZlbnQge1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgIC8qKiBUaGUgY29vcmRpbmF0ZXMgb2YgdGhlIG1vdXNlIGV2ZW50IHJlbGF0aXZlIHRvIHRoZSBjYW52YXMuICovXG4gICAgdGhpcy5jbGllbnQgPSBuZXcgUG9pbnQoKTtcbiAgICAvKiogVGhlIG1vdmVtZW50IGluIHRoaXMgcG9pbnRlciByZWxhdGl2ZSB0byB0aGUgbGFzdCBgbW91c2Vtb3ZlYCBldmVudC4gKi9cbiAgICB0aGlzLm1vdmVtZW50ID0gbmV3IFBvaW50KCk7XG4gICAgLyoqIFRoZSBvZmZzZXQgb2YgdGhlIHBvaW50ZXIgY29vcmRpbmF0ZXMgdy5yLnQuIHRhcmdldCBDb250YWluZXIgaW4gd29ybGQgc3BhY2UuIFRoaXMgaXMgbm90IHN1cHBvcnRlZCBhdCB0aGUgbW9tZW50LiAqL1xuICAgIHRoaXMub2Zmc2V0ID0gbmV3IFBvaW50KCk7XG4gICAgLyoqIFRoZSBwb2ludGVyIGNvb3JkaW5hdGVzIGluIHdvcmxkIHNwYWNlLiAqL1xuICAgIHRoaXMuZ2xvYmFsID0gbmV3IFBvaW50KCk7XG4gICAgLyoqXG4gICAgICogVGhlIHBvaW50ZXIgY29vcmRpbmF0ZXMgaW4gdGhlIHJlbmRlcmVyJ3Mge0BsaW5rIEFic3RyYWN0UmVuZGVyZXIuc2NyZWVuIHNjcmVlbn0uIFRoaXMgaGFzIHNsaWdodGx5XG4gICAgICogZGlmZmVyZW50IHNlbWFudGljcyB0aGFuIG5hdGl2ZSBQb2ludGVyRXZlbnQgc2NyZWVuWC9zY3JlZW5ZLlxuICAgICAqL1xuICAgIHRoaXMuc2NyZWVuID0gbmV3IFBvaW50KCk7XG4gIH1cbiAgLyoqIEByZWFkb25seSAqL1xuICBnZXQgY2xpZW50WCgpIHtcbiAgICByZXR1cm4gdGhpcy5jbGllbnQueDtcbiAgfVxuICAvKiogQHJlYWRvbmx5ICovXG4gIGdldCBjbGllbnRZKCkge1xuICAgIHJldHVybiB0aGlzLmNsaWVudC55O1xuICB9XG4gIC8qKlxuICAgKiBBbGlhcyBmb3Ige0BsaW5rIEZlZGVyYXRlZE1vdXNlRXZlbnQuY2xpZW50WCB0aGlzLmNsaWVudFh9LlxuICAgKiBAcmVhZG9ubHlcbiAgICovXG4gIGdldCB4KCkge1xuICAgIHJldHVybiB0aGlzLmNsaWVudFg7XG4gIH1cbiAgLyoqXG4gICAqIEFsaWFzIGZvciB7QGxpbmsgRmVkZXJhdGVkTW91c2VFdmVudC5jbGllbnRZIHRoaXMuY2xpZW50WX0uXG4gICAqIEByZWFkb25seVxuICAgKi9cbiAgZ2V0IHkoKSB7XG4gICAgcmV0dXJuIHRoaXMuY2xpZW50WTtcbiAgfVxuICAvKiogQHJlYWRvbmx5ICovXG4gIGdldCBtb3ZlbWVudFgoKSB7XG4gICAgcmV0dXJuIHRoaXMubW92ZW1lbnQueDtcbiAgfVxuICAvKiogQHJlYWRvbmx5ICovXG4gIGdldCBtb3ZlbWVudFkoKSB7XG4gICAgcmV0dXJuIHRoaXMubW92ZW1lbnQueTtcbiAgfVxuICAvKiogQHJlYWRvbmx5ICovXG4gIGdldCBvZmZzZXRYKCkge1xuICAgIHJldHVybiB0aGlzLm9mZnNldC54O1xuICB9XG4gIC8qKiBAcmVhZG9ubHkgKi9cbiAgZ2V0IG9mZnNldFkoKSB7XG4gICAgcmV0dXJuIHRoaXMub2Zmc2V0Lnk7XG4gIH1cbiAgLyoqIEByZWFkb25seSAqL1xuICBnZXQgZ2xvYmFsWCgpIHtcbiAgICByZXR1cm4gdGhpcy5nbG9iYWwueDtcbiAgfVxuICAvKiogQHJlYWRvbmx5ICovXG4gIGdldCBnbG9iYWxZKCkge1xuICAgIHJldHVybiB0aGlzLmdsb2JhbC55O1xuICB9XG4gIC8qKlxuICAgKiBUaGUgcG9pbnRlciBjb29yZGluYXRlcyBpbiB0aGUgcmVuZGVyZXIncyBzY3JlZW4uIEFsaWFzIGZvciBgc2NyZWVuLnhgLlxuICAgKiBAcmVhZG9ubHlcbiAgICovXG4gIGdldCBzY3JlZW5YKCkge1xuICAgIHJldHVybiB0aGlzLnNjcmVlbi54O1xuICB9XG4gIC8qKlxuICAgKiBUaGUgcG9pbnRlciBjb29yZGluYXRlcyBpbiB0aGUgcmVuZGVyZXIncyBzY3JlZW4uIEFsaWFzIGZvciBgc2NyZWVuLnlgLlxuICAgKiBAcmVhZG9ubHlcbiAgICovXG4gIGdldCBzY3JlZW5ZKCkge1xuICAgIHJldHVybiB0aGlzLnNjcmVlbi55O1xuICB9XG4gIC8qKlxuICAgKiBDb252ZXJ0cyBnbG9iYWwgY29vcmRpbmF0ZXMgaW50byBjb250YWluZXItbG9jYWwgY29vcmRpbmF0ZXMuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHRyYW5zZm9ybXMgY29vcmRpbmF0ZXMgZnJvbSB3b3JsZCBzcGFjZSB0byBhIGNvbnRhaW5lcidzIGxvY2FsIHNwYWNlLFxuICAgKiB1c2VmdWwgZm9yIHByZWNpc2UgcG9zaXRpb25pbmcgYW5kIGhpdCB0ZXN0aW5nLlxuICAgKiBAcGFyYW0gY29udGFpbmVyIC0gVGhlIENvbnRhaW5lciB0byBnZXQgbG9jYWwgY29vcmRpbmF0ZXMgZm9yXG4gICAqIEBwYXJhbSBwb2ludCAtIE9wdGlvbmFsIFBvaW50IG9iamVjdCB0byBzdG9yZSB0aGUgcmVzdWx0LiBJZiBub3QgcHJvdmlkZWQsIGEgbmV3IFBvaW50IHdpbGwgYmUgY3JlYXRlZFxuICAgKiBAcGFyYW0gZ2xvYmFsUG9zIC0gT3B0aW9uYWwgY3VzdG9tIGdsb2JhbCBjb29yZGluYXRlcy4gSWYgbm90IHByb3ZpZGVkLCB0aGUgZXZlbnQncyBnbG9iYWwgcG9zaXRpb24gaXMgdXNlZFxuICAgKiBAcmV0dXJucyBUaGUgbG9jYWwgY29vcmRpbmF0ZXMgYXMgYSBQb2ludCBvYmplY3RcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gQmFzaWMgdXNhZ2UgLSBnZXQgbG9jYWwgY29vcmRpbmF0ZXMgcmVsYXRpdmUgdG8gYSBjb250YWluZXJcbiAgICogc3ByaXRlLm9uKCdwb2ludGVybW92ZScsIChldmVudDogRmVkZXJhdGVkTW91c2VFdmVudCkgPT4ge1xuICAgKiAgICAgLy8gR2V0IHBvc2l0aW9uIHJlbGF0aXZlIHRvIHRoZSBzcHJpdGVcbiAgICogICAgIGNvbnN0IGxvY2FsUG9zID0gZXZlbnQuZ2V0TG9jYWxQb3NpdGlvbihzcHJpdGUpO1xuICAgKiAgICAgY29uc29sZS5sb2coJ0xvY2FsIHBvc2l0aW9uOicsIGxvY2FsUG9zLngsIGxvY2FsUG9zLnkpO1xuICAgKiB9KTtcbiAgICogLy8gVXNpbmcgY3VzdG9tIGdsb2JhbCBjb29yZGluYXRlc1xuICAgKiBjb25zdCBjdXN0b21HbG9iYWwgPSBuZXcgUG9pbnQoMTAwLCAxMDApO1xuICAgKiBzcHJpdGUub24oJ3BvaW50ZXJtb3ZlJywgKGV2ZW50OiBGZWRlcmF0ZWRNb3VzZUV2ZW50KSA9PiB7XG4gICAqICAgICAvLyBUcmFuc2Zvcm0gY3VzdG9tIGNvb3JkaW5hdGVzXG4gICAqICAgICBjb25zdCBsb2NhbFBvcyA9IGV2ZW50LmdldExvY2FsUG9zaXRpb24oc3ByaXRlLCB1bmRlZmluZWQsIGN1c3RvbUdsb2JhbCk7XG4gICAqICAgICBjb25zb2xlLmxvZygnQ3VzdG9tIGxvY2FsIHBvc2l0aW9uOicsIGxvY2FsUG9zLngsIGxvY2FsUG9zLnkpO1xuICAgKiB9KTtcbiAgICogYGBgXG4gICAqIEBzZWUge0BsaW5rIENvbnRhaW5lci53b3JsZFRyYW5zZm9ybX0gRm9yIHRoZSB0cmFuc2Zvcm1hdGlvbiBtYXRyaXhcbiAgICogQHNlZSB7QGxpbmsgUG9pbnR9IEZvciB0aGUgcG9pbnQgY2xhc3MgdXNlZCB0byBzdG9yZSBjb29yZGluYXRlc1xuICAgKi9cbiAgZ2V0TG9jYWxQb3NpdGlvbihjb250YWluZXIsIHBvaW50LCBnbG9iYWxQb3MpIHtcbiAgICByZXR1cm4gY29udGFpbmVyLndvcmxkVHJhbnNmb3JtLmFwcGx5SW52ZXJzZShnbG9iYWxQb3MgfHwgdGhpcy5nbG9iYWwsIHBvaW50KTtcbiAgfVxuICAvKipcbiAgICogV2hldGhlciB0aGUgbW9kaWZpZXIga2V5IHdhcyBwcmVzc2VkIHdoZW4gdGhpcyBldmVudCBuYXRpdmVseSBvY2N1cnJlZC5cbiAgICogQHBhcmFtIGtleSAtIFRoZSBtb2RpZmllciBrZXkuXG4gICAqL1xuICBnZXRNb2RpZmllclN0YXRlKGtleSkge1xuICAgIHJldHVybiBcImdldE1vZGlmaWVyU3RhdGVcIiBpbiB0aGlzLm5hdGl2ZUV2ZW50ICYmIHRoaXMubmF0aXZlRXZlbnQuZ2V0TW9kaWZpZXJTdGF0ZShrZXkpO1xuICB9XG4gIC8qKlxuICAgKiBOb3Qgc3VwcG9ydGVkLlxuICAgKiBAcGFyYW0gX3R5cGVBcmdcbiAgICogQHBhcmFtIF9jYW5CdWJibGVBcmdcbiAgICogQHBhcmFtIF9jYW5jZWxhYmxlQXJnXG4gICAqIEBwYXJhbSBfdmlld0FyZ1xuICAgKiBAcGFyYW0gX2RldGFpbEFyZ1xuICAgKiBAcGFyYW0gX3NjcmVlblhBcmdcbiAgICogQHBhcmFtIF9zY3JlZW5ZQXJnXG4gICAqIEBwYXJhbSBfY2xpZW50WEFyZ1xuICAgKiBAcGFyYW0gX2NsaWVudFlBcmdcbiAgICogQHBhcmFtIF9jdHJsS2V5QXJnXG4gICAqIEBwYXJhbSBfYWx0S2V5QXJnXG4gICAqIEBwYXJhbSBfc2hpZnRLZXlBcmdcbiAgICogQHBhcmFtIF9tZXRhS2V5QXJnXG4gICAqIEBwYXJhbSBfYnV0dG9uQXJnXG4gICAqIEBwYXJhbSBfcmVsYXRlZFRhcmdldEFyZ1xuICAgKiBAZGVwcmVjYXRlZCBzaW5jZSA3LjAuMFxuICAgKiBAaWdub3JlXG4gICAqL1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbWF4LXBhcmFtc1xuICBpbml0TW91c2VFdmVudChfdHlwZUFyZywgX2NhbkJ1YmJsZUFyZywgX2NhbmNlbGFibGVBcmcsIF92aWV3QXJnLCBfZGV0YWlsQXJnLCBfc2NyZWVuWEFyZywgX3NjcmVlbllBcmcsIF9jbGllbnRYQXJnLCBfY2xpZW50WUFyZywgX2N0cmxLZXlBcmcsIF9hbHRLZXlBcmcsIF9zaGlmdEtleUFyZywgX21ldGFLZXlBcmcsIF9idXR0b25BcmcsIF9yZWxhdGVkVGFyZ2V0QXJnKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiTWV0aG9kIG5vdCBpbXBsZW1lbnRlZC5cIik7XG4gIH1cbn1cblxuZXhwb3J0IHsgRmVkZXJhdGVkTW91c2VFdmVudCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9RmVkZXJhdGVkTW91c2VFdmVudC5tanMubWFwXG4iLCJpbXBvcnQgeyBGZWRlcmF0ZWRNb3VzZUV2ZW50IH0gZnJvbSAnLi9GZWRlcmF0ZWRNb3VzZUV2ZW50Lm1qcyc7XG5cblwidXNlIHN0cmljdFwiO1xuY2xhc3MgRmVkZXJhdGVkUG9pbnRlckV2ZW50IGV4dGVuZHMgRmVkZXJhdGVkTW91c2VFdmVudCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgLyoqXG4gICAgICogVGhlIHdpZHRoIG9mIHRoZSBwb2ludGVyJ3MgY29udGFjdCBhbG9uZyB0aGUgeC1heGlzLCBtZWFzdXJlZCBpbiBDU1MgcGl4ZWxzLlxuICAgICAqIHJhZGl1c1ggb2YgVG91Y2hFdmVudHMgd2lsbCBiZSByZXByZXNlbnRlZCBieSB0aGlzIHZhbHVlLlxuICAgICAqIEBzZWUgaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL1BvaW50ZXJFdmVudC93aWR0aFxuICAgICAqL1xuICAgIHRoaXMud2lkdGggPSAwO1xuICAgIC8qKlxuICAgICAqIFRoZSBoZWlnaHQgb2YgdGhlIHBvaW50ZXIncyBjb250YWN0IGFsb25nIHRoZSB5LWF4aXMsIG1lYXN1cmVkIGluIENTUyBwaXhlbHMuXG4gICAgICogcmFkaXVzWSBvZiBUb3VjaEV2ZW50cyB3aWxsIGJlIHJlcHJlc2VudGVkIGJ5IHRoaXMgdmFsdWUuXG4gICAgICogQHNlZSBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvUG9pbnRlckV2ZW50L2hlaWdodFxuICAgICAqL1xuICAgIHRoaXMuaGVpZ2h0ID0gMDtcbiAgICAvKipcbiAgICAgKiBJbmRpY2F0ZXMgd2hldGhlciBvciBub3QgdGhlIHBvaW50ZXIgZGV2aWNlIHRoYXQgY3JlYXRlZCB0aGUgZXZlbnQgaXMgdGhlIHByaW1hcnkgcG9pbnRlci5cbiAgICAgKiBAc2VlIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9Qb2ludGVyRXZlbnQvaXNQcmltYXJ5XG4gICAgICovXG4gICAgdGhpcy5pc1ByaW1hcnkgPSBmYWxzZTtcbiAgICAvKipcbiAgICAgKiBBIHVuaXF1ZSBpZGVudGlmaWVyIGZvciB0aGUgcG9pbnRpbmcgZGV2aWNlIGdlbmVyYXRpbmcgdGhlIGV2ZW50LCB0aGF0IHBlcnNpc3RzIGFjcm9zcyBldmVudHMuXG4gICAgICogQHNlZSBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvUG9pbnRlckV2ZW50L3BlcnNpc3RlbnREZXZpY2VJZFxuICAgICAqL1xuICAgIHRoaXMucGVyc2lzdGVudERldmljZUlkID0gMDtcbiAgfVxuICAvKipcbiAgICogT25seSBpbmNsdWRlZCBmb3IgY29tcGxldGVuZXNzIGZvciBub3dcbiAgICogQGlnbm9yZVxuICAgKi9cbiAgZ2V0Q29hbGVzY2VkRXZlbnRzKCkge1xuICAgIGlmICh0aGlzLnR5cGUgPT09IFwicG9pbnRlcm1vdmVcIiB8fCB0aGlzLnR5cGUgPT09IFwibW91c2Vtb3ZlXCIgfHwgdGhpcy50eXBlID09PSBcInRvdWNobW92ZVwiKSB7XG4gICAgICByZXR1cm4gW3RoaXNdO1xuICAgIH1cbiAgICByZXR1cm4gW107XG4gIH1cbiAgLyoqXG4gICAqIE9ubHkgaW5jbHVkZWQgZm9yIGNvbXBsZXRlbmVzcyBmb3Igbm93XG4gICAqIEBpZ25vcmVcbiAgICovXG4gIGdldFByZWRpY3RlZEV2ZW50cygpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJnZXRQcmVkaWN0ZWRFdmVudHMgaXMgbm90IHN1cHBvcnRlZCFcIik7XG4gIH1cbn1cblxuZXhwb3J0IHsgRmVkZXJhdGVkUG9pbnRlckV2ZW50IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1GZWRlcmF0ZWRQb2ludGVyRXZlbnQubWpzLm1hcFxuIiwiaW1wb3J0IHsgRmVkZXJhdGVkTW91c2VFdmVudCB9IGZyb20gJy4vRmVkZXJhdGVkTW91c2VFdmVudC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNsYXNzIEZlZGVyYXRlZFdoZWVsRXZlbnQgZXh0ZW5kcyBGZWRlcmF0ZWRNb3VzZUV2ZW50IHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAvKipcbiAgICAgKiBVbml0cyBzcGVjaWZpZWQgaW4gcGl4ZWxzLlxuICAgICAqIEBpZ25vcmVcbiAgICAgKi9cbiAgICB0aGlzLkRPTV9ERUxUQV9QSVhFTCA9IDA7XG4gICAgLyoqXG4gICAgICogVW5pdHMgc3BlY2lmaWVkIGluIGxpbmVzLlxuICAgICAqIEBpZ25vcmVcbiAgICAgKi9cbiAgICB0aGlzLkRPTV9ERUxUQV9MSU5FID0gMTtcbiAgICAvKipcbiAgICAgKiBVbml0cyBzcGVjaWZpZWQgaW4gcGFnZXMuXG4gICAgICogQGlnbm9yZVxuICAgICAqL1xuICAgIHRoaXMuRE9NX0RFTFRBX1BBR0UgPSAyO1xuICB9XG59XG4vKipcbiAqIFVuaXRzIHNwZWNpZmllZCBpbiBwaXhlbHMuXG4gKiBAaWdub3JlXG4gKi9cbkZlZGVyYXRlZFdoZWVsRXZlbnQuRE9NX0RFTFRBX1BJWEVMID0gMDtcbi8qKlxuICogVW5pdHMgc3BlY2lmaWVkIGluIGxpbmVzLlxuICogQGlnbm9yZVxuICovXG5GZWRlcmF0ZWRXaGVlbEV2ZW50LkRPTV9ERUxUQV9MSU5FID0gMTtcbi8qKlxuICogVW5pdHMgc3BlY2lmaWVkIGluIHBhZ2VzLlxuICogQGlnbm9yZVxuICovXG5GZWRlcmF0ZWRXaGVlbEV2ZW50LkRPTV9ERUxUQV9QQUdFID0gMjtcblxuZXhwb3J0IHsgRmVkZXJhdGVkV2hlZWxFdmVudCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9RmVkZXJhdGVkV2hlZWxFdmVudC5tanMubWFwXG4iLCJpbXBvcnQgRXZlbnRFbWl0dGVyIGZyb20gJ2V2ZW50ZW1pdHRlcjMnO1xuaW1wb3J0IHsgUG9pbnQgfSBmcm9tICcuLi9tYXRocy9wb2ludC9Qb2ludC5tanMnO1xuaW1wb3J0IHsgd2FybiB9IGZyb20gJy4uL3V0aWxzL2xvZ2dpbmcvd2Fybi5tanMnO1xuaW1wb3J0IHsgRXZlbnRzVGlja2VyIH0gZnJvbSAnLi9FdmVudFRpY2tlci5tanMnO1xuaW1wb3J0IHsgRmVkZXJhdGVkTW91c2VFdmVudCB9IGZyb20gJy4vRmVkZXJhdGVkTW91c2VFdmVudC5tanMnO1xuaW1wb3J0IHsgRmVkZXJhdGVkUG9pbnRlckV2ZW50IH0gZnJvbSAnLi9GZWRlcmF0ZWRQb2ludGVyRXZlbnQubWpzJztcbmltcG9ydCB7IEZlZGVyYXRlZFdoZWVsRXZlbnQgfSBmcm9tICcuL0ZlZGVyYXRlZFdoZWVsRXZlbnQubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jb25zdCBQUk9QQUdBVElPTl9MSU1JVCA9IDIwNDg7XG5jb25zdCB0ZW1wSGl0TG9jYXRpb24gPSBuZXcgUG9pbnQoKTtcbmNvbnN0IHRlbXBMb2NhbE1hcHBpbmcgPSBuZXcgUG9pbnQoKTtcbmNsYXNzIEV2ZW50Qm91bmRhcnkge1xuICAvKipcbiAgICogQHBhcmFtIHJvb3RUYXJnZXQgLSBUaGUgaG9sZGVyIG9mIHRoZSBldmVudCBib3VuZGFyeS5cbiAgICovXG4gIGNvbnN0cnVjdG9yKHJvb3RUYXJnZXQpIHtcbiAgICAvKipcbiAgICAgKiBFbWl0cyBldmVudHMgYWZ0ZXIgdGhleSB3ZXJlIGRpc3BhdGNoZWQgaW50byB0aGUgc2NlbmUgZ3JhcGguXG4gICAgICpcbiAgICAgKiBUaGlzIGNhbiBiZSB1c2VkIGZvciBnbG9iYWwgZXZlbnRzIGxpc3RlbmluZywgcmVnYXJkbGVzcyBvZiB0aGUgc2NlbmUgZ3JhcGggYmVpbmcgdXNlZC4gSXQgc2hvdWxkXG4gICAgICogbm90IGJlIHVzZWQgYnkgaW50ZXJhY3RpdmUgbGlicmFyaWVzIGZvciBub3JtYWwgdXNlLlxuICAgICAqXG4gICAgICogU3BlY2lhbCBldmVudHMgdGhhdCBkbyBub3QgYnViYmxlIGFsbCB0aGUgd2F5IHRvIHRoZSByb290IHRhcmdldCBhcmUgbm90IGVtaXR0ZWQgZnJvbSBoZXJlLFxuICAgICAqIGUuZy4gcG9pbnRlcmVudGVyLCBwb2ludGVybGVhdmUsIGNsaWNrLlxuICAgICAqL1xuICAgIHRoaXMuZGlzcGF0Y2ggPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gICAgLyoqXG4gICAgICogVGhpcyBmbGFnIHdvdWxkIGVtaXQgYHBvaW50ZXJtb3ZlYCwgYHRvdWNobW92ZWAsIGFuZCBgbW91c2Vtb3ZlYCBldmVudHMgb24gYWxsIENvbnRhaW5lcnMuXG4gICAgICpcbiAgICAgKiBUaGUgYG1vdmVPbkFsbGAgc2VtYW50aWNzIG1pcnJvciB0aG9zZSBvZiBlYXJsaWVyIHZlcnNpb25zIG9mIFBpeGlKUy4gVGhpcyB3YXMgZGlzYWJsZWQgaW4gZmF2b3Igb2ZcbiAgICAgKiB0aGUgUG9pbnRlciBFdmVudCBBUEkncyBhcHByb2FjaC5cbiAgICAgKi9cbiAgICB0aGlzLm1vdmVPbkFsbCA9IGZhbHNlO1xuICAgIC8qKiBFbmFibGVzIHRoZSBnbG9iYWwgbW92ZSBldmVudHMuIGBnbG9iYWxwb2ludGVybW92ZWAsIGBnbG9iYWx0b3VjaG1vdmVgLCBhbmQgYGdsb2JhbG1vdXNlbW92ZWAgKi9cbiAgICB0aGlzLmVuYWJsZUdsb2JhbE1vdmVFdmVudHMgPSB0cnVlO1xuICAgIC8qKlxuICAgICAqIFN0YXRlIG9iamVjdCBmb3IgbWFwcGluZyBtZXRob2RzLlxuICAgICAqIEBzZWUgRXZlbnRCb3VuZGFyeSN0cmFja2luZ0RhdGFcbiAgICAgKi9cbiAgICB0aGlzLm1hcHBpbmdTdGF0ZSA9IHtcbiAgICAgIHRyYWNraW5nRGF0YToge31cbiAgICB9O1xuICAgIC8qKlxuICAgICAqIFRoZSBldmVudCBwb29sIG1hcHMgZXZlbnQgY29uc3RydWN0b3JzIHRvIGFuIGZyZWUgcG9vbCBvZiBpbnN0YW5jZXMgb2YgdGhvc2Ugc3BlY2lmaWMgZXZlbnRzLlxuICAgICAqIEBzZWUgRXZlbnRCb3VuZGFyeSNhbGxvY2F0ZUV2ZW50XG4gICAgICogQHNlZSBFdmVudEJvdW5kYXJ5I2ZyZWVFdmVudFxuICAgICAqL1xuICAgIHRoaXMuZXZlbnRQb29sID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICAvKiogRXZlcnkgaW50ZXJhY3RpdmUgZWxlbWVudCBnYXRoZXJlZCBmcm9tIHRoZSBzY2VuZS4gT25seSB1c2VkIGluIGBwb2ludGVybW92ZWAgKi9cbiAgICB0aGlzLl9hbGxJbnRlcmFjdGl2ZUVsZW1lbnRzID0gW107XG4gICAgLyoqIEV2ZXJ5IGVsZW1lbnQgdGhhdCBwYXNzZWQgdGhlIGhpdCB0ZXN0LiBPbmx5IHVzZWQgaW4gYHBvaW50ZXJtb3ZlYCAqL1xuICAgIHRoaXMuX2hpdEVsZW1lbnRzID0gW107XG4gICAgLyoqIFdoZXRoZXIgb3Igbm90IHRvIGNvbGxlY3QgYWxsIHRoZSBpbnRlcmFjdGl2ZSBlbGVtZW50cyBmcm9tIHRoZSBzY2VuZS4gRW5hYmxlZCBpbiBgcG9pbnRlcm1vdmVgICovXG4gICAgdGhpcy5faXNQb2ludGVyTW92ZUV2ZW50ID0gZmFsc2U7XG4gICAgdGhpcy5yb290VGFyZ2V0ID0gcm9vdFRhcmdldDtcbiAgICB0aGlzLmhpdFBydW5lRm4gPSB0aGlzLmhpdFBydW5lRm4uYmluZCh0aGlzKTtcbiAgICB0aGlzLmhpdFRlc3RGbiA9IHRoaXMuaGl0VGVzdEZuLmJpbmQodGhpcyk7XG4gICAgdGhpcy5tYXBQb2ludGVyRG93biA9IHRoaXMubWFwUG9pbnRlckRvd24uYmluZCh0aGlzKTtcbiAgICB0aGlzLm1hcFBvaW50ZXJNb3ZlID0gdGhpcy5tYXBQb2ludGVyTW92ZS5iaW5kKHRoaXMpO1xuICAgIHRoaXMubWFwUG9pbnRlck91dCA9IHRoaXMubWFwUG9pbnRlck91dC5iaW5kKHRoaXMpO1xuICAgIHRoaXMubWFwUG9pbnRlck92ZXIgPSB0aGlzLm1hcFBvaW50ZXJPdmVyLmJpbmQodGhpcyk7XG4gICAgdGhpcy5tYXBQb2ludGVyVXAgPSB0aGlzLm1hcFBvaW50ZXJVcC5iaW5kKHRoaXMpO1xuICAgIHRoaXMubWFwUG9pbnRlclVwT3V0c2lkZSA9IHRoaXMubWFwUG9pbnRlclVwT3V0c2lkZS5iaW5kKHRoaXMpO1xuICAgIHRoaXMubWFwV2hlZWwgPSB0aGlzLm1hcFdoZWVsLmJpbmQodGhpcyk7XG4gICAgdGhpcy5tYXBDb250ZXh0TWVudSA9IHRoaXMubWFwQ29udGV4dE1lbnUuYmluZCh0aGlzKTtcbiAgICB0aGlzLm1hcHBpbmdUYWJsZSA9IHt9O1xuICAgIHRoaXMuYWRkRXZlbnRNYXBwaW5nKFwicG9pbnRlcmRvd25cIiwgdGhpcy5tYXBQb2ludGVyRG93bik7XG4gICAgdGhpcy5hZGRFdmVudE1hcHBpbmcoXCJwb2ludGVybW92ZVwiLCB0aGlzLm1hcFBvaW50ZXJNb3ZlKTtcbiAgICB0aGlzLmFkZEV2ZW50TWFwcGluZyhcInBvaW50ZXJvdXRcIiwgdGhpcy5tYXBQb2ludGVyT3V0KTtcbiAgICB0aGlzLmFkZEV2ZW50TWFwcGluZyhcInBvaW50ZXJsZWF2ZVwiLCB0aGlzLm1hcFBvaW50ZXJPdXQpO1xuICAgIHRoaXMuYWRkRXZlbnRNYXBwaW5nKFwicG9pbnRlcm92ZXJcIiwgdGhpcy5tYXBQb2ludGVyT3Zlcik7XG4gICAgdGhpcy5hZGRFdmVudE1hcHBpbmcoXCJwb2ludGVydXBcIiwgdGhpcy5tYXBQb2ludGVyVXApO1xuICAgIHRoaXMuYWRkRXZlbnRNYXBwaW5nKFwicG9pbnRlcnVwb3V0c2lkZVwiLCB0aGlzLm1hcFBvaW50ZXJVcE91dHNpZGUpO1xuICAgIHRoaXMuYWRkRXZlbnRNYXBwaW5nKFwid2hlZWxcIiwgdGhpcy5tYXBXaGVlbCk7XG4gICAgdGhpcy5hZGRFdmVudE1hcHBpbmcoXCJjb250ZXh0bWVudVwiLCB0aGlzLm1hcENvbnRleHRNZW51KTtcbiAgfVxuICAvKipcbiAgICogQWRkcyBhbiBldmVudCBtYXBwaW5nIGZvciB0aGUgZXZlbnQgYHR5cGVgIGhhbmRsZWQgYnkgYGZuYC5cbiAgICpcbiAgICogRXZlbnQgbWFwcGluZ3MgY2FuIGJlIHVzZWQgdG8gaW1wbGVtZW50IGFkZGl0aW9uYWwgb3IgY3VzdG9tIGV2ZW50cy4gVGhleSB0YWtlIGFuIGV2ZW50XG4gICAqIGNvbWluZyBmcm9tIHRoZSB1cHN0cmVhbSBzY2VuZSAob3IgZGlyZWN0bHkgZnJvbSB0aGUge0BsaW5rIEV2ZW50U3lzdGVtfSkgYW5kIGRpc3BhdGNoIG5ldyBkb3duc3RyZWFtIGV2ZW50c1xuICAgKiBnZW5lcmFsbHkgdHJpY2tsaW5nIGRvd24gYW5kIGJ1YmJsaW5nIHVwIHRvIHtAbGluayBFdmVudEJvdW5kYXJ5LnJvb3RUYXJnZXQgdGhpcy5yb290VGFyZ2V0fS5cbiAgICpcbiAgICogVG8gbW9kaWZ5IHRoZSBzZW1hbnRpY3Mgb2YgZXhpc3RpbmcgZXZlbnRzLCB0aGUgYnVpbHQtaW4gbWFwcGluZyBtZXRob2RzIG9mIEV2ZW50Qm91bmRhcnkgc2hvdWxkIGJlIG92ZXJyaWRkZW5cbiAgICogaW5zdGVhZC5cbiAgICogQHBhcmFtIHR5cGUgLSBUaGUgdHlwZSBvZiB1cHN0cmVhbSBldmVudCB0byBtYXAuXG4gICAqIEBwYXJhbSBmbiAtIFRoZSBtYXBwaW5nIG1ldGhvZC4gVGhlIGNvbnRleHQgb2YgdGhpcyBmdW5jdGlvbiBtdXN0IGJlIGJvdW5kIG1hbnVhbGx5LCBpZiBkZXNpcmVkLlxuICAgKi9cbiAgYWRkRXZlbnRNYXBwaW5nKHR5cGUsIGZuKSB7XG4gICAgaWYgKCF0aGlzLm1hcHBpbmdUYWJsZVt0eXBlXSkge1xuICAgICAgdGhpcy5tYXBwaW5nVGFibGVbdHlwZV0gPSBbXTtcbiAgICB9XG4gICAgdGhpcy5tYXBwaW5nVGFibGVbdHlwZV0ucHVzaCh7XG4gICAgICBmbixcbiAgICAgIHByaW9yaXR5OiAwXG4gICAgfSk7XG4gICAgdGhpcy5tYXBwaW5nVGFibGVbdHlwZV0uc29ydCgoYSwgYikgPT4gYS5wcmlvcml0eSAtIGIucHJpb3JpdHkpO1xuICB9XG4gIC8qKlxuICAgKiBEaXNwYXRjaGVzIHRoZSBnaXZlbiBldmVudFxuICAgKiBAcGFyYW0gZSAtIFRoZSBldmVudCB0byBkaXNwYXRjaC5cbiAgICogQHBhcmFtIHR5cGUgLSBUaGUgdHlwZSBvZiBldmVudCB0byBkaXNwYXRjaC4gRGVmYXVsdHMgdG8gYGUudHlwZWAuXG4gICAqL1xuICBkaXNwYXRjaEV2ZW50KGUsIHR5cGUpIHtcbiAgICBlLnByb3BhZ2F0aW9uU3RvcHBlZCA9IGZhbHNlO1xuICAgIGUucHJvcGFnYXRpb25JbW1lZGlhdGVseVN0b3BwZWQgPSBmYWxzZTtcbiAgICB0aGlzLnByb3BhZ2F0ZShlLCB0eXBlKTtcbiAgICB0aGlzLmRpc3BhdGNoLmVtaXQodHlwZSB8fCBlLnR5cGUsIGUpO1xuICB9XG4gIC8qKlxuICAgKiBNYXBzIHRoZSBnaXZlbiB1cHN0cmVhbSBldmVudCB0aHJvdWdoIHRoZSBldmVudCBib3VuZGFyeSBhbmQgcHJvcGFnYXRlcyBpdCBkb3duc3RyZWFtLlxuICAgKiBAcGFyYW0gZSAtIFRoZSBldmVudCB0byBtYXAuXG4gICAqL1xuICBtYXBFdmVudChlKSB7XG4gICAgaWYgKCF0aGlzLnJvb3RUYXJnZXQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgbWFwcGVycyA9IHRoaXMubWFwcGluZ1RhYmxlW2UudHlwZV07XG4gICAgaWYgKG1hcHBlcnMpIHtcbiAgICAgIGZvciAobGV0IGkgPSAwLCBqID0gbWFwcGVycy5sZW5ndGg7IGkgPCBqOyBpKyspIHtcbiAgICAgICAgbWFwcGVyc1tpXS5mbihlKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgd2FybihgW0V2ZW50Qm91bmRhcnldOiBFdmVudCBtYXBwaW5nIG5vdCBkZWZpbmVkIGZvciAke2UudHlwZX1gKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIEZpbmRzIHRoZSBDb250YWluZXIgdGhhdCBpcyB0aGUgdGFyZ2V0IG9mIGEgZXZlbnQgYXQgdGhlIGdpdmVuIGNvb3JkaW5hdGVzLlxuICAgKlxuICAgKiBUaGUgcGFzc2VkICh4LHkpIGNvb3JkaW5hdGVzIGFyZSBpbiB0aGUgd29ybGQgc3BhY2UgYWJvdmUgdGhpcyBldmVudCBib3VuZGFyeS5cbiAgICogQHBhcmFtIHggLSBUaGUgeCBjb29yZGluYXRlIG9mIHRoZSBldmVudC5cbiAgICogQHBhcmFtIHkgLSBUaGUgeSBjb29yZGluYXRlIG9mIHRoZSBldmVudC5cbiAgICovXG4gIGhpdFRlc3QoeCwgeSkge1xuICAgIEV2ZW50c1RpY2tlci5wYXVzZVVwZGF0ZSA9IHRydWU7XG4gICAgY29uc3QgdXNlTW92ZSA9IHRoaXMuX2lzUG9pbnRlck1vdmVFdmVudCAmJiB0aGlzLmVuYWJsZUdsb2JhbE1vdmVFdmVudHM7XG4gICAgY29uc3QgZm4gPSB1c2VNb3ZlID8gXCJoaXRUZXN0TW92ZVJlY3Vyc2l2ZVwiIDogXCJoaXRUZXN0UmVjdXJzaXZlXCI7XG4gICAgY29uc3QgaW52ZXJ0ZWRQYXRoID0gdGhpc1tmbl0oXG4gICAgICB0aGlzLnJvb3RUYXJnZXQsXG4gICAgICB0aGlzLnJvb3RUYXJnZXQuZXZlbnRNb2RlLFxuICAgICAgdGVtcEhpdExvY2F0aW9uLnNldCh4LCB5KSxcbiAgICAgIHRoaXMuaGl0VGVzdEZuLFxuICAgICAgdGhpcy5oaXRQcnVuZUZuXG4gICAgKTtcbiAgICByZXR1cm4gaW52ZXJ0ZWRQYXRoICYmIGludmVydGVkUGF0aFswXTtcbiAgfVxuICAvKipcbiAgICogUHJvcGFnYXRlIHRoZSBwYXNzZWQgZXZlbnQgZnJvbSBmcm9tIHtAbGluayBFdmVudEJvdW5kYXJ5LnJvb3RUYXJnZXQgdGhpcy5yb290VGFyZ2V0fSB0byBpdHNcbiAgICogdGFyZ2V0IGBlLnRhcmdldGAuXG4gICAqIEBwYXJhbSBlIC0gVGhlIGV2ZW50IHRvIHByb3BhZ2F0ZS5cbiAgICogQHBhcmFtIHR5cGUgLSBUaGUgdHlwZSBvZiBldmVudCB0byBwcm9wYWdhdGUuIERlZmF1bHRzIHRvIGBlLnR5cGVgLlxuICAgKi9cbiAgcHJvcGFnYXRlKGUsIHR5cGUpIHtcbiAgICBpZiAoIWUudGFyZ2V0KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGNvbXBvc2VkUGF0aCA9IGUuY29tcG9zZWRQYXRoKCk7XG4gICAgZS5ldmVudFBoYXNlID0gZS5DQVBUVVJJTkdfUEhBU0U7XG4gICAgZm9yIChsZXQgaSA9IDAsIGogPSBjb21wb3NlZFBhdGgubGVuZ3RoIC0gMTsgaSA8IGo7IGkrKykge1xuICAgICAgZS5jdXJyZW50VGFyZ2V0ID0gY29tcG9zZWRQYXRoW2ldO1xuICAgICAgdGhpcy5ub3RpZnlUYXJnZXQoZSwgdHlwZSk7XG4gICAgICBpZiAoZS5wcm9wYWdhdGlvblN0b3BwZWQgfHwgZS5wcm9wYWdhdGlvbkltbWVkaWF0ZWx5U3RvcHBlZCkgcmV0dXJuO1xuICAgIH1cbiAgICBlLmV2ZW50UGhhc2UgPSBlLkFUX1RBUkdFVDtcbiAgICBlLmN1cnJlbnRUYXJnZXQgPSBlLnRhcmdldDtcbiAgICB0aGlzLm5vdGlmeVRhcmdldChlLCB0eXBlKTtcbiAgICBpZiAoZS5wcm9wYWdhdGlvblN0b3BwZWQgfHwgZS5wcm9wYWdhdGlvbkltbWVkaWF0ZWx5U3RvcHBlZCkgcmV0dXJuO1xuICAgIGUuZXZlbnRQaGFzZSA9IGUuQlVCQkxJTkdfUEhBU0U7XG4gICAgZm9yIChsZXQgaSA9IGNvbXBvc2VkUGF0aC5sZW5ndGggLSAyOyBpID49IDA7IGktLSkge1xuICAgICAgZS5jdXJyZW50VGFyZ2V0ID0gY29tcG9zZWRQYXRoW2ldO1xuICAgICAgdGhpcy5ub3RpZnlUYXJnZXQoZSwgdHlwZSk7XG4gICAgICBpZiAoZS5wcm9wYWdhdGlvblN0b3BwZWQgfHwgZS5wcm9wYWdhdGlvbkltbWVkaWF0ZWx5U3RvcHBlZCkgcmV0dXJuO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogRW1pdHMgdGhlIGV2ZW50IGBlYCB0byBhbGwgaW50ZXJhY3RpdmUgY29udGFpbmVycy4gVGhlIGV2ZW50IGlzIHByb3BhZ2F0ZWQgaW4gdGhlIGJ1YmJsaW5nIHBoYXNlIGFsd2F5cy5cbiAgICpcbiAgICogVGhpcyBpcyB1c2VkIGluIHRoZSBgZ2xvYmFscG9pbnRlcm1vdmVgIGV2ZW50LlxuICAgKiBAcGFyYW0gZSAtIFRoZSBlbWl0dGVkIGV2ZW50LlxuICAgKiBAcGFyYW0gdHlwZSAtIFRoZSBsaXN0ZW5lcnMgdG8gbm90aWZ5LlxuICAgKiBAcGFyYW0gdGFyZ2V0cyAtIFRoZSB0YXJnZXRzIHRvIG5vdGlmeS5cbiAgICovXG4gIGFsbChlLCB0eXBlLCB0YXJnZXRzID0gdGhpcy5fYWxsSW50ZXJhY3RpdmVFbGVtZW50cykge1xuICAgIGlmICh0YXJnZXRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuICAgIGUuZXZlbnRQaGFzZSA9IGUuQlVCQkxJTkdfUEhBU0U7XG4gICAgY29uc3QgZXZlbnRzID0gQXJyYXkuaXNBcnJheSh0eXBlKSA/IHR5cGUgOiBbdHlwZV07XG4gICAgZm9yIChsZXQgaSA9IHRhcmdldHMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgIGV2ZW50cy5mb3JFYWNoKChldmVudCkgPT4ge1xuICAgICAgICBlLmN1cnJlbnRUYXJnZXQgPSB0YXJnZXRzW2ldO1xuICAgICAgICB0aGlzLm5vdGlmeVRhcmdldChlLCBldmVudCk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIEZpbmRzIHRoZSBwcm9wYWdhdGlvbiBwYXRoIGZyb20ge0BsaW5rIEV2ZW50Qm91bmRhcnkucm9vdFRhcmdldCByb290VGFyZ2V0fSB0byB0aGUgcGFzc2VkXG4gICAqIGB0YXJnZXRgLiBUaGUgbGFzdCBlbGVtZW50IGluIHRoZSBwYXRoIGlzIGB0YXJnZXRgLlxuICAgKiBAcGFyYW0gdGFyZ2V0IC0gVGhlIHRhcmdldCB0byBmaW5kIHRoZSBwcm9wYWdhdGlvbiBwYXRoIHRvLlxuICAgKi9cbiAgcHJvcGFnYXRpb25QYXRoKHRhcmdldCkge1xuICAgIGNvbnN0IHByb3BhZ2F0aW9uUGF0aCA9IFt0YXJnZXRdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgUFJPUEFHQVRJT05fTElNSVQgJiYgKHRhcmdldCAhPT0gdGhpcy5yb290VGFyZ2V0ICYmIHRhcmdldC5wYXJlbnQpOyBpKyspIHtcbiAgICAgIGlmICghdGFyZ2V0LnBhcmVudCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBwcm9wYWdhdGlvbiBwYXRoIHRvIGRpc2Nvbm5lY3RlZCB0YXJnZXRcIik7XG4gICAgICB9XG4gICAgICBwcm9wYWdhdGlvblBhdGgucHVzaCh0YXJnZXQucGFyZW50KTtcbiAgICAgIHRhcmdldCA9IHRhcmdldC5wYXJlbnQ7XG4gICAgfVxuICAgIHByb3BhZ2F0aW9uUGF0aC5yZXZlcnNlKCk7XG4gICAgcmV0dXJuIHByb3BhZ2F0aW9uUGF0aDtcbiAgfVxuICBoaXRUZXN0TW92ZVJlY3Vyc2l2ZShjdXJyZW50VGFyZ2V0LCBldmVudE1vZGUsIGxvY2F0aW9uLCB0ZXN0Rm4sIHBydW5lRm4sIGlnbm9yZSA9IGZhbHNlKSB7XG4gICAgbGV0IHNob3VsZFJldHVybiA9IGZhbHNlO1xuICAgIGlmICh0aGlzLl9pbnRlcmFjdGl2ZVBydW5lKGN1cnJlbnRUYXJnZXQpKSByZXR1cm4gbnVsbDtcbiAgICBpZiAoY3VycmVudFRhcmdldC5ldmVudE1vZGUgPT09IFwiZHluYW1pY1wiIHx8IGV2ZW50TW9kZSA9PT0gXCJkeW5hbWljXCIpIHtcbiAgICAgIEV2ZW50c1RpY2tlci5wYXVzZVVwZGF0ZSA9IGZhbHNlO1xuICAgIH1cbiAgICBpZiAoY3VycmVudFRhcmdldC5pbnRlcmFjdGl2ZUNoaWxkcmVuICYmIGN1cnJlbnRUYXJnZXQuY2hpbGRyZW4pIHtcbiAgICAgIGNvbnN0IGNoaWxkcmVuID0gY3VycmVudFRhcmdldC5jaGlsZHJlbjtcbiAgICAgIGZvciAobGV0IGkgPSBjaGlsZHJlbi5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICBjb25zdCBjaGlsZCA9IGNoaWxkcmVuW2ldO1xuICAgICAgICBjb25zdCBuZXN0ZWRIaXQgPSB0aGlzLmhpdFRlc3RNb3ZlUmVjdXJzaXZlKFxuICAgICAgICAgIGNoaWxkLFxuICAgICAgICAgIHRoaXMuX2lzSW50ZXJhY3RpdmUoZXZlbnRNb2RlKSA/IGV2ZW50TW9kZSA6IGNoaWxkLmV2ZW50TW9kZSxcbiAgICAgICAgICBsb2NhdGlvbixcbiAgICAgICAgICB0ZXN0Rm4sXG4gICAgICAgICAgcHJ1bmVGbixcbiAgICAgICAgICBpZ25vcmUgfHwgcHJ1bmVGbihjdXJyZW50VGFyZ2V0LCBsb2NhdGlvbilcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKG5lc3RlZEhpdCkge1xuICAgICAgICAgIGlmIChuZXN0ZWRIaXQubGVuZ3RoID4gMCAmJiAhbmVzdGVkSGl0W25lc3RlZEhpdC5sZW5ndGggLSAxXS5wYXJlbnQpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBpc0ludGVyYWN0aXZlID0gY3VycmVudFRhcmdldC5pc0ludGVyYWN0aXZlKCk7XG4gICAgICAgICAgaWYgKG5lc3RlZEhpdC5sZW5ndGggPiAwIHx8IGlzSW50ZXJhY3RpdmUpIHtcbiAgICAgICAgICAgIGlmIChpc0ludGVyYWN0aXZlKSB0aGlzLl9hbGxJbnRlcmFjdGl2ZUVsZW1lbnRzLnB1c2goY3VycmVudFRhcmdldCk7XG4gICAgICAgICAgICBuZXN0ZWRIaXQucHVzaChjdXJyZW50VGFyZ2V0KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHRoaXMuX2hpdEVsZW1lbnRzLmxlbmd0aCA9PT0gMCkgdGhpcy5faGl0RWxlbWVudHMgPSBuZXN0ZWRIaXQ7XG4gICAgICAgICAgc2hvdWxkUmV0dXJuID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBpc0ludGVyYWN0aXZlTW9kZSA9IHRoaXMuX2lzSW50ZXJhY3RpdmUoZXZlbnRNb2RlKTtcbiAgICBjb25zdCBpc0ludGVyYWN0aXZlVGFyZ2V0ID0gY3VycmVudFRhcmdldC5pc0ludGVyYWN0aXZlKCk7XG4gICAgaWYgKGlzSW50ZXJhY3RpdmVUYXJnZXQgJiYgaXNJbnRlcmFjdGl2ZVRhcmdldCkgdGhpcy5fYWxsSW50ZXJhY3RpdmVFbGVtZW50cy5wdXNoKGN1cnJlbnRUYXJnZXQpO1xuICAgIGlmIChpZ25vcmUgfHwgdGhpcy5faGl0RWxlbWVudHMubGVuZ3RoID4gMCkgcmV0dXJuIG51bGw7XG4gICAgaWYgKHNob3VsZFJldHVybikgcmV0dXJuIHRoaXMuX2hpdEVsZW1lbnRzO1xuICAgIGlmIChpc0ludGVyYWN0aXZlTW9kZSAmJiAoIXBydW5lRm4oY3VycmVudFRhcmdldCwgbG9jYXRpb24pICYmIHRlc3RGbihjdXJyZW50VGFyZ2V0LCBsb2NhdGlvbikpKSB7XG4gICAgICByZXR1cm4gaXNJbnRlcmFjdGl2ZVRhcmdldCA/IFtjdXJyZW50VGFyZ2V0XSA6IFtdO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICAvKipcbiAgICogUmVjdXJzaXZlIGltcGxlbWVudGF0aW9uIGZvciB7QGxpbmsgRXZlbnRCb3VuZGFyeS5oaXRUZXN0IGhpdFRlc3R9LlxuICAgKiBAcGFyYW0gY3VycmVudFRhcmdldCAtIFRoZSBDb250YWluZXIgdGhhdCBpcyB0byBiZSBoaXQgdGVzdGVkLlxuICAgKiBAcGFyYW0gZXZlbnRNb2RlIC0gVGhlIGV2ZW50IG1vZGUgZm9yIHRoZSBgY3VycmVudFRhcmdldGAgb3Igb25lIG9mIGl0cyBwYXJlbnRzLlxuICAgKiBAcGFyYW0gbG9jYXRpb24gLSBUaGUgbG9jYXRpb24gdGhhdCBpcyBiZWluZyB0ZXN0ZWQgZm9yIG92ZXJsYXAuXG4gICAqIEBwYXJhbSB0ZXN0Rm4gLSBDYWxsYmFjayB0aGF0IGRldGVybWluZXMgd2hldGhlciB0aGUgdGFyZ2V0IHBhc3NlcyBoaXQgdGVzdGluZy4gVGhpcyBjYWxsYmFja1xuICAgKiAgY2FuIGFzc3VtZSB0aGF0IGBwcnVuZUZuYCBmYWlsZWQgdG8gcHJ1bmUgdGhlIGNvbnRhaW5lci5cbiAgICogQHBhcmFtIHBydW5lRm4gLSBDYWxsYmFjayB0aGF0IGRldGVybWluZXNzIHdoZXRoZXIgdGhlIHRhcmdldCBhbmQgYWxsIG9mIGl0cyBjaGlsZHJlblxuICAgKiAgY2Fubm90IHBhc3MgdGhlIGhpdCB0ZXN0LiBJdCBpcyB1c2VkIGFzIGEgcHJlbGltaW5hcnkgb3B0aW1pemF0aW9uIHRvIHBydW5lIGVudGlyZSBzdWJ0cmVlc1xuICAgKiAgb2YgdGhlIHNjZW5lIGdyYXBoLlxuICAgKiBAcmV0dXJucyBBbiBhcnJheSBob2xkaW5nIHRoZSBoaXQgdGVzdGluZyB0YXJnZXQgYW5kIGFsbCBpdHMgYW5jZXN0b3JzIGluIG9yZGVyLiBUaGUgZmlyc3QgZWxlbWVudFxuICAgKiAgaXMgdGhlIHRhcmdldCBpdHNlbGYgYW5kIHRoZSBsYXN0IGlzIHtAbGluayBFdmVudEJvdW5kYXJ5LnJvb3RUYXJnZXQgcm9vdFRhcmdldH0uIFRoaXMgaXMgdGhlIG9wcG9zaXRlXG4gICAqICBvcmRlciB3LnIudC4gdGhlIHByb3BhZ2F0aW9uIHBhdGguIElmIG5vIGhpdCB0ZXN0aW5nIHRhcmdldCBpcyBmb3VuZCwgbnVsbCBpcyByZXR1cm5lZC5cbiAgICovXG4gIGhpdFRlc3RSZWN1cnNpdmUoY3VycmVudFRhcmdldCwgZXZlbnRNb2RlLCBsb2NhdGlvbiwgdGVzdEZuLCBwcnVuZUZuKSB7XG4gICAgaWYgKHRoaXMuX2ludGVyYWN0aXZlUHJ1bmUoY3VycmVudFRhcmdldCkgfHwgcHJ1bmVGbihjdXJyZW50VGFyZ2V0LCBsb2NhdGlvbikpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAoY3VycmVudFRhcmdldC5ldmVudE1vZGUgPT09IFwiZHluYW1pY1wiIHx8IGV2ZW50TW9kZSA9PT0gXCJkeW5hbWljXCIpIHtcbiAgICAgIEV2ZW50c1RpY2tlci5wYXVzZVVwZGF0ZSA9IGZhbHNlO1xuICAgIH1cbiAgICBpZiAoY3VycmVudFRhcmdldC5pbnRlcmFjdGl2ZUNoaWxkcmVuICYmIGN1cnJlbnRUYXJnZXQuY2hpbGRyZW4pIHtcbiAgICAgIGNvbnN0IGNoaWxkcmVuID0gY3VycmVudFRhcmdldC5jaGlsZHJlbjtcbiAgICAgIGNvbnN0IHJlbGF0aXZlTG9jYXRpb24gPSBsb2NhdGlvbjtcbiAgICAgIGZvciAobGV0IGkgPSBjaGlsZHJlbi5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICBjb25zdCBjaGlsZCA9IGNoaWxkcmVuW2ldO1xuICAgICAgICBjb25zdCBuZXN0ZWRIaXQgPSB0aGlzLmhpdFRlc3RSZWN1cnNpdmUoXG4gICAgICAgICAgY2hpbGQsXG4gICAgICAgICAgdGhpcy5faXNJbnRlcmFjdGl2ZShldmVudE1vZGUpID8gZXZlbnRNb2RlIDogY2hpbGQuZXZlbnRNb2RlLFxuICAgICAgICAgIHJlbGF0aXZlTG9jYXRpb24sXG4gICAgICAgICAgdGVzdEZuLFxuICAgICAgICAgIHBydW5lRm5cbiAgICAgICAgKTtcbiAgICAgICAgaWYgKG5lc3RlZEhpdCkge1xuICAgICAgICAgIGlmIChuZXN0ZWRIaXQubGVuZ3RoID4gMCAmJiAhbmVzdGVkSGl0W25lc3RlZEhpdC5sZW5ndGggLSAxXS5wYXJlbnQpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBpc0ludGVyYWN0aXZlID0gY3VycmVudFRhcmdldC5pc0ludGVyYWN0aXZlKCk7XG4gICAgICAgICAgaWYgKG5lc3RlZEhpdC5sZW5ndGggPiAwIHx8IGlzSW50ZXJhY3RpdmUpIG5lc3RlZEhpdC5wdXNoKGN1cnJlbnRUYXJnZXQpO1xuICAgICAgICAgIHJldHVybiBuZXN0ZWRIaXQ7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgaXNJbnRlcmFjdGl2ZU1vZGUgPSB0aGlzLl9pc0ludGVyYWN0aXZlKGV2ZW50TW9kZSk7XG4gICAgY29uc3QgaXNJbnRlcmFjdGl2ZVRhcmdldCA9IGN1cnJlbnRUYXJnZXQuaXNJbnRlcmFjdGl2ZSgpO1xuICAgIGlmIChpc0ludGVyYWN0aXZlTW9kZSAmJiB0ZXN0Rm4oY3VycmVudFRhcmdldCwgbG9jYXRpb24pKSB7XG4gICAgICByZXR1cm4gaXNJbnRlcmFjdGl2ZVRhcmdldCA/IFtjdXJyZW50VGFyZ2V0XSA6IFtdO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBfaXNJbnRlcmFjdGl2ZShpbnQpIHtcbiAgICByZXR1cm4gaW50ID09PSBcInN0YXRpY1wiIHx8IGludCA9PT0gXCJkeW5hbWljXCI7XG4gIH1cbiAgX2ludGVyYWN0aXZlUHJ1bmUoY29udGFpbmVyKSB7XG4gICAgaWYgKCFjb250YWluZXIgfHwgIWNvbnRhaW5lci52aXNpYmxlIHx8ICFjb250YWluZXIucmVuZGVyYWJsZSB8fCAhY29udGFpbmVyLm1lYXN1cmFibGUpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoY29udGFpbmVyLmV2ZW50TW9kZSA9PT0gXCJub25lXCIpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoY29udGFpbmVyLmV2ZW50TW9kZSA9PT0gXCJwYXNzaXZlXCIgJiYgIWNvbnRhaW5lci5pbnRlcmFjdGl2ZUNoaWxkcmVuKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIC8qKlxuICAgKiBDaGVja3Mgd2hldGhlciB0aGUgY29udGFpbmVyIG9yIGFueSBvZiBpdHMgY2hpbGRyZW4gY2Fubm90IHBhc3MgdGhlIGhpdCB0ZXN0IGF0IGFsbC5cbiAgICpcbiAgICoge0BsaW5rIEV2ZW50Qm91bmRhcnl9J3MgaW1wbGVtZW50YXRpb24gdXNlcyB0aGUge0BsaW5rIENvbnRhaW5lci5oaXRBcmVhIGhpdEFyZWF9XG4gICAqIGFuZCB7QGxpbmsgQ29udGFpbmVyLl9tYXNrRWZmZWN0fSBmb3IgcHJ1bmluZy5cbiAgICogQHBhcmFtIGNvbnRhaW5lciAtIFRoZSBjb250YWluZXIgdG8gcHJ1bmUuXG4gICAqIEBwYXJhbSBsb2NhdGlvbiAtIFRoZSBsb2NhdGlvbiB0byB0ZXN0IGZvciBvdmVybGFwLlxuICAgKi9cbiAgaGl0UHJ1bmVGbihjb250YWluZXIsIGxvY2F0aW9uKSB7XG4gICAgaWYgKGNvbnRhaW5lci5oaXRBcmVhKSB7XG4gICAgICBjb250YWluZXIud29ybGRUcmFuc2Zvcm0uYXBwbHlJbnZlcnNlKGxvY2F0aW9uLCB0ZW1wTG9jYWxNYXBwaW5nKTtcbiAgICAgIGlmICghY29udGFpbmVyLmhpdEFyZWEuY29udGFpbnModGVtcExvY2FsTWFwcGluZy54LCB0ZW1wTG9jYWxNYXBwaW5nLnkpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoY29udGFpbmVyLmVmZmVjdHMgJiYgY29udGFpbmVyLmVmZmVjdHMubGVuZ3RoKSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNvbnRhaW5lci5lZmZlY3RzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGVmZmVjdCA9IGNvbnRhaW5lci5lZmZlY3RzW2ldO1xuICAgICAgICBpZiAoZWZmZWN0LmNvbnRhaW5zUG9pbnQpIHtcbiAgICAgICAgICBjb25zdCBlZmZlY3RDb250YWluc1BvaW50ID0gZWZmZWN0LmNvbnRhaW5zUG9pbnQobG9jYXRpb24sIHRoaXMuaGl0VGVzdEZuKTtcbiAgICAgICAgICBpZiAoIWVmZmVjdENvbnRhaW5zUG9pbnQpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrcyB3aGV0aGVyIHRoZSBjb250YWluZXIgcGFzc2VzIGhpdCB0ZXN0aW5nIGZvciB0aGUgZ2l2ZW4gbG9jYXRpb24uXG4gICAqIEBwYXJhbSBjb250YWluZXIgLSBUaGUgY29udGFpbmVyIHRvIHRlc3QuXG4gICAqIEBwYXJhbSBsb2NhdGlvbiAtIFRoZSBsb2NhdGlvbiB0byB0ZXN0IGZvciBvdmVybGFwLlxuICAgKiBAcmV0dXJucyAtIFdoZXRoZXIgYGNvbnRhaW5lcmAgcGFzc2VzIGhpdCB0ZXN0aW5nIGZvciBgbG9jYXRpb25gLlxuICAgKi9cbiAgaGl0VGVzdEZuKGNvbnRhaW5lciwgbG9jYXRpb24pIHtcbiAgICBpZiAoY29udGFpbmVyLmhpdEFyZWEpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoY29udGFpbmVyPy5jb250YWluc1BvaW50KSB7XG4gICAgICBjb250YWluZXIud29ybGRUcmFuc2Zvcm0uYXBwbHlJbnZlcnNlKGxvY2F0aW9uLCB0ZW1wTG9jYWxNYXBwaW5nKTtcbiAgICAgIHJldHVybiBjb250YWluZXIuY29udGFpbnNQb2ludCh0ZW1wTG9jYWxNYXBwaW5nKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIC8qKlxuICAgKiBOb3RpZnkgYWxsIHRoZSBsaXN0ZW5lcnMgdG8gdGhlIGV2ZW50J3MgYGN1cnJlbnRUYXJnZXRgLlxuICAgKlxuICAgKiBJZiB0aGUgYGN1cnJlbnRUYXJnZXRgIGNvbnRhaW5zIHRoZSBwcm9wZXJ0eSBgb248dHlwZT5gLCB0aGVuIGl0IGlzIGNhbGxlZCBoZXJlLFxuICAgKiBzaW11bGF0aW5nIHRoZSBiZWhhdmlvciBmcm9tIHZlcnNpb24gNi54IGFuZCBwcmlvci5cbiAgICogQHBhcmFtIGUgLSBUaGUgZXZlbnQgcGFzc2VkIHRvIHRoZSB0YXJnZXQuXG4gICAqIEBwYXJhbSB0eXBlIC0gVGhlIHR5cGUgb2YgZXZlbnQgdG8gbm90aWZ5LiBEZWZhdWx0cyB0byBgZS50eXBlYC5cbiAgICovXG4gIG5vdGlmeVRhcmdldChlLCB0eXBlKSB7XG4gICAgaWYgKCFlLmN1cnJlbnRUYXJnZXQuaXNJbnRlcmFjdGl2ZSgpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHR5cGUgPz8gKHR5cGUgPSBlLnR5cGUpO1xuICAgIGNvbnN0IGhhbmRsZXJLZXkgPSBgb24ke3R5cGV9YDtcbiAgICBlLmN1cnJlbnRUYXJnZXRbaGFuZGxlcktleV0/LihlKTtcbiAgICBjb25zdCBrZXkgPSBlLmV2ZW50UGhhc2UgPT09IGUuQ0FQVFVSSU5HX1BIQVNFIHx8IGUuZXZlbnRQaGFzZSA9PT0gZS5BVF9UQVJHRVQgPyBgJHt0eXBlfWNhcHR1cmVgIDogdHlwZTtcbiAgICB0aGlzLl9ub3RpZnlMaXN0ZW5lcnMoZSwga2V5KTtcbiAgICBpZiAoZS5ldmVudFBoYXNlID09PSBlLkFUX1RBUkdFVCkge1xuICAgICAgdGhpcy5fbm90aWZ5TGlzdGVuZXJzKGUsIHR5cGUpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogTWFwcyB0aGUgdXBzdHJlYW0gYHBvaW50ZXJkb3duYCBldmVudHMgdG8gYSBkb3duc3RyZWFtIGBwb2ludGVyZG93bmAgZXZlbnQuXG4gICAqXG4gICAqIGB0b3VjaHN0YXJ0YCwgYHJpZ2h0ZG93bmAsIGBtb3VzZWRvd25gIGV2ZW50cyBhcmUgYWxzbyBkaXNwYXRjaGVkIGZvciBzcGVjaWZpYyBwb2ludGVyIHR5cGVzLlxuICAgKiBAcGFyYW0gZnJvbSAtIFRoZSB1cHN0cmVhbSBgcG9pbnRlcmRvd25gIGV2ZW50LlxuICAgKi9cbiAgbWFwUG9pbnRlckRvd24oZnJvbSkge1xuICAgIGlmICghKGZyb20gaW5zdGFuY2VvZiBGZWRlcmF0ZWRQb2ludGVyRXZlbnQpKSB7XG4gICAgICB3YXJuKFwiRXZlbnRCb3VuZGFyeSBjYW5ub3QgbWFwIGEgbm9uLXBvaW50ZXIgZXZlbnQgYXMgYSBwb2ludGVyIGV2ZW50XCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBlID0gdGhpcy5jcmVhdGVQb2ludGVyRXZlbnQoZnJvbSk7XG4gICAgdGhpcy5kaXNwYXRjaEV2ZW50KGUsIFwicG9pbnRlcmRvd25cIik7XG4gICAgaWYgKGUucG9pbnRlclR5cGUgPT09IFwidG91Y2hcIikge1xuICAgICAgdGhpcy5kaXNwYXRjaEV2ZW50KGUsIFwidG91Y2hzdGFydFwiKTtcbiAgICB9IGVsc2UgaWYgKGUucG9pbnRlclR5cGUgPT09IFwibW91c2VcIiB8fCBlLnBvaW50ZXJUeXBlID09PSBcInBlblwiKSB7XG4gICAgICBjb25zdCBpc1JpZ2h0QnV0dG9uID0gZS5idXR0b24gPT09IDI7XG4gICAgICB0aGlzLmRpc3BhdGNoRXZlbnQoZSwgaXNSaWdodEJ1dHRvbiA/IFwicmlnaHRkb3duXCIgOiBcIm1vdXNlZG93blwiKTtcbiAgICB9XG4gICAgY29uc3QgdHJhY2tpbmdEYXRhID0gdGhpcy50cmFja2luZ0RhdGEoZnJvbS5wb2ludGVySWQpO1xuICAgIHRyYWNraW5nRGF0YS5wcmVzc1RhcmdldHNCeUJ1dHRvbltmcm9tLmJ1dHRvbl0gPSBlLmNvbXBvc2VkUGF0aCgpO1xuICAgIHRoaXMuZnJlZUV2ZW50KGUpO1xuICB9XG4gIC8qKlxuICAgKiBNYXBzIHRoZSB1cHN0cmVhbSBgcG9pbnRlcm1vdmVgIHRvIGRvd25zdHJlYW0gYHBvaW50ZXJvdXRgLCBgcG9pbnRlcm92ZXJgLCBhbmQgYHBvaW50ZXJtb3ZlYCBldmVudHMsIGluIHRoYXQgb3JkZXIuXG4gICAqXG4gICAqIFRoZSB0cmFja2luZyBkYXRhIGZvciB0aGUgc3BlY2lmaWMgcG9pbnRlciBoYXMgYW4gdXBkYXRlZCBgb3ZlclRhcmdldGAuIGBtb3VzZW91dGAsIGBtb3VzZW92ZXJgLFxuICAgKiBgbW91c2Vtb3ZlYCwgYW5kIGB0b3VjaG1vdmVgIGV2ZW50cyBhcmUgZmlyZWQgYXMgd2VsbCBmb3Igc3BlY2lmaWMgcG9pbnRlciB0eXBlcy5cbiAgICogQHBhcmFtIGZyb20gLSBUaGUgdXBzdHJlYW0gYHBvaW50ZXJtb3ZlYCBldmVudC5cbiAgICovXG4gIG1hcFBvaW50ZXJNb3ZlKGZyb20pIHtcbiAgICBpZiAoIShmcm9tIGluc3RhbmNlb2YgRmVkZXJhdGVkUG9pbnRlckV2ZW50KSkge1xuICAgICAgd2FybihcIkV2ZW50Qm91bmRhcnkgY2Fubm90IG1hcCBhIG5vbi1wb2ludGVyIGV2ZW50IGFzIGEgcG9pbnRlciBldmVudFwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5fYWxsSW50ZXJhY3RpdmVFbGVtZW50cy5sZW5ndGggPSAwO1xuICAgIHRoaXMuX2hpdEVsZW1lbnRzLmxlbmd0aCA9IDA7XG4gICAgdGhpcy5faXNQb2ludGVyTW92ZUV2ZW50ID0gdHJ1ZTtcbiAgICBjb25zdCBlID0gdGhpcy5jcmVhdGVQb2ludGVyRXZlbnQoZnJvbSk7XG4gICAgdGhpcy5faXNQb2ludGVyTW92ZUV2ZW50ID0gZmFsc2U7XG4gICAgY29uc3QgaXNNb3VzZSA9IGUucG9pbnRlclR5cGUgPT09IFwibW91c2VcIiB8fCBlLnBvaW50ZXJUeXBlID09PSBcInBlblwiO1xuICAgIGNvbnN0IHRyYWNraW5nRGF0YSA9IHRoaXMudHJhY2tpbmdEYXRhKGZyb20ucG9pbnRlcklkKTtcbiAgICBjb25zdCBvdXRUYXJnZXQgPSB0aGlzLmZpbmRNb3VudGVkVGFyZ2V0KHRyYWNraW5nRGF0YS5vdmVyVGFyZ2V0cyk7XG4gICAgaWYgKHRyYWNraW5nRGF0YS5vdmVyVGFyZ2V0cz8ubGVuZ3RoID4gMCAmJiBvdXRUYXJnZXQgIT09IGUudGFyZ2V0KSB7XG4gICAgICBjb25zdCBvdXRUeXBlID0gZnJvbS50eXBlID09PSBcIm1vdXNlbW92ZVwiID8gXCJtb3VzZW91dFwiIDogXCJwb2ludGVyb3V0XCI7XG4gICAgICBjb25zdCBvdXRFdmVudCA9IHRoaXMuY3JlYXRlUG9pbnRlckV2ZW50KGZyb20sIG91dFR5cGUsIG91dFRhcmdldCk7XG4gICAgICB0aGlzLmRpc3BhdGNoRXZlbnQob3V0RXZlbnQsIFwicG9pbnRlcm91dFwiKTtcbiAgICAgIGlmIChpc01vdXNlKSB0aGlzLmRpc3BhdGNoRXZlbnQob3V0RXZlbnQsIFwibW91c2VvdXRcIik7XG4gICAgICBpZiAoIWUuY29tcG9zZWRQYXRoKCkuaW5jbHVkZXMob3V0VGFyZ2V0KSkge1xuICAgICAgICBjb25zdCBsZWF2ZUV2ZW50ID0gdGhpcy5jcmVhdGVQb2ludGVyRXZlbnQoZnJvbSwgXCJwb2ludGVybGVhdmVcIiwgb3V0VGFyZ2V0KTtcbiAgICAgICAgbGVhdmVFdmVudC5ldmVudFBoYXNlID0gbGVhdmVFdmVudC5BVF9UQVJHRVQ7XG4gICAgICAgIHdoaWxlIChsZWF2ZUV2ZW50LnRhcmdldCAmJiAhZS5jb21wb3NlZFBhdGgoKS5pbmNsdWRlcyhsZWF2ZUV2ZW50LnRhcmdldCkpIHtcbiAgICAgICAgICBsZWF2ZUV2ZW50LmN1cnJlbnRUYXJnZXQgPSBsZWF2ZUV2ZW50LnRhcmdldDtcbiAgICAgICAgICB0aGlzLm5vdGlmeVRhcmdldChsZWF2ZUV2ZW50KTtcbiAgICAgICAgICBpZiAoaXNNb3VzZSkgdGhpcy5ub3RpZnlUYXJnZXQobGVhdmVFdmVudCwgXCJtb3VzZWxlYXZlXCIpO1xuICAgICAgICAgIGxlYXZlRXZlbnQudGFyZ2V0ID0gbGVhdmVFdmVudC50YXJnZXQucGFyZW50O1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZnJlZUV2ZW50KGxlYXZlRXZlbnQpO1xuICAgICAgfVxuICAgICAgdGhpcy5mcmVlRXZlbnQob3V0RXZlbnQpO1xuICAgIH1cbiAgICBpZiAob3V0VGFyZ2V0ICE9PSBlLnRhcmdldCkge1xuICAgICAgY29uc3Qgb3ZlclR5cGUgPSBmcm9tLnR5cGUgPT09IFwibW91c2Vtb3ZlXCIgPyBcIm1vdXNlb3ZlclwiIDogXCJwb2ludGVyb3ZlclwiO1xuICAgICAgY29uc3Qgb3ZlckV2ZW50ID0gdGhpcy5jbG9uZVBvaW50ZXJFdmVudChlLCBvdmVyVHlwZSk7XG4gICAgICB0aGlzLmRpc3BhdGNoRXZlbnQob3ZlckV2ZW50LCBcInBvaW50ZXJvdmVyXCIpO1xuICAgICAgaWYgKGlzTW91c2UpIHRoaXMuZGlzcGF0Y2hFdmVudChvdmVyRXZlbnQsIFwibW91c2VvdmVyXCIpO1xuICAgICAgbGV0IG92ZXJUYXJnZXRBbmNlc3RvciA9IG91dFRhcmdldD8ucGFyZW50O1xuICAgICAgd2hpbGUgKG92ZXJUYXJnZXRBbmNlc3RvciAmJiBvdmVyVGFyZ2V0QW5jZXN0b3IgIT09IHRoaXMucm9vdFRhcmdldC5wYXJlbnQpIHtcbiAgICAgICAgaWYgKG92ZXJUYXJnZXRBbmNlc3RvciA9PT0gZS50YXJnZXQpIGJyZWFrO1xuICAgICAgICBvdmVyVGFyZ2V0QW5jZXN0b3IgPSBvdmVyVGFyZ2V0QW5jZXN0b3IucGFyZW50O1xuICAgICAgfVxuICAgICAgY29uc3QgZGlkUG9pbnRlckVudGVyID0gIW92ZXJUYXJnZXRBbmNlc3RvciB8fCBvdmVyVGFyZ2V0QW5jZXN0b3IgPT09IHRoaXMucm9vdFRhcmdldC5wYXJlbnQ7XG4gICAgICBpZiAoZGlkUG9pbnRlckVudGVyKSB7XG4gICAgICAgIGNvbnN0IGVudGVyRXZlbnQgPSB0aGlzLmNsb25lUG9pbnRlckV2ZW50KGUsIFwicG9pbnRlcmVudGVyXCIpO1xuICAgICAgICBlbnRlckV2ZW50LmV2ZW50UGhhc2UgPSBlbnRlckV2ZW50LkFUX1RBUkdFVDtcbiAgICAgICAgd2hpbGUgKGVudGVyRXZlbnQudGFyZ2V0ICYmIGVudGVyRXZlbnQudGFyZ2V0ICE9PSBvdXRUYXJnZXQgJiYgZW50ZXJFdmVudC50YXJnZXQgIT09IHRoaXMucm9vdFRhcmdldC5wYXJlbnQpIHtcbiAgICAgICAgICBlbnRlckV2ZW50LmN1cnJlbnRUYXJnZXQgPSBlbnRlckV2ZW50LnRhcmdldDtcbiAgICAgICAgICB0aGlzLm5vdGlmeVRhcmdldChlbnRlckV2ZW50KTtcbiAgICAgICAgICBpZiAoaXNNb3VzZSkgdGhpcy5ub3RpZnlUYXJnZXQoZW50ZXJFdmVudCwgXCJtb3VzZWVudGVyXCIpO1xuICAgICAgICAgIGVudGVyRXZlbnQudGFyZ2V0ID0gZW50ZXJFdmVudC50YXJnZXQucGFyZW50O1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuZnJlZUV2ZW50KGVudGVyRXZlbnQpO1xuICAgICAgfVxuICAgICAgdGhpcy5mcmVlRXZlbnQob3ZlckV2ZW50KTtcbiAgICB9XG4gICAgY29uc3QgYWxsTWV0aG9kcyA9IFtdO1xuICAgIGNvbnN0IGFsbG93R2xvYmFsUG9pbnRlckV2ZW50cyA9IHRoaXMuZW5hYmxlR2xvYmFsTW92ZUV2ZW50cyA/PyB0cnVlO1xuICAgIHRoaXMubW92ZU9uQWxsID8gYWxsTWV0aG9kcy5wdXNoKFwicG9pbnRlcm1vdmVcIikgOiB0aGlzLmRpc3BhdGNoRXZlbnQoZSwgXCJwb2ludGVybW92ZVwiKTtcbiAgICBhbGxvd0dsb2JhbFBvaW50ZXJFdmVudHMgJiYgYWxsTWV0aG9kcy5wdXNoKFwiZ2xvYmFscG9pbnRlcm1vdmVcIik7XG4gICAgaWYgKGUucG9pbnRlclR5cGUgPT09IFwidG91Y2hcIikge1xuICAgICAgdGhpcy5tb3ZlT25BbGwgPyBhbGxNZXRob2RzLnNwbGljZSgxLCAwLCBcInRvdWNobW92ZVwiKSA6IHRoaXMuZGlzcGF0Y2hFdmVudChlLCBcInRvdWNobW92ZVwiKTtcbiAgICAgIGFsbG93R2xvYmFsUG9pbnRlckV2ZW50cyAmJiBhbGxNZXRob2RzLnB1c2goXCJnbG9iYWx0b3VjaG1vdmVcIik7XG4gICAgfVxuICAgIGlmIChpc01vdXNlKSB7XG4gICAgICB0aGlzLm1vdmVPbkFsbCA/IGFsbE1ldGhvZHMuc3BsaWNlKDEsIDAsIFwibW91c2Vtb3ZlXCIpIDogdGhpcy5kaXNwYXRjaEV2ZW50KGUsIFwibW91c2Vtb3ZlXCIpO1xuICAgICAgYWxsb3dHbG9iYWxQb2ludGVyRXZlbnRzICYmIGFsbE1ldGhvZHMucHVzaChcImdsb2JhbG1vdXNlbW92ZVwiKTtcbiAgICAgIHRoaXMuY3Vyc29yID0gZS50YXJnZXQ/LmN1cnNvcjtcbiAgICB9XG4gICAgaWYgKGFsbE1ldGhvZHMubGVuZ3RoID4gMCkge1xuICAgICAgdGhpcy5hbGwoZSwgYWxsTWV0aG9kcyk7XG4gICAgfVxuICAgIHRoaXMuX2FsbEludGVyYWN0aXZlRWxlbWVudHMubGVuZ3RoID0gMDtcbiAgICB0aGlzLl9oaXRFbGVtZW50cy5sZW5ndGggPSAwO1xuICAgIHRyYWNraW5nRGF0YS5vdmVyVGFyZ2V0cyA9IGUuY29tcG9zZWRQYXRoKCk7XG4gICAgdGhpcy5mcmVlRXZlbnQoZSk7XG4gIH1cbiAgLyoqXG4gICAqIE1hcHMgdGhlIHVwc3RyZWFtIGBwb2ludGVyb3ZlcmAgdG8gZG93bnN0cmVhbSBgcG9pbnRlcm92ZXJgIGFuZCBgcG9pbnRlcmVudGVyYCBldmVudHMsIGluIHRoYXQgb3JkZXIuXG4gICAqXG4gICAqIFRoZSB0cmFja2luZyBkYXRhIGZvciB0aGUgc3BlY2lmaWMgcG9pbnRlciBnZXRzIGEgbmV3IGBvdmVyVGFyZ2V0YC5cbiAgICogQHBhcmFtIGZyb20gLSBUaGUgdXBzdHJlYW0gYHBvaW50ZXJvdmVyYCBldmVudC5cbiAgICovXG4gIG1hcFBvaW50ZXJPdmVyKGZyb20pIHtcbiAgICBpZiAoIShmcm9tIGluc3RhbmNlb2YgRmVkZXJhdGVkUG9pbnRlckV2ZW50KSkge1xuICAgICAgd2FybihcIkV2ZW50Qm91bmRhcnkgY2Fubm90IG1hcCBhIG5vbi1wb2ludGVyIGV2ZW50IGFzIGEgcG9pbnRlciBldmVudFwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgdHJhY2tpbmdEYXRhID0gdGhpcy50cmFja2luZ0RhdGEoZnJvbS5wb2ludGVySWQpO1xuICAgIGNvbnN0IGUgPSB0aGlzLmNyZWF0ZVBvaW50ZXJFdmVudChmcm9tKTtcbiAgICBjb25zdCBpc01vdXNlID0gZS5wb2ludGVyVHlwZSA9PT0gXCJtb3VzZVwiIHx8IGUucG9pbnRlclR5cGUgPT09IFwicGVuXCI7XG4gICAgdGhpcy5kaXNwYXRjaEV2ZW50KGUsIFwicG9pbnRlcm92ZXJcIik7XG4gICAgaWYgKGlzTW91c2UpIHRoaXMuZGlzcGF0Y2hFdmVudChlLCBcIm1vdXNlb3ZlclwiKTtcbiAgICBpZiAoZS5wb2ludGVyVHlwZSA9PT0gXCJtb3VzZVwiKSB0aGlzLmN1cnNvciA9IGUudGFyZ2V0Py5jdXJzb3I7XG4gICAgY29uc3QgZW50ZXJFdmVudCA9IHRoaXMuY2xvbmVQb2ludGVyRXZlbnQoZSwgXCJwb2ludGVyZW50ZXJcIik7XG4gICAgZW50ZXJFdmVudC5ldmVudFBoYXNlID0gZW50ZXJFdmVudC5BVF9UQVJHRVQ7XG4gICAgd2hpbGUgKGVudGVyRXZlbnQudGFyZ2V0ICYmIGVudGVyRXZlbnQudGFyZ2V0ICE9PSB0aGlzLnJvb3RUYXJnZXQucGFyZW50KSB7XG4gICAgICBlbnRlckV2ZW50LmN1cnJlbnRUYXJnZXQgPSBlbnRlckV2ZW50LnRhcmdldDtcbiAgICAgIHRoaXMubm90aWZ5VGFyZ2V0KGVudGVyRXZlbnQpO1xuICAgICAgaWYgKGlzTW91c2UpIHRoaXMubm90aWZ5VGFyZ2V0KGVudGVyRXZlbnQsIFwibW91c2VlbnRlclwiKTtcbiAgICAgIGVudGVyRXZlbnQudGFyZ2V0ID0gZW50ZXJFdmVudC50YXJnZXQucGFyZW50O1xuICAgIH1cbiAgICB0cmFja2luZ0RhdGEub3ZlclRhcmdldHMgPSBlLmNvbXBvc2VkUGF0aCgpO1xuICAgIHRoaXMuZnJlZUV2ZW50KGUpO1xuICAgIHRoaXMuZnJlZUV2ZW50KGVudGVyRXZlbnQpO1xuICB9XG4gIC8qKlxuICAgKiBNYXBzIHRoZSB1cHN0cmVhbSBgcG9pbnRlcm91dGAgdG8gZG93bnN0cmVhbSBgcG9pbnRlcm91dGAsIGBwb2ludGVybGVhdmVgIGV2ZW50cywgaW4gdGhhdCBvcmRlci5cbiAgICpcbiAgICogVGhlIHRyYWNraW5nIGRhdGEgZm9yIHRoZSBzcGVjaWZpYyBwb2ludGVyIGlzIGNsZWFyZWQgb2YgYSBgb3ZlclRhcmdldGAuXG4gICAqIEBwYXJhbSBmcm9tIC0gVGhlIHVwc3RyZWFtIGBwb2ludGVyb3V0YCBldmVudC5cbiAgICovXG4gIG1hcFBvaW50ZXJPdXQoZnJvbSkge1xuICAgIGlmICghKGZyb20gaW5zdGFuY2VvZiBGZWRlcmF0ZWRQb2ludGVyRXZlbnQpKSB7XG4gICAgICB3YXJuKFwiRXZlbnRCb3VuZGFyeSBjYW5ub3QgbWFwIGEgbm9uLXBvaW50ZXIgZXZlbnQgYXMgYSBwb2ludGVyIGV2ZW50XCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB0cmFja2luZ0RhdGEgPSB0aGlzLnRyYWNraW5nRGF0YShmcm9tLnBvaW50ZXJJZCk7XG4gICAgaWYgKHRyYWNraW5nRGF0YS5vdmVyVGFyZ2V0cykge1xuICAgICAgY29uc3QgaXNNb3VzZSA9IGZyb20ucG9pbnRlclR5cGUgPT09IFwibW91c2VcIiB8fCBmcm9tLnBvaW50ZXJUeXBlID09PSBcInBlblwiO1xuICAgICAgY29uc3Qgb3V0VGFyZ2V0ID0gdGhpcy5maW5kTW91bnRlZFRhcmdldCh0cmFja2luZ0RhdGEub3ZlclRhcmdldHMpO1xuICAgICAgY29uc3Qgb3V0RXZlbnQgPSB0aGlzLmNyZWF0ZVBvaW50ZXJFdmVudChmcm9tLCBcInBvaW50ZXJvdXRcIiwgb3V0VGFyZ2V0KTtcbiAgICAgIHRoaXMuZGlzcGF0Y2hFdmVudChvdXRFdmVudCk7XG4gICAgICBpZiAoaXNNb3VzZSkgdGhpcy5kaXNwYXRjaEV2ZW50KG91dEV2ZW50LCBcIm1vdXNlb3V0XCIpO1xuICAgICAgY29uc3QgbGVhdmVFdmVudCA9IHRoaXMuY3JlYXRlUG9pbnRlckV2ZW50KGZyb20sIFwicG9pbnRlcmxlYXZlXCIsIG91dFRhcmdldCk7XG4gICAgICBsZWF2ZUV2ZW50LmV2ZW50UGhhc2UgPSBsZWF2ZUV2ZW50LkFUX1RBUkdFVDtcbiAgICAgIHdoaWxlIChsZWF2ZUV2ZW50LnRhcmdldCAmJiBsZWF2ZUV2ZW50LnRhcmdldCAhPT0gdGhpcy5yb290VGFyZ2V0LnBhcmVudCkge1xuICAgICAgICBsZWF2ZUV2ZW50LmN1cnJlbnRUYXJnZXQgPSBsZWF2ZUV2ZW50LnRhcmdldDtcbiAgICAgICAgdGhpcy5ub3RpZnlUYXJnZXQobGVhdmVFdmVudCk7XG4gICAgICAgIGlmIChpc01vdXNlKSB0aGlzLm5vdGlmeVRhcmdldChsZWF2ZUV2ZW50LCBcIm1vdXNlbGVhdmVcIik7XG4gICAgICAgIGxlYXZlRXZlbnQudGFyZ2V0ID0gbGVhdmVFdmVudC50YXJnZXQucGFyZW50O1xuICAgICAgfVxuICAgICAgdHJhY2tpbmdEYXRhLm92ZXJUYXJnZXRzID0gbnVsbDtcbiAgICAgIHRoaXMuZnJlZUV2ZW50KG91dEV2ZW50KTtcbiAgICAgIHRoaXMuZnJlZUV2ZW50KGxlYXZlRXZlbnQpO1xuICAgIH1cbiAgICB0aGlzLmN1cnNvciA9IG51bGw7XG4gIH1cbiAgLyoqXG4gICAqIE1hcHMgdGhlIHVwc3RyZWFtIGBwb2ludGVydXBgIGV2ZW50IHRvIGRvd25zdHJlYW0gYHBvaW50ZXJ1cGAsIGBwb2ludGVydXBvdXRzaWRlYCxcbiAgICogYW5kIGBjbGlja2AvYHJpZ2h0Y2xpY2tgL2Bwb2ludGVydGFwYCBldmVudHMsIGluIHRoYXQgb3JkZXIuXG4gICAqXG4gICAqIFRoZSBgcG9pbnRlcnVwb3V0c2lkZWAgZXZlbnQgYnViYmxlcyBmcm9tIHRoZSBvcmlnaW5hbCBgcG9pbnRlcmRvd25gIHRhcmdldCB0byB0aGUgbW9zdCBzcGVjaWZpY1xuICAgKiBhbmNlc3RvciBvZiB0aGUgYHBvaW50ZXJkb3duYCBhbmQgYHBvaW50ZXJ1cGAgdGFyZ2V0cywgd2hpY2ggaXMgYWxzbyB0aGUgYGNsaWNrYCBldmVudCdzIHRhcmdldC4gYHRvdWNoZW5kYCxcbiAgICogYHJpZ2h0dXBgLCBgbW91c2V1cGAsIGB0b3VjaGVuZG91dHNpZGVgLCBgcmlnaHR1cG91dHNpZGVgLCBgbW91c2V1cG91dHNpZGVgLCBhbmQgYHRhcGAgYXJlIGZpcmVkIGFzIHdlbGwgZm9yXG4gICAqIHNwZWNpZmljIHBvaW50ZXIgdHlwZXMuXG4gICAqIEBwYXJhbSBmcm9tIC0gVGhlIHVwc3RyZWFtIGBwb2ludGVydXBgIGV2ZW50LlxuICAgKi9cbiAgbWFwUG9pbnRlclVwKGZyb20pIHtcbiAgICBpZiAoIShmcm9tIGluc3RhbmNlb2YgRmVkZXJhdGVkUG9pbnRlckV2ZW50KSkge1xuICAgICAgd2FybihcIkV2ZW50Qm91bmRhcnkgY2Fubm90IG1hcCBhIG5vbi1wb2ludGVyIGV2ZW50IGFzIGEgcG9pbnRlciBldmVudFwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgbm93ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgY29uc3QgZSA9IHRoaXMuY3JlYXRlUG9pbnRlckV2ZW50KGZyb20pO1xuICAgIHRoaXMuZGlzcGF0Y2hFdmVudChlLCBcInBvaW50ZXJ1cFwiKTtcbiAgICBpZiAoZS5wb2ludGVyVHlwZSA9PT0gXCJ0b3VjaFwiKSB7XG4gICAgICB0aGlzLmRpc3BhdGNoRXZlbnQoZSwgXCJ0b3VjaGVuZFwiKTtcbiAgICB9IGVsc2UgaWYgKGUucG9pbnRlclR5cGUgPT09IFwibW91c2VcIiB8fCBlLnBvaW50ZXJUeXBlID09PSBcInBlblwiKSB7XG4gICAgICBjb25zdCBpc1JpZ2h0QnV0dG9uID0gZS5idXR0b24gPT09IDI7XG4gICAgICB0aGlzLmRpc3BhdGNoRXZlbnQoZSwgaXNSaWdodEJ1dHRvbiA/IFwicmlnaHR1cFwiIDogXCJtb3VzZXVwXCIpO1xuICAgIH1cbiAgICBjb25zdCB0cmFja2luZ0RhdGEgPSB0aGlzLnRyYWNraW5nRGF0YShmcm9tLnBvaW50ZXJJZCk7XG4gICAgY29uc3QgcHJlc3NUYXJnZXQgPSB0aGlzLmZpbmRNb3VudGVkVGFyZ2V0KHRyYWNraW5nRGF0YS5wcmVzc1RhcmdldHNCeUJ1dHRvbltmcm9tLmJ1dHRvbl0pO1xuICAgIGxldCBjbGlja1RhcmdldCA9IHByZXNzVGFyZ2V0O1xuICAgIGlmIChwcmVzc1RhcmdldCAmJiAhZS5jb21wb3NlZFBhdGgoKS5pbmNsdWRlcyhwcmVzc1RhcmdldCkpIHtcbiAgICAgIGxldCBjdXJyZW50VGFyZ2V0ID0gcHJlc3NUYXJnZXQ7XG4gICAgICB3aGlsZSAoY3VycmVudFRhcmdldCAmJiAhZS5jb21wb3NlZFBhdGgoKS5pbmNsdWRlcyhjdXJyZW50VGFyZ2V0KSkge1xuICAgICAgICBlLmN1cnJlbnRUYXJnZXQgPSBjdXJyZW50VGFyZ2V0O1xuICAgICAgICB0aGlzLm5vdGlmeVRhcmdldChlLCBcInBvaW50ZXJ1cG91dHNpZGVcIik7XG4gICAgICAgIGlmIChlLnBvaW50ZXJUeXBlID09PSBcInRvdWNoXCIpIHtcbiAgICAgICAgICB0aGlzLm5vdGlmeVRhcmdldChlLCBcInRvdWNoZW5kb3V0c2lkZVwiKTtcbiAgICAgICAgfSBlbHNlIGlmIChlLnBvaW50ZXJUeXBlID09PSBcIm1vdXNlXCIgfHwgZS5wb2ludGVyVHlwZSA9PT0gXCJwZW5cIikge1xuICAgICAgICAgIGNvbnN0IGlzUmlnaHRCdXR0b24gPSBlLmJ1dHRvbiA9PT0gMjtcbiAgICAgICAgICB0aGlzLm5vdGlmeVRhcmdldChlLCBpc1JpZ2h0QnV0dG9uID8gXCJyaWdodHVwb3V0c2lkZVwiIDogXCJtb3VzZXVwb3V0c2lkZVwiKTtcbiAgICAgICAgfVxuICAgICAgICBjdXJyZW50VGFyZ2V0ID0gY3VycmVudFRhcmdldC5wYXJlbnQ7XG4gICAgICB9XG4gICAgICBkZWxldGUgdHJhY2tpbmdEYXRhLnByZXNzVGFyZ2V0c0J5QnV0dG9uW2Zyb20uYnV0dG9uXTtcbiAgICAgIGNsaWNrVGFyZ2V0ID0gY3VycmVudFRhcmdldDtcbiAgICB9XG4gICAgaWYgKGNsaWNrVGFyZ2V0KSB7XG4gICAgICBjb25zdCBjbGlja0V2ZW50ID0gdGhpcy5jbG9uZVBvaW50ZXJFdmVudChlLCBcImNsaWNrXCIpO1xuICAgICAgY2xpY2tFdmVudC50YXJnZXQgPSBjbGlja1RhcmdldDtcbiAgICAgIGNsaWNrRXZlbnQucGF0aCA9IG51bGw7XG4gICAgICBpZiAoIXRyYWNraW5nRGF0YS5jbGlja3NCeUJ1dHRvbltmcm9tLmJ1dHRvbl0pIHtcbiAgICAgICAgdHJhY2tpbmdEYXRhLmNsaWNrc0J5QnV0dG9uW2Zyb20uYnV0dG9uXSA9IHtcbiAgICAgICAgICBjbGlja0NvdW50OiAwLFxuICAgICAgICAgIHRhcmdldDogY2xpY2tFdmVudC50YXJnZXQsXG4gICAgICAgICAgdGltZVN0YW1wOiBub3dcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNsaWNrSGlzdG9yeSA9IHRyYWNraW5nRGF0YS5jbGlja3NCeUJ1dHRvbltmcm9tLmJ1dHRvbl07XG4gICAgICBpZiAoY2xpY2tIaXN0b3J5LnRhcmdldCA9PT0gY2xpY2tFdmVudC50YXJnZXQgJiYgbm93IC0gY2xpY2tIaXN0b3J5LnRpbWVTdGFtcCA8IDIwMCkge1xuICAgICAgICArK2NsaWNrSGlzdG9yeS5jbGlja0NvdW50O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2xpY2tIaXN0b3J5LmNsaWNrQ291bnQgPSAxO1xuICAgICAgfVxuICAgICAgY2xpY2tIaXN0b3J5LnRhcmdldCA9IGNsaWNrRXZlbnQudGFyZ2V0O1xuICAgICAgY2xpY2tIaXN0b3J5LnRpbWVTdGFtcCA9IG5vdztcbiAgICAgIGNsaWNrRXZlbnQuZGV0YWlsID0gY2xpY2tIaXN0b3J5LmNsaWNrQ291bnQ7XG4gICAgICBpZiAoY2xpY2tFdmVudC5wb2ludGVyVHlwZSA9PT0gXCJtb3VzZVwiKSB7XG4gICAgICAgIGNvbnN0IGlzUmlnaHRCdXR0b24gPSBjbGlja0V2ZW50LmJ1dHRvbiA9PT0gMjtcbiAgICAgICAgdGhpcy5kaXNwYXRjaEV2ZW50KGNsaWNrRXZlbnQsIGlzUmlnaHRCdXR0b24gPyBcInJpZ2h0Y2xpY2tcIiA6IFwiY2xpY2tcIik7XG4gICAgICB9IGVsc2UgaWYgKGNsaWNrRXZlbnQucG9pbnRlclR5cGUgPT09IFwidG91Y2hcIikge1xuICAgICAgICB0aGlzLmRpc3BhdGNoRXZlbnQoY2xpY2tFdmVudCwgXCJ0YXBcIik7XG4gICAgICB9XG4gICAgICB0aGlzLmRpc3BhdGNoRXZlbnQoY2xpY2tFdmVudCwgXCJwb2ludGVydGFwXCIpO1xuICAgICAgdGhpcy5mcmVlRXZlbnQoY2xpY2tFdmVudCk7XG4gICAgfVxuICAgIHRoaXMuZnJlZUV2ZW50KGUpO1xuICB9XG4gIC8qKlxuICAgKiBNYXBzIHRoZSB1cHN0cmVhbSBgcG9pbnRlcnVwb3V0c2lkZWAgZXZlbnQgdG8gYSBkb3duc3RyZWFtIGBwb2ludGVydXBvdXRzaWRlYCBldmVudCwgYnViYmxpbmcgZnJvbSB0aGUgb3JpZ2luYWxcbiAgICogYHBvaW50ZXJkb3duYCB0YXJnZXQgdG8gYHJvb3RUYXJnZXRgLlxuICAgKlxuICAgKiAoVGhlIG1vc3Qgc3BlY2lmaWMgYW5jZXN0b3Igb2YgdGhlIGBwb2ludGVyZG93bmAgZXZlbnQgYW5kIHRoZSBgcG9pbnRlcnVwYCBldmVudCBtdXN0IHRoZVxuICAgKiBge0BsaW5rIEV2ZW50Qm91bmRhcnl9J3Mgcm9vdCBiZWNhdXNlIHRoZSBgcG9pbnRlcnVwYCBldmVudCBvY2N1cnJlZCBvdXRzaWRlIG9mIHRoZSBib3VuZGFyeS4pXG4gICAqXG4gICAqIGB0b3VjaGVuZG91dHNpZGVgLCBgbW91c2V1cG91dHNpZGVgLCBhbmQgYHJpZ2h0dXBvdXRzaWRlYCBldmVudHMgYXJlIGZpcmVkIGFzIHdlbGwgZm9yIHNwZWNpZmljIHBvaW50ZXJcbiAgICogdHlwZXMuIFRoZSB0cmFja2luZyBkYXRhIGZvciB0aGUgc3BlY2lmaWMgcG9pbnRlciBpcyBjbGVhcmVkIG9mIGEgYHByZXNzVGFyZ2V0YC5cbiAgICogQHBhcmFtIGZyb20gLSBUaGUgdXBzdHJlYW0gYHBvaW50ZXJ1cG91dHNpZGVgIGV2ZW50LlxuICAgKi9cbiAgbWFwUG9pbnRlclVwT3V0c2lkZShmcm9tKSB7XG4gICAgaWYgKCEoZnJvbSBpbnN0YW5jZW9mIEZlZGVyYXRlZFBvaW50ZXJFdmVudCkpIHtcbiAgICAgIHdhcm4oXCJFdmVudEJvdW5kYXJ5IGNhbm5vdCBtYXAgYSBub24tcG9pbnRlciBldmVudCBhcyBhIHBvaW50ZXIgZXZlbnRcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHRyYWNraW5nRGF0YSA9IHRoaXMudHJhY2tpbmdEYXRhKGZyb20ucG9pbnRlcklkKTtcbiAgICBjb25zdCBwcmVzc1RhcmdldCA9IHRoaXMuZmluZE1vdW50ZWRUYXJnZXQodHJhY2tpbmdEYXRhLnByZXNzVGFyZ2V0c0J5QnV0dG9uW2Zyb20uYnV0dG9uXSk7XG4gICAgY29uc3QgZSA9IHRoaXMuY3JlYXRlUG9pbnRlckV2ZW50KGZyb20pO1xuICAgIGlmIChwcmVzc1RhcmdldCkge1xuICAgICAgbGV0IGN1cnJlbnRUYXJnZXQgPSBwcmVzc1RhcmdldDtcbiAgICAgIHdoaWxlIChjdXJyZW50VGFyZ2V0KSB7XG4gICAgICAgIGUuY3VycmVudFRhcmdldCA9IGN1cnJlbnRUYXJnZXQ7XG4gICAgICAgIHRoaXMubm90aWZ5VGFyZ2V0KGUsIFwicG9pbnRlcnVwb3V0c2lkZVwiKTtcbiAgICAgICAgaWYgKGUucG9pbnRlclR5cGUgPT09IFwidG91Y2hcIikge1xuICAgICAgICAgIHRoaXMubm90aWZ5VGFyZ2V0KGUsIFwidG91Y2hlbmRvdXRzaWRlXCIpO1xuICAgICAgICB9IGVsc2UgaWYgKGUucG9pbnRlclR5cGUgPT09IFwibW91c2VcIiB8fCBlLnBvaW50ZXJUeXBlID09PSBcInBlblwiKSB7XG4gICAgICAgICAgdGhpcy5ub3RpZnlUYXJnZXQoZSwgZS5idXR0b24gPT09IDIgPyBcInJpZ2h0dXBvdXRzaWRlXCIgOiBcIm1vdXNldXBvdXRzaWRlXCIpO1xuICAgICAgICB9XG4gICAgICAgIGN1cnJlbnRUYXJnZXQgPSBjdXJyZW50VGFyZ2V0LnBhcmVudDtcbiAgICAgIH1cbiAgICAgIGRlbGV0ZSB0cmFja2luZ0RhdGEucHJlc3NUYXJnZXRzQnlCdXR0b25bZnJvbS5idXR0b25dO1xuICAgIH1cbiAgICB0aGlzLmZyZWVFdmVudChlKTtcbiAgfVxuICAvKipcbiAgICogTWFwcyB0aGUgdXBzdHJlYW0gYHdoZWVsYCBldmVudCB0byBhIGRvd25zdHJlYW0gYHdoZWVsYCBldmVudC5cbiAgICogQHBhcmFtIGZyb20gLSBUaGUgdXBzdHJlYW0gYHdoZWVsYCBldmVudC5cbiAgICovXG4gIG1hcFdoZWVsKGZyb20pIHtcbiAgICBpZiAoIShmcm9tIGluc3RhbmNlb2YgRmVkZXJhdGVkV2hlZWxFdmVudCkpIHtcbiAgICAgIHdhcm4oXCJFdmVudEJvdW5kYXJ5IGNhbm5vdCBtYXAgYSBub24td2hlZWwgZXZlbnQgYXMgYSB3aGVlbCBldmVudFwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgd2hlZWxFdmVudCA9IHRoaXMuY3JlYXRlV2hlZWxFdmVudChmcm9tKTtcbiAgICB0aGlzLmRpc3BhdGNoRXZlbnQod2hlZWxFdmVudCk7XG4gICAgdGhpcy5mcmVlRXZlbnQod2hlZWxFdmVudCk7XG4gIH1cbiAgLyoqXG4gICAqIE1hcHMgdGhlIHVwc3RyZWFtIGBjb250ZXh0bWVudWAgZXZlbnQgdG8gYSBkb3duc3RyZWFtIGBjb250ZXh0bWVudWAgZXZlbnQuXG4gICAqIEBwYXJhbSBmcm9tIC0gVGhlIHVwc3RyZWFtIGBjb250ZXh0bWVudWAgZXZlbnQuXG4gICAqL1xuICBtYXBDb250ZXh0TWVudShmcm9tKSB7XG4gICAgaWYgKCEoZnJvbSBpbnN0YW5jZW9mIEZlZGVyYXRlZFBvaW50ZXJFdmVudCkpIHtcbiAgICAgIHdhcm4oXCJFdmVudEJvdW5kYXJ5IGNhbm5vdCBtYXAgYSBub24tcG9pbnRlciBldmVudCBhcyBhIHBvaW50ZXIgZXZlbnRcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGUgPSB0aGlzLmNyZWF0ZVBvaW50ZXJFdmVudChmcm9tKTtcbiAgICB0aGlzLmRpc3BhdGNoRXZlbnQoZSwgXCJjb250ZXh0bWVudVwiKTtcbiAgICB0aGlzLmZyZWVFdmVudChlKTtcbiAgfVxuICAvKipcbiAgICogRmluZHMgdGhlIG1vc3Qgc3BlY2lmaWMgZXZlbnQtdGFyZ2V0IGluIHRoZSBnaXZlbiBwcm9wYWdhdGlvbiBwYXRoIHRoYXQgaXMgc3RpbGwgbW91bnRlZCBpbiB0aGUgc2NlbmUgZ3JhcGguXG4gICAqXG4gICAqIFRoaXMgaXMgdXNlZCB0byBmaW5kIHRoZSBjb3JyZWN0IGBwb2ludGVydXBgIGFuZCBgcG9pbnRlcm91dGAgdGFyZ2V0IGluIHRoZSBjYXNlIHRoYXQgdGhlIG9yaWdpbmFsIGBwb2ludGVyZG93bmBcbiAgICogb3IgYHBvaW50ZXJvdmVyYCB0YXJnZXQgd2FzIHVubW91bnRlZCBmcm9tIHRoZSBzY2VuZSBncmFwaC5cbiAgICogQHBhcmFtIHByb3BhZ2F0aW9uUGF0aCAtIFRoZSBwcm9wYWdhdGlvbiBwYXRoIHdhcyB2YWxpZCBpbiB0aGUgcGFzdC5cbiAgICogQHJldHVybnMgLSBUaGUgbW9zdCBzcGVjaWZpYyBldmVudC10YXJnZXQgc3RpbGwgbW91bnRlZCBhdCB0aGUgc2FtZSBsb2NhdGlvbiBpbiB0aGUgc2NlbmUgZ3JhcGguXG4gICAqL1xuICBmaW5kTW91bnRlZFRhcmdldChwcm9wYWdhdGlvblBhdGgpIHtcbiAgICBpZiAoIXByb3BhZ2F0aW9uUGF0aCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGxldCBjdXJyZW50VGFyZ2V0ID0gcHJvcGFnYXRpb25QYXRoWzBdO1xuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgcHJvcGFnYXRpb25QYXRoLmxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAocHJvcGFnYXRpb25QYXRoW2ldLnBhcmVudCA9PT0gY3VycmVudFRhcmdldCkge1xuICAgICAgICBjdXJyZW50VGFyZ2V0ID0gcHJvcGFnYXRpb25QYXRoW2ldO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjdXJyZW50VGFyZ2V0O1xuICB9XG4gIC8qKlxuICAgKiBDcmVhdGVzIGFuIGV2ZW50IHdob3NlIGBvcmlnaW5hbEV2ZW50YCBpcyBgZnJvbWAsIHdpdGggYW4gb3B0aW9uYWwgYHR5cGVgIGFuZCBgdGFyZ2V0YCBvdmVycmlkZS5cbiAgICpcbiAgICogVGhlIGV2ZW50IGlzIGFsbG9jYXRlZCB1c2luZyB7QGxpbmsgRXZlbnRCb3VuZGFyeSNhbGxvY2F0ZUV2ZW50IHRoaXMuYWxsb2NhdGVFdmVudH0uXG4gICAqIEBwYXJhbSBmcm9tIC0gVGhlIGBvcmlnaW5hbEV2ZW50YCBmb3IgdGhlIHJldHVybmVkIGV2ZW50LlxuICAgKiBAcGFyYW0gW3R5cGU9ZnJvbS50eXBlXSAtIFRoZSB0eXBlIG9mIHRoZSByZXR1cm5lZCBldmVudC5cbiAgICogQHBhcmFtIHRhcmdldCAtIFRoZSB0YXJnZXQgb2YgdGhlIHJldHVybmVkIGV2ZW50LlxuICAgKi9cbiAgY3JlYXRlUG9pbnRlckV2ZW50KGZyb20sIHR5cGUsIHRhcmdldCkge1xuICAgIGNvbnN0IGV2ZW50ID0gdGhpcy5hbGxvY2F0ZUV2ZW50KEZlZGVyYXRlZFBvaW50ZXJFdmVudCk7XG4gICAgdGhpcy5jb3B5UG9pbnRlckRhdGEoZnJvbSwgZXZlbnQpO1xuICAgIHRoaXMuY29weU1vdXNlRGF0YShmcm9tLCBldmVudCk7XG4gICAgdGhpcy5jb3B5RGF0YShmcm9tLCBldmVudCk7XG4gICAgZXZlbnQubmF0aXZlRXZlbnQgPSBmcm9tLm5hdGl2ZUV2ZW50O1xuICAgIGV2ZW50Lm9yaWdpbmFsRXZlbnQgPSBmcm9tO1xuICAgIGV2ZW50LnRhcmdldCA9IHRhcmdldCA/PyB0aGlzLmhpdFRlc3QoZXZlbnQuZ2xvYmFsLngsIGV2ZW50Lmdsb2JhbC55KSA/PyB0aGlzLl9oaXRFbGVtZW50c1swXTtcbiAgICBpZiAodHlwZW9mIHR5cGUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIGV2ZW50LnR5cGUgPSB0eXBlO1xuICAgIH1cbiAgICByZXR1cm4gZXZlbnQ7XG4gIH1cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSB3aGVlbCBldmVudCB3aG9zZSBgb3JpZ2luYWxFdmVudGAgaXMgYGZyb21gLlxuICAgKlxuICAgKiBUaGUgZXZlbnQgaXMgYWxsb2NhdGVkIHVzaW5nIHtAbGluayBFdmVudEJvdW5kYXJ5I2FsbG9jYXRlRXZlbnQgdGhpcy5hbGxvY2F0ZUV2ZW50fS5cbiAgICogQHBhcmFtIGZyb20gLSBUaGUgdXBzdHJlYW0gd2hlZWwgZXZlbnQuXG4gICAqL1xuICBjcmVhdGVXaGVlbEV2ZW50KGZyb20pIHtcbiAgICBjb25zdCBldmVudCA9IHRoaXMuYWxsb2NhdGVFdmVudChGZWRlcmF0ZWRXaGVlbEV2ZW50KTtcbiAgICB0aGlzLmNvcHlXaGVlbERhdGEoZnJvbSwgZXZlbnQpO1xuICAgIHRoaXMuY29weU1vdXNlRGF0YShmcm9tLCBldmVudCk7XG4gICAgdGhpcy5jb3B5RGF0YShmcm9tLCBldmVudCk7XG4gICAgZXZlbnQubmF0aXZlRXZlbnQgPSBmcm9tLm5hdGl2ZUV2ZW50O1xuICAgIGV2ZW50Lm9yaWdpbmFsRXZlbnQgPSBmcm9tO1xuICAgIGV2ZW50LnRhcmdldCA9IHRoaXMuaGl0VGVzdChldmVudC5nbG9iYWwueCwgZXZlbnQuZ2xvYmFsLnkpO1xuICAgIHJldHVybiBldmVudDtcbiAgfVxuICAvKipcbiAgICogQ2xvbmVzIHRoZSBldmVudCBgZnJvbWAsIHdpdGggYW4gb3B0aW9uYWwgYHR5cGVgIG92ZXJyaWRlLlxuICAgKlxuICAgKiBUaGUgZXZlbnQgaXMgYWxsb2NhdGVkIHVzaW5nIHtAbGluayBFdmVudEJvdW5kYXJ5I2FsbG9jYXRlRXZlbnQgdGhpcy5hbGxvY2F0ZUV2ZW50fS5cbiAgICogQHBhcmFtIGZyb20gLSBUaGUgZXZlbnQgdG8gY2xvbmUuXG4gICAqIEBwYXJhbSBbdHlwZT1mcm9tLnR5cGVdIC0gVGhlIHR5cGUgb2YgdGhlIHJldHVybmVkIGV2ZW50LlxuICAgKi9cbiAgY2xvbmVQb2ludGVyRXZlbnQoZnJvbSwgdHlwZSkge1xuICAgIGNvbnN0IGV2ZW50ID0gdGhpcy5hbGxvY2F0ZUV2ZW50KEZlZGVyYXRlZFBvaW50ZXJFdmVudCk7XG4gICAgZXZlbnQubmF0aXZlRXZlbnQgPSBmcm9tLm5hdGl2ZUV2ZW50O1xuICAgIGV2ZW50Lm9yaWdpbmFsRXZlbnQgPSBmcm9tLm9yaWdpbmFsRXZlbnQ7XG4gICAgdGhpcy5jb3B5UG9pbnRlckRhdGEoZnJvbSwgZXZlbnQpO1xuICAgIHRoaXMuY29weU1vdXNlRGF0YShmcm9tLCBldmVudCk7XG4gICAgdGhpcy5jb3B5RGF0YShmcm9tLCBldmVudCk7XG4gICAgZXZlbnQudGFyZ2V0ID0gZnJvbS50YXJnZXQ7XG4gICAgZXZlbnQucGF0aCA9IGZyb20uY29tcG9zZWRQYXRoKCkuc2xpY2UoKTtcbiAgICBldmVudC50eXBlID0gdHlwZSA/PyBldmVudC50eXBlO1xuICAgIHJldHVybiBldmVudDtcbiAgfVxuICAvKipcbiAgICogQ29waWVzIHdoZWVsIHtAbGluayBGZWRlcmF0ZWRXaGVlbEV2ZW50fSBkYXRhIGZyb20gYGZyb21gIGludG8gYHRvYC5cbiAgICpcbiAgICogVGhlIGZvbGxvd2luZyBwcm9wZXJ0aWVzIGFyZSBjb3BpZWQ6XG4gICAqICsgZGVsdGFNb2RlXG4gICAqICsgZGVsdGFYXG4gICAqICsgZGVsdGFZXG4gICAqICsgZGVsdGFaXG4gICAqIEBwYXJhbSBmcm9tIC0gVGhlIGV2ZW50IHRvIGNvcHkgZGF0YSBmcm9tLlxuICAgKiBAcGFyYW0gdG8gLSBUaGUgZXZlbnQgdG8gY29weSBkYXRhIGludG8uXG4gICAqL1xuICBjb3B5V2hlZWxEYXRhKGZyb20sIHRvKSB7XG4gICAgdG8uZGVsdGFNb2RlID0gZnJvbS5kZWx0YU1vZGU7XG4gICAgdG8uZGVsdGFYID0gZnJvbS5kZWx0YVg7XG4gICAgdG8uZGVsdGFZID0gZnJvbS5kZWx0YVk7XG4gICAgdG8uZGVsdGFaID0gZnJvbS5kZWx0YVo7XG4gIH1cbiAgLyoqXG4gICAqIENvcGllcyBwb2ludGVyIHtAbGluayBGZWRlcmF0ZWRQb2ludGVyRXZlbnR9IGRhdGEgZnJvbSBgZnJvbWAgaW50byBgdG9gLlxuICAgKlxuICAgKiBUaGUgZm9sbG93aW5nIHByb3BlcnRpZXMgYXJlIGNvcGllZDpcbiAgICogKyBwb2ludGVySWRcbiAgICogKyB3aWR0aFxuICAgKiArIGhlaWdodFxuICAgKiArIGlzUHJpbWFyeVxuICAgKiArIHBvaW50ZXJUeXBlXG4gICAqICsgcHJlc3N1cmVcbiAgICogKyB0YW5nZW50aWFsUHJlc3N1cmVcbiAgICogKyB0aWx0WFxuICAgKiArIHRpbHRZXG4gICAqIEBwYXJhbSBmcm9tIC0gVGhlIGV2ZW50IHRvIGNvcHkgZGF0YSBmcm9tLlxuICAgKiBAcGFyYW0gdG8gLSBUaGUgZXZlbnQgdG8gY29weSBkYXRhIGludG8uXG4gICAqL1xuICBjb3B5UG9pbnRlckRhdGEoZnJvbSwgdG8pIHtcbiAgICBpZiAoIShmcm9tIGluc3RhbmNlb2YgRmVkZXJhdGVkUG9pbnRlckV2ZW50ICYmIHRvIGluc3RhbmNlb2YgRmVkZXJhdGVkUG9pbnRlckV2ZW50KSkgcmV0dXJuO1xuICAgIHRvLnBvaW50ZXJJZCA9IGZyb20ucG9pbnRlcklkO1xuICAgIHRvLndpZHRoID0gZnJvbS53aWR0aDtcbiAgICB0by5oZWlnaHQgPSBmcm9tLmhlaWdodDtcbiAgICB0by5pc1ByaW1hcnkgPSBmcm9tLmlzUHJpbWFyeTtcbiAgICB0by5wb2ludGVyVHlwZSA9IGZyb20ucG9pbnRlclR5cGU7XG4gICAgdG8ucHJlc3N1cmUgPSBmcm9tLnByZXNzdXJlO1xuICAgIHRvLnRhbmdlbnRpYWxQcmVzc3VyZSA9IGZyb20udGFuZ2VudGlhbFByZXNzdXJlO1xuICAgIHRvLnRpbHRYID0gZnJvbS50aWx0WDtcbiAgICB0by50aWx0WSA9IGZyb20udGlsdFk7XG4gICAgdG8udHdpc3QgPSBmcm9tLnR3aXN0O1xuICAgIHRvLnBlcnNpc3RlbnREZXZpY2VJZCA9IGZyb20ucGVyc2lzdGVudERldmljZUlkO1xuICB9XG4gIC8qKlxuICAgKiBDb3BpZXMgbW91c2Uge0BsaW5rIEZlZGVyYXRlZE1vdXNlRXZlbnR9IGRhdGEgZnJvbSBgZnJvbWAgdG8gYHRvYC5cbiAgICpcbiAgICogVGhlIGZvbGxvd2luZyBwcm9wZXJ0aWVzIGFyZSBjb3BpZWQ6XG4gICAqICsgYWx0S2V5XG4gICAqICsgYnV0dG9uXG4gICAqICsgYnV0dG9uc1xuICAgKiArIGNsaWVudFhcbiAgICogKyBjbGllbnRZXG4gICAqICsgbWV0YUtleVxuICAgKiArIG1vdmVtZW50WFxuICAgKiArIG1vdmVtZW50WVxuICAgKiArIHBhZ2VYXG4gICAqICsgcGFnZVlcbiAgICogKyB4XG4gICAqICsgeVxuICAgKiArIHNjcmVlblxuICAgKiArIHNoaWZ0S2V5XG4gICAqICsgZ2xvYmFsXG4gICAqIEBwYXJhbSBmcm9tIC0gVGhlIGV2ZW50IHRvIGNvcHkgZGF0YSBmcm9tLlxuICAgKiBAcGFyYW0gdG8gLSBUaGUgZXZlbnQgdG8gY29weSBkYXRhIGludG8uXG4gICAqL1xuICBjb3B5TW91c2VEYXRhKGZyb20sIHRvKSB7XG4gICAgaWYgKCEoZnJvbSBpbnN0YW5jZW9mIEZlZGVyYXRlZE1vdXNlRXZlbnQgJiYgdG8gaW5zdGFuY2VvZiBGZWRlcmF0ZWRNb3VzZUV2ZW50KSkgcmV0dXJuO1xuICAgIHRvLmFsdEtleSA9IGZyb20uYWx0S2V5O1xuICAgIHRvLmJ1dHRvbiA9IGZyb20uYnV0dG9uO1xuICAgIHRvLmJ1dHRvbnMgPSBmcm9tLmJ1dHRvbnM7XG4gICAgdG8uY2xpZW50LmNvcHlGcm9tKGZyb20uY2xpZW50KTtcbiAgICB0by5jdHJsS2V5ID0gZnJvbS5jdHJsS2V5O1xuICAgIHRvLm1ldGFLZXkgPSBmcm9tLm1ldGFLZXk7XG4gICAgdG8ubW92ZW1lbnQuY29weUZyb20oZnJvbS5tb3ZlbWVudCk7XG4gICAgdG8uc2NyZWVuLmNvcHlGcm9tKGZyb20uc2NyZWVuKTtcbiAgICB0by5zaGlmdEtleSA9IGZyb20uc2hpZnRLZXk7XG4gICAgdG8uZ2xvYmFsLmNvcHlGcm9tKGZyb20uZ2xvYmFsKTtcbiAgfVxuICAvKipcbiAgICogQ29waWVzIGJhc2Uge0BsaW5rIEZlZGVyYXRlZEV2ZW50fSBkYXRhIGZyb20gYGZyb21gIGludG8gYHRvYC5cbiAgICpcbiAgICogVGhlIGZvbGxvd2luZyBwcm9wZXJ0aWVzIGFyZSBjb3BpZWQ6XG4gICAqICsgaXNUcnVzdGVkXG4gICAqICsgc3JjRWxlbWVudFxuICAgKiArIHRpbWVTdGFtcFxuICAgKiArIHR5cGVcbiAgICogQHBhcmFtIGZyb20gLSBUaGUgZXZlbnQgdG8gY29weSBkYXRhIGZyb20uXG4gICAqIEBwYXJhbSB0byAtIFRoZSBldmVudCB0byBjb3B5IGRhdGEgaW50by5cbiAgICovXG4gIGNvcHlEYXRhKGZyb20sIHRvKSB7XG4gICAgdG8uaXNUcnVzdGVkID0gZnJvbS5pc1RydXN0ZWQ7XG4gICAgdG8uc3JjRWxlbWVudCA9IGZyb20uc3JjRWxlbWVudDtcbiAgICB0by50aW1lU3RhbXAgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICB0by50eXBlID0gZnJvbS50eXBlO1xuICAgIHRvLmRldGFpbCA9IGZyb20uZGV0YWlsO1xuICAgIHRvLnZpZXcgPSBmcm9tLnZpZXc7XG4gICAgdG8ud2hpY2ggPSBmcm9tLndoaWNoO1xuICAgIHRvLmxheWVyLmNvcHlGcm9tKGZyb20ubGF5ZXIpO1xuICAgIHRvLnBhZ2UuY29weUZyb20oZnJvbS5wYWdlKTtcbiAgfVxuICAvKipcbiAgICogQHBhcmFtIGlkIC0gVGhlIHBvaW50ZXIgSUQuXG4gICAqIEByZXR1cm5zIFRoZSB0cmFja2luZyBkYXRhIHN0b3JlZCBmb3IgdGhlIGdpdmVuIHBvaW50ZXIuIElmIG5vIGRhdGEgZXhpc3RzLCBhIGJsYW5rXG4gICAqICBzdGF0ZSB3aWxsIGJlIGNyZWF0ZWQuXG4gICAqL1xuICB0cmFja2luZ0RhdGEoaWQpIHtcbiAgICBpZiAoIXRoaXMubWFwcGluZ1N0YXRlLnRyYWNraW5nRGF0YVtpZF0pIHtcbiAgICAgIHRoaXMubWFwcGluZ1N0YXRlLnRyYWNraW5nRGF0YVtpZF0gPSB7XG4gICAgICAgIHByZXNzVGFyZ2V0c0J5QnV0dG9uOiB7fSxcbiAgICAgICAgY2xpY2tzQnlCdXR0b246IHt9LFxuICAgICAgICBvdmVyVGFyZ2V0OiBudWxsXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5tYXBwaW5nU3RhdGUudHJhY2tpbmdEYXRhW2lkXTtcbiAgfVxuICAvKipcbiAgICogQWxsb2NhdGUgYSBzcGVjaWZpYyB0eXBlIG9mIGV2ZW50IGZyb20ge0BsaW5rIEV2ZW50Qm91bmRhcnkjZXZlbnRQb29sIHRoaXMuZXZlbnRQb29sfS5cbiAgICpcbiAgICogVGhpcyBhbGxvY2F0aW9uIGlzIGNvbnN0cnVjdG9yLWFnbm9zdGljLCBhcyBsb25nIGFzIGl0IG9ubHkgdGFrZXMgb25lIGFyZ3VtZW50IC0gdGhpcyBldmVudFxuICAgKiBib3VuZGFyeS5cbiAgICogQHBhcmFtIGNvbnN0cnVjdG9yIC0gVGhlIGV2ZW50J3MgY29uc3RydWN0b3IuXG4gICAqIEByZXR1cm5zIEFuIGV2ZW50IG9mIHRoZSBnaXZlbiB0eXBlLlxuICAgKi9cbiAgYWxsb2NhdGVFdmVudChjb25zdHJ1Y3Rvcikge1xuICAgIGlmICghdGhpcy5ldmVudFBvb2wuaGFzKGNvbnN0cnVjdG9yKSkge1xuICAgICAgdGhpcy5ldmVudFBvb2wuc2V0KGNvbnN0cnVjdG9yLCBbXSk7XG4gICAgfVxuICAgIGNvbnN0IGV2ZW50ID0gdGhpcy5ldmVudFBvb2wuZ2V0KGNvbnN0cnVjdG9yKS5wb3AoKSB8fCBuZXcgY29uc3RydWN0b3IodGhpcyk7XG4gICAgZXZlbnQuZXZlbnRQaGFzZSA9IGV2ZW50Lk5PTkU7XG4gICAgZXZlbnQuY3VycmVudFRhcmdldCA9IG51bGw7XG4gICAgZXZlbnQuZGVmYXVsdFByZXZlbnRlZCA9IGZhbHNlO1xuICAgIGV2ZW50LnBhdGggPSBudWxsO1xuICAgIGV2ZW50LnRhcmdldCA9IG51bGw7XG4gICAgcmV0dXJuIGV2ZW50O1xuICB9XG4gIC8qKlxuICAgKiBGcmVlcyB0aGUgZXZlbnQgYW5kIHB1dHMgaXQgYmFjayBpbnRvIHRoZSBldmVudCBwb29sLlxuICAgKlxuICAgKiBJdCBpcyBpbGxlZ2FsIHRvIHJldXNlIHRoZSBldmVudCB1bnRpbCBpdCBpcyBhbGxvY2F0ZWQgYWdhaW4sIHVzaW5nIGB0aGlzLmFsbG9jYXRlRXZlbnRgLlxuICAgKlxuICAgKiBJdCBpcyBhbHNvIGFkdmlzZWQgdGhhdCBldmVudHMgbm90IGFsbG9jYXRlZCBmcm9tIHtAbGluayBFdmVudEJvdW5kYXJ5I2FsbG9jYXRlRXZlbnQgdGhpcy5hbGxvY2F0ZUV2ZW50fVxuICAgKiBub3QgYmUgZnJlZWQuIFRoaXMgaXMgYmVjYXVzZSBvZiB0aGUgcG9zc2liaWxpdHkgdGhhdCB0aGUgc2FtZSBldmVudCBpcyBmcmVlZCB0d2ljZSwgd2hpY2ggY2FuIGNhdXNlXG4gICAqIGl0IHRvIGJlIGFsbG9jYXRlZCB0d2ljZSAmIHJlc3VsdCBpbiBvdmVyd3JpdGluZy5cbiAgICogQHBhcmFtIGV2ZW50IC0gVGhlIGV2ZW50IHRvIGJlIGZyZWVkLlxuICAgKiBAdGhyb3dzIEVycm9yIGlmIHRoZSBldmVudCBpcyBtYW5hZ2VkIGJ5IGFub3RoZXIgZXZlbnQgYm91bmRhcnkuXG4gICAqL1xuICBmcmVlRXZlbnQoZXZlbnQpIHtcbiAgICBpZiAoZXZlbnQubWFuYWdlciAhPT0gdGhpcykgdGhyb3cgbmV3IEVycm9yKFwiSXQgaXMgaWxsZWdhbCB0byBmcmVlIGFuIGV2ZW50IG5vdCBtYW5hZ2VkIGJ5IHRoaXMgRXZlbnRCb3VuZGFyeSFcIik7XG4gICAgY29uc3QgY29uc3RydWN0b3IgPSBldmVudC5jb25zdHJ1Y3RvcjtcbiAgICBpZiAoIXRoaXMuZXZlbnRQb29sLmhhcyhjb25zdHJ1Y3RvcikpIHtcbiAgICAgIHRoaXMuZXZlbnRQb29sLnNldChjb25zdHJ1Y3RvciwgW10pO1xuICAgIH1cbiAgICB0aGlzLmV2ZW50UG9vbC5nZXQoY29uc3RydWN0b3IpLnB1c2goZXZlbnQpO1xuICB9XG4gIC8qKlxuICAgKiBTaW1pbGFyIHRvIHtAbGluayBFdmVudEVtaXR0ZXIuZW1pdH0sIGV4Y2VwdCBpdCBzdG9wcyBpZiB0aGUgYHByb3BhZ2F0aW9uSW1tZWRpYXRlbHlTdG9wcGVkYCBmbGFnXG4gICAqIGlzIHNldCBvbiB0aGUgZXZlbnQuXG4gICAqIEBwYXJhbSBlIC0gVGhlIGV2ZW50IHRvIGNhbGwgZWFjaCBsaXN0ZW5lciB3aXRoLlxuICAgKiBAcGFyYW0gdHlwZSAtIFRoZSBldmVudCBrZXkuXG4gICAqL1xuICBfbm90aWZ5TGlzdGVuZXJzKGUsIHR5cGUpIHtcbiAgICBjb25zdCBsaXN0ZW5lcnMgPSBlLmN1cnJlbnRUYXJnZXQuX2V2ZW50c1t0eXBlXTtcbiAgICBpZiAoIWxpc3RlbmVycykgcmV0dXJuO1xuICAgIGlmIChcImZuXCIgaW4gbGlzdGVuZXJzKSB7XG4gICAgICBpZiAobGlzdGVuZXJzLm9uY2UpIGUuY3VycmVudFRhcmdldC5yZW1vdmVMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcnMuZm4sIHZvaWQgMCwgdHJ1ZSk7XG4gICAgICBsaXN0ZW5lcnMuZm4uY2FsbChsaXN0ZW5lcnMuY29udGV4dCwgZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZvciAobGV0IGkgPSAwLCBqID0gbGlzdGVuZXJzLmxlbmd0aDsgaSA8IGogJiYgIWUucHJvcGFnYXRpb25JbW1lZGlhdGVseVN0b3BwZWQ7IGkrKykge1xuICAgICAgICBpZiAobGlzdGVuZXJzW2ldLm9uY2UpIGUuY3VycmVudFRhcmdldC5yZW1vdmVMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcnNbaV0uZm4sIHZvaWQgMCwgdHJ1ZSk7XG4gICAgICAgIGxpc3RlbmVyc1tpXS5mbi5jYWxsKGxpc3RlbmVyc1tpXS5jb250ZXh0LCBlKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IHsgRXZlbnRCb3VuZGFyeSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9RXZlbnRCb3VuZGFyeS5tanMubWFwXG4iLCJpbXBvcnQgeyBFeHRlbnNpb25UeXBlIH0gZnJvbSAnLi4vZXh0ZW5zaW9ucy9FeHRlbnNpb25zLm1qcyc7XG5pbXBvcnQgeyBFdmVudEJvdW5kYXJ5IH0gZnJvbSAnLi9FdmVudEJvdW5kYXJ5Lm1qcyc7XG5pbXBvcnQgeyBFdmVudHNUaWNrZXIgfSBmcm9tICcuL0V2ZW50VGlja2VyLm1qcyc7XG5pbXBvcnQgeyBGZWRlcmF0ZWRQb2ludGVyRXZlbnQgfSBmcm9tICcuL0ZlZGVyYXRlZFBvaW50ZXJFdmVudC5tanMnO1xuaW1wb3J0IHsgRmVkZXJhdGVkV2hlZWxFdmVudCB9IGZyb20gJy4vRmVkZXJhdGVkV2hlZWxFdmVudC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IE1PVVNFX1BPSU5URVJfSUQgPSAxO1xuY29uc3QgVE9VQ0hfVE9fUE9JTlRFUiA9IHtcbiAgdG91Y2hzdGFydDogXCJwb2ludGVyZG93blwiLFxuICB0b3VjaGVuZDogXCJwb2ludGVydXBcIixcbiAgdG91Y2hlbmRvdXRzaWRlOiBcInBvaW50ZXJ1cG91dHNpZGVcIixcbiAgdG91Y2htb3ZlOiBcInBvaW50ZXJtb3ZlXCIsXG4gIHRvdWNoY2FuY2VsOiBcInBvaW50ZXJjYW5jZWxcIlxufTtcbmNvbnN0IF9FdmVudFN5c3RlbSA9IGNsYXNzIF9FdmVudFN5c3RlbSB7XG4gIC8qKlxuICAgKiBAcGFyYW0ge1JlbmRlcmVyfSByZW5kZXJlclxuICAgKi9cbiAgY29uc3RydWN0b3IocmVuZGVyZXIpIHtcbiAgICAvKipcbiAgICAgKiBJbmRpY2F0ZXMgd2hldGhlciB0aGUgY3VycmVudCBkZXZpY2Ugc3VwcG9ydHMgdG91Y2ggZXZlbnRzIGFjY29yZGluZyB0byB0aGUgVzNDIFRvdWNoIEV2ZW50cyBzcGVjLlxuICAgICAqIFRoaXMgaXMgdXNlZCB0byBkZXRlcm1pbmUgdGhlIGFwcHJvcHJpYXRlIGV2ZW50IGhhbmRsaW5nIHN0cmF0ZWd5LlxuICAgICAqIEBzZWUge0BsaW5rIGh0dHBzOi8vd3d3LnczLm9yZy9UUi90b3VjaC1ldmVudHMvfSBXM0MgVG91Y2ggRXZlbnRzIFNwZWNpZmljYXRpb25cbiAgICAgKiBAcmVhZG9ubHlcbiAgICAgKiBAZGVmYXVsdCAnb250b3VjaHN0YXJ0JyBpbiBnbG9iYWxUaGlzXG4gICAgICovXG4gICAgdGhpcy5zdXBwb3J0c1RvdWNoRXZlbnRzID0gXCJvbnRvdWNoc3RhcnRcIiBpbiBnbG9iYWxUaGlzO1xuICAgIC8qKlxuICAgICAqIEluZGljYXRlcyB3aGV0aGVyIHRoZSBjdXJyZW50IGRldmljZSBzdXBwb3J0cyBwb2ludGVyIGV2ZW50cyBhY2NvcmRpbmcgdG8gdGhlIFczQyBQb2ludGVyIEV2ZW50cyBzcGVjLlxuICAgICAqIFVzZWQgdG8gb3B0aW1pemUgZXZlbnQgaGFuZGxpbmcgYW5kIHByb3ZpZGUgbW9yZSBjb25zaXN0ZW50IGNyb3NzLWRldmljZSBpbnRlcmFjdGlvbi5cbiAgICAgKiBAc2VlIHtAbGluayBodHRwczovL3d3dy53My5vcmcvVFIvcG9pbnRlcmV2ZW50cy99IFczQyBQb2ludGVyIEV2ZW50cyBTcGVjaWZpY2F0aW9uXG4gICAgICogQHJlYWRvbmx5XG4gICAgICogQGRlZmF1bHQgISFnbG9iYWxUaGlzLlBvaW50ZXJFdmVudFxuICAgICAqL1xuICAgIHRoaXMuc3VwcG9ydHNQb2ludGVyRXZlbnRzID0gISFnbG9iYWxUaGlzLlBvaW50ZXJFdmVudDtcbiAgICAvKipcbiAgICAgKiBUaGUgRE9NIGVsZW1lbnQgdG8gd2hpY2ggdGhlIHJvb3QgZXZlbnQgbGlzdGVuZXJzIGFyZSBib3VuZC4gVGhpcyBpcyBhdXRvbWF0aWNhbGx5IHNldCB0b1xuICAgICAqIHRoZSByZW5kZXJlcidzIHtAbGluayBBYnN0cmFjdFJlbmRlcmVyI2NhbnZhcyBjYW52YXN9LlxuICAgICAqL1xuICAgIHRoaXMuZG9tRWxlbWVudCA9IG51bGw7XG4gICAgLyoqIFRoZSByZXNvbHV0aW9uIHVzZWQgdG8gY29udmVydCBiZXR3ZWVuIHRoZSBET00gY2xpZW50IHNwYWNlIGludG8gd29ybGQgc3BhY2UuICovXG4gICAgdGhpcy5yZXNvbHV0aW9uID0gMTtcbiAgICB0aGlzLnJlbmRlcmVyID0gcmVuZGVyZXI7XG4gICAgdGhpcy5yb290Qm91bmRhcnkgPSBuZXcgRXZlbnRCb3VuZGFyeShudWxsKTtcbiAgICBFdmVudHNUaWNrZXIuaW5pdCh0aGlzKTtcbiAgICB0aGlzLmF1dG9QcmV2ZW50RGVmYXVsdCA9IHRydWU7XG4gICAgdGhpcy5fZXZlbnRzQWRkZWQgPSBmYWxzZTtcbiAgICB0aGlzLl9yb290UG9pbnRlckV2ZW50ID0gbmV3IEZlZGVyYXRlZFBvaW50ZXJFdmVudChudWxsKTtcbiAgICB0aGlzLl9yb290V2hlZWxFdmVudCA9IG5ldyBGZWRlcmF0ZWRXaGVlbEV2ZW50KG51bGwpO1xuICAgIHRoaXMuX3Jvb3RDb250ZXh0TWVudUV2ZW50ID0gbmV3IEZlZGVyYXRlZFBvaW50ZXJFdmVudChudWxsKTtcbiAgICB0aGlzLmN1cnNvclN0eWxlcyA9IHtcbiAgICAgIGRlZmF1bHQ6IFwiaW5oZXJpdFwiLFxuICAgICAgcG9pbnRlcjogXCJwb2ludGVyXCJcbiAgICB9O1xuICAgIHRoaXMuZmVhdHVyZXMgPSBuZXcgUHJveHkoeyAuLi5fRXZlbnRTeXN0ZW0uZGVmYXVsdEV2ZW50RmVhdHVyZXMgfSwge1xuICAgICAgc2V0OiAodGFyZ2V0LCBrZXksIHZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChrZXkgPT09IFwiZ2xvYmFsTW92ZVwiKSB7XG4gICAgICAgICAgdGhpcy5yb290Qm91bmRhcnkuZW5hYmxlR2xvYmFsTW92ZUV2ZW50cyA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHRhcmdldFtrZXldID0gdmFsdWU7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHRoaXMuX29uUG9pbnRlckRvd24gPSB0aGlzLl9vblBvaW50ZXJEb3duLmJpbmQodGhpcyk7XG4gICAgdGhpcy5fb25Qb2ludGVyTW92ZSA9IHRoaXMuX29uUG9pbnRlck1vdmUuYmluZCh0aGlzKTtcbiAgICB0aGlzLl9vblBvaW50ZXJVcCA9IHRoaXMuX29uUG9pbnRlclVwLmJpbmQodGhpcyk7XG4gICAgdGhpcy5fb25Qb2ludGVyT3Zlck91dCA9IHRoaXMuX29uUG9pbnRlck92ZXJPdXQuYmluZCh0aGlzKTtcbiAgICB0aGlzLl9vbkNvbnRleHRNZW51ID0gdGhpcy5fb25Db250ZXh0TWVudS5iaW5kKHRoaXMpO1xuICAgIHRoaXMub25XaGVlbCA9IHRoaXMub25XaGVlbC5iaW5kKHRoaXMpO1xuICB9XG4gIC8qKlxuICAgKiBUaGUgZGVmYXVsdCBpbnRlcmFjdGlvbiBtb2RlIGZvciBhbGwgZGlzcGxheSBvYmplY3RzLlxuICAgKiBAc2VlIENvbnRhaW5lci5ldmVudE1vZGVcbiAgICogQHR5cGUge0V2ZW50TW9kZX1cbiAgICogQHJlYWRvbmx5XG4gICAqIEBzaW5jZSA3LjIuMFxuICAgKi9cbiAgc3RhdGljIGdldCBkZWZhdWx0RXZlbnRNb2RlKCkge1xuICAgIHJldHVybiB0aGlzLl9kZWZhdWx0RXZlbnRNb2RlO1xuICB9XG4gIC8qKlxuICAgKiBSdW5uZXIgaW5pdCBjYWxsZWQsIHZpZXcgaXMgYXZhaWxhYmxlIGF0IHRoaXMgcG9pbnQuXG4gICAqIEBpZ25vcmVcbiAgICovXG4gIGluaXQob3B0aW9ucykge1xuICAgIGNvbnN0IHsgY2FudmFzLCByZXNvbHV0aW9uIH0gPSB0aGlzLnJlbmRlcmVyO1xuICAgIHRoaXMuc2V0VGFyZ2V0RWxlbWVudChjYW52YXMpO1xuICAgIHRoaXMucmVzb2x1dGlvbiA9IHJlc29sdXRpb247XG4gICAgX0V2ZW50U3lzdGVtLl9kZWZhdWx0RXZlbnRNb2RlID0gb3B0aW9ucy5ldmVudE1vZGUgPz8gXCJwYXNzaXZlXCI7XG4gICAgT2JqZWN0LmFzc2lnbih0aGlzLmZlYXR1cmVzLCBvcHRpb25zLmV2ZW50RmVhdHVyZXMgPz8ge30pO1xuICAgIHRoaXMucm9vdEJvdW5kYXJ5LmVuYWJsZUdsb2JhbE1vdmVFdmVudHMgPSB0aGlzLmZlYXR1cmVzLmdsb2JhbE1vdmU7XG4gIH1cbiAgLyoqXG4gICAqIEhhbmRsZSBjaGFuZ2luZyByZXNvbHV0aW9uLlxuICAgKiBAaWdub3JlXG4gICAqL1xuICByZXNvbHV0aW9uQ2hhbmdlKHJlc29sdXRpb24pIHtcbiAgICB0aGlzLnJlc29sdXRpb24gPSByZXNvbHV0aW9uO1xuICB9XG4gIC8qKiBEZXN0cm95cyBhbGwgZXZlbnQgbGlzdGVuZXJzIGFuZCBkZXRhY2hlcyB0aGUgcmVuZGVyZXIuICovXG4gIGRlc3Ryb3koKSB7XG4gICAgRXZlbnRzVGlja2VyLmRlc3Ryb3koKTtcbiAgICB0aGlzLnNldFRhcmdldEVsZW1lbnQobnVsbCk7XG4gICAgdGhpcy5yZW5kZXJlciA9IG51bGw7XG4gICAgdGhpcy5fY3VycmVudEN1cnNvciA9IG51bGw7XG4gIH1cbiAgLyoqXG4gICAqIFNldHMgdGhlIGN1cnJlbnQgY3Vyc29yIG1vZGUsIGhhbmRsaW5nIGFueSBjYWxsYmFja3Mgb3IgQ1NTIHN0eWxlIGNoYW5nZXMuXG4gICAqIFRoZSBjdXJzb3IgY2FuIGJlIGEgQ1NTIGN1cnNvciBzdHJpbmcsIGEgY3VzdG9tIGNhbGxiYWNrIGZ1bmN0aW9uLCBvciBhIGtleSBmcm9tIHRoZSBjdXJzb3JTdHlsZXMgZGljdGlvbmFyeS5cbiAgICogQHBhcmFtIG1vZGUgLSBDdXJzb3IgbW9kZSB0byBzZXQuIENhbiBiZTpcbiAgICogLSBBIENTUyBjdXJzb3Igc3RyaW5nIChlLmcuLCAncG9pbnRlcicsICdncmFiJylcbiAgICogLSBBIGtleSBmcm9tIHRoZSBjdXJzb3JTdHlsZXMgZGljdGlvbmFyeVxuICAgKiAtIG51bGwvdW5kZWZpbmVkIHRvIHJlc2V0IHRvIGRlZmF1bHRcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gVXNpbmcgcHJlZGVmaW5lZCBjdXJzb3Igc3R5bGVzXG4gICAqIGFwcC5yZW5kZXJlci5ldmVudHMuc2V0Q3Vyc29yKCdwb2ludGVyJyk7ICAgIC8vIFNldCBzdGFuZGFyZCBwb2ludGVyIGN1cnNvclxuICAgKiBhcHAucmVuZGVyZXIuZXZlbnRzLnNldEN1cnNvcignZ3JhYicpOyAgICAgICAvLyBTZXQgZ3JhYiBjdXJzb3JcbiAgICogYXBwLnJlbmRlcmVyLmV2ZW50cy5zZXRDdXJzb3IobnVsbCk7ICAgICAgICAgLy8gUmVzZXQgdG8gZGVmYXVsdFxuICAgKlxuICAgKiAvLyBVc2luZyBjdXN0b20gY3Vyc29yIHN0eWxlc1xuICAgKiBhcHAucmVuZGVyZXIuZXZlbnRzLmN1cnNvclN0eWxlcy5jdXN0b20gPSAndXJsKFwiY3Vyc29yLnBuZ1wiKSwgYXV0byc7XG4gICAqIGFwcC5yZW5kZXJlci5ldmVudHMuc2V0Q3Vyc29yKCdjdXN0b20nKTsgICAgIC8vIEFwcGx5IGN1c3RvbSBjdXJzb3JcbiAgICpcbiAgICogLy8gVXNpbmcgY2FsbGJhY2stYmFzZWQgY3Vyc29yXG4gICAqIGFwcC5yZW5kZXJlci5ldmVudHMuY3Vyc29yU3R5bGVzLmR5bmFtaWMgPSAobW9kZSkgPT4ge1xuICAgKiAgICAgZG9jdW1lbnQuYm9keS5zdHlsZS5jdXJzb3IgPSBtb2RlID09PSAnaG92ZXInID8gJ3BvaW50ZXInIDogJ2RlZmF1bHQnO1xuICAgKiB9O1xuICAgKiBhcHAucmVuZGVyZXIuZXZlbnRzLnNldEN1cnNvcignZHluYW1pYycpOyAgICAvLyBUcmlnZ2VyIGN1cnNvciBjYWxsYmFja1xuICAgKiBgYGBcbiAgICogQHJlbWFya3NcbiAgICogLSBIYXMgbm8gZWZmZWN0IG9uIE9mZnNjcmVlbkNhbnZhcyBleGNlcHQgZm9yIGNhbGxiYWNrLWJhc2VkIGN1cnNvcnNcbiAgICogLSBDYWNoZXMgY3VycmVudCBjdXJzb3IgdG8gYXZvaWQgdW5uZWNlc3NhcnkgRE9NIHVwZGF0ZXNcbiAgICogLSBTdXBwb3J0cyBDU1MgY3Vyc29yIHZhbHVlcywgc3R5bGUgb2JqZWN0cywgYW5kIGNhbGxiYWNrIGZ1bmN0aW9uc1xuICAgKiBAc2VlIHtAbGluayBFdmVudFN5c3RlbS5jdXJzb3JTdHlsZXN9IEZvciBkZWZpbmluZyBjdXN0b20gY3Vyc29yIHN0eWxlc1xuICAgKiBAc2VlIHtAbGluayBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9DU1MvY3Vyc29yfSBNRE4gQ3Vyc29yIFJlZmVyZW5jZVxuICAgKi9cbiAgc2V0Q3Vyc29yKG1vZGUpIHtcbiAgICBtb2RlIHx8IChtb2RlID0gXCJkZWZhdWx0XCIpO1xuICAgIGxldCBhcHBseVN0eWxlcyA9IHRydWU7XG4gICAgaWYgKGdsb2JhbFRoaXMuT2Zmc2NyZWVuQ2FudmFzICYmIHRoaXMuZG9tRWxlbWVudCBpbnN0YW5jZW9mIE9mZnNjcmVlbkNhbnZhcykge1xuICAgICAgYXBwbHlTdHlsZXMgPSBmYWxzZTtcbiAgICB9XG4gICAgaWYgKHRoaXMuX2N1cnJlbnRDdXJzb3IgPT09IG1vZGUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5fY3VycmVudEN1cnNvciA9IG1vZGU7XG4gICAgY29uc3Qgc3R5bGUgPSB0aGlzLmN1cnNvclN0eWxlc1ttb2RlXTtcbiAgICBpZiAoc3R5bGUpIHtcbiAgICAgIHN3aXRjaCAodHlwZW9mIHN0eWxlKSB7XG4gICAgICAgIGNhc2UgXCJzdHJpbmdcIjpcbiAgICAgICAgICBpZiAoYXBwbHlTdHlsZXMpIHtcbiAgICAgICAgICAgIHRoaXMuZG9tRWxlbWVudC5zdHlsZS5jdXJzb3IgPSBzdHlsZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJmdW5jdGlvblwiOlxuICAgICAgICAgIHN0eWxlKG1vZGUpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwib2JqZWN0XCI6XG4gICAgICAgICAgaWYgKGFwcGx5U3R5bGVzKSB7XG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKHRoaXMuZG9tRWxlbWVudC5zdHlsZSwgc3R5bGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGFwcGx5U3R5bGVzICYmIHR5cGVvZiBtb2RlID09PSBcInN0cmluZ1wiICYmICFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwodGhpcy5jdXJzb3JTdHlsZXMsIG1vZGUpKSB7XG4gICAgICB0aGlzLmRvbUVsZW1lbnQuc3R5bGUuY3Vyc29yID0gbW9kZTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIFRoZSBnbG9iYWwgcG9pbnRlciBldmVudCBpbnN0YW5jZSBjb250YWluaW5nIHRoZSBtb3N0IHJlY2VudCBwb2ludGVyIHN0YXRlLlxuICAgKiBUaGlzIGlzIHVzZWZ1bCBmb3IgYWNjZXNzaW5nIHBvaW50ZXIgaW5mb3JtYXRpb24gd2l0aG91dCBsaXN0ZW5pbmcgdG8gZXZlbnRzLlxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBBY2Nlc3MgY3VycmVudCBwb2ludGVyIHBvc2l0aW9uIGF0IGFueSB0aW1lXG4gICAqIGNvbnN0IGV2ZW50U3lzdGVtID0gYXBwLnJlbmRlcmVyLmV2ZW50cztcbiAgICogY29uc3QgcG9pbnRlciA9IGV2ZW50U3lzdGVtLnBvaW50ZXI7XG4gICAqXG4gICAqIC8vIEdldCBnbG9iYWwgY29vcmRpbmF0ZXNcbiAgICogY29uc29sZS5sb2coJ1Bvc2l0aW9uOicsIHBvaW50ZXIuZ2xvYmFsLngsIHBvaW50ZXIuZ2xvYmFsLnkpO1xuICAgKlxuICAgKiAvLyBDaGVjayBidXR0b24gc3RhdGVcbiAgICogY29uc29sZS5sb2coJ0J1dHRvbnMgcHJlc3NlZDonLCBwb2ludGVyLmJ1dHRvbnMpO1xuICAgKlxuICAgKiAvLyBHZXQgcG9pbnRlciB0eXBlIGFuZCBwcmVzc3VyZVxuICAgKiBjb25zb2xlLmxvZygnVHlwZTonLCBwb2ludGVyLnBvaW50ZXJUeXBlKTtcbiAgICogY29uc29sZS5sb2coJ1ByZXNzdXJlOicsIHBvaW50ZXIucHJlc3N1cmUpO1xuICAgKiBgYGBcbiAgICogQHJlYWRvbmx5XG4gICAqIEBzaW5jZSA3LjIuMFxuICAgKiBAc2VlIHtAbGluayBGZWRlcmF0ZWRQb2ludGVyRXZlbnR9IEZvciBhbGwgYXZhaWxhYmxlIHBvaW50ZXIgcHJvcGVydGllc1xuICAgKi9cbiAgZ2V0IHBvaW50ZXIoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3Jvb3RQb2ludGVyRXZlbnQ7XG4gIH1cbiAgLyoqXG4gICAqIEV2ZW50IGhhbmRsZXIgZm9yIHBvaW50ZXIgZG93biBldmVudHMgb24ge0BsaW5rIEV2ZW50U3lzdGVtI2RvbUVsZW1lbnQgdGhpcy5kb21FbGVtZW50fS5cbiAgICogQHBhcmFtIG5hdGl2ZUV2ZW50IC0gVGhlIG5hdGl2ZSBtb3VzZS9wb2ludGVyL3RvdWNoIGV2ZW50LlxuICAgKi9cbiAgX29uUG9pbnRlckRvd24obmF0aXZlRXZlbnQpIHtcbiAgICBpZiAoIXRoaXMuZmVhdHVyZXMuY2xpY2spIHJldHVybjtcbiAgICB0aGlzLnJvb3RCb3VuZGFyeS5yb290VGFyZ2V0ID0gdGhpcy5yZW5kZXJlci5sYXN0T2JqZWN0UmVuZGVyZWQ7XG4gICAgY29uc3QgZXZlbnRzID0gdGhpcy5fbm9ybWFsaXplVG9Qb2ludGVyRGF0YShuYXRpdmVFdmVudCk7XG4gICAgaWYgKHRoaXMuYXV0b1ByZXZlbnREZWZhdWx0ICYmIGV2ZW50c1swXS5pc05vcm1hbGl6ZWQpIHtcbiAgICAgIGNvbnN0IGNhbmNlbGFibGUgPSBuYXRpdmVFdmVudC5jYW5jZWxhYmxlIHx8ICEoXCJjYW5jZWxhYmxlXCIgaW4gbmF0aXZlRXZlbnQpO1xuICAgICAgaWYgKGNhbmNlbGFibGUpIHtcbiAgICAgICAgbmF0aXZlRXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZm9yIChsZXQgaSA9IDAsIGogPSBldmVudHMubGVuZ3RoOyBpIDwgajsgaSsrKSB7XG4gICAgICBjb25zdCBuYXRpdmVFdmVudDIgPSBldmVudHNbaV07XG4gICAgICBjb25zdCBmZWRlcmF0ZWRFdmVudCA9IHRoaXMuX2Jvb3RzdHJhcEV2ZW50KHRoaXMuX3Jvb3RQb2ludGVyRXZlbnQsIG5hdGl2ZUV2ZW50Mik7XG4gICAgICB0aGlzLnJvb3RCb3VuZGFyeS5tYXBFdmVudChmZWRlcmF0ZWRFdmVudCk7XG4gICAgfVxuICAgIHRoaXMuc2V0Q3Vyc29yKHRoaXMucm9vdEJvdW5kYXJ5LmN1cnNvcik7XG4gIH1cbiAgLyoqXG4gICAqIEV2ZW50IGhhbmRsZXIgZm9yIHBvaW50ZXIgbW92ZSBldmVudHMgb24gb24ge0BsaW5rIEV2ZW50U3lzdGVtI2RvbUVsZW1lbnQgdGhpcy5kb21FbGVtZW50fS5cbiAgICogQHBhcmFtIG5hdGl2ZUV2ZW50IC0gVGhlIG5hdGl2ZSBtb3VzZS9wb2ludGVyL3RvdWNoIGV2ZW50cy5cbiAgICovXG4gIF9vblBvaW50ZXJNb3ZlKG5hdGl2ZUV2ZW50KSB7XG4gICAgaWYgKCF0aGlzLmZlYXR1cmVzLm1vdmUpIHJldHVybjtcbiAgICB0aGlzLnJvb3RCb3VuZGFyeS5yb290VGFyZ2V0ID0gdGhpcy5yZW5kZXJlci5sYXN0T2JqZWN0UmVuZGVyZWQ7XG4gICAgRXZlbnRzVGlja2VyLnBvaW50ZXJNb3ZlZCgpO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRFdmVudHMgPSB0aGlzLl9ub3JtYWxpemVUb1BvaW50ZXJEYXRhKG5hdGl2ZUV2ZW50KTtcbiAgICBmb3IgKGxldCBpID0gMCwgaiA9IG5vcm1hbGl6ZWRFdmVudHMubGVuZ3RoOyBpIDwgajsgaSsrKSB7XG4gICAgICBjb25zdCBldmVudCA9IHRoaXMuX2Jvb3RzdHJhcEV2ZW50KHRoaXMuX3Jvb3RQb2ludGVyRXZlbnQsIG5vcm1hbGl6ZWRFdmVudHNbaV0pO1xuICAgICAgdGhpcy5yb290Qm91bmRhcnkubWFwRXZlbnQoZXZlbnQpO1xuICAgIH1cbiAgICB0aGlzLnNldEN1cnNvcih0aGlzLnJvb3RCb3VuZGFyeS5jdXJzb3IpO1xuICB9XG4gIC8qKlxuICAgKiBFdmVudCBoYW5kbGVyIGZvciBwb2ludGVyIHVwIGV2ZW50cyBvbiB7QGxpbmsgRXZlbnRTeXN0ZW0jZG9tRWxlbWVudCB0aGlzLmRvbUVsZW1lbnR9LlxuICAgKiBAcGFyYW0gbmF0aXZlRXZlbnQgLSBUaGUgbmF0aXZlIG1vdXNlL3BvaW50ZXIvdG91Y2ggZXZlbnQuXG4gICAqL1xuICBfb25Qb2ludGVyVXAobmF0aXZlRXZlbnQpIHtcbiAgICBpZiAoIXRoaXMuZmVhdHVyZXMuY2xpY2spIHJldHVybjtcbiAgICB0aGlzLnJvb3RCb3VuZGFyeS5yb290VGFyZ2V0ID0gdGhpcy5yZW5kZXJlci5sYXN0T2JqZWN0UmVuZGVyZWQ7XG4gICAgbGV0IHRhcmdldCA9IG5hdGl2ZUV2ZW50LnRhcmdldDtcbiAgICBpZiAobmF0aXZlRXZlbnQuY29tcG9zZWRQYXRoICYmIG5hdGl2ZUV2ZW50LmNvbXBvc2VkUGF0aCgpLmxlbmd0aCA+IDApIHtcbiAgICAgIHRhcmdldCA9IG5hdGl2ZUV2ZW50LmNvbXBvc2VkUGF0aCgpWzBdO1xuICAgIH1cbiAgICBjb25zdCBvdXRzaWRlID0gdGFyZ2V0ICE9PSB0aGlzLmRvbUVsZW1lbnQgPyBcIm91dHNpZGVcIiA6IFwiXCI7XG4gICAgY29uc3Qgbm9ybWFsaXplZEV2ZW50cyA9IHRoaXMuX25vcm1hbGl6ZVRvUG9pbnRlckRhdGEobmF0aXZlRXZlbnQpO1xuICAgIGZvciAobGV0IGkgPSAwLCBqID0gbm9ybWFsaXplZEV2ZW50cy5sZW5ndGg7IGkgPCBqOyBpKyspIHtcbiAgICAgIGNvbnN0IGV2ZW50ID0gdGhpcy5fYm9vdHN0cmFwRXZlbnQodGhpcy5fcm9vdFBvaW50ZXJFdmVudCwgbm9ybWFsaXplZEV2ZW50c1tpXSk7XG4gICAgICBldmVudC50eXBlICs9IG91dHNpZGU7XG4gICAgICB0aGlzLnJvb3RCb3VuZGFyeS5tYXBFdmVudChldmVudCk7XG4gICAgfVxuICAgIHRoaXMuc2V0Q3Vyc29yKHRoaXMucm9vdEJvdW5kYXJ5LmN1cnNvcik7XG4gIH1cbiAgLyoqXG4gICAqIEV2ZW50IGhhbmRsZXIgZm9yIHBvaW50ZXIgb3ZlciAmIG91dCBldmVudHMgb24ge0BsaW5rIEV2ZW50U3lzdGVtI2RvbUVsZW1lbnQgdGhpcy5kb21FbGVtZW50fS5cbiAgICogQHBhcmFtIG5hdGl2ZUV2ZW50IC0gVGhlIG5hdGl2ZSBtb3VzZS9wb2ludGVyL3RvdWNoIGV2ZW50LlxuICAgKi9cbiAgX29uUG9pbnRlck92ZXJPdXQobmF0aXZlRXZlbnQpIHtcbiAgICBpZiAoIXRoaXMuZmVhdHVyZXMuY2xpY2spIHJldHVybjtcbiAgICB0aGlzLnJvb3RCb3VuZGFyeS5yb290VGFyZ2V0ID0gdGhpcy5yZW5kZXJlci5sYXN0T2JqZWN0UmVuZGVyZWQ7XG4gICAgY29uc3Qgbm9ybWFsaXplZEV2ZW50cyA9IHRoaXMuX25vcm1hbGl6ZVRvUG9pbnRlckRhdGEobmF0aXZlRXZlbnQpO1xuICAgIGZvciAobGV0IGkgPSAwLCBqID0gbm9ybWFsaXplZEV2ZW50cy5sZW5ndGg7IGkgPCBqOyBpKyspIHtcbiAgICAgIGNvbnN0IGV2ZW50ID0gdGhpcy5fYm9vdHN0cmFwRXZlbnQodGhpcy5fcm9vdFBvaW50ZXJFdmVudCwgbm9ybWFsaXplZEV2ZW50c1tpXSk7XG4gICAgICB0aGlzLnJvb3RCb3VuZGFyeS5tYXBFdmVudChldmVudCk7XG4gICAgfVxuICAgIHRoaXMuc2V0Q3Vyc29yKHRoaXMucm9vdEJvdW5kYXJ5LmN1cnNvcik7XG4gIH1cbiAgLyoqXG4gICAqIEV2ZW50IGhhbmRsZXIgZm9yIGBjb250ZXh0bWVudWAgZXZlbnRzIG9uIHtAbGluayBFdmVudFN5c3RlbSNkb21FbGVtZW50IHRoaXMuZG9tRWxlbWVudH0uXG4gICAqXG4gICAqIHtAbGluayBFdmVudFN5c3RlbSNhdXRvUHJldmVudERlZmF1bHQgYXV0b1ByZXZlbnREZWZhdWx0fSBkb2VzIG5vdCBhcHBseSwgc28gdGhlIGJyb3dzZXIgbWVudVxuICAgKiBvcGVucyB1bmxlc3MgYSBsaXN0ZW5lciBjYWxscyBgcHJldmVudERlZmF1bHQoKWAuXG4gICAqIEBwYXJhbSBuYXRpdmVFdmVudCAtIFRoZSBuYXRpdmUgbW91c2UvcG9pbnRlciBldmVudC5cbiAgICovXG4gIF9vbkNvbnRleHRNZW51KG5hdGl2ZUV2ZW50KSB7XG4gICAgaWYgKCF0aGlzLmZlYXR1cmVzLmNsaWNrKSByZXR1cm47XG4gICAgdGhpcy5yb290Qm91bmRhcnkucm9vdFRhcmdldCA9IHRoaXMucmVuZGVyZXIubGFzdE9iamVjdFJlbmRlcmVkO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRFdmVudHMgPSB0aGlzLl9ub3JtYWxpemVUb1BvaW50ZXJEYXRhKG5hdGl2ZUV2ZW50KTtcbiAgICBmb3IgKGxldCBpID0gMCwgaiA9IG5vcm1hbGl6ZWRFdmVudHMubGVuZ3RoOyBpIDwgajsgaSsrKSB7XG4gICAgICBjb25zdCBldmVudCA9IHRoaXMuX2Jvb3RzdHJhcEV2ZW50KHRoaXMuX3Jvb3RDb250ZXh0TWVudUV2ZW50LCBub3JtYWxpemVkRXZlbnRzW2ldKTtcbiAgICAgIHRoaXMucm9vdEJvdW5kYXJ5Lm1hcEV2ZW50KGV2ZW50KTtcbiAgICB9XG4gICAgdGhpcy5zZXRDdXJzb3IodGhpcy5yb290Qm91bmRhcnkuY3Vyc29yKTtcbiAgfVxuICAvKipcbiAgICogUGFzc2l2ZSBoYW5kbGVyIGZvciBgd2hlZWxgIGV2ZW50cyBvbiB7QGxpbmsgRXZlbnRTeXN0ZW0uZG9tRWxlbWVudCB0aGlzLmRvbUVsZW1lbnR9LlxuICAgKiBAcGFyYW0gbmF0aXZlRXZlbnQgLSBUaGUgbmF0aXZlIHdoZWVsIGV2ZW50LlxuICAgKi9cbiAgb25XaGVlbChuYXRpdmVFdmVudCkge1xuICAgIGlmICghdGhpcy5mZWF0dXJlcy53aGVlbCkgcmV0dXJuO1xuICAgIGNvbnN0IHdoZWVsRXZlbnQgPSB0aGlzLm5vcm1hbGl6ZVdoZWVsRXZlbnQobmF0aXZlRXZlbnQpO1xuICAgIHRoaXMucm9vdEJvdW5kYXJ5LnJvb3RUYXJnZXQgPSB0aGlzLnJlbmRlcmVyLmxhc3RPYmplY3RSZW5kZXJlZDtcbiAgICB0aGlzLnJvb3RCb3VuZGFyeS5tYXBFdmVudCh3aGVlbEV2ZW50KTtcbiAgfVxuICAvKipcbiAgICogU2V0cyB0aGUge0BsaW5rIEV2ZW50U3lzdGVtI2RvbUVsZW1lbnQgZG9tRWxlbWVudH0gYW5kIGJpbmRzIGV2ZW50IGxpc3RlbmVycy5cbiAgICogVGhpcyBtZXRob2QgbWFuYWdlcyB0aGUgRE9NIGV2ZW50IGJpbmRpbmdzIGZvciB0aGUgZXZlbnQgc3lzdGVtLCBhbGxvd2luZyB5b3UgdG9cbiAgICogY2hhbmdlIG9yIHJlbW92ZSB0aGUgdGFyZ2V0IGVsZW1lbnQgdGhhdCByZWNlaXZlcyBpbnB1dCBldmVudHMuXG4gICAqID4gWyFJTVBPUlRBTlRdIFRoaXMgd2lsbCBkZWZhdWx0IHRvIHRoZSBjYW52YXMgZWxlbWVudCBvZiB0aGUgcmVuZGVyZXIsIHNvIHlvdVxuICAgKiA+IHNob3VsZCBub3QgbmVlZCB0byBjYWxsIHRoaXMgdW5sZXNzIHlvdSBhcmUgdXNpbmcgYSBjdXN0b20gZWxlbWVudC5cbiAgICogQHBhcmFtIGVsZW1lbnQgLSBUaGUgbmV3IERPTSBlbGVtZW50IHRvIGJpbmQgZXZlbnRzIHRvLCBvciBudWxsIHRvIHJlbW92ZSBhbGwgZXZlbnQgYmluZGluZ3NcbiAgICogQGV4YW1wbGVcbiAgICogYGBgdHNcbiAgICogLy8gU2V0IGEgbmV3IGNhbnZhcyBlbGVtZW50IGFzIHRoZSB0YXJnZXRcbiAgICogY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAqIGFwcC5yZW5kZXJlci5ldmVudHMuc2V0VGFyZ2V0RWxlbWVudChjYW52YXMpO1xuICAgKlxuICAgKiAvLyBSZW1vdmUgYWxsIGV2ZW50IGJpbmRpbmdzXG4gICAqIGFwcC5yZW5kZXJlci5ldmVudHMuc2V0VGFyZ2V0RWxlbWVudChudWxsKTtcbiAgICpcbiAgICogLy8gU3dpdGNoIHRvIGEgZGlmZmVyZW50IGNhbnZhc1xuICAgKiBjb25zdCBuZXdDYW52YXMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjZ2FtZS1jYW52YXMnKTtcbiAgICogYXBwLnJlbmRlcmVyLmV2ZW50cy5zZXRUYXJnZXRFbGVtZW50KG5ld0NhbnZhcyk7XG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIEF1dG9tYXRpY2FsbHkgcmVtb3ZlcyBldmVudCBsaXN0ZW5lcnMgZnJvbSBwcmV2aW91cyBlbGVtZW50XG4gICAqIC0gUmVxdWlyZWQgZm9yIHRoZSBldmVudCBzeXN0ZW0gdG8gZnVuY3Rpb25cbiAgICogLSBTYWZlIHRvIGNhbGwgbXVsdGlwbGUgdGltZXNcbiAgICogQHNlZSB7QGxpbmsgRXZlbnRTeXN0ZW0jZG9tRWxlbWVudH0gVGhlIGN1cnJlbnQgRE9NIGVsZW1lbnRcbiAgICogQHNlZSB7QGxpbmsgRXZlbnRzVGlja2VyfSBGb3IgdGhlIHRpY2tlciBzeXN0ZW0gdGhhdCB0cmFja3MgcG9pbnRlciBtb3ZlbWVudFxuICAgKi9cbiAgc2V0VGFyZ2V0RWxlbWVudChlbGVtZW50KSB7XG4gICAgdGhpcy5fcmVtb3ZlRXZlbnRzKCk7XG4gICAgdGhpcy5kb21FbGVtZW50ID0gZWxlbWVudDtcbiAgICBFdmVudHNUaWNrZXIuZG9tRWxlbWVudCA9IGVsZW1lbnQ7XG4gICAgdGhpcy5fYWRkRXZlbnRzKCk7XG4gIH1cbiAgLyoqIFJlZ2lzdGVyIGV2ZW50IGxpc3RlbmVycyBvbiB7QGxpbmsgUmVuZGVyZXIjZG9tRWxlbWVudCB0aGlzLmRvbUVsZW1lbnR9LiAqL1xuICBfYWRkRXZlbnRzKCkge1xuICAgIGlmICh0aGlzLl9ldmVudHNBZGRlZCB8fCAhdGhpcy5kb21FbGVtZW50KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIEV2ZW50c1RpY2tlci5hZGRUaWNrZXJMaXN0ZW5lcigpO1xuICAgIGNvbnN0IHN0eWxlID0gdGhpcy5kb21FbGVtZW50LnN0eWxlO1xuICAgIGlmIChzdHlsZSkge1xuICAgICAgaWYgKGdsb2JhbFRoaXMubmF2aWdhdG9yLm1zUG9pbnRlckVuYWJsZWQpIHtcbiAgICAgICAgc3R5bGUubXNDb250ZW50Wm9vbWluZyA9IFwibm9uZVwiO1xuICAgICAgICBzdHlsZS5tc1RvdWNoQWN0aW9uID0gXCJub25lXCI7XG4gICAgICB9IGVsc2UgaWYgKHRoaXMuc3VwcG9ydHNQb2ludGVyRXZlbnRzKSB7XG4gICAgICAgIHN0eWxlLnRvdWNoQWN0aW9uID0gXCJub25lXCI7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICh0aGlzLnN1cHBvcnRzUG9pbnRlckV2ZW50cykge1xuICAgICAgZ2xvYmFsVGhpcy5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwicG9pbnRlcm1vdmVcIiwgdGhpcy5fb25Qb2ludGVyTW92ZSwgdHJ1ZSk7XG4gICAgICB0aGlzLmRvbUVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJkb3duXCIsIHRoaXMuX29uUG9pbnRlckRvd24sIHRydWUpO1xuICAgICAgdGhpcy5kb21FbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJwb2ludGVybGVhdmVcIiwgdGhpcy5fb25Qb2ludGVyT3Zlck91dCwgdHJ1ZSk7XG4gICAgICB0aGlzLmRvbUVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJvdmVyXCIsIHRoaXMuX29uUG9pbnRlck92ZXJPdXQsIHRydWUpO1xuICAgICAgZ2xvYmFsVGhpcy5hZGRFdmVudExpc3RlbmVyKFwicG9pbnRlcnVwXCIsIHRoaXMuX29uUG9pbnRlclVwLCB0cnVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZ2xvYmFsVGhpcy5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwibW91c2Vtb3ZlXCIsIHRoaXMuX29uUG9pbnRlck1vdmUsIHRydWUpO1xuICAgICAgdGhpcy5kb21FbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZWRvd25cIiwgdGhpcy5fb25Qb2ludGVyRG93biwgdHJ1ZSk7XG4gICAgICB0aGlzLmRvbUVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlb3V0XCIsIHRoaXMuX29uUG9pbnRlck92ZXJPdXQsIHRydWUpO1xuICAgICAgdGhpcy5kb21FbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZW92ZXJcIiwgdGhpcy5fb25Qb2ludGVyT3Zlck91dCwgdHJ1ZSk7XG4gICAgICBnbG9iYWxUaGlzLmFkZEV2ZW50TGlzdGVuZXIoXCJtb3VzZXVwXCIsIHRoaXMuX29uUG9pbnRlclVwLCB0cnVlKTtcbiAgICAgIGlmICh0aGlzLnN1cHBvcnRzVG91Y2hFdmVudHMpIHtcbiAgICAgICAgdGhpcy5kb21FbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJ0b3VjaHN0YXJ0XCIsIHRoaXMuX29uUG9pbnRlckRvd24sIHRydWUpO1xuICAgICAgICB0aGlzLmRvbUVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInRvdWNoZW5kXCIsIHRoaXMuX29uUG9pbnRlclVwLCB0cnVlKTtcbiAgICAgICAgdGhpcy5kb21FbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJ0b3VjaG1vdmVcIiwgdGhpcy5fb25Qb2ludGVyTW92ZSwgdHJ1ZSk7XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuZG9tRWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwid2hlZWxcIiwgdGhpcy5vbldoZWVsLCB7XG4gICAgICBwYXNzaXZlOiB0cnVlLFxuICAgICAgY2FwdHVyZTogdHJ1ZVxuICAgIH0pO1xuICAgIHRoaXMuZG9tRWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY29udGV4dG1lbnVcIiwgdGhpcy5fb25Db250ZXh0TWVudSwgdHJ1ZSk7XG4gICAgdGhpcy5fZXZlbnRzQWRkZWQgPSB0cnVlO1xuICB9XG4gIC8qKiBVbnJlZ2lzdGVyIGV2ZW50IGxpc3RlbmVycyBvbiB7QGxpbmsgRXZlbnRTeXN0ZW0jZG9tRWxlbWVudCB0aGlzLmRvbUVsZW1lbnR9LiAqL1xuICBfcmVtb3ZlRXZlbnRzKCkge1xuICAgIGlmICghdGhpcy5fZXZlbnRzQWRkZWQgfHwgIXRoaXMuZG9tRWxlbWVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBFdmVudHNUaWNrZXIucmVtb3ZlVGlja2VyTGlzdGVuZXIoKTtcbiAgICBjb25zdCBzdHlsZSA9IHRoaXMuZG9tRWxlbWVudC5zdHlsZTtcbiAgICBpZiAoc3R5bGUpIHtcbiAgICAgIGlmIChnbG9iYWxUaGlzLm5hdmlnYXRvci5tc1BvaW50ZXJFbmFibGVkKSB7XG4gICAgICAgIHN0eWxlLm1zQ29udGVudFpvb21pbmcgPSBcIlwiO1xuICAgICAgICBzdHlsZS5tc1RvdWNoQWN0aW9uID0gXCJcIjtcbiAgICAgIH0gZWxzZSBpZiAodGhpcy5zdXBwb3J0c1BvaW50ZXJFdmVudHMpIHtcbiAgICAgICAgc3R5bGUudG91Y2hBY3Rpb24gPSBcIlwiO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAodGhpcy5zdXBwb3J0c1BvaW50ZXJFdmVudHMpIHtcbiAgICAgIGdsb2JhbFRoaXMuZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJtb3ZlXCIsIHRoaXMuX29uUG9pbnRlck1vdmUsIHRydWUpO1xuICAgICAgdGhpcy5kb21FbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb2ludGVyZG93blwiLCB0aGlzLl9vblBvaW50ZXJEb3duLCB0cnVlKTtcbiAgICAgIHRoaXMuZG9tRWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwicG9pbnRlcmxlYXZlXCIsIHRoaXMuX29uUG9pbnRlck92ZXJPdXQsIHRydWUpO1xuICAgICAgdGhpcy5kb21FbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb2ludGVyb3ZlclwiLCB0aGlzLl9vblBvaW50ZXJPdmVyT3V0LCB0cnVlKTtcbiAgICAgIGdsb2JhbFRoaXMucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBvaW50ZXJ1cFwiLCB0aGlzLl9vblBvaW50ZXJVcCwgdHJ1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGdsb2JhbFRoaXMuZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1vdXNlbW92ZVwiLCB0aGlzLl9vblBvaW50ZXJNb3ZlLCB0cnVlKTtcbiAgICAgIHRoaXMuZG9tRWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwibW91c2Vkb3duXCIsIHRoaXMuX29uUG9pbnRlckRvd24sIHRydWUpO1xuICAgICAgdGhpcy5kb21FbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtb3VzZW91dFwiLCB0aGlzLl9vblBvaW50ZXJPdmVyT3V0LCB0cnVlKTtcbiAgICAgIHRoaXMuZG9tRWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwibW91c2VvdmVyXCIsIHRoaXMuX29uUG9pbnRlck92ZXJPdXQsIHRydWUpO1xuICAgICAgZ2xvYmFsVGhpcy5yZW1vdmVFdmVudExpc3RlbmVyKFwibW91c2V1cFwiLCB0aGlzLl9vblBvaW50ZXJVcCwgdHJ1ZSk7XG4gICAgICBpZiAodGhpcy5zdXBwb3J0c1RvdWNoRXZlbnRzKSB7XG4gICAgICAgIHRoaXMuZG9tRWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwidG91Y2hzdGFydFwiLCB0aGlzLl9vblBvaW50ZXJEb3duLCB0cnVlKTtcbiAgICAgICAgdGhpcy5kb21FbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJ0b3VjaGVuZFwiLCB0aGlzLl9vblBvaW50ZXJVcCwgdHJ1ZSk7XG4gICAgICAgIHRoaXMuZG9tRWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKFwidG91Y2htb3ZlXCIsIHRoaXMuX29uUG9pbnRlck1vdmUsIHRydWUpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLmRvbUVsZW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIndoZWVsXCIsIHRoaXMub25XaGVlbCwgdHJ1ZSk7XG4gICAgdGhpcy5kb21FbGVtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjb250ZXh0bWVudVwiLCB0aGlzLl9vbkNvbnRleHRNZW51LCB0cnVlKTtcbiAgICB0aGlzLmRvbUVsZW1lbnQgPSBudWxsO1xuICAgIHRoaXMuX2V2ZW50c0FkZGVkID0gZmFsc2U7XG4gIH1cbiAgLyoqXG4gICAqIE1hcHMgY29vcmRpbmF0ZXMgZnJvbSBET00vc2NyZWVuIHNwYWNlIGludG8gUGl4aUpTIG5vcm1hbGl6ZWQgY29vcmRpbmF0ZXMuXG4gICAqIFRoaXMgdGFrZXMgaW50byBhY2NvdW50IHRoZSBjdXJyZW50IHNjYWxlLCBwb3NpdGlvbiwgYW5kIHJlc29sdXRpb24gb2YgdGhlIERPTSBlbGVtZW50LlxuICAgKiBAcGFyYW0gcG9pbnQgLSBUaGUgcG9pbnQgdG8gc3RvcmUgdGhlIG1hcHBlZCBjb29yZGluYXRlcyBpblxuICAgKiBAcGFyYW0geCAtIFRoZSB4IGNvb3JkaW5hdGUgaW4gRE9NL2NsaWVudCBzcGFjZVxuICAgKiBAcGFyYW0geSAtIFRoZSB5IGNvb3JkaW5hdGUgaW4gRE9NL2NsaWVudCBzcGFjZVxuICAgKiBAZXhhbXBsZVxuICAgKiBgYGB0c1xuICAgKiAvLyBNYXAgbW91c2UgY29vcmRpbmF0ZXMgdG8gUGl4aUpTIHNwYWNlXG4gICAqIGNvbnN0IHBvaW50ID0gbmV3IFBvaW50KCk7XG4gICAqIGFwcC5yZW5kZXJlci5ldmVudHMubWFwUG9zaXRpb25Ub1BvaW50KFxuICAgKiAgICAgcG9pbnQsXG4gICAqICAgICBldmVudC5jbGllbnRYLFxuICAgKiAgICAgZXZlbnQuY2xpZW50WVxuICAgKiApO1xuICAgKiBjb25zb2xlLmxvZygnTWFwcGVkIHBvc2l0aW9uOicsIHBvaW50LngsIHBvaW50LnkpO1xuICAgKlxuICAgKiAvLyBVc2luZyB3aXRoIHBvaW50ZXIgZXZlbnRzXG4gICAqIHNwcml0ZS5vbigncG9pbnRlcm1vdmUnLCAoZXZlbnQpID0+IHtcbiAgICogICAgIC8vIGV2ZW50Lmdsb2JhbCBhbHJlYWR5IGNvbnRhaW5zIG1hcHBlZCBjb29yZGluYXRlc1xuICAgKiAgICAgY29uc29sZS5sb2coJ0dsb2JhbDonLCBldmVudC5nbG9iYWwueCwgZXZlbnQuZ2xvYmFsLnkpO1xuICAgKlxuICAgKiAgICAgLy8gTWFwIHRvIGxvY2FsIGNvb3JkaW5hdGVzXG4gICAqICAgICBjb25zdCBsb2NhbCA9IGV2ZW50LmdldExvY2FsUG9zaXRpb24oc3ByaXRlKTtcbiAgICogICAgIGNvbnNvbGUubG9nKCdMb2NhbDonLCBsb2NhbC54LCBsb2NhbC55KTtcbiAgICogfSk7XG4gICAqIGBgYFxuICAgKiBAcmVtYXJrc1xuICAgKiAtIEFjY291bnRzIGZvciBlbGVtZW50IHNjYWxpbmcgYW5kIHBvc2l0aW9uaW5nXG4gICAqIC0gQWRqdXN0cyBmb3IgZGV2aWNlIHBpeGVsIHJhdGlvL3Jlc29sdXRpb25cbiAgICovXG4gIG1hcFBvc2l0aW9uVG9Qb2ludChwb2ludCwgeCwgeSkge1xuICAgIGNvbnN0IHJlY3QgPSB0aGlzLmRvbUVsZW1lbnQuaXNDb25uZWN0ZWQgPyB0aGlzLmRvbUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkgOiB7XG4gICAgICB4OiAwLFxuICAgICAgeTogMCxcbiAgICAgIHdpZHRoOiB0aGlzLmRvbUVsZW1lbnQud2lkdGgsXG4gICAgICBoZWlnaHQ6IHRoaXMuZG9tRWxlbWVudC5oZWlnaHQsXG4gICAgICBsZWZ0OiAwLFxuICAgICAgdG9wOiAwXG4gICAgfTtcbiAgICBjb25zdCByZXNvbHV0aW9uTXVsdGlwbGllciA9IDEgLyB0aGlzLnJlc29sdXRpb247XG4gICAgcG9pbnQueCA9ICh4IC0gcmVjdC5sZWZ0KSAqICh0aGlzLmRvbUVsZW1lbnQud2lkdGggLyByZWN0LndpZHRoKSAqIHJlc29sdXRpb25NdWx0aXBsaWVyO1xuICAgIHBvaW50LnkgPSAoeSAtIHJlY3QudG9wKSAqICh0aGlzLmRvbUVsZW1lbnQuaGVpZ2h0IC8gcmVjdC5oZWlnaHQpICogcmVzb2x1dGlvbk11bHRpcGxpZXI7XG4gIH1cbiAgLyoqXG4gICAqIEVuc3VyZXMgdGhhdCB0aGUgb3JpZ2luYWwgZXZlbnQgb2JqZWN0IGNvbnRhaW5zIGFsbCBkYXRhIHRoYXQgYSByZWd1bGFyIHBvaW50ZXIgZXZlbnQgd291bGQgaGF2ZVxuICAgKiBAcGFyYW0gZXZlbnQgLSBUaGUgb3JpZ2luYWwgZXZlbnQgZGF0YSBmcm9tIGEgdG91Y2ggb3IgbW91c2UgZXZlbnRcbiAgICogQHJldHVybnMgQW4gYXJyYXkgY29udGFpbmluZyBhIHNpbmdsZSBub3JtYWxpemVkIHBvaW50ZXIgZXZlbnQsIGluIHRoZSBjYXNlIG9mIGEgcG9pbnRlclxuICAgKiAgb3IgbW91c2UgZXZlbnQsIG9yIGEgbXVsdGlwbGUgbm9ybWFsaXplZCBwb2ludGVyIGV2ZW50cyBpZiB0aGVyZSBhcmUgbXVsdGlwbGUgY2hhbmdlZCB0b3VjaGVzXG4gICAqL1xuICBfbm9ybWFsaXplVG9Qb2ludGVyRGF0YShldmVudCkge1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRFdmVudHMgPSBbXTtcbiAgICBpZiAodGhpcy5zdXBwb3J0c1RvdWNoRXZlbnRzICYmIGV2ZW50IGluc3RhbmNlb2YgVG91Y2hFdmVudCkge1xuICAgICAgZm9yIChsZXQgaSA9IDAsIGxpID0gZXZlbnQuY2hhbmdlZFRvdWNoZXMubGVuZ3RoOyBpIDwgbGk7IGkrKykge1xuICAgICAgICBjb25zdCB0b3VjaCA9IGV2ZW50LmNoYW5nZWRUb3VjaGVzW2ldO1xuICAgICAgICBpZiAodHlwZW9mIHRvdWNoLmJ1dHRvbiA9PT0gXCJ1bmRlZmluZWRcIikgdG91Y2guYnV0dG9uID0gMDtcbiAgICAgICAgaWYgKHR5cGVvZiB0b3VjaC5idXR0b25zID09PSBcInVuZGVmaW5lZFwiKSB0b3VjaC5idXR0b25zID0gMTtcbiAgICAgICAgaWYgKHR5cGVvZiB0b3VjaC5pc1ByaW1hcnkgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICB0b3VjaC5pc1ByaW1hcnkgPSBldmVudC50b3VjaGVzLmxlbmd0aCA9PT0gMSAmJiBldmVudC50eXBlID09PSBcInRvdWNoc3RhcnRcIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIHRvdWNoLndpZHRoID09PSBcInVuZGVmaW5lZFwiKSB0b3VjaC53aWR0aCA9IHRvdWNoLnJhZGl1c1ggfHwgMTtcbiAgICAgICAgaWYgKHR5cGVvZiB0b3VjaC5oZWlnaHQgPT09IFwidW5kZWZpbmVkXCIpIHRvdWNoLmhlaWdodCA9IHRvdWNoLnJhZGl1c1kgfHwgMTtcbiAgICAgICAgaWYgKHR5cGVvZiB0b3VjaC50aWx0WCA9PT0gXCJ1bmRlZmluZWRcIikgdG91Y2gudGlsdFggPSAwO1xuICAgICAgICBpZiAodHlwZW9mIHRvdWNoLnRpbHRZID09PSBcInVuZGVmaW5lZFwiKSB0b3VjaC50aWx0WSA9IDA7XG4gICAgICAgIGlmICh0eXBlb2YgdG91Y2gucG9pbnRlclR5cGUgPT09IFwidW5kZWZpbmVkXCIpIHRvdWNoLnBvaW50ZXJUeXBlID0gXCJ0b3VjaFwiO1xuICAgICAgICBpZiAodHlwZW9mIHRvdWNoLnBvaW50ZXJJZCA9PT0gXCJ1bmRlZmluZWRcIikgdG91Y2gucG9pbnRlcklkID0gdG91Y2guaWRlbnRpZmllciB8fCAwO1xuICAgICAgICBpZiAodHlwZW9mIHRvdWNoLnByZXNzdXJlID09PSBcInVuZGVmaW5lZFwiKSB0b3VjaC5wcmVzc3VyZSA9IHRvdWNoLmZvcmNlIHx8IDAuNTtcbiAgICAgICAgaWYgKHR5cGVvZiB0b3VjaC50d2lzdCA9PT0gXCJ1bmRlZmluZWRcIikgdG91Y2gudHdpc3QgPSAwO1xuICAgICAgICBpZiAodHlwZW9mIHRvdWNoLnRhbmdlbnRpYWxQcmVzc3VyZSA9PT0gXCJ1bmRlZmluZWRcIikgdG91Y2gudGFuZ2VudGlhbFByZXNzdXJlID0gMDtcbiAgICAgICAgaWYgKHR5cGVvZiB0b3VjaC5sYXllclggPT09IFwidW5kZWZpbmVkXCIpIHRvdWNoLmxheWVyWCA9IHRvdWNoLm9mZnNldFggPSB0b3VjaC5jbGllbnRYO1xuICAgICAgICBpZiAodHlwZW9mIHRvdWNoLmxheWVyWSA9PT0gXCJ1bmRlZmluZWRcIikgdG91Y2gubGF5ZXJZID0gdG91Y2gub2Zmc2V0WSA9IHRvdWNoLmNsaWVudFk7XG4gICAgICAgIHRvdWNoLmlzTm9ybWFsaXplZCA9IHRydWU7XG4gICAgICAgIHRvdWNoLnR5cGUgPSBldmVudC50eXBlO1xuICAgICAgICB0b3VjaC5hbHRLZXkgPz8gKHRvdWNoLmFsdEtleSA9IGV2ZW50LmFsdEtleSk7XG4gICAgICAgIHRvdWNoLmN0cmxLZXkgPz8gKHRvdWNoLmN0cmxLZXkgPSBldmVudC5jdHJsS2V5KTtcbiAgICAgICAgdG91Y2gubWV0YUtleSA/PyAodG91Y2gubWV0YUtleSA9IGV2ZW50Lm1ldGFLZXkpO1xuICAgICAgICB0b3VjaC5zaGlmdEtleSA/PyAodG91Y2guc2hpZnRLZXkgPSBldmVudC5zaGlmdEtleSk7XG4gICAgICAgIG5vcm1hbGl6ZWRFdmVudHMucHVzaCh0b3VjaCk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICghZ2xvYmFsVGhpcy5Nb3VzZUV2ZW50IHx8IGV2ZW50IGluc3RhbmNlb2YgTW91c2VFdmVudCAmJiAoIXRoaXMuc3VwcG9ydHNQb2ludGVyRXZlbnRzIHx8ICEoZXZlbnQgaW5zdGFuY2VvZiBnbG9iYWxUaGlzLlBvaW50ZXJFdmVudCkpKSB7XG4gICAgICBjb25zdCB0ZW1wRXZlbnQgPSBldmVudDtcbiAgICAgIGlmICh0eXBlb2YgdGVtcEV2ZW50LmlzUHJpbWFyeSA9PT0gXCJ1bmRlZmluZWRcIikgdGVtcEV2ZW50LmlzUHJpbWFyeSA9IHRydWU7XG4gICAgICBpZiAodHlwZW9mIHRlbXBFdmVudC53aWR0aCA9PT0gXCJ1bmRlZmluZWRcIikgdGVtcEV2ZW50LndpZHRoID0gMTtcbiAgICAgIGlmICh0eXBlb2YgdGVtcEV2ZW50LmhlaWdodCA9PT0gXCJ1bmRlZmluZWRcIikgdGVtcEV2ZW50LmhlaWdodCA9IDE7XG4gICAgICBpZiAodHlwZW9mIHRlbXBFdmVudC50aWx0WCA9PT0gXCJ1bmRlZmluZWRcIikgdGVtcEV2ZW50LnRpbHRYID0gMDtcbiAgICAgIGlmICh0eXBlb2YgdGVtcEV2ZW50LnRpbHRZID09PSBcInVuZGVmaW5lZFwiKSB0ZW1wRXZlbnQudGlsdFkgPSAwO1xuICAgICAgaWYgKHR5cGVvZiB0ZW1wRXZlbnQucG9pbnRlclR5cGUgPT09IFwidW5kZWZpbmVkXCIpIHRlbXBFdmVudC5wb2ludGVyVHlwZSA9IFwibW91c2VcIjtcbiAgICAgIGlmICh0eXBlb2YgdGVtcEV2ZW50LnBvaW50ZXJJZCA9PT0gXCJ1bmRlZmluZWRcIikgdGVtcEV2ZW50LnBvaW50ZXJJZCA9IE1PVVNFX1BPSU5URVJfSUQ7XG4gICAgICBpZiAodHlwZW9mIHRlbXBFdmVudC5wcmVzc3VyZSA9PT0gXCJ1bmRlZmluZWRcIikgdGVtcEV2ZW50LnByZXNzdXJlID0gMC41O1xuICAgICAgaWYgKHR5cGVvZiB0ZW1wRXZlbnQudHdpc3QgPT09IFwidW5kZWZpbmVkXCIpIHRlbXBFdmVudC50d2lzdCA9IDA7XG4gICAgICBpZiAodHlwZW9mIHRlbXBFdmVudC50YW5nZW50aWFsUHJlc3N1cmUgPT09IFwidW5kZWZpbmVkXCIpIHRlbXBFdmVudC50YW5nZW50aWFsUHJlc3N1cmUgPSAwO1xuICAgICAgdGVtcEV2ZW50LmlzTm9ybWFsaXplZCA9IHRydWU7XG4gICAgICBub3JtYWxpemVkRXZlbnRzLnB1c2godGVtcEV2ZW50KTtcbiAgICB9IGVsc2Uge1xuICAgICAgbm9ybWFsaXplZEV2ZW50cy5wdXNoKGV2ZW50KTtcbiAgICB9XG4gICAgcmV0dXJuIG5vcm1hbGl6ZWRFdmVudHM7XG4gIH1cbiAgLyoqXG4gICAqIE5vcm1hbGl6ZXMgdGhlIG5hdGl2ZSB7QGxpbmsgaHR0cHM6Ly93M2MuZ2l0aHViLmlvL3VpZXZlbnRzLyNpbnRlcmZhY2Utd2hlZWxldmVudCBXaGVlbEV2ZW50fS5cbiAgICpcbiAgICogVGhlIHJldHVybmVkIHtAbGluayBGZWRlcmF0ZWRXaGVlbEV2ZW50fSBpcyBhIHNoYXJlZCBpbnN0YW5jZS4gSXQgd2lsbCBub3QgcGVyc2lzdCBhY3Jvc3NcbiAgICogbXVsdGlwbGUgbmF0aXZlIHdoZWVsIGV2ZW50cy5cbiAgICogQHBhcmFtIG5hdGl2ZUV2ZW50IC0gVGhlIG5hdGl2ZSB3aGVlbCBldmVudCB0aGF0IG9jY3VycmVkIG9uIHRoZSBjYW52YXMuXG4gICAqIEByZXR1cm5zIEEgZmVkZXJhdGVkIHdoZWVsIGV2ZW50LlxuICAgKi9cbiAgbm9ybWFsaXplV2hlZWxFdmVudChuYXRpdmVFdmVudCkge1xuICAgIGNvbnN0IGV2ZW50ID0gdGhpcy5fcm9vdFdoZWVsRXZlbnQ7XG4gICAgdGhpcy5fdHJhbnNmZXJNb3VzZURhdGEoZXZlbnQsIG5hdGl2ZUV2ZW50KTtcbiAgICBldmVudC5kZWx0YVggPSBuYXRpdmVFdmVudC5kZWx0YVg7XG4gICAgZXZlbnQuZGVsdGFZID0gbmF0aXZlRXZlbnQuZGVsdGFZO1xuICAgIGV2ZW50LmRlbHRhWiA9IG5hdGl2ZUV2ZW50LmRlbHRhWjtcbiAgICBldmVudC5kZWx0YU1vZGUgPSBuYXRpdmVFdmVudC5kZWx0YU1vZGU7XG4gICAgdGhpcy5tYXBQb3NpdGlvblRvUG9pbnQoZXZlbnQuc2NyZWVuLCBuYXRpdmVFdmVudC5jbGllbnRYLCBuYXRpdmVFdmVudC5jbGllbnRZKTtcbiAgICBldmVudC5nbG9iYWwuY29weUZyb20oZXZlbnQuc2NyZWVuKTtcbiAgICBldmVudC5vZmZzZXQuY29weUZyb20oZXZlbnQuc2NyZWVuKTtcbiAgICBldmVudC5uYXRpdmVFdmVudCA9IG5hdGl2ZUV2ZW50O1xuICAgIGV2ZW50LnR5cGUgPSBuYXRpdmVFdmVudC50eXBlO1xuICAgIHJldHVybiBldmVudDtcbiAgfVxuICAvKipcbiAgICogTm9ybWFsaXplcyB0aGUgYG5hdGl2ZUV2ZW50YCBpbnRvIGEgZmVkZXJhdGVlZCB7QGxpbmsgRmVkZXJhdGVkUG9pbnRlckV2ZW50fS5cbiAgICogQHBhcmFtIGV2ZW50XG4gICAqIEBwYXJhbSBuYXRpdmVFdmVudFxuICAgKi9cbiAgX2Jvb3RzdHJhcEV2ZW50KGV2ZW50LCBuYXRpdmVFdmVudCkge1xuICAgIGV2ZW50Lm9yaWdpbmFsRXZlbnQgPSBudWxsO1xuICAgIGV2ZW50Lm5hdGl2ZUV2ZW50ID0gbmF0aXZlRXZlbnQ7XG4gICAgZXZlbnQucG9pbnRlcklkID0gbmF0aXZlRXZlbnQucG9pbnRlcklkO1xuICAgIGV2ZW50LndpZHRoID0gbmF0aXZlRXZlbnQud2lkdGg7XG4gICAgZXZlbnQuaGVpZ2h0ID0gbmF0aXZlRXZlbnQuaGVpZ2h0O1xuICAgIGV2ZW50LmlzUHJpbWFyeSA9IG5hdGl2ZUV2ZW50LmlzUHJpbWFyeTtcbiAgICBldmVudC5wb2ludGVyVHlwZSA9IG5hdGl2ZUV2ZW50LnBvaW50ZXJUeXBlO1xuICAgIGV2ZW50LnByZXNzdXJlID0gbmF0aXZlRXZlbnQucHJlc3N1cmU7XG4gICAgZXZlbnQudGFuZ2VudGlhbFByZXNzdXJlID0gbmF0aXZlRXZlbnQudGFuZ2VudGlhbFByZXNzdXJlO1xuICAgIGV2ZW50LnRpbHRYID0gbmF0aXZlRXZlbnQudGlsdFg7XG4gICAgZXZlbnQudGlsdFkgPSBuYXRpdmVFdmVudC50aWx0WTtcbiAgICBldmVudC50d2lzdCA9IG5hdGl2ZUV2ZW50LnR3aXN0O1xuICAgIHRoaXMuX3RyYW5zZmVyTW91c2VEYXRhKGV2ZW50LCBuYXRpdmVFdmVudCk7XG4gICAgdGhpcy5tYXBQb3NpdGlvblRvUG9pbnQoZXZlbnQuc2NyZWVuLCBuYXRpdmVFdmVudC5jbGllbnRYLCBuYXRpdmVFdmVudC5jbGllbnRZKTtcbiAgICBldmVudC5nbG9iYWwuY29weUZyb20oZXZlbnQuc2NyZWVuKTtcbiAgICBldmVudC5vZmZzZXQuY29weUZyb20oZXZlbnQuc2NyZWVuKTtcbiAgICBldmVudC5pc1RydXN0ZWQgPSBuYXRpdmVFdmVudC5pc1RydXN0ZWQ7XG4gICAgaWYgKGV2ZW50LnR5cGUgPT09IFwicG9pbnRlcmxlYXZlXCIpIHtcbiAgICAgIGV2ZW50LnR5cGUgPSBcInBvaW50ZXJvdXRcIjtcbiAgICB9XG4gICAgaWYgKGV2ZW50LnR5cGUuc3RhcnRzV2l0aChcIm1vdXNlXCIpKSB7XG4gICAgICBldmVudC50eXBlID0gZXZlbnQudHlwZS5yZXBsYWNlKFwibW91c2VcIiwgXCJwb2ludGVyXCIpO1xuICAgIH1cbiAgICBpZiAoZXZlbnQudHlwZS5zdGFydHNXaXRoKFwidG91Y2hcIikpIHtcbiAgICAgIGV2ZW50LnR5cGUgPSBUT1VDSF9UT19QT0lOVEVSW2V2ZW50LnR5cGVdIHx8IGV2ZW50LnR5cGU7XG4gICAgfVxuICAgIHJldHVybiBldmVudDtcbiAgfVxuICAvKipcbiAgICogVHJhbnNmZXJzIGJhc2UgJiBtb3VzZSBldmVudCBkYXRhIGZyb20gdGhlIGBuYXRpdmVFdmVudGAgdG8gdGhlIGZlZGVyYXRlZCBldmVudC5cbiAgICogQHBhcmFtIGV2ZW50XG4gICAqIEBwYXJhbSBuYXRpdmVFdmVudFxuICAgKi9cbiAgX3RyYW5zZmVyTW91c2VEYXRhKGV2ZW50LCBuYXRpdmVFdmVudCkge1xuICAgIGV2ZW50LmlzVHJ1c3RlZCA9IG5hdGl2ZUV2ZW50LmlzVHJ1c3RlZDtcbiAgICBldmVudC5zcmNFbGVtZW50ID0gbmF0aXZlRXZlbnQuc3JjRWxlbWVudDtcbiAgICBldmVudC50aW1lU3RhbXAgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICBldmVudC50eXBlID0gbmF0aXZlRXZlbnQudHlwZTtcbiAgICBldmVudC5hbHRLZXkgPSBuYXRpdmVFdmVudC5hbHRLZXk7XG4gICAgZXZlbnQuYnV0dG9uID0gbmF0aXZlRXZlbnQuYnV0dG9uO1xuICAgIGV2ZW50LmJ1dHRvbnMgPSBuYXRpdmVFdmVudC5idXR0b25zO1xuICAgIGV2ZW50LmNsaWVudC54ID0gbmF0aXZlRXZlbnQuY2xpZW50WDtcbiAgICBldmVudC5jbGllbnQueSA9IG5hdGl2ZUV2ZW50LmNsaWVudFk7XG4gICAgZXZlbnQuY3RybEtleSA9IG5hdGl2ZUV2ZW50LmN0cmxLZXk7XG4gICAgZXZlbnQubWV0YUtleSA9IG5hdGl2ZUV2ZW50Lm1ldGFLZXk7XG4gICAgZXZlbnQubW92ZW1lbnQueCA9IG5hdGl2ZUV2ZW50Lm1vdmVtZW50WDtcbiAgICBldmVudC5tb3ZlbWVudC55ID0gbmF0aXZlRXZlbnQubW92ZW1lbnRZO1xuICAgIGV2ZW50LnBhZ2UueCA9IG5hdGl2ZUV2ZW50LnBhZ2VYO1xuICAgIGV2ZW50LnBhZ2UueSA9IG5hdGl2ZUV2ZW50LnBhZ2VZO1xuICAgIGV2ZW50LnJlbGF0ZWRUYXJnZXQgPSBudWxsO1xuICAgIGV2ZW50LnNoaWZ0S2V5ID0gbmF0aXZlRXZlbnQuc2hpZnRLZXk7XG4gIH1cbn07XG4vKiogQGlnbm9yZSAqL1xuX0V2ZW50U3lzdGVtLmV4dGVuc2lvbiA9IHtcbiAgbmFtZTogXCJldmVudHNcIixcbiAgdHlwZTogW1xuICAgIEV4dGVuc2lvblR5cGUuV2ViR0xTeXN0ZW0sXG4gICAgRXh0ZW5zaW9uVHlwZS5DYW52YXNTeXN0ZW0sXG4gICAgRXh0ZW5zaW9uVHlwZS5XZWJHUFVTeXN0ZW1cbiAgXSxcbiAgcHJpb3JpdHk6IC0xXG59O1xuLyoqXG4gKiBUaGUgZXZlbnQgZmVhdHVyZXMgdGhhdCBhcmUgZW5hYmxlZCBieSB0aGUgRXZlbnRTeXN0ZW1cbiAqIEBzaW5jZSA3LjIuMFxuICogQGV4YW1wbGVcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBFdmVudFN5c3RlbSwgRXZlbnRTeXN0ZW1GZWF0dXJlcyB9IGZyb20gJ3BpeGkuanMnO1xuICogLy8gQWNjZXNzIHRoZSBkZWZhdWx0IGV2ZW50IGZlYXR1cmVzXG4gKiBFdmVudFN5c3RlbS5kZWZhdWx0RXZlbnRGZWF0dXJlcyA9IHtcbiAqICAgICAvLyBFbmFibGUgcG9pbnRlciBtb3ZlbWVudCBldmVudHNcbiAqICAgICBtb3ZlOiB0cnVlLFxuICogICAgIC8vIEVuYWJsZSBnbG9iYWwgcG9pbnRlciBtb3ZlIGV2ZW50c1xuICogICAgIGdsb2JhbE1vdmU6IHRydWUsXG4gKiAgICAgLy8gRW5hYmxlIGNsaWNrIGV2ZW50c1xuICogICAgIGNsaWNrOiB0cnVlLFxuICogICAgIC8vIEVuYWJsZSB3aGVlbCBldmVudHNcbiAqICAgICB3aGVlbDogdHJ1ZSxcbiAqIH07XG4gKiBgYGBcbiAqL1xuX0V2ZW50U3lzdGVtLmRlZmF1bHRFdmVudEZlYXR1cmVzID0ge1xuICAvKiogRW5hYmxlcyBwb2ludGVyIGV2ZW50cyBhc3NvY2lhdGVkIHdpdGggcG9pbnRlciBtb3ZlbWVudC4gKi9cbiAgbW92ZTogdHJ1ZSxcbiAgLyoqIEVuYWJsZXMgZ2xvYmFsIHBvaW50ZXIgbW92ZSBldmVudHMuICovXG4gIGdsb2JhbE1vdmU6IHRydWUsXG4gIC8qKiBFbmFibGVzIHBvaW50ZXIgZXZlbnRzIGFzc29jaWF0ZWQgd2l0aCBjbGlja2luZy4gKi9cbiAgY2xpY2s6IHRydWUsXG4gIC8qKiBFbmFibGVzIHdoZWVsIGV2ZW50cy4gKi9cbiAgd2hlZWw6IHRydWVcbn07XG5sZXQgRXZlbnRTeXN0ZW0gPSBfRXZlbnRTeXN0ZW07XG5cbmV4cG9ydCB7IEV2ZW50U3lzdGVtIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1FdmVudFN5c3RlbS5tanMubWFwXG4iLCJpbXBvcnQgeyBFdmVudFN5c3RlbSB9IGZyb20gJy4vRXZlbnRTeXN0ZW0ubWpzJztcbmltcG9ydCB7IEZlZGVyYXRlZEV2ZW50IH0gZnJvbSAnLi9GZWRlcmF0ZWRFdmVudC5tanMnO1xuXG5cInVzZSBzdHJpY3RcIjtcbmNvbnN0IEZlZGVyYXRlZENvbnRhaW5lciA9IHtcbiAgb25jbGljazogbnVsbCxcbiAgb25jb250ZXh0bWVudTogbnVsbCxcbiAgb25tb3VzZWRvd246IG51bGwsXG4gIG9ubW91c2VlbnRlcjogbnVsbCxcbiAgb25tb3VzZWxlYXZlOiBudWxsLFxuICBvbm1vdXNlbW92ZTogbnVsbCxcbiAgb25nbG9iYWxtb3VzZW1vdmU6IG51bGwsXG4gIG9ubW91c2VvdXQ6IG51bGwsXG4gIG9ubW91c2VvdmVyOiBudWxsLFxuICBvbm1vdXNldXA6IG51bGwsXG4gIG9ubW91c2V1cG91dHNpZGU6IG51bGwsXG4gIG9ucG9pbnRlcmNhbmNlbDogbnVsbCxcbiAgb25wb2ludGVyZG93bjogbnVsbCxcbiAgb25wb2ludGVyZW50ZXI6IG51bGwsXG4gIG9ucG9pbnRlcmxlYXZlOiBudWxsLFxuICBvbnBvaW50ZXJtb3ZlOiBudWxsLFxuICBvbmdsb2JhbHBvaW50ZXJtb3ZlOiBudWxsLFxuICBvbnBvaW50ZXJvdXQ6IG51bGwsXG4gIG9ucG9pbnRlcm92ZXI6IG51bGwsXG4gIG9ucG9pbnRlcnRhcDogbnVsbCxcbiAgb25wb2ludGVydXA6IG51bGwsXG4gIG9ucG9pbnRlcnVwb3V0c2lkZTogbnVsbCxcbiAgb25yaWdodGNsaWNrOiBudWxsLFxuICBvbnJpZ2h0ZG93bjogbnVsbCxcbiAgb25yaWdodHVwOiBudWxsLFxuICBvbnJpZ2h0dXBvdXRzaWRlOiBudWxsLFxuICBvbnRhcDogbnVsbCxcbiAgb250b3VjaGNhbmNlbDogbnVsbCxcbiAgb250b3VjaGVuZDogbnVsbCxcbiAgb250b3VjaGVuZG91dHNpZGU6IG51bGwsXG4gIG9udG91Y2htb3ZlOiBudWxsLFxuICBvbmdsb2JhbHRvdWNobW92ZTogbnVsbCxcbiAgb250b3VjaHN0YXJ0OiBudWxsLFxuICBvbndoZWVsOiBudWxsLFxuICBnZXQgaW50ZXJhY3RpdmUoKSB7XG4gICAgcmV0dXJuIHRoaXMuZXZlbnRNb2RlID09PSBcImR5bmFtaWNcIiB8fCB0aGlzLmV2ZW50TW9kZSA9PT0gXCJzdGF0aWNcIjtcbiAgfSxcbiAgc2V0IGludGVyYWN0aXZlKHZhbHVlKSB7XG4gICAgdGhpcy5ldmVudE1vZGUgPSB2YWx1ZSA/IFwic3RhdGljXCIgOiBcInBhc3NpdmVcIjtcbiAgfSxcbiAgX2ludGVybmFsRXZlbnRNb2RlOiB2b2lkIDAsXG4gIGdldCBldmVudE1vZGUoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2ludGVybmFsRXZlbnRNb2RlID8/IEV2ZW50U3lzdGVtLmRlZmF1bHRFdmVudE1vZGU7XG4gIH0sXG4gIHNldCBldmVudE1vZGUodmFsdWUpIHtcbiAgICB0aGlzLl9pbnRlcm5hbEV2ZW50TW9kZSA9IHZhbHVlO1xuICB9LFxuICBpc0ludGVyYWN0aXZlKCkge1xuICAgIHJldHVybiB0aGlzLmV2ZW50TW9kZSA9PT0gXCJzdGF0aWNcIiB8fCB0aGlzLmV2ZW50TW9kZSA9PT0gXCJkeW5hbWljXCI7XG4gIH0sXG4gIGludGVyYWN0aXZlQ2hpbGRyZW46IHRydWUsXG4gIGhpdEFyZWE6IG51bGwsXG4gIGFkZEV2ZW50TGlzdGVuZXIodHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpIHtcbiAgICBjb25zdCBjYXB0dXJlID0gdHlwZW9mIG9wdGlvbnMgPT09IFwiYm9vbGVhblwiICYmIG9wdGlvbnMgfHwgdHlwZW9mIG9wdGlvbnMgPT09IFwib2JqZWN0XCIgJiYgb3B0aW9ucy5jYXB0dXJlO1xuICAgIGNvbnN0IHNpZ25hbCA9IHR5cGVvZiBvcHRpb25zID09PSBcIm9iamVjdFwiID8gb3B0aW9ucy5zaWduYWwgOiB2b2lkIDA7XG4gICAgY29uc3Qgb25jZSA9IHR5cGVvZiBvcHRpb25zID09PSBcIm9iamVjdFwiID8gb3B0aW9ucy5vbmNlID09PSB0cnVlIDogZmFsc2U7XG4gICAgY29uc3QgY29udGV4dCA9IHR5cGVvZiBsaXN0ZW5lciA9PT0gXCJmdW5jdGlvblwiID8gdm9pZCAwIDogbGlzdGVuZXI7XG4gICAgdHlwZSA9IGNhcHR1cmUgPyBgJHt0eXBlfWNhcHR1cmVgIDogdHlwZTtcbiAgICBjb25zdCBsaXN0ZW5lckZuID0gdHlwZW9mIGxpc3RlbmVyID09PSBcImZ1bmN0aW9uXCIgPyBsaXN0ZW5lciA6IGxpc3RlbmVyLmhhbmRsZUV2ZW50O1xuICAgIGNvbnN0IGVtaXR0ZXIgPSB0aGlzO1xuICAgIGlmIChzaWduYWwpIHtcbiAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgKCkgPT4ge1xuICAgICAgICBlbWl0dGVyLm9mZih0eXBlLCBsaXN0ZW5lckZuLCBjb250ZXh0KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAob25jZSkge1xuICAgICAgZW1pdHRlci5vbmNlKHR5cGUsIGxpc3RlbmVyRm4sIGNvbnRleHQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBlbWl0dGVyLm9uKHR5cGUsIGxpc3RlbmVyRm4sIGNvbnRleHQpO1xuICAgIH1cbiAgfSxcbiAgcmVtb3ZlRXZlbnRMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lciwgb3B0aW9ucykge1xuICAgIGNvbnN0IGNhcHR1cmUgPSB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJib29sZWFuXCIgJiYgb3B0aW9ucyB8fCB0eXBlb2Ygb3B0aW9ucyA9PT0gXCJvYmplY3RcIiAmJiBvcHRpb25zLmNhcHR1cmU7XG4gICAgY29uc3QgY29udGV4dCA9IHR5cGVvZiBsaXN0ZW5lciA9PT0gXCJmdW5jdGlvblwiID8gdm9pZCAwIDogbGlzdGVuZXI7XG4gICAgdHlwZSA9IGNhcHR1cmUgPyBgJHt0eXBlfWNhcHR1cmVgIDogdHlwZTtcbiAgICBsaXN0ZW5lciA9IHR5cGVvZiBsaXN0ZW5lciA9PT0gXCJmdW5jdGlvblwiID8gbGlzdGVuZXIgOiBsaXN0ZW5lci5oYW5kbGVFdmVudDtcbiAgICB0aGlzLm9mZih0eXBlLCBsaXN0ZW5lciwgY29udGV4dCk7XG4gIH0sXG4gIGRpc3BhdGNoRXZlbnQoZSkge1xuICAgIGlmICghKGUgaW5zdGFuY2VvZiBGZWRlcmF0ZWRFdmVudCkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkNvbnRhaW5lciBjYW5ub3QgcHJvcGFnYXRlIGV2ZW50cyBvdXRzaWRlIG9mIHRoZSBGZWRlcmF0ZWQgRXZlbnRzIEFQSVwiKTtcbiAgICB9XG4gICAgZS5kZWZhdWx0UHJldmVudGVkID0gZmFsc2U7XG4gICAgZS5wYXRoID0gbnVsbDtcbiAgICBlLnRhcmdldCA9IHRoaXM7XG4gICAgZS5tYW5hZ2VyLmRpc3BhdGNoRXZlbnQoZSk7XG4gICAgcmV0dXJuICFlLmRlZmF1bHRQcmV2ZW50ZWQ7XG4gIH1cbn07XG5cbmV4cG9ydCB7IEZlZGVyYXRlZENvbnRhaW5lciB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9RmVkZXJhdGVkRXZlbnRUYXJnZXQubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOzs7QUFJQSxJQUFNLGlCQUFOLE1BQXFCO0NBQ25CLFlBQVksU0FBUzs7RUFFbkIsS0FBSyxpQkFBaUI7O0VBRXRCLEtBQUssWUFBWTs7RUFFakIsS0FBSyxrQkFBa0I7Ozs7O0VBS3ZCLEtBQUssMEJBQTBCO0dBQzdCLElBQUksQ0FBQyxLQUFLLFNBQVM7R0FDbkIsTUFBTSxPQUFPLEtBQUssUUFBUSxzQkFBc0I7R0FDaEQsTUFBTSxlQUFlLEtBQUssUUFBUTtHQUNsQyxNQUFNLGdCQUFnQixLQUFLLFFBQVE7R0FDbkMsTUFBTSxLQUFLLEtBQUssUUFBUSxlQUFlLEtBQUssVUFBVTtHQUN0RCxNQUFNLEtBQUssS0FBSyxTQUFTLGdCQUFnQixLQUFLLFVBQVU7R0FHeEQsTUFBTSxlQUFlLGFBRlYsS0FBSyxLQUVxQixNQUQxQixLQUFLLElBQzhCLFlBQVksR0FBRyxJQUFJLEdBQUc7R0FDcEUsSUFBSSxpQkFBaUIsS0FBSyxnQkFBZ0I7SUFDeEMsS0FBSyxZQUFZLE1BQU0sWUFBWTtJQUNuQyxLQUFLLGlCQUFpQjtHQUN4QjtFQUNGO0VBQ0EsS0FBSyxjQUFjLFFBQVE7RUFDM0IsS0FBSyxZQUFZLFFBQVE7RUFDekIsSUFBSSxXQUFXLG1CQUFtQixLQUFLLFVBQVUsa0JBQWtCLGlCQUFpQjtFQUNwRixLQUFLLFVBQVUsS0FBSyxVQUFVO0VBQzlCLEtBQUssZ0JBQWdCO0NBQ3ZCOztDQUVBLElBQUksU0FBUztFQUNYLE9BQU8sS0FBSztDQUNkOztDQUVBLGlCQUFpQjtFQUNmLElBQUksQ0FBQyxLQUFLLFlBQVksY0FBYyxLQUFLLFFBQVEsWUFBWTtHQUMzRCxLQUFLLFFBQVEsV0FBVyxZQUFZLEtBQUssV0FBVztHQUNwRCxLQUFLLGtCQUFrQjtFQUN6QjtDQUNGOztDQUVBLGtCQUFrQjtFQUNoQixJQUFJLG9CQUFvQixZQUFZO0dBQ2xDLElBQUksS0FBSyxXQUFXO0lBQ2xCLEtBQUssVUFBVSxXQUFXO0lBQzFCLEtBQUssWUFBWTtHQUNuQjtHQUNBLEtBQUssWUFBWSxJQUFJLGdCQUFnQixZQUFZO0lBQy9DLEtBQUssTUFBTSxTQUFTLFNBQVM7S0FDM0IsSUFBSSxNQUFNLFdBQVcsS0FBSyxTQUN4QjtLQUVGLE1BQU0sZUFBZSxLQUFLLE9BQU87S0FDakMsTUFBTSxnQkFBZ0IsS0FBSyxPQUFPO0tBQ2xDLE1BQU0sS0FBSyxNQUFNLFlBQVksUUFBUSxlQUFlLEtBQUssVUFBVTtLQUNuRSxNQUFNLEtBQUssTUFBTSxZQUFZLFNBQVMsZ0JBQWdCLEtBQUssVUFBVTtLQUVyRSxJQURvQixLQUFLLGdCQUFnQixNQUFNLEtBQUssZ0JBQWdCLElBQ25EO01BQ2YsS0FBSyxrQkFBa0I7TUFDdkIsS0FBSyxjQUFjO01BQ25CLEtBQUssY0FBYztLQUNyQjtJQUNGO0dBQ0YsQ0FBQztHQUNELEtBQUssVUFBVSxRQUFRLEtBQUssT0FBTztFQUNyQyxPQUFPLElBQUksQ0FBQyxLQUFLLGlCQUNmLE9BQU8sT0FBTyxJQUFJLEtBQUssbUJBQW1CLE1BQU0sZ0JBQWdCLElBQUk7Q0FFeEU7O0NBRUEsVUFBVTtFQUNSLElBQUksS0FBSyxXQUFXO0dBQ2xCLEtBQUssVUFBVSxXQUFXO0dBQzFCLEtBQUssWUFBWTtFQUNuQixPQUFPLElBQUksS0FBSyxpQkFDZCxPQUFPLE9BQU8sT0FBTyxLQUFLLGlCQUFpQjtFQUU3QyxLQUFLLGNBQWM7RUFDbkIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssVUFBVTtFQUNmLEtBQUssa0JBQWtCO0VBQ3ZCLEtBQUssaUJBQWlCO0VBQ3RCLEtBQUssY0FBYztFQUNuQixLQUFLLGNBQWM7Q0FDckI7QUFDRjs7O0FDMUZBLElBQU0saUJBQU4sTUFBTSxlQUFlOzs7OztDQUtuQixZQUFZLFNBQVM7O0VBRW5CLEtBQUssVUFBVTs7RUFFZixLQUFLLGVBQWU7Ozs7O0VBS3BCLEtBQUssYUFBYTs7Ozs7OztFQU9sQixLQUFLLFdBQVc7O0VBRWhCLEtBQUssbUJBQW1COzs7OztFQUt4QixLQUFLLGFBQWEsZUFBZSxVQUFVOztFQUUzQyxLQUFLLHFCQUFxQjs7RUFFMUIsS0FBSyxnQ0FBZ0M7O0VBRXJDLEtBQUssUUFBUSxJQUFJLE1BQU07O0VBRXZCLEtBQUssT0FBTyxJQUFJLE1BQU07Ozs7OztFQU10QixLQUFLLE9BQU87Ozs7OztFQU1aLEtBQUssa0JBQWtCOzs7Ozs7RUFNdkIsS0FBSyxZQUFZOzs7Ozs7RUFNakIsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxVQUFVO0NBQ2pCOztDQUVBLElBQUksU0FBUztFQUNYLE9BQU8sS0FBSyxNQUFNO0NBQ3BCOztDQUVBLElBQUksU0FBUztFQUNYLE9BQU8sS0FBSyxNQUFNO0NBQ3BCOztDQUVBLElBQUksUUFBUTtFQUNWLE9BQU8sS0FBSyxLQUFLO0NBQ25COztDQUVBLElBQUksUUFBUTtFQUNWLE9BQU8sS0FBSyxLQUFLO0NBQ25COzs7OztDQUtBLElBQUksT0FBTztFQUNULE9BQU87Q0FDVDs7Ozs7Q0FLQSxlQUFlO0VBQ2IsSUFBSSxLQUFLLFlBQVksQ0FBQyxLQUFLLFFBQVEsS0FBSyxLQUFLLEtBQUssS0FBSyxTQUFTLE9BQU8sS0FBSyxTQUMxRSxLQUFLLE9BQU8sS0FBSyxTQUFTLEtBQUssUUFBUSxnQkFBZ0IsS0FBSyxNQUFNLElBQUksQ0FBQztFQUV6RSxPQUFPLEtBQUs7Q0FDZDs7Ozs7Ozs7O0NBU0EsVUFBVSxPQUFPLFVBQVUsYUFBYTtFQUN0QyxNQUFNLElBQUksTUFBTSxxRkFBcUY7Q0FDdkc7Ozs7Ozs7Ozs7O0NBV0EsWUFBWSxVQUFVLGFBQWEsZ0JBQWdCLFVBQVUsWUFBWTtFQUN2RSxNQUFNLElBQUksTUFBTSx1RkFBdUY7Q0FDekc7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWtCQSxpQkFBaUI7RUFDZixJQUFJLEtBQUssdUJBQXVCLFNBQVMsS0FBSyxZQUFZLFlBQ3hELEtBQUssWUFBWSxlQUFlO0VBRWxDLEtBQUssbUJBQW1CO0NBQzFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQW9CQSwyQkFBMkI7RUFDekIsS0FBSyxnQ0FBZ0M7Q0FDdkM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXdCQSxrQkFBa0I7RUFDaEIsS0FBSyxxQkFBcUI7Q0FDNUI7QUFDRjs7O0FDbE1BLElBQUksY0FBYztBQUNsQixJQUFJLFlBQVk7QUFDaEIsSUFBSSxjQUFjO0FBQ2xCLElBQUksaUJBQWlCO0FBQ3JCLElBQUksZUFBZTtBQUNuQixJQUFJLGdCQUFnQjtBQUNwQixJQUFJLGNBQWM7QUFDbEIsSUFBSSxlQUFlO0FBQ25CLElBQUksZUFBZTtBQUNuQixJQUFJLGdCQUFnQjtBQUNwQixJQUFJLGtCQUFrQjtBQUN0QixJQUFJLG9CQUFvQjtBQUN4QixJQUFJLGFBQWE7QUFDakIsSUFBSSxjQUFjO0FBQ2xCLElBQUksZUFBZTtBQUNuQixJQUFJLHVCQUF1QixTQUFVLFdBQVc7Q0FDNUMsT0FBUSxPQUFPLGNBQWMsZUFDekIsVUFBVSxhQUFhLGNBQ3ZCLE9BQU8sVUFBVSxtQkFBbUIsWUFDcEMsVUFBVSxpQkFBaUIsS0FDM0IsT0FBTyxhQUFhO0FBQzVCO0FBQ0EsU0FBUyxZQUFZLFdBQVc7Q0FDNUIsT0FBTyxTQUFVLE9BQU87RUFBRSxPQUFPLE1BQU0sS0FBSyxTQUFTO0NBQUc7QUFDNUQ7QUFDQSxTQUF3QkEsV0FBUyxPQUFPO0NBQ3BDLElBQUksTUFBTTtFQUNOLFdBQVc7RUFDWCxVQUFVO0VBQ1YsZ0JBQWdCO0NBQ3BCO0NBQ0EsSUFBSSxDQUFDLFNBQVMsT0FBTyxjQUFjLGFBQy9CLE1BQU07RUFDRixXQUFXLFVBQVU7RUFDckIsVUFBVSxVQUFVO0VBQ3BCLGdCQUFnQixVQUFVLGtCQUFrQjtDQUNoRDtNQUVDLElBQUksT0FBTyxVQUFVLFVBQ3RCLElBQUksWUFBWTtNQUVmLElBQUksU0FBUyxNQUFNLFdBQ3BCLE1BQU07RUFDRixXQUFXLE1BQU07RUFDakIsVUFBVSxNQUFNO0VBQ2hCLGdCQUFnQixNQUFNLGtCQUFrQjtDQUM1QztDQUVKLElBQUksWUFBWSxJQUFJO0NBQ3BCLElBQUksTUFBTSxVQUFVLE1BQU0sT0FBTztDQUNqQyxJQUFJLE9BQU8sSUFBSSxPQUFPLGFBQ2xCLFlBQVksSUFBSTtDQUVwQixNQUFNLFVBQVUsTUFBTSxTQUFTO0NBQy9CLElBQUksT0FBTyxJQUFJLE9BQU8sYUFDbEIsWUFBWSxJQUFJO0NBRXBCLElBQUksUUFBUSxZQUFZLFNBQVM7Q0FDakMsSUFBSSxTQUFTO0VBQ1QsT0FBTztHQUNILE9BQU8sTUFBTSxXQUFXLEtBQUssQ0FBQyxNQUFNLFlBQVk7R0FDaEQsTUFBTSxNQUFNLFNBQVM7R0FDckIsUUFBUSxDQUFDLE1BQU0sV0FBVyxNQUNyQixNQUFNLFdBQVcsS0FBSyxxQkFBcUIsR0FBRyxNQUMvQyxDQUFDLE1BQU0sWUFBWTtHQUN2QixXQUFXLE1BQU0sY0FBYztHQUMvQixTQUFTLE1BQU0sV0FBVyxLQUN0QixNQUFNLFNBQVMsS0FDZixNQUFNLFdBQVcsS0FDakIsTUFBTSxjQUFjLEtBQ3BCLHFCQUFxQixHQUFHLE1BQ3hCLENBQUMsTUFBTSxZQUFZO0VBQzNCO0VBQ0EsUUFBUTtHQUNKLE9BQU8sTUFBTSxXQUFXO0dBQ3hCLFFBQVEsQ0FBQyxNQUFNLFdBQVcsS0FBSyxNQUFNLFlBQVk7R0FDakQsUUFBUSxNQUFNLFdBQVcsS0FBSyxNQUFNLFlBQVk7RUFDcEQ7RUFDQSxTQUFTO0dBQ0wsT0FBUSxDQUFDLE1BQU0sWUFBWSxLQUFLLE1BQU0sV0FBVyxLQUM1QyxDQUFDLE1BQU0sWUFBWSxLQUFLLE1BQU0sWUFBWTtHQUMvQyxRQUFRLENBQUMsTUFBTSxZQUFZLEtBQ3ZCLENBQUMsTUFBTSxXQUFXLEtBQ2xCLENBQUMsTUFBTSxZQUFZLE1BQ2xCLE1BQU0sWUFBWSxLQUFLLE1BQU0sYUFBYTtHQUMvQyxRQUFTLENBQUMsTUFBTSxZQUFZLE1BQ3ZCLE1BQU0sV0FBVyxLQUNkLE1BQU0sWUFBWSxLQUNsQixNQUFNLFlBQVksS0FDbEIsTUFBTSxhQUFhLE1BQ3ZCLE1BQU0sYUFBYTtFQUMzQjtFQUNBLFNBQVM7R0FDTCxPQUFPLE1BQU0sWUFBWTtHQUN6QixRQUFRLE1BQU0sYUFBYTtHQUMzQixRQUFRLE1BQU0sWUFBWSxLQUFLLE1BQU0sYUFBYTtFQUN0RDtFQUNBLE9BQU87R0FDSCxZQUFZLE1BQU0sZUFBZTtHQUNqQyxjQUFjLE1BQU0saUJBQWlCO0dBQ3JDLE9BQU8sTUFBTSxVQUFVO0dBQ3ZCLFNBQVMsTUFBTSxZQUFZO0dBQzNCLFFBQVEsTUFBTSxXQUFXO0dBQ3pCLFFBQVEsTUFBTSxlQUFlLEtBQ3pCLE1BQU0saUJBQWlCLEtBQ3ZCLE1BQU0sVUFBVSxLQUNoQixNQUFNLFlBQVksS0FDbEIsTUFBTSxXQUFXO0VBQ3pCO0VBQ0EsS0FBSztFQUNMLE9BQU87RUFDUCxRQUFRO0NBQ1o7Q0FDQSxPQUFPLE1BQ0gsT0FBTyxNQUFNLFVBQ1QsT0FBTyxRQUFRLFVBQ2YsT0FBTyxRQUFRLFVBQ2YsT0FBTyxNQUFNO0NBQ3JCLE9BQU8sUUFDSCxPQUFPLE1BQU0sU0FBUyxPQUFPLFFBQVEsU0FBUyxPQUFPLFFBQVE7Q0FDakUsT0FBTyxTQUNILE9BQU8sTUFBTSxVQUFVLE9BQU8sUUFBUSxVQUFVLE9BQU8sUUFBUTtDQUNuRSxPQUFPO0FBQ1g7OztBQ3ZIQSxJQUFNLFlBRGVDLFdBQVcsV0FBV0EsV0FBQUEsQ0FDYixXQUFXLFNBQVM7OztBQ0dsRCxJQUFNLGVBQWU7QUFDckIsSUFBTSxpQkFBaUI7QUFDdkIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxnQkFBZ0I7QUFDdEIsSUFBTSxpQkFBaUI7QUFDdkIsSUFBTSxpQkFBaUI7QUFDdkIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSx1QkFBdUIsTUFBTSxxQkFBcUI7Ozs7Q0FLdEQsWUFBWSxVQUFVLGNBQWMsVUFBVTtFQUM1QyxLQUFLLGNBQWM7O0VBRW5CLEtBQUssUUFBUTs7RUFFYixLQUFLLGlCQUFpQjs7RUFFdEIsS0FBSyx5QkFBeUI7O0VBRTlCLEtBQUssWUFBWTs7RUFFakIsS0FBSyx5QkFBeUI7O0VBRTlCLEtBQUssT0FBTzs7RUFFWixLQUFLLFNBQVMsQ0FBQzs7RUFFZixLQUFLLFlBQVk7O0VBRWpCLEtBQUssWUFBWSxDQUFDOztFQUVsQixLQUFLLHNCQUFzQjs7RUFFM0IsS0FBSywwQkFBMEI7RUFFL0IsS0FBSyxrQkFBa0I7O0VBRXZCLEtBQUssa0JBQWtCLEtBQUssV0FBVyxLQUFLLElBQUk7RUFDaEQsS0FBSyxvQkFBb0IsS0FBSyxhQUFhLEtBQUssSUFBSTtFQUNwRCxLQUFLLFdBQVc7RUFDaEIsSUFBSSxZQUFZLFVBQVUsWUFBWSxPQUNwQyxLQUFLLGlCQUFpQjtFQUV4QixLQUFLLFlBQVk7Q0FDbkI7Ozs7OztDQU1BLElBQUksV0FBVztFQUNiLE9BQU8sS0FBSztDQUNkOzs7Ozs7Q0FNQSxJQUFJLHdCQUF3QjtFQUMxQixPQUFPLEtBQUs7Q0FDZDs7Ozs7Q0FLQSxJQUFJLFVBQVU7RUFDWixPQUFPLEtBQUs7Q0FDZDs7Ozs7Q0FLQSxJQUFJLE1BQU07RUFDUixPQUFPLEtBQUs7Q0FDZDs7Ozs7Q0FLQSxtQkFBbUI7RUFDakIsTUFBTSxVQUFVLFNBQVMsY0FBYyxRQUFRO0VBQy9DLFFBQVEsTUFBTSxRQUFRLEdBQUcsY0FBYztFQUN2QyxRQUFRLE1BQU0sU0FBUyxHQUFHLGNBQWM7RUFDeEMsUUFBUSxNQUFNLFdBQVc7RUFDekIsUUFBUSxNQUFNLE1BQU0sR0FBRyxlQUFlO0VBQ3RDLFFBQVEsTUFBTSxPQUFPLEdBQUcsZUFBZTtFQUN2QyxRQUFRLE1BQU0sU0FBUyxnQkFBZ0IsU0FBUztFQUNoRCxRQUFRLE1BQU0sa0JBQWtCO0VBQ2hDLFFBQVEsUUFBUTtFQUNoQixRQUFRLGlCQUFpQixlQUFlO0dBQ3RDLEtBQUsseUJBQXlCO0dBQzlCLEtBQUssVUFBVTtHQUNmLEtBQUssa0JBQWtCO0VBQ3pCLENBQUM7RUFDRCxTQUFTLEtBQUssWUFBWSxPQUFPO0VBQ2pDLEtBQUssV0FBVztDQUNsQjs7Ozs7Q0FLQSxvQkFBb0I7RUFDbEIsSUFBSSxDQUFDLEtBQUssVUFDUjtFQUVGLFNBQVMsS0FBSyxZQUFZLEtBQUssUUFBUTtFQUN2QyxLQUFLLFdBQVc7Q0FDbEI7Ozs7OztDQU1BLFlBQVk7RUFDVixJQUFJLEtBQUssV0FDUDtFQUVGLEtBQUssWUFBWTtFQUNqQixJQUFJLENBQUMsS0FBSyxNQUFNO0dBQ2QsS0FBSyxPQUFPLFNBQVMsY0FBYyxLQUFLO0dBQ3hDLEtBQUssS0FBSyxNQUFNLFdBQVc7R0FDM0IsS0FBSyxLQUFLLE1BQU0sTUFBTSxHQUFHLGdCQUFnQjtHQUN6QyxLQUFLLEtBQUssTUFBTSxPQUFPLEdBQUcsZ0JBQWdCO0dBQzFDLEtBQUssS0FBSyxNQUFNLGdCQUFnQjtHQUNoQyxLQUFLLEtBQUssTUFBTSxTQUFTLGlCQUFpQixTQUFTO0dBQ25ELEtBQUssa0JBQWtCLElBQUksZUFBZTtJQUN4QyxZQUFZLEtBQUs7SUFDakIsVUFBVSxLQUFLO0dBQ2pCLENBQUM7RUFDSDtFQUNBLElBQUksS0FBSyx3QkFDUCxXQUFXLFNBQVMsaUJBQWlCLGFBQWEsS0FBSyxtQkFBbUIsSUFBSTtFQUVoRixNQUFNLFNBQVMsS0FBSyxVQUFVLEtBQUs7RUFDbkMsSUFBSSxDQUFDLE9BQU8sWUFBWTtHQUN0QixNQUFNLFdBQVcsSUFBSSx1QkFBdUI7SUFDMUMsSUFBSSxPQUFPLFlBQVk7S0FDckIsU0FBUyxXQUFXO0tBQ3BCLEtBQUssZ0JBQWdCLGVBQWU7S0FDcEMsS0FBSyx3QkFBd0I7SUFDL0I7R0FDRixDQUFDO0dBQ0QsU0FBUyxRQUFRLFNBQVMsTUFBTTtJQUFFLFdBQVc7SUFBTSxTQUFTO0dBQUssQ0FBQztFQUNwRSxPQUFPO0dBQ0wsS0FBSyxnQkFBZ0IsZUFBZTtHQUNwQyxLQUFLLHdCQUF3QjtFQUMvQjtDQUNGO0NBRUEsMEJBQTBCO0VBQ3hCLEtBQUssVUFBVSxRQUFRLFdBQVcsSUFBSSxJQUFJO0VBQzFDLElBQUksS0FBSyxVQUFVLG9CQUNqQixLQUFLLHlCQUF5QixLQUFLLFVBQVUsa0JBQWtCO0NBRW5FOzs7OztDQUtBLGNBQWM7RUFDWixJQUFJLENBQUMsS0FBSyxhQUFhLEtBQUssd0JBQzFCO0VBRUYsS0FBSyxZQUFZO0VBQ2pCLFdBQVcsU0FBUyxvQkFBb0IsYUFBYSxLQUFLLG1CQUFtQixJQUFJO0VBQ2pGLEtBQUssVUFBVSxRQUFRLFdBQVcsT0FBTyxJQUFJO0VBQzdDLEtBQUssTUFBTSxTQUFTLEtBQUssV0FBVztHQUNsQyxJQUFJLE1BQU0sZ0JBQWdCLFlBQVk7SUFDcEMsTUFBTSxlQUFlLFdBQVcsWUFBWSxNQUFNLGNBQWM7SUFDaEUsTUFBTSxpQkFBaUI7R0FDekI7R0FDQSxNQUFNLG9CQUFvQjtFQUM1QjtFQUNBLEtBQUssTUFBTSxrQkFBa0IsS0FBSyxRQUFRO0dBRXhDLEtBRGtCLE9BQU8sZUFDckIsQ0FBQyxTQUFTLFFBQVE7SUFDcEIsSUFBSSxJQUFJLFlBQ04sSUFBSSxXQUFXLFlBQVksR0FBRztHQUVsQyxDQUFDO0dBQ0QsT0FBTyxLQUFLLE9BQU87RUFDckI7RUFDQSxJQUFJLEtBQUssTUFBTSxZQUNiLEtBQUssS0FBSyxXQUFXLFlBQVksS0FBSyxJQUFJO0VBRTVDLEtBQUssU0FBUyxDQUFDO0VBQ2YsS0FBSyxZQUFZLENBQUM7Q0FDcEI7Ozs7OztDQU1BLHlCQUF5QixXQUFXO0VBQ2xDLElBQUksQ0FBQyxVQUFVLFdBQVcsQ0FBQyxVQUFVLG9CQUNuQztFQUVGLElBQUksVUFBVSxZQUFZO0dBQ3hCLElBQUksQ0FBQyxVQUFVLG1CQUNiLEtBQUssVUFBVSxTQUFTO0dBRTFCLFVBQVUsWUFBWSxLQUFLO0VBQzdCO0VBQ0EsTUFBTSxXQUFXLFVBQVU7RUFDM0IsSUFBSSxVQUNGLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FDbkMsS0FBSyx5QkFBeUIsU0FBUyxFQUFFO0NBRy9DOzs7OztDQUtBLEtBQUssU0FBUztFQUVaLE1BQU0sZ0JBQWdCLEVBQ3BCLHNCQUFzQjtHQUNwQixHQUhnQixxQkFBcUI7R0FJckMsR0FBRyxTQUFTLHdCQUF3QixDQUFDO0VBQ3ZDLEVBQ0Y7RUFDQSxLQUFLLFFBQVEsY0FBYyxxQkFBcUI7RUFDaEQsS0FBSyxpQkFBaUIsY0FBYyxxQkFBcUI7RUFDekQsS0FBSyx5QkFBeUIsY0FBYyxxQkFBcUI7RUFDakUsSUFBSSxLQUFLLGdCQUNQLFdBQVcsaUJBQWlCLFdBQVcsS0FBSyxpQkFBaUIsS0FBSztFQUVwRSxJQUFJLGNBQWMscUJBQXFCLGtCQUNyQyxLQUFLLFVBQVU7RUFFakIsS0FBSyxVQUFVLFFBQVEsV0FBVyxPQUFPLElBQUk7Q0FDL0M7Ozs7Ozs7OztDQVNBLGFBQWE7RUFDWCxNQUFNLE1BQU0sWUFBWSxJQUFJO0VBQzVCLElBQUksS0FBSyxZQUFZLFFBQVEsVUFBVSxNQUFNLEtBQUsscUJBQ2hEO0VBRUYsS0FBSyxzQkFBc0IsTUFBTSxLQUFLO0VBQ3RDLEtBQUssQ0FBQyxLQUFLLFVBQVUscUJBQXFCLENBQUMsS0FBSyxVQUFVLEtBQUssV0FBVyxDQUFDLEtBQUssaUJBQzlFO0VBRUYsTUFBTSw0QkFBNEIsSUFBSSxJQUFJO0VBQzFDLElBQUksS0FBSyxVQUFVLG9CQUFvQjtHQUNyQyxLQUFLLHlCQUF5QixLQUFLLFVBQVUsa0JBQWtCO0dBQy9ELEtBQUssTUFBTSxTQUFTLEtBQUssV0FDdkIsSUFBSSxNQUFNLGNBQWMsS0FBSyxXQUMzQixVQUFVLElBQUksS0FBSyxVQUFVLFFBQVEsS0FBSyxDQUFDO0VBR2pEO0VBQ0EsS0FBSyxJQUFJLElBQUksS0FBSyxVQUFVLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztHQUNuRCxNQUFNLFFBQVEsS0FBSyxVQUFVO0dBQzdCLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxHQUFHO0lBQ3JCLElBQUksTUFBTSxrQkFBa0IsTUFBTSxlQUFlLFlBQVk7S0FDM0QsTUFBTSxlQUFlLFdBQVcsWUFBWSxNQUFNLGNBQWM7S0FFaEUsS0FEa0IsU0FBUyxNQUFNLGNBQzlCLENBQUMsQ0FBQyxLQUFLLE1BQU0sY0FBYztLQUM5QixNQUFNLGlCQUFpQjtJQUN6QjtJQUNBLE1BQU0sb0JBQW9CO0lBQzFCLFlBQVksS0FBSyxXQUFXLEdBQUcsQ0FBQztHQUNsQztFQUNGO0VBQ0EsSUFBSSxLQUFLLFVBQVUsbUJBQ2pCLEtBQUssZ0JBQWdCLGVBQWU7RUFFdEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssVUFBVSxRQUFRLEtBQUs7R0FDOUMsTUFBTSxRQUFRLEtBQUssVUFBVTtHQUM3QixJQUFJLENBQUMsTUFBTSxxQkFBcUIsQ0FBQyxNQUFNLGdCQUNyQztHQUVGLE1BQU0sTUFBTSxNQUFNO0dBQ2xCLE1BQU0sVUFBVSxNQUFNLFdBQVcsTUFBTSxVQUFVLENBQUMsQ0FBQztHQUNuRCxJQUFJLE1BQU0sU0FBUztJQUNqQixNQUFNLEtBQUssTUFBTTtJQUNqQixJQUFJLE1BQU0sT0FBTyxHQUFHLEdBQUcsS0FBSyxRQUFRLElBQUksR0FBRyxFQUFFO0lBQzdDLElBQUksTUFBTSxNQUFNLEdBQUcsR0FBRyxLQUFLLFFBQVEsSUFBSSxHQUFHLEVBQUU7SUFDNUMsSUFBSSxNQUFNLFFBQVEsR0FBRyxRQUFRLFFBQVEsR0FBRyxFQUFFO0lBQzFDLElBQUksTUFBTSxTQUFTLEdBQUcsUUFBUSxTQUFTLEdBQUcsRUFBRTtHQUM5QyxPQUFPO0lBQ0wsS0FBSyxZQUFZLE9BQU87SUFDeEIsSUFBSSxNQUFNLE9BQU8sR0FBRyxRQUFRLEVBQUU7SUFDOUIsSUFBSSxNQUFNLE1BQU0sR0FBRyxRQUFRLEVBQUU7SUFDN0IsSUFBSSxNQUFNLFFBQVEsR0FBRyxRQUFRLE1BQU07SUFDbkMsSUFBSSxNQUFNLFNBQVMsR0FBRyxRQUFRLE9BQU87R0FDdkM7RUFDRjtFQUNBLEtBQUs7Q0FDUDs7Ozs7O0NBTUEsaUJBQWlCLEtBQUs7RUFDcEIsSUFBSSxZQUFZLFNBQVMsSUFBSSxLQUFLLGdCQUFnQixJQUFJLE1BQU0sa0JBQWtCLElBQUk7Q0FDcEY7Ozs7O0NBS0EsWUFBWSxTQUFTO0VBQ25CLElBQUksUUFBUSxJQUFJLEdBQUc7R0FDakIsUUFBUSxTQUFTLFFBQVE7R0FDekIsUUFBUSxJQUFJO0VBQ2Q7RUFDQSxJQUFJLFFBQVEsSUFBSSxHQUFHO0dBQ2pCLFFBQVEsVUFBVSxRQUFRO0dBQzFCLFFBQVEsSUFBSTtFQUNkO0VBQ0EsTUFBTSxFQUFFLE9BQU8sV0FBVyxRQUFRLGVBQWUsS0FBSztFQUN0RCxJQUFJLFFBQVEsSUFBSSxRQUFRLFFBQVEsV0FDOUIsUUFBUSxRQUFRLFlBQVksUUFBUTtFQUV0QyxJQUFJLFFBQVEsSUFBSSxRQUFRLFNBQVMsWUFDL0IsUUFBUSxTQUFTLGFBQWEsUUFBUTtDQUUxQzs7Ozs7OztDQU9BLFVBQVUsV0FBVztFQUVuQixJQUFJLE1BRFMsS0FBSyxTQUFTLFVBQVUsY0FDeEIsQ0FBQyxDQUFDLElBQUk7RUFDbkIsSUFBSSxLQUFLO0dBQ1AsSUFBSSxZQUFZO0dBQ2hCLElBQUksZ0JBQWdCLE9BQU87R0FDM0IsSUFBSSxnQkFBZ0IsWUFBWTtHQUNoQyxJQUFJLFdBQVc7RUFDakIsT0FBTztHQUNMLElBQUksVUFBVSxtQkFBbUIsVUFBVTtJQUN6QyxNQUFNLFNBQVMsY0FBYyxRQUFRO0lBQ3JDLElBQUksQ0FBQyxLQUFLLE9BQ1IsSUFBSSxNQUFNLFFBQVE7R0FFdEIsT0FBTztJQUNMLE1BQU0sU0FBUyxjQUFjLFVBQVUsY0FBYztJQUNyRCxJQUFJLE1BQU0sVUFBVTs7Ozs7Ozs7Ozs7Ozs7R0FjdEI7R0FDQSxJQUFJLE1BQU0sUUFBUSxHQUFHLGVBQWU7R0FDcEMsSUFBSSxNQUFNLFNBQVMsR0FBRyxlQUFlO0dBQ3JDLElBQUksTUFBTSxrQkFBa0IsS0FBSyxRQUFRLDBCQUEwQjtHQUNuRSxJQUFJLE1BQU0sV0FBVztHQUNyQixJQUFJLE1BQU0sU0FBUyxpQkFBaUIsU0FBUztHQUM3QyxJQUFJLE1BQU0sY0FBYztHQUN4QixJQUFJLFVBQVUsVUFBVSxZQUFZLENBQUMsQ0FBQyxTQUFTLFFBQVEsR0FDckQsSUFBSSxhQUFhLGFBQWEsS0FBSztRQUVuQyxJQUFJLGFBQWEsYUFBYSxRQUFRO0dBRXhDLElBQUksVUFBVSxVQUFVLE1BQU0sY0FBYyxHQUMxQyxJQUFJLGFBQWEsaUJBQWlCLFdBQVc7UUFFN0MsSUFBSSxhQUFhLGlCQUFpQixNQUFNO0dBRTFDLElBQUksaUJBQWlCLFNBQVMsS0FBSyxTQUFTLEtBQUssSUFBSSxDQUFDO0dBQ3RELElBQUksaUJBQWlCLFNBQVMsS0FBSyxTQUFTLEtBQUssSUFBSSxDQUFDO0dBQ3RELElBQUksaUJBQWlCLFlBQVksS0FBSyxZQUFZLEtBQUssSUFBSSxDQUFDO0VBQzlEO0VBQ0EsSUFBSSxNQUFNLGdCQUFnQixVQUFVO0VBQ3BDLElBQUksT0FBTyxVQUFVO0VBQ3JCLElBQUksVUFBVSxnQkFDWixJQUFJLFlBQVksVUFBVTtFQUU1QixJQUFJLFVBQVUsbUJBQW1CLFVBQVUsb0JBQW9CLE1BQzdELElBQUksUUFBUSxVQUFVO09BQ2pCLElBQUksQ0FBQyxVQUFVLGtCQUFrQixVQUFVLG1CQUFtQixNQUNuRSxJQUFJLFFBQVEsYUFBYSxVQUFVO0VBRXJDLElBQUksVUFBVSxrQkFBa0IsVUFBVSxtQkFBbUIsTUFDM0QsSUFBSSxhQUFhLGNBQWMsVUFBVSxjQUFjO0VBRXpELElBQUksVUFBVSxhQUNaLElBQUksV0FBVyxVQUFVO09BRXpCLElBQUksV0FBVztFQUVqQixJQUFJLEtBQUssT0FDUCxLQUFLLGlCQUFpQixHQUFHO0VBRTNCLFVBQVUsb0JBQW9CO0VBQzlCLFVBQVUsaUJBQWlCO0VBQzNCLElBQUksWUFBWTtFQUNoQixLQUFLLFVBQVUsS0FBSyxTQUFTO0VBQzdCLEtBQUssS0FBSyxZQUFZLFVBQVUsY0FBYztDQUNoRDs7Ozs7OztDQU9BLGVBQWUsR0FBRyxNQUFNO0VBQ3RCLE1BQU0sRUFBRSxXQUFXLFdBQVcsRUFBRTtFQUNoQyxNQUFNLFdBQVcsS0FBSyxVQUFVLE9BQU87RUFDdkMsTUFBTSxRQUFRLE9BQU8sT0FBTyxJQUFJLGVBQWUsUUFBUSxHQUFHLEVBQUUsT0FBTyxDQUFDO0VBQ3BFLFNBQVMsYUFBYSxLQUFLLFVBQVU7RUFDckMsS0FBSyxTQUFTLFVBQVUsU0FBUyxjQUFjLE9BQU8sS0FBSyxDQUFDO0NBQzlEOzs7Ozs7Q0FNQSxTQUFTLEdBQUc7RUFDVixLQUFLLGVBQWUsR0FBRztHQUFDO0dBQVM7R0FBYztFQUFLLENBQUM7Q0FDdkQ7Ozs7OztDQU1BLFNBQVMsR0FBRztFQUNWLElBQUksQ0FBQyxFQUFFLE9BQU8sYUFBYSxXQUFXLEdBQ3BDLEVBQUUsT0FBTyxhQUFhLGFBQWEsV0FBVztFQUVoRCxLQUFLLGVBQWUsR0FBRyxDQUFDLFdBQVcsQ0FBQztDQUN0Qzs7Ozs7O0NBTUEsWUFBWSxHQUFHO0VBQ2IsSUFBSSxDQUFDLEVBQUUsT0FBTyxhQUFhLFdBQVcsR0FDcEMsRUFBRSxPQUFPLGFBQWEsYUFBYSxRQUFRO0VBRTdDLEtBQUssZUFBZSxHQUFHLENBQUMsVUFBVSxDQUFDO0NBQ3JDOzs7Ozs7Q0FNQSxXQUFXLEdBQUc7RUFDWixJQUFJLEVBQUUsWUFBWSxnQkFBZ0IsQ0FBQyxLQUFLLGdCQUN0QztFQUVGLEtBQUssVUFBVTtDQUNqQjs7Ozs7O0NBTUEsYUFBYSxHQUFHO0VBQ2QsSUFBSSxFQUFFLGNBQWMsS0FBSyxFQUFFLGNBQWMsR0FDdkM7RUFFRixLQUFLLFlBQVk7Q0FDbkI7Ozs7OztDQU1BLFVBQVU7RUFDUixLQUFLLFlBQVk7RUFDakIsS0FBSyxrQkFBa0I7RUFDdkIsS0FBSyxpQkFBaUIsUUFBUTtFQUM5QixLQUFLLGtCQUFrQjtFQUN2QixLQUFLLE9BQU87RUFDWixLQUFLLFNBQVM7RUFDZCxLQUFLLFlBQVk7RUFDakIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssV0FBVztFQUNoQixXQUFXLG9CQUFvQixXQUFXLEtBQUssZUFBZTtFQUM5RCxLQUFLLGtCQUFrQjtFQUN2QixXQUFXLFNBQVMsb0JBQW9CLGFBQWEsS0FBSyxtQkFBbUIsSUFBSTtFQUNqRixLQUFLLG9CQUFvQjtDQUMzQjs7Ozs7Ozs7OztDQVVBLHdCQUF3QixTQUFTO0VBQy9CLElBQUksU0FDRixLQUFLLFVBQVU7T0FFZixLQUFLLFlBQVk7Q0FFckI7Q0FDQSxTQUFTLGdCQUFnQjtFQUN2QixJQUFJLENBQUMsS0FBSyxPQUFPLGlCQUNmLEtBQUssT0FBTyxrQkFBa0IsQ0FBQztFQUVqQyxPQUFPLEtBQUssT0FBTztDQUNyQjtBQUNGOztBQUVBLHFCQUFxQixZQUFZO0NBQy9CLE1BQU0sQ0FDSixjQUFjLGFBQ2QsY0FBYyxZQUNoQjtDQUNBLE1BQU07QUFDUjs7Ozs7Ozs7Ozs7Ozs7QUFjQSxxQkFBcUIsaUJBQWlCOzs7OztDQUtwQyxrQkFBa0I7Ozs7O0NBS2xCLE9BQU87Ozs7O0NBS1AsZUFBZTs7Ozs7Q0FLZix1QkFBdUI7QUFDekI7QUFDQSxJQUFJLHNCQUFzQjs7O0FDNWpCMUIsSUFBTSxzQkFBc0I7Q0FDMUIsWUFBWTtDQUNaLGlCQUFpQjtDQUNqQixnQkFBZ0I7Q0FDaEIsVUFBVTtDQUNWLGdCQUFnQjtDQUNoQixnQkFBZ0I7Q0FDaEIseUJBQXlCO0NBQ3pCLG9CQUFvQjtDQUNwQixtQkFBbUI7Q0FDbkIsZ0JBQWdCO0NBQ2hCLFdBQVc7QUFDYjs7O0FDVEEsSUFBTSxVQUFOLE1BQWM7Ozs7O0NBS1osWUFBWSxVQUFVOztFQUVwQixLQUFLLHVCQUF1QixDQUFDO0VBQzdCLEtBQUssWUFBWTtFQUNqQixLQUFLLFVBQVUsUUFBUSxXQUFXLElBQUksSUFBSTtFQUMxQyxLQUFLLFVBQVUsUUFBUSxLQUFLLElBQUksSUFBSTtFQUNwQyxLQUFLLGNBQWMsU0FBUyxjQUFjLEtBQUs7RUFDL0MsS0FBSyxZQUFZLE1BQU0sV0FBVztFQUNsQyxLQUFLLFlBQVksTUFBTSxNQUFNO0VBQzdCLEtBQUssWUFBWSxNQUFNLE9BQU87RUFDOUIsS0FBSyxZQUFZLE1BQU0sZ0JBQWdCO0VBQ3ZDLEtBQUssWUFBWSxNQUFNLFNBQVM7Q0FDbEM7O0NBRUEsT0FBTztFQUNMLEtBQUssa0JBQWtCLElBQUksZUFBZTtHQUN4QyxZQUFZLEtBQUs7R0FDakIsVUFBVSxLQUFLO0VBQ2pCLENBQUM7Q0FDSDs7Ozs7O0NBTUEsY0FBYyxjQUFjLGlCQUFpQjtFQUMzQyxJQUFJLENBQUMsS0FBSyxxQkFBcUIsU0FBUyxZQUFZLEdBQ2xELEtBQUsscUJBQXFCLEtBQUssWUFBWTtDQUUvQzs7Ozs7Q0FLQSxpQkFBaUIsZUFBZSxDQUNoQzs7Ozs7O0NBTUEsbUJBQW1CLGVBQWU7RUFDaEMsT0FBTztDQUNUOztDQUVBLGFBQWE7RUFDWCxNQUFNLHNCQUFzQixLQUFLO0VBQ2pDLElBQUksb0JBQW9CLFdBQVcsR0FBRztHQUNwQyxLQUFLLFlBQVksT0FBTztHQUN4QjtFQUNGO0VBQ0EsS0FBSyxnQkFBZ0IsZUFBZTtFQUNwQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksb0JBQW9CLFFBQVEsS0FBSztHQUNuRCxNQUFNLGVBQWUsb0JBQW9CO0dBQ3pDLE1BQU0sVUFBVSxhQUFhO0dBQzdCLElBQUksQ0FBQyxhQUFhLFVBQVUsYUFBYSxzQkFBc0IsR0FBRztJQUNoRSxTQUFTLE9BQU87SUFDaEIsb0JBQW9CLE9BQU8sR0FBRyxDQUFDO0lBQy9CO0dBQ0YsT0FBTztJQUNMLElBQUksQ0FBQyxLQUFLLFlBQVksU0FBUyxPQUFPLEdBQUc7S0FDdkMsUUFBUSxNQUFNLFdBQVc7S0FDekIsUUFBUSxNQUFNLGdCQUFnQjtLQUM5QixLQUFLLFlBQVksWUFBWSxPQUFPO0lBQ3RDO0lBQ0EsTUFBTSxLQUFLLGFBQWE7SUFDeEIsTUFBTSxTQUFTLGFBQWE7SUFDNUIsTUFBTSxLQUFLLGFBQWEsUUFBUSxPQUFPO0lBQ3ZDLE1BQU0sS0FBSyxhQUFhLFNBQVMsT0FBTztJQUN4QyxRQUFRLE1BQU0sa0JBQWtCLEdBQUcsR0FBRyxLQUFLLEdBQUc7SUFDOUMsUUFBUSxNQUFNLFlBQVksVUFBVSxHQUFHLEVBQUUsSUFBSSxHQUFHLEVBQUUsSUFBSSxHQUFHLEVBQUUsSUFBSSxHQUFHLEVBQUUsSUFBSSxHQUFHLEtBQUssR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHO0lBQ2xHLFFBQVEsTUFBTSxVQUFVLGFBQWEsV0FBVyxTQUFTO0dBQzNEO0VBQ0Y7Q0FDRjs7Q0FFQSxVQUFVO0VBQ1IsS0FBSyxVQUFVLFFBQVEsV0FBVyxPQUFPLElBQUk7RUFDN0MsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUsscUJBQXFCLFFBQVEsS0FFcEQsS0FEMEIscUJBQXFCLEVBQ25DLENBQUMsU0FBUyxPQUFPO0VBRS9CLEtBQUsscUJBQXFCLFNBQVM7RUFDbkMsS0FBSyxZQUFZLE9BQU87RUFDeEIsS0FBSyxnQkFBZ0IsUUFBUTtFQUM3QixLQUFLLFlBQVk7Q0FDbkI7QUFDRjs7Ozs7QUFLQSxRQUFRLFlBQVk7Q0FDbEIsTUFBTTtFQUNKLGNBQWM7RUFDZCxjQUFjO0VBQ2QsY0FBYztDQUNoQjtDQUNBLE1BQU07QUFDUjs7O0FDeEdBLElBQU0sb0JBQU4sTUFBd0I7Q0FDdEIsY0FBYzs7RUFFWixLQUFLLHVCQUF1QjtFQUM1QixLQUFLLGFBQWE7RUFDbEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssZUFBZTtFQUNwQixLQUFLLGVBQWU7Q0FDdEI7Ozs7O0NBS0EsS0FBSyxRQUFRO0VBQ1gsS0FBSyxxQkFBcUI7RUFDMUIsS0FBSyxTQUFTO0VBQ2QsS0FBSyx1QkFBdUI7RUFDNUIsS0FBSyxhQUFhO0VBQ2xCLEtBQUssV0FBVztFQUNoQixLQUFLLGVBQWU7RUFDcEIsS0FBSyxlQUFlO0NBQ3RCOztDQUVBLElBQUksY0FBYztFQUNoQixPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksWUFBWSxRQUFRO0VBQ3RCLEtBQUssZUFBZTtDQUN0Qjs7Q0FFQSxvQkFBb0I7RUFDbEIsSUFBSSxLQUFLLGdCQUFnQixDQUFDLEtBQUssWUFDN0I7RUFFRixPQUFPLE9BQU8sSUFBSSxLQUFLLGVBQWUsTUFBTSxnQkFBZ0IsV0FBVztFQUN2RSxLQUFLLGVBQWU7Q0FDdEI7O0NBRUEsdUJBQXVCO0VBQ3JCLElBQUksQ0FBQyxLQUFLLGNBQ1I7RUFFRixPQUFPLE9BQU8sT0FBTyxLQUFLLGVBQWUsSUFBSTtFQUM3QyxLQUFLLGVBQWU7Q0FDdEI7O0NBRUEsZUFBZTtFQUNiLEtBQUssV0FBVztDQUNsQjs7Q0FFQSxVQUFVO0VBQ1IsSUFBSSxDQUFDLEtBQUssY0FBYyxLQUFLLGNBQzNCO0VBRUYsSUFBSSxLQUFLLFVBQVU7R0FDakIsS0FBSyxXQUFXO0dBQ2hCO0VBQ0Y7RUFDQSxNQUFNLG1CQUFtQixLQUFLLE9BQU87RUFDckMsSUFBSSxLQUFLLE9BQU8sdUJBQXVCLGlCQUFpQixnQkFBZ0IsU0FDdEU7RUFFRixXQUFXLFNBQVMsY0FBYyxLQUFLLE9BQU8sd0JBQXdCLElBQUksYUFBYSxlQUFlO0dBQ3BHLFNBQVMsaUJBQWlCO0dBQzFCLFNBQVMsaUJBQWlCO0dBQzFCLGFBQWEsaUJBQWlCO0dBQzlCLFdBQVcsaUJBQWlCO0VBQzlCLENBQUMsSUFBSSxJQUFJLFdBQVcsYUFBYTtHQUMvQixTQUFTLGlCQUFpQjtHQUMxQixTQUFTLGlCQUFpQjtFQUM1QixDQUFDLENBQUM7Q0FDSjs7Ozs7Ozs7Q0FRQSxjQUFjLFFBQVE7RUFDcEIsS0FBSyxjQUFjLE9BQU87RUFDMUIsSUFBSSxLQUFLLGFBQWEsS0FBSyxzQkFDekI7RUFFRixLQUFLLGFBQWE7RUFDbEIsS0FBSyxRQUFRO0NBQ2Y7O0NBRUEsVUFBVTtFQUNSLEtBQUsscUJBQXFCO0VBQzFCLEtBQUssU0FBUztFQUNkLEtBQUssYUFBYTtFQUNsQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssZUFBZTtFQUNwQixLQUFLLGVBQWU7Q0FDdEI7QUFDRjtBQUNBLElBQU0sZUFBZSxJQUFJLGtCQUFrQjs7O0FDbEczQyxJQUFNLHNCQUFOLGNBQWtDLGVBQWU7Q0FDL0MsY0FBYztFQUNaLE1BQU0sR0FBRyxTQUFTOztFQUVsQixLQUFLLFNBQVMsSUFBSSxNQUFNOztFQUV4QixLQUFLLFdBQVcsSUFBSSxNQUFNOztFQUUxQixLQUFLLFNBQVMsSUFBSSxNQUFNOztFQUV4QixLQUFLLFNBQVMsSUFBSSxNQUFNOzs7OztFQUt4QixLQUFLLFNBQVMsSUFBSSxNQUFNO0NBQzFCOztDQUVBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOztDQUVBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOzs7OztDQUtBLElBQUksSUFBSTtFQUNOLE9BQU8sS0FBSztDQUNkOzs7OztDQUtBLElBQUksSUFBSTtFQUNOLE9BQU8sS0FBSztDQUNkOztDQUVBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSyxTQUFTO0NBQ3ZCOztDQUVBLElBQUksWUFBWTtFQUNkLE9BQU8sS0FBSyxTQUFTO0NBQ3ZCOztDQUVBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOztDQUVBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOztDQUVBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOztDQUVBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOzs7OztDQUtBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOzs7OztDQUtBLElBQUksVUFBVTtFQUNaLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTZCQSxpQkFBaUIsV0FBVyxPQUFPLFdBQVc7RUFDNUMsT0FBTyxVQUFVLGVBQWUsYUFBYSxhQUFhLEtBQUssUUFBUSxLQUFLO0NBQzlFOzs7OztDQUtBLGlCQUFpQixLQUFLO0VBQ3BCLE9BQU8sc0JBQXNCLEtBQUssZUFBZSxLQUFLLFlBQVksaUJBQWlCLEdBQUc7Q0FDeEY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXNCQSxlQUFlLFVBQVUsZUFBZSxnQkFBZ0IsVUFBVSxZQUFZLGFBQWEsYUFBYSxhQUFhLGFBQWEsYUFBYSxZQUFZLGNBQWMsYUFBYSxZQUFZLG1CQUFtQjtFQUNuTixNQUFNLElBQUksTUFBTSx5QkFBeUI7Q0FDM0M7QUFDRjs7O0FDNUlBLElBQU0sd0JBQU4sY0FBb0Msb0JBQW9CO0NBQ3RELGNBQWM7RUFDWixNQUFNLEdBQUcsU0FBUzs7Ozs7O0VBTWxCLEtBQUssUUFBUTs7Ozs7O0VBTWIsS0FBSyxTQUFTOzs7OztFQUtkLEtBQUssWUFBWTs7Ozs7RUFLakIsS0FBSyxxQkFBcUI7Q0FDNUI7Ozs7O0NBS0EscUJBQXFCO0VBQ25CLElBQUksS0FBSyxTQUFTLGlCQUFpQixLQUFLLFNBQVMsZUFBZSxLQUFLLFNBQVMsYUFDNUUsT0FBTyxDQUFDLElBQUk7RUFFZCxPQUFPLENBQUM7Q0FDVjs7Ozs7Q0FLQSxxQkFBcUI7RUFDbkIsTUFBTSxJQUFJLE1BQU0sc0NBQXNDO0NBQ3hEO0FBQ0Y7OztBQzNDQSxJQUFNLHNCQUFOLGNBQWtDLG9CQUFvQjtDQUNwRCxjQUFjO0VBQ1osTUFBTSxHQUFHLFNBQVM7Ozs7O0VBS2xCLEtBQUssa0JBQWtCOzs7OztFQUt2QixLQUFLLGlCQUFpQjs7Ozs7RUFLdEIsS0FBSyxpQkFBaUI7Q0FDeEI7QUFDRjs7Ozs7QUFLQSxvQkFBb0Isa0JBQWtCOzs7OztBQUt0QyxvQkFBb0IsaUJBQWlCOzs7OztBQUtyQyxvQkFBb0IsaUJBQWlCOzs7QUM1QnJDLElBQU0sb0JBQW9CO0FBQzFCLElBQU0sa0JBQWtCLElBQUksTUFBTTtBQUNsQyxJQUFNLG1CQUFtQixJQUFJLE1BQU07QUFDbkMsSUFBTSxnQkFBTixNQUFvQjs7OztDQUlsQixZQUFZLFlBQVk7Ozs7Ozs7Ozs7RUFVdEIsS0FBSyxXQUFXLElBQUlDLHNCQUFhOzs7Ozs7O0VBT2pDLEtBQUssWUFBWTs7RUFFakIsS0FBSyx5QkFBeUI7Ozs7O0VBSzlCLEtBQUssZUFBZSxFQUNsQixjQUFjLENBQUMsRUFDakI7Ozs7OztFQU1BLEtBQUssNEJBQTRCLElBQUksSUFBSTs7RUFFekMsS0FBSywwQkFBMEIsQ0FBQzs7RUFFaEMsS0FBSyxlQUFlLENBQUM7O0VBRXJCLEtBQUssc0JBQXNCO0VBQzNCLEtBQUssYUFBYTtFQUNsQixLQUFLLGFBQWEsS0FBSyxXQUFXLEtBQUssSUFBSTtFQUMzQyxLQUFLLFlBQVksS0FBSyxVQUFVLEtBQUssSUFBSTtFQUN6QyxLQUFLLGlCQUFpQixLQUFLLGVBQWUsS0FBSyxJQUFJO0VBQ25ELEtBQUssaUJBQWlCLEtBQUssZUFBZSxLQUFLLElBQUk7RUFDbkQsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjLEtBQUssSUFBSTtFQUNqRCxLQUFLLGlCQUFpQixLQUFLLGVBQWUsS0FBSyxJQUFJO0VBQ25ELEtBQUssZUFBZSxLQUFLLGFBQWEsS0FBSyxJQUFJO0VBQy9DLEtBQUssc0JBQXNCLEtBQUssb0JBQW9CLEtBQUssSUFBSTtFQUM3RCxLQUFLLFdBQVcsS0FBSyxTQUFTLEtBQUssSUFBSTtFQUN2QyxLQUFLLGlCQUFpQixLQUFLLGVBQWUsS0FBSyxJQUFJO0VBQ25ELEtBQUssZUFBZSxDQUFDO0VBQ3JCLEtBQUssZ0JBQWdCLGVBQWUsS0FBSyxjQUFjO0VBQ3ZELEtBQUssZ0JBQWdCLGVBQWUsS0FBSyxjQUFjO0VBQ3ZELEtBQUssZ0JBQWdCLGNBQWMsS0FBSyxhQUFhO0VBQ3JELEtBQUssZ0JBQWdCLGdCQUFnQixLQUFLLGFBQWE7RUFDdkQsS0FBSyxnQkFBZ0IsZUFBZSxLQUFLLGNBQWM7RUFDdkQsS0FBSyxnQkFBZ0IsYUFBYSxLQUFLLFlBQVk7RUFDbkQsS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssbUJBQW1CO0VBQ2pFLEtBQUssZ0JBQWdCLFNBQVMsS0FBSyxRQUFRO0VBQzNDLEtBQUssZ0JBQWdCLGVBQWUsS0FBSyxjQUFjO0NBQ3pEOzs7Ozs7Ozs7Ozs7O0NBYUEsZ0JBQWdCLE1BQU0sSUFBSTtFQUN4QixJQUFJLENBQUMsS0FBSyxhQUFhLE9BQ3JCLEtBQUssYUFBYSxRQUFRLENBQUM7RUFFN0IsS0FBSyxhQUFhLEtBQUssQ0FBQyxLQUFLO0dBQzNCO0dBQ0EsVUFBVTtFQUNaLENBQUM7RUFDRCxLQUFLLGFBQWEsS0FBSyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsV0FBVyxFQUFFLFFBQVE7Q0FDaEU7Ozs7OztDQU1BLGNBQWMsR0FBRyxNQUFNO0VBQ3JCLEVBQUUscUJBQXFCO0VBQ3ZCLEVBQUUsZ0NBQWdDO0VBQ2xDLEtBQUssVUFBVSxHQUFHLElBQUk7RUFDdEIsS0FBSyxTQUFTLEtBQUssUUFBUSxFQUFFLE1BQU0sQ0FBQztDQUN0Qzs7Ozs7Q0FLQSxTQUFTLEdBQUc7RUFDVixJQUFJLENBQUMsS0FBSyxZQUNSO0VBRUYsTUFBTSxVQUFVLEtBQUssYUFBYSxFQUFFO0VBQ3BDLElBQUksU0FDRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLElBQUksR0FBRyxLQUN6QyxRQUFRLEVBQUUsQ0FBQyxHQUFHLENBQUM7T0FHakIsS0FBSyxrREFBa0QsRUFBRSxNQUFNO0NBRW5FOzs7Ozs7OztDQVFBLFFBQVEsR0FBRyxHQUFHO0VBQ1osYUFBYSxjQUFjO0VBRTNCLE1BQU0sS0FEVSxLQUFLLHVCQUF1QixLQUFLLHlCQUM1Qix5QkFBeUI7RUFDOUMsTUFBTSxlQUFlLEtBQUssR0FBRyxDQUMzQixLQUFLLFlBQ0wsS0FBSyxXQUFXLFdBQ2hCLGdCQUFnQixJQUFJLEdBQUcsQ0FBQyxHQUN4QixLQUFLLFdBQ0wsS0FBSyxVQUNQO0VBQ0EsT0FBTyxnQkFBZ0IsYUFBYTtDQUN0Qzs7Ozs7OztDQU9BLFVBQVUsR0FBRyxNQUFNO0VBQ2pCLElBQUksQ0FBQyxFQUFFLFFBQ0w7RUFFRixNQUFNLGVBQWUsRUFBRSxhQUFhO0VBQ3BDLEVBQUUsYUFBYSxFQUFFO0VBQ2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxhQUFhLFNBQVMsR0FBRyxJQUFJLEdBQUcsS0FBSztHQUN2RCxFQUFFLGdCQUFnQixhQUFhO0dBQy9CLEtBQUssYUFBYSxHQUFHLElBQUk7R0FDekIsSUFBSSxFQUFFLHNCQUFzQixFQUFFLCtCQUErQjtFQUMvRDtFQUNBLEVBQUUsYUFBYSxFQUFFO0VBQ2pCLEVBQUUsZ0JBQWdCLEVBQUU7RUFDcEIsS0FBSyxhQUFhLEdBQUcsSUFBSTtFQUN6QixJQUFJLEVBQUUsc0JBQXNCLEVBQUUsK0JBQStCO0VBQzdELEVBQUUsYUFBYSxFQUFFO0VBQ2pCLEtBQUssSUFBSSxJQUFJLGFBQWEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ2pELEVBQUUsZ0JBQWdCLGFBQWE7R0FDL0IsS0FBSyxhQUFhLEdBQUcsSUFBSTtHQUN6QixJQUFJLEVBQUUsc0JBQXNCLEVBQUUsK0JBQStCO0VBQy9EO0NBQ0Y7Ozs7Ozs7OztDQVNBLElBQUksR0FBRyxNQUFNLFVBQVUsS0FBSyx5QkFBeUI7RUFDbkQsSUFBSSxRQUFRLFdBQVcsR0FBRztFQUMxQixFQUFFLGFBQWEsRUFBRTtFQUNqQixNQUFNLFNBQVMsTUFBTSxRQUFRLElBQUksSUFBSSxPQUFPLENBQUMsSUFBSTtFQUNqRCxLQUFLLElBQUksSUFBSSxRQUFRLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FDdkMsT0FBTyxTQUFTLFVBQVU7R0FDeEIsRUFBRSxnQkFBZ0IsUUFBUTtHQUMxQixLQUFLLGFBQWEsR0FBRyxLQUFLO0VBQzVCLENBQUM7Q0FFTDs7Ozs7O0NBTUEsZ0JBQWdCLFFBQVE7RUFDdEIsTUFBTSxrQkFBa0IsQ0FBQyxNQUFNO0VBQy9CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxxQkFBc0IsV0FBVyxLQUFLLGNBQWMsT0FBTyxRQUFTLEtBQUs7R0FDM0YsSUFBSSxDQUFDLE9BQU8sUUFDVixNQUFNLElBQUksTUFBTSxxREFBcUQ7R0FFdkUsZ0JBQWdCLEtBQUssT0FBTyxNQUFNO0dBQ2xDLFNBQVMsT0FBTztFQUNsQjtFQUNBLGdCQUFnQixRQUFRO0VBQ3hCLE9BQU87Q0FDVDtDQUNBLHFCQUFxQixlQUFlLFdBQVcsVUFBVSxRQUFRLFNBQVMsU0FBUyxPQUFPO0VBQ3hGLElBQUksZUFBZTtFQUNuQixJQUFJLEtBQUssa0JBQWtCLGFBQWEsR0FBRyxPQUFPO0VBQ2xELElBQUksY0FBYyxjQUFjLGFBQWEsY0FBYyxXQUN6RCxhQUFhLGNBQWM7RUFFN0IsSUFBSSxjQUFjLHVCQUF1QixjQUFjLFVBQVU7R0FDL0QsTUFBTSxXQUFXLGNBQWM7R0FDL0IsS0FBSyxJQUFJLElBQUksU0FBUyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7SUFDN0MsTUFBTSxRQUFRLFNBQVM7SUFDdkIsTUFBTSxZQUFZLEtBQUsscUJBQ3JCLE9BQ0EsS0FBSyxlQUFlLFNBQVMsSUFBSSxZQUFZLE1BQU0sV0FDbkQsVUFDQSxRQUNBLFNBQ0EsVUFBVSxRQUFRLGVBQWUsUUFBUSxDQUMzQztJQUNBLElBQUksV0FBVztLQUNiLElBQUksVUFBVSxTQUFTLEtBQUssQ0FBQyxVQUFVLFVBQVUsU0FBUyxFQUFFLENBQUMsUUFDM0Q7S0FFRixNQUFNLGdCQUFnQixjQUFjLGNBQWM7S0FDbEQsSUFBSSxVQUFVLFNBQVMsS0FBSyxlQUFlO01BQ3pDLElBQUksZUFBZSxLQUFLLHdCQUF3QixLQUFLLGFBQWE7TUFDbEUsVUFBVSxLQUFLLGFBQWE7S0FDOUI7S0FDQSxJQUFJLEtBQUssYUFBYSxXQUFXLEdBQUcsS0FBSyxlQUFlO0tBQ3hELGVBQWU7SUFDakI7R0FDRjtFQUNGO0VBQ0EsTUFBTSxvQkFBb0IsS0FBSyxlQUFlLFNBQVM7RUFDdkQsTUFBTSxzQkFBc0IsY0FBYyxjQUFjO0VBQ3hELElBQUksdUJBQXVCLHFCQUFxQixLQUFLLHdCQUF3QixLQUFLLGFBQWE7RUFDL0YsSUFBSSxVQUFVLEtBQUssYUFBYSxTQUFTLEdBQUcsT0FBTztFQUNuRCxJQUFJLGNBQWMsT0FBTyxLQUFLO0VBQzlCLElBQUkscUJBQXNCLENBQUMsUUFBUSxlQUFlLFFBQVEsS0FBSyxPQUFPLGVBQWUsUUFBUSxHQUMzRixPQUFPLHNCQUFzQixDQUFDLGFBQWEsSUFBSSxDQUFDO0VBRWxELE9BQU87Q0FDVDs7Ozs7Ozs7Ozs7Ozs7O0NBZUEsaUJBQWlCLGVBQWUsV0FBVyxVQUFVLFFBQVEsU0FBUztFQUNwRSxJQUFJLEtBQUssa0JBQWtCLGFBQWEsS0FBSyxRQUFRLGVBQWUsUUFBUSxHQUMxRSxPQUFPO0VBRVQsSUFBSSxjQUFjLGNBQWMsYUFBYSxjQUFjLFdBQ3pELGFBQWEsY0FBYztFQUU3QixJQUFJLGNBQWMsdUJBQXVCLGNBQWMsVUFBVTtHQUMvRCxNQUFNLFdBQVcsY0FBYztHQUMvQixNQUFNLG1CQUFtQjtHQUN6QixLQUFLLElBQUksSUFBSSxTQUFTLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztJQUM3QyxNQUFNLFFBQVEsU0FBUztJQUN2QixNQUFNLFlBQVksS0FBSyxpQkFDckIsT0FDQSxLQUFLLGVBQWUsU0FBUyxJQUFJLFlBQVksTUFBTSxXQUNuRCxrQkFDQSxRQUNBLE9BQ0Y7SUFDQSxJQUFJLFdBQVc7S0FDYixJQUFJLFVBQVUsU0FBUyxLQUFLLENBQUMsVUFBVSxVQUFVLFNBQVMsRUFBRSxDQUFDLFFBQzNEO0tBRUYsTUFBTSxnQkFBZ0IsY0FBYyxjQUFjO0tBQ2xELElBQUksVUFBVSxTQUFTLEtBQUssZUFBZSxVQUFVLEtBQUssYUFBYTtLQUN2RSxPQUFPO0lBQ1Q7R0FDRjtFQUNGO0VBQ0EsTUFBTSxvQkFBb0IsS0FBSyxlQUFlLFNBQVM7RUFDdkQsTUFBTSxzQkFBc0IsY0FBYyxjQUFjO0VBQ3hELElBQUkscUJBQXFCLE9BQU8sZUFBZSxRQUFRLEdBQ3JELE9BQU8sc0JBQXNCLENBQUMsYUFBYSxJQUFJLENBQUM7RUFFbEQsT0FBTztDQUNUO0NBQ0EsZUFBZSxLQUFLO0VBQ2xCLE9BQU8sUUFBUSxZQUFZLFFBQVE7Q0FDckM7Q0FDQSxrQkFBa0IsV0FBVztFQUMzQixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsV0FBVyxDQUFDLFVBQVUsY0FBYyxDQUFDLFVBQVUsWUFDMUUsT0FBTztFQUVULElBQUksVUFBVSxjQUFjLFFBQzFCLE9BQU87RUFFVCxJQUFJLFVBQVUsY0FBYyxhQUFhLENBQUMsVUFBVSxxQkFDbEQsT0FBTztFQUVULE9BQU87Q0FDVDs7Ozs7Ozs7O0NBU0EsV0FBVyxXQUFXLFVBQVU7RUFDOUIsSUFBSSxVQUFVLFNBQVM7R0FDckIsVUFBVSxlQUFlLGFBQWEsVUFBVSxnQkFBZ0I7R0FDaEUsSUFBSSxDQUFDLFVBQVUsUUFBUSxTQUFTLGlCQUFpQixHQUFHLGlCQUFpQixDQUFDLEdBQ3BFLE9BQU87RUFFWDtFQUNBLElBQUksVUFBVSxXQUFXLFVBQVUsUUFBUSxRQUN6QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLFFBQVEsS0FBSztHQUNqRCxNQUFNLFNBQVMsVUFBVSxRQUFRO0dBQ2pDLElBQUksT0FBTyxlQUVMO1FBQUEsQ0FEd0IsT0FBTyxjQUFjLFVBQVUsS0FBSyxTQUN6QyxHQUNyQixPQUFPO0dBQUE7RUFHYjtFQUVGLE9BQU87Q0FDVDs7Ozs7OztDQU9BLFVBQVUsV0FBVyxVQUFVO0VBQzdCLElBQUksVUFBVSxTQUNaLE9BQU87RUFFVCxJQUFJLFdBQVcsZUFBZTtHQUM1QixVQUFVLGVBQWUsYUFBYSxVQUFVLGdCQUFnQjtHQUNoRSxPQUFPLFVBQVUsY0FBYyxnQkFBZ0I7RUFDakQ7RUFDQSxPQUFPO0NBQ1Q7Ozs7Ozs7OztDQVNBLGFBQWEsR0FBRyxNQUFNO0VBQ3BCLElBQUksQ0FBQyxFQUFFLGNBQWMsY0FBYyxHQUNqQztFQUVGLFNBQVMsT0FBTyxFQUFFO0VBQ2xCLE1BQU0sYUFBYSxLQUFLO0VBQ3hCLEVBQUUsY0FBYyxXQUFXLEdBQUcsQ0FBQztFQUMvQixNQUFNLE1BQU0sRUFBRSxlQUFlLEVBQUUsbUJBQW1CLEVBQUUsZUFBZSxFQUFFLFlBQVksR0FBRyxLQUFLLFdBQVc7RUFDcEcsS0FBSyxpQkFBaUIsR0FBRyxHQUFHO0VBQzVCLElBQUksRUFBRSxlQUFlLEVBQUUsV0FDckIsS0FBSyxpQkFBaUIsR0FBRyxJQUFJO0NBRWpDOzs7Ozs7O0NBT0EsZUFBZSxNQUFNO0VBQ25CLElBQUksRUFBRSxnQkFBZ0Isd0JBQXdCO0dBQzVDLEtBQUssaUVBQWlFO0dBQ3RFO0VBQ0Y7RUFDQSxNQUFNLElBQUksS0FBSyxtQkFBbUIsSUFBSTtFQUN0QyxLQUFLLGNBQWMsR0FBRyxhQUFhO0VBQ25DLElBQUksRUFBRSxnQkFBZ0IsU0FDcEIsS0FBSyxjQUFjLEdBQUcsWUFBWTtPQUM3QixJQUFJLEVBQUUsZ0JBQWdCLFdBQVcsRUFBRSxnQkFBZ0IsT0FBTztHQUMvRCxNQUFNLGdCQUFnQixFQUFFLFdBQVc7R0FDbkMsS0FBSyxjQUFjLEdBQUcsZ0JBQWdCLGNBQWMsV0FBVztFQUNqRTtFQUNBLE1BQU0sZUFBZSxLQUFLLGFBQWEsS0FBSyxTQUFTO0VBQ3JELGFBQWEscUJBQXFCLEtBQUssVUFBVSxFQUFFLGFBQWE7RUFDaEUsS0FBSyxVQUFVLENBQUM7Q0FDbEI7Ozs7Ozs7O0NBUUEsZUFBZSxNQUFNO0VBQ25CLElBQUksRUFBRSxnQkFBZ0Isd0JBQXdCO0dBQzVDLEtBQUssaUVBQWlFO0dBQ3RFO0VBQ0Y7RUFDQSxLQUFLLHdCQUF3QixTQUFTO0VBQ3RDLEtBQUssYUFBYSxTQUFTO0VBQzNCLEtBQUssc0JBQXNCO0VBQzNCLE1BQU0sSUFBSSxLQUFLLG1CQUFtQixJQUFJO0VBQ3RDLEtBQUssc0JBQXNCO0VBQzNCLE1BQU0sVUFBVSxFQUFFLGdCQUFnQixXQUFXLEVBQUUsZ0JBQWdCO0VBQy9ELE1BQU0sZUFBZSxLQUFLLGFBQWEsS0FBSyxTQUFTO0VBQ3JELE1BQU0sWUFBWSxLQUFLLGtCQUFrQixhQUFhLFdBQVc7RUFDakUsSUFBSSxhQUFhLGFBQWEsU0FBUyxLQUFLLGNBQWMsRUFBRSxRQUFRO0dBQ2xFLE1BQU0sVUFBVSxLQUFLLFNBQVMsY0FBYyxhQUFhO0dBQ3pELE1BQU0sV0FBVyxLQUFLLG1CQUFtQixNQUFNLFNBQVMsU0FBUztHQUNqRSxLQUFLLGNBQWMsVUFBVSxZQUFZO0dBQ3pDLElBQUksU0FBUyxLQUFLLGNBQWMsVUFBVSxVQUFVO0dBQ3BELElBQUksQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLFNBQVMsU0FBUyxHQUFHO0lBQ3pDLE1BQU0sYUFBYSxLQUFLLG1CQUFtQixNQUFNLGdCQUFnQixTQUFTO0lBQzFFLFdBQVcsYUFBYSxXQUFXO0lBQ25DLE9BQU8sV0FBVyxVQUFVLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxTQUFTLFdBQVcsTUFBTSxHQUFHO0tBQ3pFLFdBQVcsZ0JBQWdCLFdBQVc7S0FDdEMsS0FBSyxhQUFhLFVBQVU7S0FDNUIsSUFBSSxTQUFTLEtBQUssYUFBYSxZQUFZLFlBQVk7S0FDdkQsV0FBVyxTQUFTLFdBQVcsT0FBTztJQUN4QztJQUNBLEtBQUssVUFBVSxVQUFVO0dBQzNCO0dBQ0EsS0FBSyxVQUFVLFFBQVE7RUFDekI7RUFDQSxJQUFJLGNBQWMsRUFBRSxRQUFRO0dBQzFCLE1BQU0sV0FBVyxLQUFLLFNBQVMsY0FBYyxjQUFjO0dBQzNELE1BQU0sWUFBWSxLQUFLLGtCQUFrQixHQUFHLFFBQVE7R0FDcEQsS0FBSyxjQUFjLFdBQVcsYUFBYTtHQUMzQyxJQUFJLFNBQVMsS0FBSyxjQUFjLFdBQVcsV0FBVztHQUN0RCxJQUFJLHFCQUFxQixXQUFXO0dBQ3BDLE9BQU8sc0JBQXNCLHVCQUF1QixLQUFLLFdBQVcsUUFBUTtJQUMxRSxJQUFJLHVCQUF1QixFQUFFLFFBQVE7SUFDckMscUJBQXFCLG1CQUFtQjtHQUMxQztHQUVBLElBRHdCLENBQUMsc0JBQXNCLHVCQUF1QixLQUFLLFdBQVcsUUFDakU7SUFDbkIsTUFBTSxhQUFhLEtBQUssa0JBQWtCLEdBQUcsY0FBYztJQUMzRCxXQUFXLGFBQWEsV0FBVztJQUNuQyxPQUFPLFdBQVcsVUFBVSxXQUFXLFdBQVcsYUFBYSxXQUFXLFdBQVcsS0FBSyxXQUFXLFFBQVE7S0FDM0csV0FBVyxnQkFBZ0IsV0FBVztLQUN0QyxLQUFLLGFBQWEsVUFBVTtLQUM1QixJQUFJLFNBQVMsS0FBSyxhQUFhLFlBQVksWUFBWTtLQUN2RCxXQUFXLFNBQVMsV0FBVyxPQUFPO0lBQ3hDO0lBQ0EsS0FBSyxVQUFVLFVBQVU7R0FDM0I7R0FDQSxLQUFLLFVBQVUsU0FBUztFQUMxQjtFQUNBLE1BQU0sYUFBYSxDQUFDO0VBQ3BCLE1BQU0sMkJBQTJCLEtBQUssMEJBQTBCO0VBQ2hFLEtBQUssWUFBWSxXQUFXLEtBQUssYUFBYSxJQUFJLEtBQUssY0FBYyxHQUFHLGFBQWE7RUFDckYsNEJBQTRCLFdBQVcsS0FBSyxtQkFBbUI7RUFDL0QsSUFBSSxFQUFFLGdCQUFnQixTQUFTO0dBQzdCLEtBQUssWUFBWSxXQUFXLE9BQU8sR0FBRyxHQUFHLFdBQVcsSUFBSSxLQUFLLGNBQWMsR0FBRyxXQUFXO0dBQ3pGLDRCQUE0QixXQUFXLEtBQUssaUJBQWlCO0VBQy9EO0VBQ0EsSUFBSSxTQUFTO0dBQ1gsS0FBSyxZQUFZLFdBQVcsT0FBTyxHQUFHLEdBQUcsV0FBVyxJQUFJLEtBQUssY0FBYyxHQUFHLFdBQVc7R0FDekYsNEJBQTRCLFdBQVcsS0FBSyxpQkFBaUI7R0FDN0QsS0FBSyxTQUFTLEVBQUUsUUFBUTtFQUMxQjtFQUNBLElBQUksV0FBVyxTQUFTLEdBQ3RCLEtBQUssSUFBSSxHQUFHLFVBQVU7RUFFeEIsS0FBSyx3QkFBd0IsU0FBUztFQUN0QyxLQUFLLGFBQWEsU0FBUztFQUMzQixhQUFhLGNBQWMsRUFBRSxhQUFhO0VBQzFDLEtBQUssVUFBVSxDQUFDO0NBQ2xCOzs7Ozs7O0NBT0EsZUFBZSxNQUFNO0VBQ25CLElBQUksRUFBRSxnQkFBZ0Isd0JBQXdCO0dBQzVDLEtBQUssaUVBQWlFO0dBQ3RFO0VBQ0Y7RUFDQSxNQUFNLGVBQWUsS0FBSyxhQUFhLEtBQUssU0FBUztFQUNyRCxNQUFNLElBQUksS0FBSyxtQkFBbUIsSUFBSTtFQUN0QyxNQUFNLFVBQVUsRUFBRSxnQkFBZ0IsV0FBVyxFQUFFLGdCQUFnQjtFQUMvRCxLQUFLLGNBQWMsR0FBRyxhQUFhO0VBQ25DLElBQUksU0FBUyxLQUFLLGNBQWMsR0FBRyxXQUFXO0VBQzlDLElBQUksRUFBRSxnQkFBZ0IsU0FBUyxLQUFLLFNBQVMsRUFBRSxRQUFRO0VBQ3ZELE1BQU0sYUFBYSxLQUFLLGtCQUFrQixHQUFHLGNBQWM7RUFDM0QsV0FBVyxhQUFhLFdBQVc7RUFDbkMsT0FBTyxXQUFXLFVBQVUsV0FBVyxXQUFXLEtBQUssV0FBVyxRQUFRO0dBQ3hFLFdBQVcsZ0JBQWdCLFdBQVc7R0FDdEMsS0FBSyxhQUFhLFVBQVU7R0FDNUIsSUFBSSxTQUFTLEtBQUssYUFBYSxZQUFZLFlBQVk7R0FDdkQsV0FBVyxTQUFTLFdBQVcsT0FBTztFQUN4QztFQUNBLGFBQWEsY0FBYyxFQUFFLGFBQWE7RUFDMUMsS0FBSyxVQUFVLENBQUM7RUFDaEIsS0FBSyxVQUFVLFVBQVU7Q0FDM0I7Ozs7Ozs7Q0FPQSxjQUFjLE1BQU07RUFDbEIsSUFBSSxFQUFFLGdCQUFnQix3QkFBd0I7R0FDNUMsS0FBSyxpRUFBaUU7R0FDdEU7RUFDRjtFQUNBLE1BQU0sZUFBZSxLQUFLLGFBQWEsS0FBSyxTQUFTO0VBQ3JELElBQUksYUFBYSxhQUFhO0dBQzVCLE1BQU0sVUFBVSxLQUFLLGdCQUFnQixXQUFXLEtBQUssZ0JBQWdCO0dBQ3JFLE1BQU0sWUFBWSxLQUFLLGtCQUFrQixhQUFhLFdBQVc7R0FDakUsTUFBTSxXQUFXLEtBQUssbUJBQW1CLE1BQU0sY0FBYyxTQUFTO0dBQ3RFLEtBQUssY0FBYyxRQUFRO0dBQzNCLElBQUksU0FBUyxLQUFLLGNBQWMsVUFBVSxVQUFVO0dBQ3BELE1BQU0sYUFBYSxLQUFLLG1CQUFtQixNQUFNLGdCQUFnQixTQUFTO0dBQzFFLFdBQVcsYUFBYSxXQUFXO0dBQ25DLE9BQU8sV0FBVyxVQUFVLFdBQVcsV0FBVyxLQUFLLFdBQVcsUUFBUTtJQUN4RSxXQUFXLGdCQUFnQixXQUFXO0lBQ3RDLEtBQUssYUFBYSxVQUFVO0lBQzVCLElBQUksU0FBUyxLQUFLLGFBQWEsWUFBWSxZQUFZO0lBQ3ZELFdBQVcsU0FBUyxXQUFXLE9BQU87R0FDeEM7R0FDQSxhQUFhLGNBQWM7R0FDM0IsS0FBSyxVQUFVLFFBQVE7R0FDdkIsS0FBSyxVQUFVLFVBQVU7RUFDM0I7RUFDQSxLQUFLLFNBQVM7Q0FDaEI7Ozs7Ozs7Ozs7O0NBV0EsYUFBYSxNQUFNO0VBQ2pCLElBQUksRUFBRSxnQkFBZ0Isd0JBQXdCO0dBQzVDLEtBQUssaUVBQWlFO0dBQ3RFO0VBQ0Y7RUFDQSxNQUFNLE1BQU0sWUFBWSxJQUFJO0VBQzVCLE1BQU0sSUFBSSxLQUFLLG1CQUFtQixJQUFJO0VBQ3RDLEtBQUssY0FBYyxHQUFHLFdBQVc7RUFDakMsSUFBSSxFQUFFLGdCQUFnQixTQUNwQixLQUFLLGNBQWMsR0FBRyxVQUFVO09BQzNCLElBQUksRUFBRSxnQkFBZ0IsV0FBVyxFQUFFLGdCQUFnQixPQUFPO0dBQy9ELE1BQU0sZ0JBQWdCLEVBQUUsV0FBVztHQUNuQyxLQUFLLGNBQWMsR0FBRyxnQkFBZ0IsWUFBWSxTQUFTO0VBQzdEO0VBQ0EsTUFBTSxlQUFlLEtBQUssYUFBYSxLQUFLLFNBQVM7RUFDckQsTUFBTSxjQUFjLEtBQUssa0JBQWtCLGFBQWEscUJBQXFCLEtBQUssT0FBTztFQUN6RixJQUFJLGNBQWM7RUFDbEIsSUFBSSxlQUFlLENBQUMsRUFBRSxhQUFhLENBQUMsQ0FBQyxTQUFTLFdBQVcsR0FBRztHQUMxRCxJQUFJLGdCQUFnQjtHQUNwQixPQUFPLGlCQUFpQixDQUFDLEVBQUUsYUFBYSxDQUFDLENBQUMsU0FBUyxhQUFhLEdBQUc7SUFDakUsRUFBRSxnQkFBZ0I7SUFDbEIsS0FBSyxhQUFhLEdBQUcsa0JBQWtCO0lBQ3ZDLElBQUksRUFBRSxnQkFBZ0IsU0FDcEIsS0FBSyxhQUFhLEdBQUcsaUJBQWlCO1NBQ2pDLElBQUksRUFBRSxnQkFBZ0IsV0FBVyxFQUFFLGdCQUFnQixPQUFPO0tBQy9ELE1BQU0sZ0JBQWdCLEVBQUUsV0FBVztLQUNuQyxLQUFLLGFBQWEsR0FBRyxnQkFBZ0IsbUJBQW1CLGdCQUFnQjtJQUMxRTtJQUNBLGdCQUFnQixjQUFjO0dBQ2hDO0dBQ0EsT0FBTyxhQUFhLHFCQUFxQixLQUFLO0dBQzlDLGNBQWM7RUFDaEI7RUFDQSxJQUFJLGFBQWE7R0FDZixNQUFNLGFBQWEsS0FBSyxrQkFBa0IsR0FBRyxPQUFPO0dBQ3BELFdBQVcsU0FBUztHQUNwQixXQUFXLE9BQU87R0FDbEIsSUFBSSxDQUFDLGFBQWEsZUFBZSxLQUFLLFNBQ3BDLGFBQWEsZUFBZSxLQUFLLFVBQVU7SUFDekMsWUFBWTtJQUNaLFFBQVEsV0FBVztJQUNuQixXQUFXO0dBQ2I7R0FFRixNQUFNLGVBQWUsYUFBYSxlQUFlLEtBQUs7R0FDdEQsSUFBSSxhQUFhLFdBQVcsV0FBVyxVQUFVLE1BQU0sYUFBYSxZQUFZLEtBQzlFLEVBQUUsYUFBYTtRQUVmLGFBQWEsYUFBYTtHQUU1QixhQUFhLFNBQVMsV0FBVztHQUNqQyxhQUFhLFlBQVk7R0FDekIsV0FBVyxTQUFTLGFBQWE7R0FDakMsSUFBSSxXQUFXLGdCQUFnQixTQUFTO0lBQ3RDLE1BQU0sZ0JBQWdCLFdBQVcsV0FBVztJQUM1QyxLQUFLLGNBQWMsWUFBWSxnQkFBZ0IsZUFBZSxPQUFPO0dBQ3ZFLE9BQU8sSUFBSSxXQUFXLGdCQUFnQixTQUNwQyxLQUFLLGNBQWMsWUFBWSxLQUFLO0dBRXRDLEtBQUssY0FBYyxZQUFZLFlBQVk7R0FDM0MsS0FBSyxVQUFVLFVBQVU7RUFDM0I7RUFDQSxLQUFLLFVBQVUsQ0FBQztDQUNsQjs7Ozs7Ozs7Ozs7O0NBWUEsb0JBQW9CLE1BQU07RUFDeEIsSUFBSSxFQUFFLGdCQUFnQix3QkFBd0I7R0FDNUMsS0FBSyxpRUFBaUU7R0FDdEU7RUFDRjtFQUNBLE1BQU0sZUFBZSxLQUFLLGFBQWEsS0FBSyxTQUFTO0VBQ3JELE1BQU0sY0FBYyxLQUFLLGtCQUFrQixhQUFhLHFCQUFxQixLQUFLLE9BQU87RUFDekYsTUFBTSxJQUFJLEtBQUssbUJBQW1CLElBQUk7RUFDdEMsSUFBSSxhQUFhO0dBQ2YsSUFBSSxnQkFBZ0I7R0FDcEIsT0FBTyxlQUFlO0lBQ3BCLEVBQUUsZ0JBQWdCO0lBQ2xCLEtBQUssYUFBYSxHQUFHLGtCQUFrQjtJQUN2QyxJQUFJLEVBQUUsZ0JBQWdCLFNBQ3BCLEtBQUssYUFBYSxHQUFHLGlCQUFpQjtTQUNqQyxJQUFJLEVBQUUsZ0JBQWdCLFdBQVcsRUFBRSxnQkFBZ0IsT0FDeEQsS0FBSyxhQUFhLEdBQUcsRUFBRSxXQUFXLElBQUksbUJBQW1CLGdCQUFnQjtJQUUzRSxnQkFBZ0IsY0FBYztHQUNoQztHQUNBLE9BQU8sYUFBYSxxQkFBcUIsS0FBSztFQUNoRDtFQUNBLEtBQUssVUFBVSxDQUFDO0NBQ2xCOzs7OztDQUtBLFNBQVMsTUFBTTtFQUNiLElBQUksRUFBRSxnQkFBZ0Isc0JBQXNCO0dBQzFDLEtBQUssNkRBQTZEO0dBQ2xFO0VBQ0Y7RUFDQSxNQUFNLGFBQWEsS0FBSyxpQkFBaUIsSUFBSTtFQUM3QyxLQUFLLGNBQWMsVUFBVTtFQUM3QixLQUFLLFVBQVUsVUFBVTtDQUMzQjs7Ozs7Q0FLQSxlQUFlLE1BQU07RUFDbkIsSUFBSSxFQUFFLGdCQUFnQix3QkFBd0I7R0FDNUMsS0FBSyxpRUFBaUU7R0FDdEU7RUFDRjtFQUNBLE1BQU0sSUFBSSxLQUFLLG1CQUFtQixJQUFJO0VBQ3RDLEtBQUssY0FBYyxHQUFHLGFBQWE7RUFDbkMsS0FBSyxVQUFVLENBQUM7Q0FDbEI7Ozs7Ozs7OztDQVNBLGtCQUFrQixpQkFBaUI7RUFDakMsSUFBSSxDQUFDLGlCQUNILE9BQU87RUFFVCxJQUFJLGdCQUFnQixnQkFBZ0I7RUFDcEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGdCQUFnQixRQUFRLEtBQzFDLElBQUksZ0JBQWdCLEVBQUUsQ0FBQyxXQUFXLGVBQ2hDLGdCQUFnQixnQkFBZ0I7T0FFaEM7RUFHSixPQUFPO0NBQ1Q7Ozs7Ozs7OztDQVNBLG1CQUFtQixNQUFNLE1BQU0sUUFBUTtFQUNyQyxNQUFNLFFBQVEsS0FBSyxjQUFjLHFCQUFxQjtFQUN0RCxLQUFLLGdCQUFnQixNQUFNLEtBQUs7RUFDaEMsS0FBSyxjQUFjLE1BQU0sS0FBSztFQUM5QixLQUFLLFNBQVMsTUFBTSxLQUFLO0VBQ3pCLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0sZ0JBQWdCO0VBQ3RCLE1BQU0sU0FBUyxVQUFVLEtBQUssUUFBUSxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU8sQ0FBQyxLQUFLLEtBQUssYUFBYTtFQUMzRixJQUFJLE9BQU8sU0FBUyxVQUNsQixNQUFNLE9BQU87RUFFZixPQUFPO0NBQ1Q7Ozs7Ozs7Q0FPQSxpQkFBaUIsTUFBTTtFQUNyQixNQUFNLFFBQVEsS0FBSyxjQUFjLG1CQUFtQjtFQUNwRCxLQUFLLGNBQWMsTUFBTSxLQUFLO0VBQzlCLEtBQUssY0FBYyxNQUFNLEtBQUs7RUFDOUIsS0FBSyxTQUFTLE1BQU0sS0FBSztFQUN6QixNQUFNLGNBQWMsS0FBSztFQUN6QixNQUFNLGdCQUFnQjtFQUN0QixNQUFNLFNBQVMsS0FBSyxRQUFRLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTyxDQUFDO0VBQzFELE9BQU87Q0FDVDs7Ozs7Ozs7Q0FRQSxrQkFBa0IsTUFBTSxNQUFNO0VBQzVCLE1BQU0sUUFBUSxLQUFLLGNBQWMscUJBQXFCO0VBQ3RELE1BQU0sY0FBYyxLQUFLO0VBQ3pCLE1BQU0sZ0JBQWdCLEtBQUs7RUFDM0IsS0FBSyxnQkFBZ0IsTUFBTSxLQUFLO0VBQ2hDLEtBQUssY0FBYyxNQUFNLEtBQUs7RUFDOUIsS0FBSyxTQUFTLE1BQU0sS0FBSztFQUN6QixNQUFNLFNBQVMsS0FBSztFQUNwQixNQUFNLE9BQU8sS0FBSyxhQUFhLENBQUMsQ0FBQyxNQUFNO0VBQ3ZDLE1BQU0sT0FBTyxRQUFRLE1BQU07RUFDM0IsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Q0FZQSxjQUFjLE1BQU0sSUFBSTtFQUN0QixHQUFHLFlBQVksS0FBSztFQUNwQixHQUFHLFNBQVMsS0FBSztFQUNqQixHQUFHLFNBQVMsS0FBSztFQUNqQixHQUFHLFNBQVMsS0FBSztDQUNuQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkEsZ0JBQWdCLE1BQU0sSUFBSTtFQUN4QixJQUFJLEVBQUUsZ0JBQWdCLHlCQUF5QixjQUFjLHdCQUF3QjtFQUNyRixHQUFHLFlBQVksS0FBSztFQUNwQixHQUFHLFFBQVEsS0FBSztFQUNoQixHQUFHLFNBQVMsS0FBSztFQUNqQixHQUFHLFlBQVksS0FBSztFQUNwQixHQUFHLGNBQWMsS0FBSztFQUN0QixHQUFHLFdBQVcsS0FBSztFQUNuQixHQUFHLHFCQUFxQixLQUFLO0VBQzdCLEdBQUcsUUFBUSxLQUFLO0VBQ2hCLEdBQUcsUUFBUSxLQUFLO0VBQ2hCLEdBQUcsUUFBUSxLQUFLO0VBQ2hCLEdBQUcscUJBQXFCLEtBQUs7Q0FDL0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUJBLGNBQWMsTUFBTSxJQUFJO0VBQ3RCLElBQUksRUFBRSxnQkFBZ0IsdUJBQXVCLGNBQWMsc0JBQXNCO0VBQ2pGLEdBQUcsU0FBUyxLQUFLO0VBQ2pCLEdBQUcsU0FBUyxLQUFLO0VBQ2pCLEdBQUcsVUFBVSxLQUFLO0VBQ2xCLEdBQUcsT0FBTyxTQUFTLEtBQUssTUFBTTtFQUM5QixHQUFHLFVBQVUsS0FBSztFQUNsQixHQUFHLFVBQVUsS0FBSztFQUNsQixHQUFHLFNBQVMsU0FBUyxLQUFLLFFBQVE7RUFDbEMsR0FBRyxPQUFPLFNBQVMsS0FBSyxNQUFNO0VBQzlCLEdBQUcsV0FBVyxLQUFLO0VBQ25CLEdBQUcsT0FBTyxTQUFTLEtBQUssTUFBTTtDQUNoQzs7Ozs7Ozs7Ozs7O0NBWUEsU0FBUyxNQUFNLElBQUk7RUFDakIsR0FBRyxZQUFZLEtBQUs7RUFDcEIsR0FBRyxhQUFhLEtBQUs7RUFDckIsR0FBRyxZQUFZLFlBQVksSUFBSTtFQUMvQixHQUFHLE9BQU8sS0FBSztFQUNmLEdBQUcsU0FBUyxLQUFLO0VBQ2pCLEdBQUcsT0FBTyxLQUFLO0VBQ2YsR0FBRyxRQUFRLEtBQUs7RUFDaEIsR0FBRyxNQUFNLFNBQVMsS0FBSyxLQUFLO0VBQzVCLEdBQUcsS0FBSyxTQUFTLEtBQUssSUFBSTtDQUM1Qjs7Ozs7O0NBTUEsYUFBYSxJQUFJO0VBQ2YsSUFBSSxDQUFDLEtBQUssYUFBYSxhQUFhLEtBQ2xDLEtBQUssYUFBYSxhQUFhLE1BQU07R0FDbkMsc0JBQXNCLENBQUM7R0FDdkIsZ0JBQWdCLENBQUM7R0FDakIsWUFBWTtFQUNkO0VBRUYsT0FBTyxLQUFLLGFBQWEsYUFBYTtDQUN4Qzs7Ozs7Ozs7O0NBU0EsY0FBYyxhQUFhO0VBQ3pCLElBQUksQ0FBQyxLQUFLLFVBQVUsSUFBSSxXQUFXLEdBQ2pDLEtBQUssVUFBVSxJQUFJLGFBQWEsQ0FBQyxDQUFDO0VBRXBDLE1BQU0sUUFBUSxLQUFLLFVBQVUsSUFBSSxXQUFXLENBQUMsQ0FBQyxJQUFJLEtBQUssSUFBSSxZQUFZLElBQUk7RUFDM0UsTUFBTSxhQUFhLE1BQU07RUFDekIsTUFBTSxnQkFBZ0I7RUFDdEIsTUFBTSxtQkFBbUI7RUFDekIsTUFBTSxPQUFPO0VBQ2IsTUFBTSxTQUFTO0VBQ2YsT0FBTztDQUNUOzs7Ozs7Ozs7Ozs7Q0FZQSxVQUFVLE9BQU87RUFDZixJQUFJLE1BQU0sWUFBWSxNQUFNLE1BQU0sSUFBSSxNQUFNLG1FQUFtRTtFQUMvRyxNQUFNLGNBQWMsTUFBTTtFQUMxQixJQUFJLENBQUMsS0FBSyxVQUFVLElBQUksV0FBVyxHQUNqQyxLQUFLLFVBQVUsSUFBSSxhQUFhLENBQUMsQ0FBQztFQUVwQyxLQUFLLFVBQVUsSUFBSSxXQUFXLENBQUMsQ0FBQyxLQUFLLEtBQUs7Q0FDNUM7Ozs7Ozs7Q0FPQSxpQkFBaUIsR0FBRyxNQUFNO0VBQ3hCLE1BQU0sWUFBWSxFQUFFLGNBQWMsUUFBUTtFQUMxQyxJQUFJLENBQUMsV0FBVztFQUNoQixJQUFJLFFBQVEsV0FBVztHQUNyQixJQUFJLFVBQVUsTUFBTSxFQUFFLGNBQWMsZUFBZSxNQUFNLFVBQVUsSUFBSSxLQUFLLEdBQUcsSUFBSTtHQUNuRixVQUFVLEdBQUcsS0FBSyxVQUFVLFNBQVMsQ0FBQztFQUN4QyxPQUNFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsSUFBSSxLQUFLLENBQUMsRUFBRSwrQkFBK0IsS0FBSztHQUNwRixJQUFJLFVBQVUsRUFBRSxDQUFDLE1BQU0sRUFBRSxjQUFjLGVBQWUsTUFBTSxVQUFVLEVBQUUsQ0FBQyxJQUFJLEtBQUssR0FBRyxJQUFJO0dBQ3pGLFVBQVUsRUFBRSxDQUFDLEdBQUcsS0FBSyxVQUFVLEVBQUUsQ0FBQyxTQUFTLENBQUM7RUFDOUM7Q0FFSjtBQUNGOzs7QUNyNkJBLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sbUJBQW1CO0NBQ3ZCLFlBQVk7Q0FDWixVQUFVO0NBQ1YsaUJBQWlCO0NBQ2pCLFdBQVc7Q0FDWCxhQUFhO0FBQ2Y7QUFDQSxJQUFNLGVBQWUsTUFBTSxhQUFhOzs7O0NBSXRDLFlBQVksVUFBVTs7Ozs7Ozs7RUFRcEIsS0FBSyxzQkFBc0Isa0JBQWtCOzs7Ozs7OztFQVE3QyxLQUFLLHdCQUF3QixDQUFDLENBQUMsV0FBVzs7Ozs7RUFLMUMsS0FBSyxhQUFhOztFQUVsQixLQUFLLGFBQWE7RUFDbEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssZUFBZSxJQUFJLGNBQWMsSUFBSTtFQUMxQyxhQUFhLEtBQUssSUFBSTtFQUN0QixLQUFLLHFCQUFxQjtFQUMxQixLQUFLLGVBQWU7RUFDcEIsS0FBSyxvQkFBb0IsSUFBSSxzQkFBc0IsSUFBSTtFQUN2RCxLQUFLLGtCQUFrQixJQUFJLG9CQUFvQixJQUFJO0VBQ25ELEtBQUssd0JBQXdCLElBQUksc0JBQXNCLElBQUk7RUFDM0QsS0FBSyxlQUFlO0dBQ2xCLFNBQVM7R0FDVCxTQUFTO0VBQ1g7RUFDQSxLQUFLLFdBQVcsSUFBSSxNQUFNLEVBQUUsR0FBRyxhQUFhLHFCQUFxQixHQUFHLEVBQ2xFLE1BQU0sUUFBUSxLQUFLLFVBQVU7R0FDM0IsSUFBSSxRQUFRLGNBQ1YsS0FBSyxhQUFhLHlCQUF5QjtHQUU3QyxPQUFPLE9BQU87R0FDZCxPQUFPO0VBQ1QsRUFDRixDQUFDO0VBQ0QsS0FBSyxpQkFBaUIsS0FBSyxlQUFlLEtBQUssSUFBSTtFQUNuRCxLQUFLLGlCQUFpQixLQUFLLGVBQWUsS0FBSyxJQUFJO0VBQ25ELEtBQUssZUFBZSxLQUFLLGFBQWEsS0FBSyxJQUFJO0VBQy9DLEtBQUssb0JBQW9CLEtBQUssa0JBQWtCLEtBQUssSUFBSTtFQUN6RCxLQUFLLGlCQUFpQixLQUFLLGVBQWUsS0FBSyxJQUFJO0VBQ25ELEtBQUssVUFBVSxLQUFLLFFBQVEsS0FBSyxJQUFJO0NBQ3ZDOzs7Ozs7OztDQVFBLFdBQVcsbUJBQW1CO0VBQzVCLE9BQU8sS0FBSztDQUNkOzs7OztDQUtBLEtBQUssU0FBUztFQUNaLE1BQU0sRUFBRSxRQUFRLGVBQWUsS0FBSztFQUNwQyxLQUFLLGlCQUFpQixNQUFNO0VBQzVCLEtBQUssYUFBYTtFQUNsQixhQUFhLG9CQUFvQixRQUFRLGFBQWE7RUFDdEQsT0FBTyxPQUFPLEtBQUssVUFBVSxRQUFRLGlCQUFpQixDQUFDLENBQUM7RUFDeEQsS0FBSyxhQUFhLHlCQUF5QixLQUFLLFNBQVM7Q0FDM0Q7Ozs7O0NBS0EsaUJBQWlCLFlBQVk7RUFDM0IsS0FBSyxhQUFhO0NBQ3BCOztDQUVBLFVBQVU7RUFDUixhQUFhLFFBQVE7RUFDckIsS0FBSyxpQkFBaUIsSUFBSTtFQUMxQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxpQkFBaUI7Q0FDeEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBZ0NBLFVBQVUsTUFBTTtFQUNkLFNBQVMsT0FBTztFQUNoQixJQUFJLGNBQWM7RUFDbEIsSUFBSSxXQUFXLG1CQUFtQixLQUFLLHNCQUFzQixpQkFDM0QsY0FBYztFQUVoQixJQUFJLEtBQUssbUJBQW1CLE1BQzFCO0VBRUYsS0FBSyxpQkFBaUI7RUFDdEIsTUFBTSxRQUFRLEtBQUssYUFBYTtFQUNoQyxJQUFJLE9BQ0YsUUFBUSxPQUFPLE9BQWY7R0FDRSxLQUFLO0lBQ0gsSUFBSSxhQUNGLEtBQUssV0FBVyxNQUFNLFNBQVM7SUFFakM7R0FDRixLQUFLO0lBQ0gsTUFBTSxJQUFJO0lBQ1Y7R0FDRixLQUFLLFVBQ0gsSUFBSSxhQUNGLE9BQU8sT0FBTyxLQUFLLFdBQVcsT0FBTyxLQUFLO0VBR2hEO09BQ0ssSUFBSSxlQUFlLE9BQU8sU0FBUyxZQUFZLENBQUMsT0FBTyxVQUFVLGVBQWUsS0FBSyxLQUFLLGNBQWMsSUFBSSxHQUNqSCxLQUFLLFdBQVcsTUFBTSxTQUFTO0NBRW5DOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0F3QkEsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLO0NBQ2Q7Ozs7O0NBS0EsZUFBZSxhQUFhO0VBQzFCLElBQUksQ0FBQyxLQUFLLFNBQVMsT0FBTztFQUMxQixLQUFLLGFBQWEsYUFBYSxLQUFLLFNBQVM7RUFDN0MsTUFBTSxTQUFTLEtBQUssd0JBQXdCLFdBQVc7RUFDdkQsSUFBSSxLQUFLLHNCQUFzQixPQUFPLEVBQUUsQ0FBQyxjQUNwQjtPQUFBLFlBQVksY0FBYyxFQUFFLGdCQUFnQixjQUU3RCxZQUFZLGVBQWU7RUFBQTtFQUcvQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLElBQUksR0FBRyxLQUFLO0dBQzdDLE1BQU0sZUFBZSxPQUFPO0dBQzVCLE1BQU0saUJBQWlCLEtBQUssZ0JBQWdCLEtBQUssbUJBQW1CLFlBQVk7R0FDaEYsS0FBSyxhQUFhLFNBQVMsY0FBYztFQUMzQztFQUNBLEtBQUssVUFBVSxLQUFLLGFBQWEsTUFBTTtDQUN6Qzs7Ozs7Q0FLQSxlQUFlLGFBQWE7RUFDMUIsSUFBSSxDQUFDLEtBQUssU0FBUyxNQUFNO0VBQ3pCLEtBQUssYUFBYSxhQUFhLEtBQUssU0FBUztFQUM3QyxhQUFhLGFBQWE7RUFDMUIsTUFBTSxtQkFBbUIsS0FBSyx3QkFBd0IsV0FBVztFQUNqRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksaUJBQWlCLFFBQVEsSUFBSSxHQUFHLEtBQUs7R0FDdkQsTUFBTSxRQUFRLEtBQUssZ0JBQWdCLEtBQUssbUJBQW1CLGlCQUFpQixFQUFFO0dBQzlFLEtBQUssYUFBYSxTQUFTLEtBQUs7RUFDbEM7RUFDQSxLQUFLLFVBQVUsS0FBSyxhQUFhLE1BQU07Q0FDekM7Ozs7O0NBS0EsYUFBYSxhQUFhO0VBQ3hCLElBQUksQ0FBQyxLQUFLLFNBQVMsT0FBTztFQUMxQixLQUFLLGFBQWEsYUFBYSxLQUFLLFNBQVM7RUFDN0MsSUFBSSxTQUFTLFlBQVk7RUFDekIsSUFBSSxZQUFZLGdCQUFnQixZQUFZLGFBQWEsQ0FBQyxDQUFDLFNBQVMsR0FDbEUsU0FBUyxZQUFZLGFBQWEsQ0FBQyxDQUFDO0VBRXRDLE1BQU0sVUFBVSxXQUFXLEtBQUssYUFBYSxZQUFZO0VBQ3pELE1BQU0sbUJBQW1CLEtBQUssd0JBQXdCLFdBQVc7RUFDakUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGlCQUFpQixRQUFRLElBQUksR0FBRyxLQUFLO0dBQ3ZELE1BQU0sUUFBUSxLQUFLLGdCQUFnQixLQUFLLG1CQUFtQixpQkFBaUIsRUFBRTtHQUM5RSxNQUFNLFFBQVE7R0FDZCxLQUFLLGFBQWEsU0FBUyxLQUFLO0VBQ2xDO0VBQ0EsS0FBSyxVQUFVLEtBQUssYUFBYSxNQUFNO0NBQ3pDOzs7OztDQUtBLGtCQUFrQixhQUFhO0VBQzdCLElBQUksQ0FBQyxLQUFLLFNBQVMsT0FBTztFQUMxQixLQUFLLGFBQWEsYUFBYSxLQUFLLFNBQVM7RUFDN0MsTUFBTSxtQkFBbUIsS0FBSyx3QkFBd0IsV0FBVztFQUNqRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksaUJBQWlCLFFBQVEsSUFBSSxHQUFHLEtBQUs7R0FDdkQsTUFBTSxRQUFRLEtBQUssZ0JBQWdCLEtBQUssbUJBQW1CLGlCQUFpQixFQUFFO0dBQzlFLEtBQUssYUFBYSxTQUFTLEtBQUs7RUFDbEM7RUFDQSxLQUFLLFVBQVUsS0FBSyxhQUFhLE1BQU07Q0FDekM7Ozs7Ozs7O0NBUUEsZUFBZSxhQUFhO0VBQzFCLElBQUksQ0FBQyxLQUFLLFNBQVMsT0FBTztFQUMxQixLQUFLLGFBQWEsYUFBYSxLQUFLLFNBQVM7RUFDN0MsTUFBTSxtQkFBbUIsS0FBSyx3QkFBd0IsV0FBVztFQUNqRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksaUJBQWlCLFFBQVEsSUFBSSxHQUFHLEtBQUs7R0FDdkQsTUFBTSxRQUFRLEtBQUssZ0JBQWdCLEtBQUssdUJBQXVCLGlCQUFpQixFQUFFO0dBQ2xGLEtBQUssYUFBYSxTQUFTLEtBQUs7RUFDbEM7RUFDQSxLQUFLLFVBQVUsS0FBSyxhQUFhLE1BQU07Q0FDekM7Ozs7O0NBS0EsUUFBUSxhQUFhO0VBQ25CLElBQUksQ0FBQyxLQUFLLFNBQVMsT0FBTztFQUMxQixNQUFNLGFBQWEsS0FBSyxvQkFBb0IsV0FBVztFQUN2RCxLQUFLLGFBQWEsYUFBYSxLQUFLLFNBQVM7RUFDN0MsS0FBSyxhQUFhLFNBQVMsVUFBVTtDQUN2Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTRCQSxpQkFBaUIsU0FBUztFQUN4QixLQUFLLGNBQWM7RUFDbkIsS0FBSyxhQUFhO0VBQ2xCLGFBQWEsYUFBYTtFQUMxQixLQUFLLFdBQVc7Q0FDbEI7O0NBRUEsYUFBYTtFQUNYLElBQUksS0FBSyxnQkFBZ0IsQ0FBQyxLQUFLLFlBQzdCO0VBRUYsYUFBYSxrQkFBa0I7RUFDL0IsTUFBTSxRQUFRLEtBQUssV0FBVztFQUM5QixJQUFJLE9BQU87R0FDVCxJQUFJLFdBQVcsVUFBVSxrQkFBa0I7SUFDekMsTUFBTSxtQkFBbUI7SUFDekIsTUFBTSxnQkFBZ0I7R0FDeEIsT0FBTyxJQUFJLEtBQUssdUJBQ2QsTUFBTSxjQUFjO0VBRXhCO0VBQ0EsSUFBSSxLQUFLLHVCQUF1QjtHQUM5QixXQUFXLFNBQVMsaUJBQWlCLGVBQWUsS0FBSyxnQkFBZ0IsSUFBSTtHQUM3RSxLQUFLLFdBQVcsaUJBQWlCLGVBQWUsS0FBSyxnQkFBZ0IsSUFBSTtHQUN6RSxLQUFLLFdBQVcsaUJBQWlCLGdCQUFnQixLQUFLLG1CQUFtQixJQUFJO0dBQzdFLEtBQUssV0FBVyxpQkFBaUIsZUFBZSxLQUFLLG1CQUFtQixJQUFJO0dBQzVFLFdBQVcsaUJBQWlCLGFBQWEsS0FBSyxjQUFjLElBQUk7RUFDbEUsT0FBTztHQUNMLFdBQVcsU0FBUyxpQkFBaUIsYUFBYSxLQUFLLGdCQUFnQixJQUFJO0dBQzNFLEtBQUssV0FBVyxpQkFBaUIsYUFBYSxLQUFLLGdCQUFnQixJQUFJO0dBQ3ZFLEtBQUssV0FBVyxpQkFBaUIsWUFBWSxLQUFLLG1CQUFtQixJQUFJO0dBQ3pFLEtBQUssV0FBVyxpQkFBaUIsYUFBYSxLQUFLLG1CQUFtQixJQUFJO0dBQzFFLFdBQVcsaUJBQWlCLFdBQVcsS0FBSyxjQUFjLElBQUk7R0FDOUQsSUFBSSxLQUFLLHFCQUFxQjtJQUM1QixLQUFLLFdBQVcsaUJBQWlCLGNBQWMsS0FBSyxnQkFBZ0IsSUFBSTtJQUN4RSxLQUFLLFdBQVcsaUJBQWlCLFlBQVksS0FBSyxjQUFjLElBQUk7SUFDcEUsS0FBSyxXQUFXLGlCQUFpQixhQUFhLEtBQUssZ0JBQWdCLElBQUk7R0FDekU7RUFDRjtFQUNBLEtBQUssV0FBVyxpQkFBaUIsU0FBUyxLQUFLLFNBQVM7R0FDdEQsU0FBUztHQUNULFNBQVM7RUFDWCxDQUFDO0VBQ0QsS0FBSyxXQUFXLGlCQUFpQixlQUFlLEtBQUssZ0JBQWdCLElBQUk7RUFDekUsS0FBSyxlQUFlO0NBQ3RCOztDQUVBLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxLQUFLLGdCQUFnQixDQUFDLEtBQUssWUFDOUI7RUFFRixhQUFhLHFCQUFxQjtFQUNsQyxNQUFNLFFBQVEsS0FBSyxXQUFXO0VBQzlCLElBQUksT0FBTztHQUNULElBQUksV0FBVyxVQUFVLGtCQUFrQjtJQUN6QyxNQUFNLG1CQUFtQjtJQUN6QixNQUFNLGdCQUFnQjtHQUN4QixPQUFPLElBQUksS0FBSyx1QkFDZCxNQUFNLGNBQWM7RUFFeEI7RUFDQSxJQUFJLEtBQUssdUJBQXVCO0dBQzlCLFdBQVcsU0FBUyxvQkFBb0IsZUFBZSxLQUFLLGdCQUFnQixJQUFJO0dBQ2hGLEtBQUssV0FBVyxvQkFBb0IsZUFBZSxLQUFLLGdCQUFnQixJQUFJO0dBQzVFLEtBQUssV0FBVyxvQkFBb0IsZ0JBQWdCLEtBQUssbUJBQW1CLElBQUk7R0FDaEYsS0FBSyxXQUFXLG9CQUFvQixlQUFlLEtBQUssbUJBQW1CLElBQUk7R0FDL0UsV0FBVyxvQkFBb0IsYUFBYSxLQUFLLGNBQWMsSUFBSTtFQUNyRSxPQUFPO0dBQ0wsV0FBVyxTQUFTLG9CQUFvQixhQUFhLEtBQUssZ0JBQWdCLElBQUk7R0FDOUUsS0FBSyxXQUFXLG9CQUFvQixhQUFhLEtBQUssZ0JBQWdCLElBQUk7R0FDMUUsS0FBSyxXQUFXLG9CQUFvQixZQUFZLEtBQUssbUJBQW1CLElBQUk7R0FDNUUsS0FBSyxXQUFXLG9CQUFvQixhQUFhLEtBQUssbUJBQW1CLElBQUk7R0FDN0UsV0FBVyxvQkFBb0IsV0FBVyxLQUFLLGNBQWMsSUFBSTtHQUNqRSxJQUFJLEtBQUsscUJBQXFCO0lBQzVCLEtBQUssV0FBVyxvQkFBb0IsY0FBYyxLQUFLLGdCQUFnQixJQUFJO0lBQzNFLEtBQUssV0FBVyxvQkFBb0IsWUFBWSxLQUFLLGNBQWMsSUFBSTtJQUN2RSxLQUFLLFdBQVcsb0JBQW9CLGFBQWEsS0FBSyxnQkFBZ0IsSUFBSTtHQUM1RTtFQUNGO0VBQ0EsS0FBSyxXQUFXLG9CQUFvQixTQUFTLEtBQUssU0FBUyxJQUFJO0VBQy9ELEtBQUssV0FBVyxvQkFBb0IsZUFBZSxLQUFLLGdCQUFnQixJQUFJO0VBQzVFLEtBQUssYUFBYTtFQUNsQixLQUFLLGVBQWU7Q0FDdEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBZ0NBLG1CQUFtQixPQUFPLEdBQUcsR0FBRztFQUM5QixNQUFNLE9BQU8sS0FBSyxXQUFXLGNBQWMsS0FBSyxXQUFXLHNCQUFzQixJQUFJO0dBQ25GLEdBQUc7R0FDSCxHQUFHO0dBQ0gsT0FBTyxLQUFLLFdBQVc7R0FDdkIsUUFBUSxLQUFLLFdBQVc7R0FDeEIsTUFBTTtHQUNOLEtBQUs7RUFDUDtFQUNBLE1BQU0sdUJBQXVCLElBQUksS0FBSztFQUN0QyxNQUFNLEtBQUssSUFBSSxLQUFLLFNBQVMsS0FBSyxXQUFXLFFBQVEsS0FBSyxTQUFTO0VBQ25FLE1BQU0sS0FBSyxJQUFJLEtBQUssUUFBUSxLQUFLLFdBQVcsU0FBUyxLQUFLLFVBQVU7Q0FDdEU7Ozs7Ozs7Q0FPQSx3QkFBd0IsT0FBTztFQUM3QixNQUFNLG1CQUFtQixDQUFDO0VBQzFCLElBQUksS0FBSyx1QkFBdUIsaUJBQWlCLFlBQy9DLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxNQUFNLGVBQWUsUUFBUSxJQUFJLElBQUksS0FBSztHQUM3RCxNQUFNLFFBQVEsTUFBTSxlQUFlO0dBQ25DLElBQUksT0FBTyxNQUFNLFdBQVcsYUFBYSxNQUFNLFNBQVM7R0FDeEQsSUFBSSxPQUFPLE1BQU0sWUFBWSxhQUFhLE1BQU0sVUFBVTtHQUMxRCxJQUFJLE9BQU8sTUFBTSxjQUFjLGFBQzdCLE1BQU0sWUFBWSxNQUFNLFFBQVEsV0FBVyxLQUFLLE1BQU0sU0FBUztHQUVqRSxJQUFJLE9BQU8sTUFBTSxVQUFVLGFBQWEsTUFBTSxRQUFRLE1BQU0sV0FBVztHQUN2RSxJQUFJLE9BQU8sTUFBTSxXQUFXLGFBQWEsTUFBTSxTQUFTLE1BQU0sV0FBVztHQUN6RSxJQUFJLE9BQU8sTUFBTSxVQUFVLGFBQWEsTUFBTSxRQUFRO0dBQ3RELElBQUksT0FBTyxNQUFNLFVBQVUsYUFBYSxNQUFNLFFBQVE7R0FDdEQsSUFBSSxPQUFPLE1BQU0sZ0JBQWdCLGFBQWEsTUFBTSxjQUFjO0dBQ2xFLElBQUksT0FBTyxNQUFNLGNBQWMsYUFBYSxNQUFNLFlBQVksTUFBTSxjQUFjO0dBQ2xGLElBQUksT0FBTyxNQUFNLGFBQWEsYUFBYSxNQUFNLFdBQVcsTUFBTSxTQUFTO0dBQzNFLElBQUksT0FBTyxNQUFNLFVBQVUsYUFBYSxNQUFNLFFBQVE7R0FDdEQsSUFBSSxPQUFPLE1BQU0sdUJBQXVCLGFBQWEsTUFBTSxxQkFBcUI7R0FDaEYsSUFBSSxPQUFPLE1BQU0sV0FBVyxhQUFhLE1BQU0sU0FBUyxNQUFNLFVBQVUsTUFBTTtHQUM5RSxJQUFJLE9BQU8sTUFBTSxXQUFXLGFBQWEsTUFBTSxTQUFTLE1BQU0sVUFBVSxNQUFNO0dBQzlFLE1BQU0sZUFBZTtHQUNyQixNQUFNLE9BQU8sTUFBTTtHQUNuQixNQUFNLFdBQVcsTUFBTSxTQUFTLE1BQU07R0FDdEMsTUFBTSxZQUFZLE1BQU0sVUFBVSxNQUFNO0dBQ3hDLE1BQU0sWUFBWSxNQUFNLFVBQVUsTUFBTTtHQUN4QyxNQUFNLGFBQWEsTUFBTSxXQUFXLE1BQU07R0FDMUMsaUJBQWlCLEtBQUssS0FBSztFQUM3QjtPQUNLLElBQUksQ0FBQyxXQUFXLGNBQWMsaUJBQWlCLGVBQWUsQ0FBQyxLQUFLLHlCQUF5QixFQUFFLGlCQUFpQixXQUFXLGdCQUFnQjtHQUNoSixNQUFNLFlBQVk7R0FDbEIsSUFBSSxPQUFPLFVBQVUsY0FBYyxhQUFhLFVBQVUsWUFBWTtHQUN0RSxJQUFJLE9BQU8sVUFBVSxVQUFVLGFBQWEsVUFBVSxRQUFRO0dBQzlELElBQUksT0FBTyxVQUFVLFdBQVcsYUFBYSxVQUFVLFNBQVM7R0FDaEUsSUFBSSxPQUFPLFVBQVUsVUFBVSxhQUFhLFVBQVUsUUFBUTtHQUM5RCxJQUFJLE9BQU8sVUFBVSxVQUFVLGFBQWEsVUFBVSxRQUFRO0dBQzlELElBQUksT0FBTyxVQUFVLGdCQUFnQixhQUFhLFVBQVUsY0FBYztHQUMxRSxJQUFJLE9BQU8sVUFBVSxjQUFjLGFBQWEsVUFBVSxZQUFZO0dBQ3RFLElBQUksT0FBTyxVQUFVLGFBQWEsYUFBYSxVQUFVLFdBQVc7R0FDcEUsSUFBSSxPQUFPLFVBQVUsVUFBVSxhQUFhLFVBQVUsUUFBUTtHQUM5RCxJQUFJLE9BQU8sVUFBVSx1QkFBdUIsYUFBYSxVQUFVLHFCQUFxQjtHQUN4RixVQUFVLGVBQWU7R0FDekIsaUJBQWlCLEtBQUssU0FBUztFQUNqQyxPQUNFLGlCQUFpQixLQUFLLEtBQUs7RUFFN0IsT0FBTztDQUNUOzs7Ozs7Ozs7Q0FTQSxvQkFBb0IsYUFBYTtFQUMvQixNQUFNLFFBQVEsS0FBSztFQUNuQixLQUFLLG1CQUFtQixPQUFPLFdBQVc7RUFDMUMsTUFBTSxTQUFTLFlBQVk7RUFDM0IsTUFBTSxTQUFTLFlBQVk7RUFDM0IsTUFBTSxTQUFTLFlBQVk7RUFDM0IsTUFBTSxZQUFZLFlBQVk7RUFDOUIsS0FBSyxtQkFBbUIsTUFBTSxRQUFRLFlBQVksU0FBUyxZQUFZLE9BQU87RUFDOUUsTUFBTSxPQUFPLFNBQVMsTUFBTSxNQUFNO0VBQ2xDLE1BQU0sT0FBTyxTQUFTLE1BQU0sTUFBTTtFQUNsQyxNQUFNLGNBQWM7RUFDcEIsTUFBTSxPQUFPLFlBQVk7RUFDekIsT0FBTztDQUNUOzs7Ozs7Q0FNQSxnQkFBZ0IsT0FBTyxhQUFhO0VBQ2xDLE1BQU0sZ0JBQWdCO0VBQ3RCLE1BQU0sY0FBYztFQUNwQixNQUFNLFlBQVksWUFBWTtFQUM5QixNQUFNLFFBQVEsWUFBWTtFQUMxQixNQUFNLFNBQVMsWUFBWTtFQUMzQixNQUFNLFlBQVksWUFBWTtFQUM5QixNQUFNLGNBQWMsWUFBWTtFQUNoQyxNQUFNLFdBQVcsWUFBWTtFQUM3QixNQUFNLHFCQUFxQixZQUFZO0VBQ3ZDLE1BQU0sUUFBUSxZQUFZO0VBQzFCLE1BQU0sUUFBUSxZQUFZO0VBQzFCLE1BQU0sUUFBUSxZQUFZO0VBQzFCLEtBQUssbUJBQW1CLE9BQU8sV0FBVztFQUMxQyxLQUFLLG1CQUFtQixNQUFNLFFBQVEsWUFBWSxTQUFTLFlBQVksT0FBTztFQUM5RSxNQUFNLE9BQU8sU0FBUyxNQUFNLE1BQU07RUFDbEMsTUFBTSxPQUFPLFNBQVMsTUFBTSxNQUFNO0VBQ2xDLE1BQU0sWUFBWSxZQUFZO0VBQzlCLElBQUksTUFBTSxTQUFTLGdCQUNqQixNQUFNLE9BQU87RUFFZixJQUFJLE1BQU0sS0FBSyxXQUFXLE9BQU8sR0FDL0IsTUFBTSxPQUFPLE1BQU0sS0FBSyxRQUFRLFNBQVMsU0FBUztFQUVwRCxJQUFJLE1BQU0sS0FBSyxXQUFXLE9BQU8sR0FDL0IsTUFBTSxPQUFPLGlCQUFpQixNQUFNLFNBQVMsTUFBTTtFQUVyRCxPQUFPO0NBQ1Q7Ozs7OztDQU1BLG1CQUFtQixPQUFPLGFBQWE7RUFDckMsTUFBTSxZQUFZLFlBQVk7RUFDOUIsTUFBTSxhQUFhLFlBQVk7RUFDL0IsTUFBTSxZQUFZLFlBQVksSUFBSTtFQUNsQyxNQUFNLE9BQU8sWUFBWTtFQUN6QixNQUFNLFNBQVMsWUFBWTtFQUMzQixNQUFNLFNBQVMsWUFBWTtFQUMzQixNQUFNLFVBQVUsWUFBWTtFQUM1QixNQUFNLE9BQU8sSUFBSSxZQUFZO0VBQzdCLE1BQU0sT0FBTyxJQUFJLFlBQVk7RUFDN0IsTUFBTSxVQUFVLFlBQVk7RUFDNUIsTUFBTSxVQUFVLFlBQVk7RUFDNUIsTUFBTSxTQUFTLElBQUksWUFBWTtFQUMvQixNQUFNLFNBQVMsSUFBSSxZQUFZO0VBQy9CLE1BQU0sS0FBSyxJQUFJLFlBQVk7RUFDM0IsTUFBTSxLQUFLLElBQUksWUFBWTtFQUMzQixNQUFNLGdCQUFnQjtFQUN0QixNQUFNLFdBQVcsWUFBWTtDQUMvQjtBQUNGOztBQUVBLGFBQWEsWUFBWTtDQUN2QixNQUFNO0NBQ04sTUFBTTtFQUNKLGNBQWM7RUFDZCxjQUFjO0VBQ2QsY0FBYztDQUNoQjtDQUNBLFVBQVU7QUFDWjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFvQkEsYUFBYSx1QkFBdUI7O0NBRWxDLE1BQU07O0NBRU4sWUFBWTs7Q0FFWixPQUFPOztDQUVQLE9BQU87QUFDVDtBQUNBLElBQUksY0FBYzs7O0FDem1CbEIsSUFBTSxxQkFBcUI7Q0FDekIsU0FBUztDQUNULGVBQWU7Q0FDZixhQUFhO0NBQ2IsY0FBYztDQUNkLGNBQWM7Q0FDZCxhQUFhO0NBQ2IsbUJBQW1CO0NBQ25CLFlBQVk7Q0FDWixhQUFhO0NBQ2IsV0FBVztDQUNYLGtCQUFrQjtDQUNsQixpQkFBaUI7Q0FDakIsZUFBZTtDQUNmLGdCQUFnQjtDQUNoQixnQkFBZ0I7Q0FDaEIsZUFBZTtDQUNmLHFCQUFxQjtDQUNyQixjQUFjO0NBQ2QsZUFBZTtDQUNmLGNBQWM7Q0FDZCxhQUFhO0NBQ2Isb0JBQW9CO0NBQ3BCLGNBQWM7Q0FDZCxhQUFhO0NBQ2IsV0FBVztDQUNYLGtCQUFrQjtDQUNsQixPQUFPO0NBQ1AsZUFBZTtDQUNmLFlBQVk7Q0FDWixtQkFBbUI7Q0FDbkIsYUFBYTtDQUNiLG1CQUFtQjtDQUNuQixjQUFjO0NBQ2QsU0FBUztDQUNULElBQUksY0FBYztFQUNoQixPQUFPLEtBQUssY0FBYyxhQUFhLEtBQUssY0FBYztDQUM1RDtDQUNBLElBQUksWUFBWSxPQUFPO0VBQ3JCLEtBQUssWUFBWSxRQUFRLFdBQVc7Q0FDdEM7Q0FDQSxvQkFBb0IsS0FBSztDQUN6QixJQUFJLFlBQVk7RUFDZCxPQUFPLEtBQUssc0JBQXNCLFlBQVk7Q0FDaEQ7Q0FDQSxJQUFJLFVBQVUsT0FBTztFQUNuQixLQUFLLHFCQUFxQjtDQUM1QjtDQUNBLGdCQUFnQjtFQUNkLE9BQU8sS0FBSyxjQUFjLFlBQVksS0FBSyxjQUFjO0NBQzNEO0NBQ0EscUJBQXFCO0NBQ3JCLFNBQVM7Q0FDVCxpQkFBaUIsTUFBTSxVQUFVLFNBQVM7RUFDeEMsTUFBTSxVQUFVLE9BQU8sWUFBWSxhQUFhLFdBQVcsT0FBTyxZQUFZLFlBQVksUUFBUTtFQUNsRyxNQUFNLFNBQVMsT0FBTyxZQUFZLFdBQVcsUUFBUSxTQUFTLEtBQUs7RUFDbkUsTUFBTSxPQUFPLE9BQU8sWUFBWSxXQUFXLFFBQVEsU0FBUyxPQUFPO0VBQ25FLE1BQU0sVUFBVSxPQUFPLGFBQWEsYUFBYSxLQUFLLElBQUk7RUFDMUQsT0FBTyxVQUFVLEdBQUcsS0FBSyxXQUFXO0VBQ3BDLE1BQU0sYUFBYSxPQUFPLGFBQWEsYUFBYSxXQUFXLFNBQVM7RUFDeEUsTUFBTSxVQUFVO0VBQ2hCLElBQUksUUFDRixPQUFPLGlCQUFpQixlQUFlO0dBQ3JDLFFBQVEsSUFBSSxNQUFNLFlBQVksT0FBTztFQUN2QyxDQUFDO0VBRUgsSUFBSSxNQUNGLFFBQVEsS0FBSyxNQUFNLFlBQVksT0FBTztPQUV0QyxRQUFRLEdBQUcsTUFBTSxZQUFZLE9BQU87Q0FFeEM7Q0FDQSxvQkFBb0IsTUFBTSxVQUFVLFNBQVM7RUFDM0MsTUFBTSxVQUFVLE9BQU8sWUFBWSxhQUFhLFdBQVcsT0FBTyxZQUFZLFlBQVksUUFBUTtFQUNsRyxNQUFNLFVBQVUsT0FBTyxhQUFhLGFBQWEsS0FBSyxJQUFJO0VBQzFELE9BQU8sVUFBVSxHQUFHLEtBQUssV0FBVztFQUNwQyxXQUFXLE9BQU8sYUFBYSxhQUFhLFdBQVcsU0FBUztFQUNoRSxLQUFLLElBQUksTUFBTSxVQUFVLE9BQU87Q0FDbEM7Q0FDQSxjQUFjLEdBQUc7RUFDZixJQUFJLEVBQUUsYUFBYSxpQkFDakIsTUFBTSxJQUFJLE1BQU0sdUVBQXVFO0VBRXpGLEVBQUUsbUJBQW1CO0VBQ3JCLEVBQUUsT0FBTztFQUNULEVBQUUsU0FBUztFQUNYLEVBQUUsUUFBUSxjQUFjLENBQUM7RUFDekIsT0FBTyxDQUFDLEVBQUU7Q0FDWjtBQUNGIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTNdfQ==
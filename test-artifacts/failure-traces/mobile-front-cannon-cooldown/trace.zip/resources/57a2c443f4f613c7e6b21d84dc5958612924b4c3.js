import { H as warn } from "/node_modules/.vite/deps/CanvasPool-BcIVNj8Y.js?v=7ab6e4ce";
//#region node_modules/pixi.js/lib/assets/utils/convertToList.mjs
var convertToList = (input, transform, forceTransform = false) => {
	if (!Array.isArray(input)) input = [input];
	if (!transform) return input;
	return input.map((item) => {
		if (typeof item === "string" || forceTransform) return transform(item);
		return item;
	});
};
//#endregion
//#region node_modules/pixi.js/lib/assets/cache/Cache.mjs
var CacheClass = class {
	constructor() {
		this._parsers = [];
		this._cache = /* @__PURE__ */ new Map();
		this._cacheMap = /* @__PURE__ */ new Map();
	}
	/** Clear all entries. */
	reset() {
		this._cacheMap.clear();
		this._cache.clear();
	}
	/**
	* Check if the key exists
	* @param key - The key to check
	*/
	has(key) {
		return this._cache.has(key);
	}
	/**
	* Fetch entry by key
	* @param key - The key of the entry to get
	*/
	get(key) {
		const result = this._cache.get(key);
		if (!result) warn(`[Assets] Asset id ${key} was not found in the Cache`);
		return result;
	}
	/**
	* Set a value by key or keys name
	* @param key - The key or keys to set
	* @param value - The value to store in the cache or from which cacheable assets will be derived.
	*/
	set(key, value) {
		const keys = convertToList(key);
		let cacheableAssets;
		for (let i = 0; i < this.parsers.length; i++) {
			const parser = this.parsers[i];
			if (parser.test(value)) {
				cacheableAssets = parser.getCacheableAssets(keys, value);
				break;
			}
		}
		const cacheableMap = new Map(Object.entries(cacheableAssets || {}));
		if (!cacheableAssets) keys.forEach((key2) => {
			cacheableMap.set(key2, value);
		});
		const cacheKeys = [...cacheableMap.keys()];
		const cachedAssets = {
			cacheKeys,
			keys
		};
		keys.forEach((key2) => {
			this._cacheMap.set(key2, cachedAssets);
		});
		cacheKeys.forEach((key2) => {
			const val = cacheableAssets ? cacheableAssets[key2] : value;
			if (this._cache.has(key2) && this._cache.get(key2) !== val) warn("[Cache] already has key:", key2);
			this._cache.set(key2, cacheableMap.get(key2));
		});
	}
	/**
	* Remove entry by key
	*
	* This function will also remove any associated alias from the cache also.
	* @param key - The key of the entry to remove
	*/
	remove(key) {
		if (!this._cacheMap.has(key)) {
			warn(`[Assets] Asset id ${key} was not found in the Cache`);
			return;
		}
		const cacheMap = this._cacheMap.get(key);
		cacheMap.cacheKeys.forEach((key2) => {
			this._cache.delete(key2);
		});
		cacheMap.keys.forEach((key2) => {
			this._cacheMap.delete(key2);
		});
	}
	/**
	* All loader parsers registered
	* @advanced
	*/
	get parsers() {
		return this._parsers;
	}
};
var Cache = new CacheClass();
//#endregion
export { convertToList as n, Cache as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ2FjaGUtSkVHRnJEUkYuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vcGl4aS5qcy9saWIvYXNzZXRzL3V0aWxzL2NvbnZlcnRUb0xpc3QubWpzIiwiLi4vLi4vcGl4aS5qcy9saWIvYXNzZXRzL2NhY2hlL0NhY2hlLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbmNvbnN0IGNvbnZlcnRUb0xpc3QgPSAoaW5wdXQsIHRyYW5zZm9ybSwgZm9yY2VUcmFuc2Zvcm0gPSBmYWxzZSkgPT4ge1xuICBpZiAoIUFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG4gICAgaW5wdXQgPSBbaW5wdXRdO1xuICB9XG4gIGlmICghdHJhbnNmb3JtKSB7XG4gICAgcmV0dXJuIGlucHV0O1xuICB9XG4gIHJldHVybiBpbnB1dC5tYXAoKGl0ZW0pID0+IHtcbiAgICBpZiAodHlwZW9mIGl0ZW0gPT09IFwic3RyaW5nXCIgfHwgZm9yY2VUcmFuc2Zvcm0pIHtcbiAgICAgIHJldHVybiB0cmFuc2Zvcm0oaXRlbSk7XG4gICAgfVxuICAgIHJldHVybiBpdGVtO1xuICB9KTtcbn07XG5cbmV4cG9ydCB7IGNvbnZlcnRUb0xpc3QgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbnZlcnRUb0xpc3QubWpzLm1hcFxuIiwiaW1wb3J0IHsgd2FybiB9IGZyb20gJy4uLy4uL3V0aWxzL2xvZ2dpbmcvd2Fybi5tanMnO1xuaW1wb3J0IHsgY29udmVydFRvTGlzdCB9IGZyb20gJy4uL3V0aWxzL2NvbnZlcnRUb0xpc3QubWpzJztcblxuXCJ1c2Ugc3RyaWN0XCI7XG5jbGFzcyBDYWNoZUNsYXNzIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5fcGFyc2VycyA9IFtdO1xuICAgIHRoaXMuX2NhY2hlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICB0aGlzLl9jYWNoZU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIH1cbiAgLyoqIENsZWFyIGFsbCBlbnRyaWVzLiAqL1xuICByZXNldCgpIHtcbiAgICB0aGlzLl9jYWNoZU1hcC5jbGVhcigpO1xuICAgIHRoaXMuX2NhY2hlLmNsZWFyKCk7XG4gIH1cbiAgLyoqXG4gICAqIENoZWNrIGlmIHRoZSBrZXkgZXhpc3RzXG4gICAqIEBwYXJhbSBrZXkgLSBUaGUga2V5IHRvIGNoZWNrXG4gICAqL1xuICBoYXMoa2V5KSB7XG4gICAgcmV0dXJuIHRoaXMuX2NhY2hlLmhhcyhrZXkpO1xuICB9XG4gIC8qKlxuICAgKiBGZXRjaCBlbnRyeSBieSBrZXlcbiAgICogQHBhcmFtIGtleSAtIFRoZSBrZXkgb2YgdGhlIGVudHJ5IHRvIGdldFxuICAgKi9cbiAgZ2V0KGtleSkge1xuICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMuX2NhY2hlLmdldChrZXkpO1xuICAgIGlmICghcmVzdWx0KSB7XG4gICAgICB3YXJuKGBbQXNzZXRzXSBBc3NldCBpZCAke2tleX0gd2FzIG5vdCBmb3VuZCBpbiB0aGUgQ2FjaGVgKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICAvKipcbiAgICogU2V0IGEgdmFsdWUgYnkga2V5IG9yIGtleXMgbmFtZVxuICAgKiBAcGFyYW0ga2V5IC0gVGhlIGtleSBvciBrZXlzIHRvIHNldFxuICAgKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gc3RvcmUgaW4gdGhlIGNhY2hlIG9yIGZyb20gd2hpY2ggY2FjaGVhYmxlIGFzc2V0cyB3aWxsIGJlIGRlcml2ZWQuXG4gICAqL1xuICBzZXQoa2V5LCB2YWx1ZSkge1xuICAgIGNvbnN0IGtleXMgPSBjb252ZXJ0VG9MaXN0KGtleSk7XG4gICAgbGV0IGNhY2hlYWJsZUFzc2V0cztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMucGFyc2Vycy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgcGFyc2VyID0gdGhpcy5wYXJzZXJzW2ldO1xuICAgICAgaWYgKHBhcnNlci50ZXN0KHZhbHVlKSkge1xuICAgICAgICBjYWNoZWFibGVBc3NldHMgPSBwYXJzZXIuZ2V0Q2FjaGVhYmxlQXNzZXRzKGtleXMsIHZhbHVlKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGNhY2hlYWJsZU1hcCA9IG5ldyBNYXAoT2JqZWN0LmVudHJpZXMoY2FjaGVhYmxlQXNzZXRzIHx8IHt9KSk7XG4gICAgaWYgKCFjYWNoZWFibGVBc3NldHMpIHtcbiAgICAgIGtleXMuZm9yRWFjaCgoa2V5MikgPT4ge1xuICAgICAgICBjYWNoZWFibGVNYXAuc2V0KGtleTIsIHZhbHVlKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBjYWNoZUtleXMgPSBbLi4uY2FjaGVhYmxlTWFwLmtleXMoKV07XG4gICAgY29uc3QgY2FjaGVkQXNzZXRzID0ge1xuICAgICAgY2FjaGVLZXlzLFxuICAgICAga2V5c1xuICAgIH07XG4gICAga2V5cy5mb3JFYWNoKChrZXkyKSA9PiB7XG4gICAgICB0aGlzLl9jYWNoZU1hcC5zZXQoa2V5MiwgY2FjaGVkQXNzZXRzKTtcbiAgICB9KTtcbiAgICBjYWNoZUtleXMuZm9yRWFjaCgoa2V5MikgPT4ge1xuICAgICAgY29uc3QgdmFsID0gY2FjaGVhYmxlQXNzZXRzID8gY2FjaGVhYmxlQXNzZXRzW2tleTJdIDogdmFsdWU7XG4gICAgICBpZiAodGhpcy5fY2FjaGUuaGFzKGtleTIpICYmIHRoaXMuX2NhY2hlLmdldChrZXkyKSAhPT0gdmFsKSB7XG4gICAgICAgIHdhcm4oXCJbQ2FjaGVdIGFscmVhZHkgaGFzIGtleTpcIiwga2V5Mik7XG4gICAgICB9XG4gICAgICB0aGlzLl9jYWNoZS5zZXQoa2V5MiwgY2FjaGVhYmxlTWFwLmdldChrZXkyKSk7XG4gICAgfSk7XG4gIH1cbiAgLyoqXG4gICAqIFJlbW92ZSBlbnRyeSBieSBrZXlcbiAgICpcbiAgICogVGhpcyBmdW5jdGlvbiB3aWxsIGFsc28gcmVtb3ZlIGFueSBhc3NvY2lhdGVkIGFsaWFzIGZyb20gdGhlIGNhY2hlIGFsc28uXG4gICAqIEBwYXJhbSBrZXkgLSBUaGUga2V5IG9mIHRoZSBlbnRyeSB0byByZW1vdmVcbiAgICovXG4gIHJlbW92ZShrZXkpIHtcbiAgICBpZiAoIXRoaXMuX2NhY2hlTWFwLmhhcyhrZXkpKSB7XG4gICAgICB3YXJuKGBbQXNzZXRzXSBBc3NldCBpZCAke2tleX0gd2FzIG5vdCBmb3VuZCBpbiB0aGUgQ2FjaGVgKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgY2FjaGVNYXAgPSB0aGlzLl9jYWNoZU1hcC5nZXQoa2V5KTtcbiAgICBjb25zdCBjYWNoZUtleXMgPSBjYWNoZU1hcC5jYWNoZUtleXM7XG4gICAgY2FjaGVLZXlzLmZvckVhY2goKGtleTIpID0+IHtcbiAgICAgIHRoaXMuX2NhY2hlLmRlbGV0ZShrZXkyKTtcbiAgICB9KTtcbiAgICBjYWNoZU1hcC5rZXlzLmZvckVhY2goKGtleTIpID0+IHtcbiAgICAgIHRoaXMuX2NhY2hlTWFwLmRlbGV0ZShrZXkyKTtcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogQWxsIGxvYWRlciBwYXJzZXJzIHJlZ2lzdGVyZWRcbiAgICogQGFkdmFuY2VkXG4gICAqL1xuICBnZXQgcGFyc2VycygpIHtcbiAgICByZXR1cm4gdGhpcy5fcGFyc2VycztcbiAgfVxufVxuY29uc3QgQ2FjaGUgPSBuZXcgQ2FjaGVDbGFzcygpO1xuXG5leHBvcnQgeyBDYWNoZSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Q2FjaGUubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOztBQUNBLElBQU0saUJBQWlCLE9BQU8sV0FBVyxpQkFBaUIsVUFBVTtDQUNsRSxJQUFJLENBQUMsTUFBTSxRQUFRLEtBQUssR0FDdEIsUUFBUSxDQUFDLEtBQUs7Q0FFaEIsSUFBSSxDQUFDLFdBQ0gsT0FBTztDQUVULE9BQU8sTUFBTSxLQUFLLFNBQVM7RUFDekIsSUFBSSxPQUFPLFNBQVMsWUFBWSxnQkFDOUIsT0FBTyxVQUFVLElBQUk7RUFFdkIsT0FBTztDQUNULENBQUM7QUFDSDs7O0FDVkEsSUFBTSxhQUFOLE1BQWlCO0NBQ2YsY0FBYztFQUNaLEtBQUssV0FBVyxDQUFDO0VBQ2pCLEtBQUsseUJBQXlCLElBQUksSUFBSTtFQUN0QyxLQUFLLDRCQUE0QixJQUFJLElBQUk7Q0FDM0M7O0NBRUEsUUFBUTtFQUNOLEtBQUssVUFBVSxNQUFNO0VBQ3JCLEtBQUssT0FBTyxNQUFNO0NBQ3BCOzs7OztDQUtBLElBQUksS0FBSztFQUNQLE9BQU8sS0FBSyxPQUFPLElBQUksR0FBRztDQUM1Qjs7Ozs7Q0FLQSxJQUFJLEtBQUs7RUFDUCxNQUFNLFNBQVMsS0FBSyxPQUFPLElBQUksR0FBRztFQUNsQyxJQUFJLENBQUMsUUFDSCxLQUFLLHFCQUFxQixJQUFJLDRCQUE0QjtFQUU1RCxPQUFPO0NBQ1Q7Ozs7OztDQU1BLElBQUksS0FBSyxPQUFPO0VBQ2QsTUFBTSxPQUFPLGNBQWMsR0FBRztFQUM5QixJQUFJO0VBQ0osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxRQUFRLEtBQUs7R0FDNUMsTUFBTSxTQUFTLEtBQUssUUFBUTtHQUM1QixJQUFJLE9BQU8sS0FBSyxLQUFLLEdBQUc7SUFDdEIsa0JBQWtCLE9BQU8sbUJBQW1CLE1BQU0sS0FBSztJQUN2RDtHQUNGO0VBQ0Y7RUFDQSxNQUFNLGVBQWUsSUFBSSxJQUFJLE9BQU8sUUFBUSxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7RUFDbEUsSUFBSSxDQUFDLGlCQUNILEtBQUssU0FBUyxTQUFTO0dBQ3JCLGFBQWEsSUFBSSxNQUFNLEtBQUs7RUFDOUIsQ0FBQztFQUVILE1BQU0sWUFBWSxDQUFDLEdBQUcsYUFBYSxLQUFLLENBQUM7RUFDekMsTUFBTSxlQUFlO0dBQ25CO0dBQ0E7RUFDRjtFQUNBLEtBQUssU0FBUyxTQUFTO0dBQ3JCLEtBQUssVUFBVSxJQUFJLE1BQU0sWUFBWTtFQUN2QyxDQUFDO0VBQ0QsVUFBVSxTQUFTLFNBQVM7R0FDMUIsTUFBTSxNQUFNLGtCQUFrQixnQkFBZ0IsUUFBUTtHQUN0RCxJQUFJLEtBQUssT0FBTyxJQUFJLElBQUksS0FBSyxLQUFLLE9BQU8sSUFBSSxJQUFJLE1BQU0sS0FDckQsS0FBSyw0QkFBNEIsSUFBSTtHQUV2QyxLQUFLLE9BQU8sSUFBSSxNQUFNLGFBQWEsSUFBSSxJQUFJLENBQUM7RUFDOUMsQ0FBQztDQUNIOzs7Ozs7O0NBT0EsT0FBTyxLQUFLO0VBQ1YsSUFBSSxDQUFDLEtBQUssVUFBVSxJQUFJLEdBQUcsR0FBRztHQUM1QixLQUFLLHFCQUFxQixJQUFJLDRCQUE0QjtHQUMxRDtFQUNGO0VBQ0EsTUFBTSxXQUFXLEtBQUssVUFBVSxJQUFJLEdBQUc7RUFFdkMsU0FEMkIsVUFDakIsU0FBUyxTQUFTO0dBQzFCLEtBQUssT0FBTyxPQUFPLElBQUk7RUFDekIsQ0FBQztFQUNELFNBQVMsS0FBSyxTQUFTLFNBQVM7R0FDOUIsS0FBSyxVQUFVLE9BQU8sSUFBSTtFQUM1QixDQUFDO0NBQ0g7Ozs7O0NBS0EsSUFBSSxVQUFVO0VBQ1osT0FBTyxLQUFLO0NBQ2Q7QUFDRjtBQUNBLElBQU0sUUFBUSxJQUFJLFdBQVciLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxXX0=